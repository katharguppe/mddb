
import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

// const firebaseConfig = {
// apiKey: "AIzaSyD8vQafpyyFMhqn1Y-NfvA9VvGDabVgqFA",
// databaseURL: "https://fcplcrmreal-default-rtdb.asia-southeast1.firebasedatabase.app/",
// authDomain: "fcplcrmreal.firebaseapp.com",
// projectId: "fcplcrmreal",
// storageBucket: "fcplcrmreal.appspot.com",
// messagingSenderId: "668012368465",
// appId: "1:668012368465:web:9128f78d4a803b75b95e70"
// };

const firebaseConfig = {
    apiKey: "AIzaSyD4fgBog-4ztHrxJA25s229k3QLLfdro1g",
    authDomain: "trhiveapplication.firebaseapp.com",
    projectId: "trhiveapplication",
    storageBucket: "trhiveapplication.firebasestorage.app",
    messagingSenderId: "82494287429",
    appId: "1:82494287429:web:02c4101ae63f53e5057d2c",
    measurementId: "G-LP8YXFQ966"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

export { database }

