import {MdKeyboardBackspace} from 'react-icons/md'

export const GoBack = ({navigate})=>{
     return (
        <div className='flex items-center' onClick={()=>navigate(-1)}>
            <MdKeyboardBackspace/>
            <h6>Go Back</h6>

        </div>
     )
}