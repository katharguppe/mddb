import React from 'react';
import {IoClose} from 'react-icons/io5';
import {useSelector,useDispatch} from 'react-redux'
import { ErrorAction } from '../../redux/actions/authAction';

export function SuccessNotification() {

  const auth = useSelector(state=>state.Auth)
  const dispatch = useDispatch()

  return (
    auth?.error?.type === 'success' &&  <div className='bg-[#ddf4ff] p-4 flex items-center border border-[#a8d8ff] justify-between'>
        <h6 className='text-[13.5px] font-[400]'>{auth?.error?.message}</h6>
        <IoClose size={18} className="text-[#0a69db] cursor-pointer" onClick={()=>dispatch(ErrorAction({type:'',message:'',visible:false}))} />
    </div>
  )
}

export function ErrorNotification() {
  const auth = useSelector(state=>state.Auth)
  const dispatch = useDispatch()

    return (
      auth?.error?.type === 'error' && <div className='bg-[#ffebe8] p-4 flex items-center border border-[#ffc1c1] justify-between'>
          <h6 className='text-[13.5px] font-[400]'>{auth?.error?.message}</h6>
          <IoClose size={18} className="text-[#cf212e] cursor-pointer" onClick={()=>dispatch(ErrorAction({type:'',message:'',visible:false}))} />
      </div>
    )
}

export function WarningNotification() {
   const auth = useSelector(state=>state.Auth)
   const dispatch = useDispatch()


    return (
      auth?.error?.type === 'warning' && <div className='bg-[#fff5c4] p-4 flex items-center border border-[#fce572] justify-between'>
          <h6 className='text-[13.5px] font-[400]'>{auth?.error?.message}</h6>
          <IoClose size={18} className="text-[#e8d264] cursor-pointer" onClick={()=>dispatch(ErrorAction({type:'',message:'',visible:false}))} />
      </div>
    )
}  
