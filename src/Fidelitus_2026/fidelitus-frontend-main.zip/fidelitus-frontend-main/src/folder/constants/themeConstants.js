export const btnColor = "#158a93"
export const lightThemeColor = "#e6fdff"



export const gray_icon = "#cfcfcf"

export const highlight_color = "#6bd1e8"