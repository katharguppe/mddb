export const LOG_IN = "LOG_IN";
export const LOG_OUT = "LOG_OUT";
export const ERROR = "ERROR";
export const PROFILEPIC = "PROFILEPIC";
