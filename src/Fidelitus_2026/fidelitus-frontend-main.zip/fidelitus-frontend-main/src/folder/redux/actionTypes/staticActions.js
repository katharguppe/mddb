export const NOTES = "NOTES";
export const GALLERY_STATE = "GALLERY_STATE";
export const PAGINATION_STATE = "PAGINATION_STATE";
export const FULL_SCREEN = "FULL_SCREEN";

