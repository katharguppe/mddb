import React from 'react'

function Footer() {


  const menu = [
    {name:'Terms',path:''},
    {name:'Privacy',path:''},
    {name:'Security',path:''},
    {name:'Status',path:''},
    {name:'Docs',path:''},
    {name:'ContactUs',path:''},
    {name:'Training',path:''},
    {name:'Blog',path:''},
    {name:'About',path:''},
    {name:'Vision',path:''},
    {name:'Mission',path:''}
  ]  

  return (
    <div className='border-t mx-2 text-[11px] flex py-12 sm:mx-40 text-center items-center justify-center mt-10'>


        <div className='flex-col  sm:flex-row  text-center items-center justify-center'>
        <span className='text-[11px] text-[#646d76] cursor-pointer'>© 2023 Fidelitus, Inc.</span>
        
        <div className='w-4/5 mx-auto grid grid-cols-6 xs:place-items-center items-center justify-center mt-4  sm:inline-flex w-full sm:mt-0 mx-0 sm:grid-cols-0'>
        {menu?.map((m)=>(
            <span className='px-0 pb-2 text-[11px] text-[#0a69db] sm:px-3 pb-0 cursor-pointer'>{m?.name}</span>
        ))}
        </div>
        </div>  

        <div>

          
        </div>

    </div>
  )
}

export default Footer