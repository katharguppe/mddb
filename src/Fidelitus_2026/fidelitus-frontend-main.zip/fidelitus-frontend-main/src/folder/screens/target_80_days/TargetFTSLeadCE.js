import React, { useState, useEffect } from "react";
import Grid from "@mui/material/Grid";
import { TextInput } from "../../components/input";
import { ButtonFilled, ButtonOutlined } from "../../components/button";
import { useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";

import GoBack from "../../components/back/GoBack";
import TargetFTSLeadMenu from "./TargetFTSLeadMenu";

import {
  createUserTarget,
  updateUserTarget,
  getUserTargetById
} from "../../services/UserTargetService";

import { getMonths } from "../../services/MonthService";

import {
  GetDepartmentService,
  GetUsersByDepartment
} from "../../services/DepartmentServices";

export default function TargetFTSLeadCE() {
  const navigate = useNavigate();
  const { id } = useParams();
  const auth = useSelector((state) => state.Auth);

  const isEditMode = Boolean(id);
  const isAdmin = auth?.roles?.includes("admin");

  const [loader, setLoader] = useState(false);
  const [months, setMonths] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [usersList, setUsersList] = useState([]);

  const [selectedDept, setSelectedDept] = useState("");
  const [selectedUser, setSelectedUser] = useState("");

  const [form, setForm] = useState({
    month_id: "",
    target: "",
    achieved: ""
  });

  // ===============================================
  // ON LOAD
  // ===============================================
  useEffect(() => {
    loadMonths();

    if (isAdmin) loadDepartments();
    if (isEditMode) loadExisting();
  }, [id]);

  // ===============================================
  // LOAD MONTHS
  // ===============================================
  const loadMonths = async () => {
    try {
      const res = await getMonths();
      setMonths(res?.data?.data || []);
    } catch (err) {
      console.log("Error loading months:", err);
    }
  };

  // ===============================================
  // LOAD DEPARTMENTS (Admin Only)
  // ===============================================
  const loadDepartments = async () => {
    try {
      const res = await GetDepartmentService();
      const list = res?.data?.datas || [];

      const options = list.map((d) => ({
        label: d.department_name,
        value: d.id || d._id
      }));

      setDepartments(options);
    } catch (err) {
      console.log("Error loading departments:", err);
    }
  };

  // ===============================================
  // LOAD USERS BASED ON DEPARTMENT
  // ===============================================
  const handleDeptSelect = async (e) => {
    const deptId = e.target.value;
    setSelectedDept(deptId);
    setSelectedUser("");
    setUsersList([]);

    if (!deptId) return;

    try {
      const res = await GetUsersByDepartment(deptId);
      const list = res?.data?.datas || [];

      const userOptions = list.map((u) => ({
        label: u.name,
        value: u._id
      }));

      setUsersList(userOptions);
    } catch (err) {
      console.log("Error loading users:", err);
    }
  };

  const handleUserSelect = (e) => {
    setSelectedUser(e.target.value);
  };

  // ===============================================
  // LOAD EXISTING TARGET (EDIT MODE)
  // ===============================================
  const loadExisting = async () => {
    try {
      const res = await getUserTargetById(id);
      const data = res?.data?.data;
      if (!data) return;

      const monthId =
        typeof data.month_id === "object"
          ? data.month_id._id || data.month_id.id
          : data.month_id;

      setForm({
        month_id: monthId || "",
        target: data.target,
        achieved: data.achieved
      });

      // also fill department and users list
      const deptId = data?.user_id?.department_id?.[0];
      if (deptId) {
        setSelectedDept(deptId);
        const res2 = await GetUsersByDepartment(deptId);
        const list = res2?.data?.datas || [];

        setUsersList(list.map((u) => ({ label: u.name, value: u._id })));
        setSelectedUser(data.user_id?._id);
      }
    } catch (err) {
      console.log("Error loading existing record:", err);
    }
  };

  // ===============================================
  // FORM INPUT
  // ===============================================
  const handlechange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
  };

  // ===============================================
  // SUBMIT TARGET
  // ===============================================
  const submitTarget = async () => {
    if (isAdmin && !selectedUser) {
      alert("Please select a user");
      return;
    }
    if (!form.month_id) {
      alert("Select month");
      return;
    }
    if (form.target === "") {
      alert("Enter target");
      return;
    }

    setLoader(true);

    const payload = {
      user_id: isAdmin ? selectedUser : auth.id,
      month_id: form.month_id,
      target: Number(form.target),
      achieved: form.achieved ? Number(form.achieved) : 0
    };

    try {
      if (isEditMode) {
        await updateUserTarget(id, payload);
      } else {
        await createUserTarget(payload);
      }

      alert("Target saved!");
      navigate("/target_fts_leads/list");
    } catch (err) {
      console.log(err);
      alert("Failed to save target");
    }

    setLoader(false);
  };

  // ===============================================
  // RENDER PAGE
  // ===============================================
  return (
    <div className="box-border h-screen max-h-screen overflow-hidden">
      <div className="block sm:flex">
        <TargetFTSLeadMenu />

        <div className="h-screen max-h-screen min-h-screen pr-5 ml-5 overflow-y-scroll">
          <div className="w-[85%] min-w-[38vw] max-w-[85vw]">
            <GoBack />

            <div className="pb-2 mb-4 border-b">
              <h6 className="font-[800] mb-1">
                {isEditMode ? "Edit BD Target" : "Create BD Target"}
              </h6>
              <h6 className="text-[11px] leading-tight font-[500] p-2 bg-slate-100">
                Select department → user → month → target.
              </h6>
            </div>

            <Grid container spacing={2}>
              {/* Admin can select department */}
              {isAdmin && (
                <>
                  <Grid item xs={12} md={6}>
                    <label className="text-[12px] font-[600] mb-1 block">
                      Department <span className="text-red-500">*</span>
                    </label>
                    <select
                      className="w-full border rounded px-3 py-2 text-[13px]"
                      value={selectedDept}
                      onChange={handleDeptSelect}
                    >
                      <option value="">Select department</option>
                      {departments.map((d) => (
                        <option key={d.value} value={d.value}>
                          {d.label}
                        </option>
                      ))}
                    </select>
                  </Grid>

                  <Grid item xs={12} md={6}>
                    <label className="text-[12px] font-[600] mb-1 block">
                      User <span className="text-red-500">*</span>
                    </label>
                    <select
                      className="w-full border rounded px-3 py-2 text-[13px]"
                      value={selectedUser}
                      onChange={handleUserSelect}
                      disabled={!selectedDept}
                    >
                      <option value="">Select user</option>
                      {usersList.map((u) => (
                        <option key={u.value} value={u.value}>
                          {u.label}
                        </option>
                      ))}
                    </select>
                  </Grid>
                </>
              )}

              <Grid item xs={12} md={6}>
                <label className="text-[12px] font-[600] mb-1 block">
                  Month <span className="text-red-500">*</span>
                </label>
                <select
                  name="month_id"
                  value={form.month_id}
                  onChange={handlechange}
                  className="w-full border rounded px-3 py-2 text-[13px]"
                >
                  <option value="">Select month</option>
                  {months.map((m) => (
                    <option key={m._id} value={m._id}>
                      {m.month_name} {m.year}
                    </option>
                  ))}
                </select>

                <TextInput
                  label="Target"
                  name="target"
                  type="number"
                  value={form.target}
                  handlechange={handlechange}
                  mandatory={true}
                />
              </Grid>

              <Grid item xs={12} md={6}>
                <TextInput
                  label="Achieved"
                  name="achieved"
                  type="number"
                  value={form.achieved}
                  handlechange={handlechange}
                />
              </Grid>
            </Grid>

            {/* FOOTER BUTTONS */}
            <div className="flex items-center pt-5 mt-5 mb-10 border-t">
              <div className="mr-2">
                <ButtonOutlined btnName="Back" onClick={() => navigate(-1)} />
              </div>

              <div>
                <ButtonFilled
                  btnName={loader ? "Saving..." : "Save"}
                  onClick={submitTarget}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

