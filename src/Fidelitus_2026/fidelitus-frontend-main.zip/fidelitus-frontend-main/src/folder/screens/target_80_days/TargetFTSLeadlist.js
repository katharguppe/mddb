import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import Chart from "react-apexcharts";

import TargetFTSLeadMenu from "./TargetFTSLeadMenu";

import {
  getUserTargets,
  deleteUserTarget,
} from "../../services/UserTargetService";

import {
  getMonths,
  createMonth,
  updateMonth,
  deleteMonth,
} from "../../services/MonthService";

import { GetDepartmentService } from "../../services/DepartmentServices";

// ===================================================================
// MAIN COMPONENT
// ===================================================================
export default function TargetFTSLeadList() {
  const navigate = useNavigate();
  const auth = useSelector((state) => state.Auth);

  const isAdmin = auth?.roles?.includes("admin");
  const isHod = auth?.roles?.includes("hod");
  const isMdAdmin = auth?.roles?.includes("md_admin");

  // Treat admin + md_admin as "super admins"
  const isSuperAdmin = isAdmin || isMdAdmin;
  const canUseFilters = isSuperAdmin || isHod; // who can see dept/user filters + list
  const isAdminOrHodOrMd = canUseFilters;

  // HOD department IDs (can be array)
  const hodDeptIds =
    (auth?.department_id || []).map((d) => d?.id || d?._id || d) || [];

  const [loading, setLoading] = useState(true);
  const [targets, setTargets] = useState([]);
  const [months, setMonths] = useState([]);
  const [departments, setDepartments] = useState([]);

  const [search, setSearch] = useState("");
  const [selectedDeptId, setSelectedDeptId] = useState(""); // "" = All (within allowed scope)
  const [selectedUserId, setSelectedUserId] = useState(""); // "" = All Users

  const [viewUser, setViewUser] = useState(null);

  // Month modal
  const [monthModalOpen, setMonthModalOpen] = useState(false);
  const [monthForm, setMonthForm] = useState({
    month_name: "",
    month_number: "",
    year: "",
  });
  const [editMonthId, setEditMonthId] = useState(null);

  // Month filter state
  const [monthFilterMode, setMonthFilterMode] = useState("all"); // "all" | "range" | "next80"
  const [rangeStartMonthId, setRangeStartMonthId] = useState("");
  const [rangeEndMonthId, setRangeEndMonthId] = useState("");

  useEffect(() => {
    loadAllData();
  }, []);

  // ===================================================================
  // LOAD ALL DATA (MONTHS, TARGETS, DEPARTMENTS)
  // ===================================================================
  const loadAllData = async () => {
    setLoading(true);
    try {
      const [m, t, d] = await Promise.all([
        getMonths(),
        getUserTargets(),
        GetDepartmentService(),
      ]);

      setMonths(m?.data?.data || []);

      const rawTargets = t?.data?.data || [];
      const formattedTargets = rawTargets.map((item) => ({
        ...item,
        user_id: {
          ...item.user_id,
          _id: item.user_id?._id || item.user_id?.id,
        },
        month_id: {
          ...item.month_id,
          _id: item.month_id?._id || item.month_id?.id,
        },
      }));
      setTargets(formattedTargets);

      setDepartments(d?.data?.datas || []);
    } catch (err) {
      console.log(err);
    }
    setLoading(false);
  };

  // ===================================================================
  // MONTH NAME
  // ===================================================================
  const getMonthName = (monthId) => {
    if (!monthId) return "";
    const id = typeof monthId === "object" ? monthId._id : monthId;
    const m = months.find((x) => x._id === id);
    if (!m) return "";
    if (m.month_name === "January") return "January (till 19th)";
    return `${m.month_name} ${m.year}`;
  };

  // ===================================================================
  // MONTH FILTER HELPERS
  // ===================================================================
  const getSortedMonths = () => {
    return [...months].sort((a, b) => {
      if (a.year !== b.year) return a.year - b.year;
      return (a.month_number || 0) - (b.month_number || 0);
    });
  };

  const applyMonthFilter = (allTargets) => {
    if (!months || months.length === 0) return allTargets;

    // Helper to find month record
    const findMonth = (target) => {
      const id =
        typeof target.month_id === "object"
          ? target.month_id._id
          : target.month_id;
      return months.find((m) => m._id === id);
    };

    if (monthFilterMode === "all") {
      return allTargets;
    }

    if (monthFilterMode === "range") {
      if (!rangeStartMonthId || !rangeEndMonthId) return allTargets;

      const startMonth = months.find((m) => m._id === rangeStartMonthId);
      const endMonth = months.find((m) => m._id === rangeEndMonthId);
      if (!startMonth || !endMonth) return allTargets;

      const getKey = (m) =>
        Number(m.year || 0) * 12 + Number(m.month_number || 0) - 1;

      const startKey = getKey(startMonth);
      const endKey = getKey(endMonth);
      const minKey = Math.min(startKey, endKey);
      const maxKey = Math.max(startKey, endKey);

      return allTargets.filter((t) => {
        const m = findMonth(t);
        if (!m) return false;
        const key = getKey(m);
        return key >= minKey && key <= maxKey;
      });
    }

    if (monthFilterMode === "next80") {
      const today = new Date();
      const start = new Date(
        today.getFullYear(),
        today.getMonth(),
        today.getDate()
      );
      const end = new Date(start);
      end.setDate(end.getDate() + 80);

      const getMonthRange = (m) => {
        // month_number is 1–12
        const startDate = new Date(m.year, m.month_number - 1, 1);
        const endDate = new Date(m.year, m.month_number, 0); // last day of month
        return { startDate, endDate };
      };

      return allTargets.filter((t) => {
        const m = findMonth(t);
        if (!m) return false;
        const { startDate, endDate } = getMonthRange(m);
        // Include month if it overlaps with [start, end]
        return endDate >= start && startDate <= end;
      });
    }

    return allTargets;
  };

  const sortedMonths = getSortedMonths();

  // ===================================================================
  // GROUP TARGETS BY USER
  // ===================================================================
  const groupByUser = (list) => {
    const out = {};
    list.forEach((t) => {
      if (!t.user_id?._id) return;

      if (!out[t.user_id._id]) {
        out[t.user_id._id] = {
          user: t.user_id,
          items: [],
        };
      }
      out[t.user_id._id].items.push(t);
    });
    return Object.values(out);
  };

  // 1) Apply month filter at target level
  let monthFilteredTargets = applyMonthFilter(targets);

  // 2) Restrict data for HOD: only their own department(s)
  if (isHod && !isSuperAdmin && hodDeptIds.length > 0) {
    const hodDeptSet = new Set(hodDeptIds);
    monthFilteredTargets = monthFilteredTargets.filter((t) => {
      const deptIds = t.user_id?.department_id || [];
      return deptIds.some((depId) => hodDeptSet.has(depId));
    });
  }

  // 3) Group filtered targets by user
  const grouped = groupByUser(monthFilteredTargets);

  // ===================================================================
  // DEPARTMENT & USER OPTIONS (FROM FILTERED TARGET DATA)
  // ===================================================================
  const deptIdsInTargets = new Set();
  grouped.forEach((u) => {
    (u.user?.department_id || []).forEach((depId) => {
      if (depId) deptIdsInTargets.add(depId);
    });
  });

  const hodDeptSet = new Set(hodDeptIds);

  let departmentOptions = [];
  if (isSuperAdmin) {
    // Admin / MD Admin: all departments that have targets
    departmentOptions = departments.filter((d) => deptIdsInTargets.has(d.id));
  } else if (isHod) {
    // HOD: only own department(s) that also appear in targets
    departmentOptions = departments.filter(
      (d) => hodDeptSet.has(d.id) && deptIdsInTargets.has(d.id)
    );
  }

  const userOptions = grouped.filter((u) => {
    if (!selectedDeptId) return true;
    const deptIds = u.user?.department_id || [];
    return deptIds.includes(selectedDeptId);
  });

  // ===================================================================
  // FINAL FILTERED GROUPS (DEPT + USER + SEARCH)
  // ===================================================================
  const filtered = grouped.filter((u) => {
    const deptIds = u.user?.department_id || [];

    const matchDept = !selectedDeptId || deptIds.includes(selectedDeptId);
    const matchUser = !selectedUserId || u.user._id === selectedUserId;
    const matchSearch = u.user?.name
      ?.toLowerCase()
      .includes(search.toLowerCase());

    return matchDept && matchUser && matchSearch;
  });

  // ===================================================================
  // DELETE ALL TARGETS FOR A USER (Admin Only)
  // ===================================================================
  const deleteAllTargets = async (group) => {
    if (!window.confirm(`Delete ALL targets for ${group.user.name}?`)) return;

    try {
      for (const item of group.items) {
        await deleteUserTarget(item._id);
      }
      alert("All targets deleted");
      loadAllData();
    } catch (err) {
      console.log(err);
      alert("Failed to delete targets");
    }
  };

  // ===================================================================
  // MONTH MODAL HANDLERS
  // ===================================================================
  const openMonthModal = () => setMonthModalOpen(true);
  const closeMonthModal = () => {
    setMonthForm({ month_name: "", month_number: "", year: "" });
    setEditMonthId(null);
    setMonthModalOpen(false);
  };

  const handleMonthFormChange = (e) => {
    setMonthForm((p) => ({ ...p, [e.target.name]: e.target.value }));
  };

  const saveMonth = async () => {
    if (!monthForm.month_name || !monthForm.month_number || !monthForm.year) {
      alert("All fields are required!");
      return;
    }

    try {
      if (editMonthId) {
        await updateMonth(editMonthId, monthForm);
        alert("Month updated!");
      } else {
        await createMonth(monthForm);
        alert("Month added!");
      }
      closeMonthModal();
      loadAllData();
    } catch (err) {
      console.log(err);
      alert("Failed to save month");
    }
  };

  const startEditMonth = (m) => {
    setMonthForm({
      month_name: m.month_name,
      month_number: m.month_number,
      year: m.year,
    });
    setEditMonthId(m._id);
    setMonthModalOpen(true);
  };

  const removeMonth = async (id) => {
    if (!window.confirm("Delete this month?")) return;
    try {
      await deleteMonth(id);
      alert("Month deleted!");
      loadAllData();
    } catch (err) {
      console.log(err);
    }
  };

  const openUserView = (data) => setViewUser(data);
  const closeUserView = () => setViewUser(null);

  // Next 80 days info text
  const today = new Date();
  const next80 = new Date(today);
  next80.setDate(next80.getDate() + 80);
  const formatDate = (d) =>
    d.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });

  // ===================================================================
  // RENDER
  // ===================================================================
  return (
    <div className="flex h-screen max-h-screen">
      <div className="min-w-44">
        <TargetFTSLeadMenu />
      </div>

      <div className="flex-1 px-6 pt-6">
        {/* HEADER */}
        <div className="flex items-center justify-between pb-3 mb-4 border-b">
          <h6 className="font-[700] text-[15px]">User Targets</h6>

          {/* ADMIN ONLY BUTTONS */}
          {isSuperAdmin && (
            <div className="flex gap-2">
              <button
                onClick={openMonthModal}
                className="px-3 py-1.5 bg-purple-600 text-white text-[12px] rounded"
              >
                + Add Month
              </button>

              <button
                onClick={() => navigate("/target_fts_leads/list/create")}
                className="px-3 py-1.5 bg-blue-600 text-white text-[12px] rounded"
              >
                + Add Target
              </button>
            </div>
          )}
        </div>

        {/* MONTH MODAL */}
        {monthModalOpen && (
          <MonthModal
            form={monthForm}
            handleChange={handleMonthFormChange}
            onClose={closeMonthModal}
            onSave={saveMonth}
            months={months}
            editMonth={startEditMonth}
            deleteMonth={removeMonth}
            isAdmin={isSuperAdmin}
            isEditMode={!!editMonthId}
          />
        )}

        {/* DETAIL VIEW OR LIST */}
        {viewUser ? (
          <UserDetailView
            data={viewUser}
            getMonthName={getMonthName}
            onBack={closeUserView}
            navigate={navigate}
            isAdmin={isSuperAdmin}
          />
        ) : (
          <>
            {loading && <p>Loading...</p>}

            {isAdminOrHodOrMd ? (
              <>
                {/* MONTH FILTERS (Admin / HOD / MD Admin) */}
                <div className="mb-4 space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[12px] font-semibold text-gray-700">
                      Month Filter:
                    </span>

                    <button
                      onClick={() => {
                        setMonthFilterMode("all");
                        setRangeStartMonthId("");
                        setRangeEndMonthId("");
                      }}
                      className={`px-3 py-1 rounded-full text-[11px] border ${
                        monthFilterMode === "all"
                          ? "bg-blue-600 text-white border-blue-600"
                          : "bg-white text-gray-700 border-gray-300"
                      }`}
                    >
                      All Months
                    </button>

                    <button
                      onClick={() => setMonthFilterMode("range")}
                      className={`px-3 py-1 rounded-full text-[11px] border ${
                        monthFilterMode === "range"
                          ? "bg-blue-600 text-white border-blue-600"
                          : "bg-white text-gray-700 border-gray-300"
                      }`}
                    >
                      Custom Range
                    </button>

                    <button
                      onClick={() => {
                        setMonthFilterMode("next80");
                        setRangeStartMonthId("");
                        setRangeEndMonthId("");
                      }}
                      className={`px-3 py-1 rounded-full text-[11px] border ${
                        monthFilterMode === "next80"
                          ? "bg-blue-600 text-white border-blue-600"
                          : "bg-white text-gray-700 border-gray-300"
                      }`}
                    >
                      Next 80 Days
                    </button>
                  </div>

                  {/* RANGE SELECTORS */}
                  {monthFilterMode === "range" && (
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[11px] text-gray-600">From:</span>
                      <select
                        className="px-3 py-1 border rounded text-[12px]"
                        value={rangeStartMonthId}
                        onChange={(e) => setRangeStartMonthId(e.target.value)}
                      >
                        <option value="">Select start month</option>
                        {sortedMonths.map((m) => (
                          <option key={m._id} value={m._id}>
                            {m.month_name} {m.year}
                          </option>
                        ))}
                      </select>

                      <span className="text-[11px] text-gray-600">To:</span>
                      <select
                        className="px-3 py-1 border rounded text-[12px]"
                        value={rangeEndMonthId}
                        onChange={(e) => setRangeEndMonthId(e.target.value)}
                      >
                        <option value="">Select end month</option>
                        {sortedMonths.map((m) => (
                          <option key={m._id} value={m._id}>
                            {m.month_name} {m.year}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {/* NEXT 80 DAYS INFO */}
                  {monthFilterMode === "next80" && (
                    <p className="text-[11px] text-gray-600">
                      Showing targets for months overlapping the next{" "}
                      <span className="font-semibold">80 days</span> (
                      {formatDate(today)} → {formatDate(next80)}).
                    </p>
                  )}
                </div>

                {/* DEPT / USER / SEARCH FILTERS */}
                <div className="flex flex-wrap gap-2 mb-3">
                  {/* Department Filter */}
                  <select
                    className="px-3 py-1 border rounded text-[12px]"
                    value={selectedDeptId}
                    onChange={(e) => {
                      setSelectedDeptId(e.target.value);
                      setSelectedUserId("");
                    }}
                  >
                    <option value="">
                      {isSuperAdmin ? "All Departments" : "All (My Department)"}
                    </option>
                    {departmentOptions.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.department_name}
                      </option>
                    ))}
                  </select>

                  {/* User Filter */}
                  <select
                    className="px-3 py-1 border rounded text-[12px]"
                    value={selectedUserId}
                    onChange={(e) => setSelectedUserId(e.target.value)}
                  >
                    <option value="">All Users</option>
                    {userOptions.map((u) => (
                      <option key={u.user._id} value={u.user._id}>
                        {u.user.name}
                      </option>
                    ))}
                  </select>

                  {/* Search by Name */}
                  <input
                    type="text"
                    placeholder="Search user..."
                    className="px-3 py-1 text-sm border rounded"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>

                {/* ADMIN / HOD / MD TABLE */}
                <UserTargetTable
                  users={filtered}
                  openUserView={openUserView}
                  deleteAllTargets={deleteAllTargets}
                  isAdmin={isSuperAdmin}
                />
              </>
            ) : (
              // NORMAL USER: only see own summary (all months, no extra filters)
              (() => {
                const myData =
                  grouped.find((u) => u.user._id === auth.id) || {
                    user: auth,
                    items: [],
                  };

                return (
                  <UserDetailView
                    data={myData}
                    getMonthName={getMonthName}
                    navigate={navigate}
                    hideBack
                    isAdmin={isSuperAdmin}
                  />
                );
              })()
            )}
          </>
        )}
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                               MONTH MODAL                                   */
/* -------------------------------------------------------------------------- */

function MonthModal({
  form,
  handleChange,
  onClose,
  onSave,
  months,
  editMonth,
  deleteMonth,
  isAdmin,
  isEditMode,
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40">
      <div className="bg-white p-6 rounded-lg shadow-xl w-[420px] max-h-[85vh] overflow-y-auto">
        <h3 className="text-[16px] font-[700] mb-4">
          {isEditMode ? "Edit Month" : "Add New Month"}
        </h3>

        {/* FORM */}
        <div className="mb-5 space-y-3">
          <select
            name="month_name"
            value={form.month_name}
            onChange={handleChange}
            className="w-full border px-3 py-2 rounded text-[13px]"
          >
            <option value="">Select Month</option>
            {[
              "January",
              "February",
              "March",
              "April",
              "May",
              "June",
              "July",
              "August",
              "September",
              "October",
              "November",
              "December",
            ].map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>

          <input
            type="number"
            name="month_number"
            value={form.month_number}
            onChange={handleChange}
            placeholder="Month Number"
            className="w-full border px-3 py-2 rounded text-[13px]"
          />

          <input
            type="number"
            name="year"
            value={form.year}
            onChange={handleChange}
            placeholder="Year"
            className="w-full border px-3 py-2 rounded text-[13px]"
          />
        </div>

        {/* EXISTING MONTHS */}
        <h4 className="font-[600] mb-2 text-[13px]">Existing Months</h4>

        <div className="border rounded mb-4 max-h-[200px] overflow-y-auto">
          {months.map((m) => (
            <div
              key={m._id}
              className="flex justify-between items-center px-3 py-2 border-b text-[12px]"
            >
              <span>
                {m.month_name} ({m.year})
              </span>

              {isAdmin && (
                <div className="flex gap-3">
                  <button
                    onClick={() => editMonth(m)}
                    className="text-blue-600 text-[11px] underline"
                  >
                    Edit
                  </button>

                  <button
                    onClick={() => deleteMonth(m._id)}
                    className="text-red-600 text-[11px] underline"
                  >
                    Delete
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* BUTTONS */}
        <div className="flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1 text-[12px] border rounded"
          >
            Cancel
          </button>

          {isAdmin && (
            <button
              onClick={onSave}
              className="px-3 py-1 text-[12px] bg-blue-600 text-white rounded"
            >
              {isEditMode ? "Update" : "Save"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                             ADMIN / HOD / MD TABLE                          */
/* -------------------------------------------------------------------------- */

function UserTargetTable({ users, openUserView, deleteAllTargets, isAdmin }) {
  // 💰 Format money with commas + rupee symbol
  const formatMoney = (num) => {
    if (!num && num !== 0) return "₹0";
    return "₹" + num.toLocaleString("en-IN");
  };

  return (
    <div className="overflow-hidden bg-white border border-gray-300 rounded-lg shadow-sm">
      {/* HEADER */}
      <div
        className="grid grid-cols-5 bg-gray-200 px-4 py-3 border-b
                      text-[14px] font-bold text-gray-800 tracking-wide"
      >
        <span>Name</span>
        <span className="text-center">Target</span>
        <span className="text-center">Achieved</span>
        <span className="text-center">Shortfall / Surplus</span>
        <span className="text-center">Action</span>
      </div>

      {users.length === 0 ? (
        <div className="p-4 text-sm text-center text-gray-500">
          No users found
        </div>
      ) : (
        users.map((u, idx) => {
          const totalTarget = u.items.reduce((a, x) => a + x.target, 0);
          const totalAchieved = u.items.reduce((a, x) => a + x.achieved, 0);

          // REAL LOGIC
          const difference = totalAchieved - totalTarget;
          const isSurplus = difference >= 0;
          const valueToShow = Math.abs(difference);

          return (
            <div
              key={u.user._id}
              className={`grid grid-cols-5 px-4 py-2 border-b text-[13px]
                ${idx % 2 === 0 ? "bg-white" : "bg-gray-50"}`}
            >
              {/* NAME */}
              <span className="font-semibold text-[15px] text-[#1b709b]">
                {u.user.name}
              </span>

              {/* TARGET */}
              <span className="font-bold text-center text-[14px] text-black/80">
                {formatMoney(totalTarget)}
              </span>

              {/* ACHIEVED */}
              <span className="font-bold text-center text-[14px] text-black/80">
                {formatMoney(totalAchieved)}
              </span>

              {/* SHORTFALL / SURPLUS */}
              <span className="text-center">
                {isSurplus ? (
                  <span
                    className="px-2 py-0.5 bg-green-100 
                                   text-green-700 font-semibold 
                                   rounded text-[13px]"
                  >
                    +{formatMoney(valueToShow)}
                  </span>
                ) : (
                  <span
                    className="px-2 py-0.5 bg-red-100 
                                   text-red-600 font-semibold 
                                   rounded text-[13px]"
                  >
                    -{formatMoney(valueToShow)}
                  </span>
                )}
              </span>

              {/* ACTION BUTTONS */}
              <span className="flex justify-center gap-2">
                <button
                  onClick={() => openUserView(u)}
                  className="px-3 py-1 bg-blue-600 hover:bg-blue-700 
                             text-white text-[12px] rounded-md transition"
                >
                  View
                </button>

                {isAdmin && (
                  <button
                    onClick={() => deleteAllTargets(u)}
                    className="px-3 py-1 bg-red-600 hover:bg-red-700 
                               text-white text-[12px] rounded-md transition"
                  >
                    Delete
                  </button>
                )}
              </span>
            </div>
          );
        })
      )}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                           USER DETAIL VIEW                                  */
/* -------------------------------------------------------------------------- */

function UserDetailView({
  data,
  getMonthName,
  onBack,
  navigate,
  hideBack,
  isAdmin,
}) {
  if (!data) return <p>No Target Found</p>;

  // Format money as ₹ with Indian commas
  const formatMoney = (num) => {
    if (!num && num !== 0) return "₹0";
    return "₹" + num.toLocaleString("en-IN");
  };

  const monthLabels = data.items.map((x) => getMonthName(x.month_id));
  const targetData = data.items.map((x) => x.target);
  const achievedData = data.items.map((x) => x.achieved);

  const chartSeries = [
    { name: "Target", data: targetData },
    { name: "Achieved", data: achievedData },
  ];

  const chartOptions = {
    chart: { type: "bar", height: 320, toolbar: { show: false } },
    plotOptions: {
      bar: { horizontal: false, columnWidth: "50%", endingShape: "rounded" },
    },
    dataLabels: { enabled: true },
    xaxis: { categories: monthLabels, labels: { rotate: -45 } },
    yaxis: { title: { text: "Amount" } },
    colors: ["#3b82f6", "#10b981"],
  };

  const deleteSingle = async (id) => {
    if (!window.confirm("Delete this target?")) return;

    try {
      await deleteUserTarget(id);
      alert("Target deleted!");
      window.location.reload();
    } catch (err) {
      alert("Error deleting target");
    }
  };

  return (
    <div className="p-4 bg-white border rounded-lg shadow-sm">
      {!hideBack && (
        <button
          onClick={onBack}
          className="mb-3 px-3 py-1 bg-slate-200 rounded text-[12px]"
        >
          ← Back
        </button>
      )}

      {/* HEADER */}
      <div className="flex items-center justify-between mb-3">
        <h6 className="font-[700] text-[15px] text-[#1b709b]">
          {data.user.name}'s Target Summary
        </h6>

        {isAdmin && (
          <button
            onClick={() =>
              navigate(`/target_fts_leads/list/create?user=${data.user._id}`)
            }
            className="px-3 py-1 bg-blue-600 hover:bg-blue-700 
                       text-white text-[12px] rounded"
          >
            + Add Target
          </button>
        )}
      </div>

      {/* TABLE */}
      <div className="mt-3 overflow-hidden bg-white border border-gray-300 rounded-lg shadow-sm">
        {/* HEADER */}
        <div
          className="grid grid-cols-5 bg-gray-200 px-4 py-3 border-b
                text-[14px] font-bold text-gray-800 tracking-wide"
        >
          <span>Month</span>
          <span className="text-center">Target</span>
          <span className="text-center">Achieved</span>
          <span className="text-center">Shortfall / Surplus</span>
          <span className="text-center">Action</span>
        </div>

        {data.items.length === 0 ? (
          <div className="p-4 text-sm text-center text-gray-500">
            No targets found
          </div>
        ) : (
          data.items.map((t, idx) => {
            const target = t.target;
            const achieved = t.achieved;

            const diff = achieved - target;
            const isSurplus = diff >= 0;
            const valueToShow = Math.abs(diff);

            return (
              <div
                key={t._id}
                className={`grid grid-cols-5 px-4 py-2 border-b text-[13px]
          ${idx % 2 === 0 ? "bg-white" : "bg-gray-50"}`}
              >
                {/* MONTH */}
                <span className="font-semibold text-[15px] text-[#1b709b]">
                  {getMonthName(t.month_id)}
                </span>

                {/* TARGET */}
                <span className="font-bold text-center text-[14px] text-black/80">
                  {formatMoney(target)}
                </span>

                {/* ACHIEVED */}
                <span className="font-bold text-center text-[14px] text-black/80">
                  {formatMoney(achieved)}
                </span>

                {/* SHORTFALL / SURPLUS */}
                <span className="text-center">
                  {isSurplus ? (
                    <span
                      className="px-2 py-0.5 bg-green-100 
                             text-green-700 font-semibold 
                             rounded text-[13px]"
                    >
                      +{formatMoney(valueToShow)}
                    </span>
                  ) : (
                    <span
                      className="px-2 py-0.5 bg-red-100 
                             text-red-600 font-semibold 
                             rounded text-[13px]"
                    >
                      -{formatMoney(valueToShow)}
                    </span>
                  )}
                </span>

                {/* ACTION BUTTONS */}
                <span className="flex justify-center gap-2">
                  {isAdmin && (
                    <>
                      <button
                        onClick={() =>
                          navigate(`/target_fts_leads/list/edit/${t._id}`)
                        }
                        className="px-3 py-1 bg-blue-600 hover:bg-blue-700 
                           text-white text-[12px] rounded-md transition"
                      >
                        Edit
                      </button>

                      <button
                        onClick={() => deleteSingle(t._id)}
                        className="px-3 py-1 bg-red-600 hover:bg-red-700 
                           text-white text-[12px] rounded-md transition"
                      >
                        Delete
                      </button>
                    </>
                  )}
                </span>
              </div>
            );
          })
        )}
      </div>

      {/* CHART */}
      <div className="p-4 mt-5 bg-white border rounded-lg shadow">
        <h6 className="font-[700] text-[13px] mb-3">
          Monthly Performance Chart
        </h6>
        <Chart
          options={chartOptions}
          series={chartSeries}
          type="bar"
          height={320}
        />
      </div>
    </div>
  );
}








//=========>> Old one





// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import Chart from "react-apexcharts";

// import TargetFTSLeadMenu from "./TargetFTSLeadMenu";

// import {
//   getUserTargets,
//   deleteUserTarget,
// } from "../../services/UserTargetService";

// import {
//   getMonths,
//   createMonth,
//   updateMonth,
//   deleteMonth,
// } from "../../services/MonthService";

// import { GetDepartmentService } from "../../services/DepartmentServices";

// // ===================================================================
// // MAIN COMPONENT
// // ===================================================================
// export default function TargetFTSLeadList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   const isAdmin = auth?.roles?.includes("admin");
//   const isHod = auth?.roles?.includes("hod");
//   const isMdAdmin = auth?.roles?.includes("md_admin");

//   const canUseFilters = isAdmin || isHod || isMdAdmin; // who can see dept/user filters + list
//   const isAdminOrHodOrMd = canUseFilters;

//   const [loading, setLoading] = useState(true);
//   const [targets, setTargets] = useState([]);
//   const [months, setMonths] = useState([]);
//   const [departments, setDepartments] = useState([]);

//   const [search, setSearch] = useState("");
//   const [selectedDeptId, setSelectedDeptId] = useState(""); // "" = All Departments
//   const [selectedUserId, setSelectedUserId] = useState(""); // "" = All Users

//   const [viewUser, setViewUser] = useState(null);

//   // Month modal
//   const [monthModalOpen, setMonthModalOpen] = useState(false);
//   const [monthForm, setMonthForm] = useState({
//     month_name: "",
//     month_number: "",
//     year: "",
//   });
//   const [editMonthId, setEditMonthId] = useState(null);

//   // Month filter state
//   const [monthFilterMode, setMonthFilterMode] = useState("all"); // "all" | "range" | "next80"
//   const [rangeStartMonthId, setRangeStartMonthId] = useState("");
//   const [rangeEndMonthId, setRangeEndMonthId] = useState("");

//   useEffect(() => {
//     loadAllData();
//   }, []);

//   // ===================================================================
//   // LOAD ALL DATA (MONTHS, TARGETS, DEPARTMENTS)
//   // ===================================================================
//   const loadAllData = async () => {
//     setLoading(true);
//     try {
//       const [m, t, d] = await Promise.all([
//         getMonths(),
//         getUserTargets(),
//         GetDepartmentService(),
//       ]);

//       setMonths(m?.data?.data || []);

//       const rawTargets = t?.data?.data || [];
//       const formattedTargets = rawTargets.map((item) => ({
//         ...item,
//         user_id: {
//           ...item.user_id,
//           _id: item.user_id?._id || item.user_id?.id,
//         },
//         month_id: {
//           ...item.month_id,
//           _id: item.month_id?._id || item.month_id?.id,
//         },
//       }));
//       setTargets(formattedTargets);

//       setDepartments(d?.data?.datas || []);
//     } catch (err) {
//       console.log(err);
//     }
//     setLoading(false);
//   };

//   // ===================================================================
//   // MONTH NAME
//   // ===================================================================
//   const getMonthName = (monthId) => {
//     if (!monthId) return "";
//     const id = typeof monthId === "object" ? monthId._id : monthId;
//     const m = months.find((x) => x._id === id);
//     if (!m) return "";
//     if (m.month_name === "January") return "January (till 19th)";
//     return `${m.month_name} ${m.year}`;
//   };

//   // ===================================================================
//   // MONTH FILTER HELPERS
//   // ===================================================================
//   const getSortedMonths = () => {
//     return [...months].sort((a, b) => {
//       if (a.year !== b.year) return a.year - b.year;
//       return (a.month_number || 0) - (b.month_number || 0);
//     });
//   };

//   const applyMonthFilter = (allTargets) => {
//     if (!months || months.length === 0) return allTargets;

//     // Helper to find month record
//     const findMonth = (target) => {
//       const id =
//         typeof target.month_id === "object"
//           ? target.month_id._id
//           : target.month_id;
//       return months.find((m) => m._id === id);
//     };

//     if (monthFilterMode === "all") {
//       return allTargets;
//     }

//     if (monthFilterMode === "range") {
//       if (!rangeStartMonthId || !rangeEndMonthId) return allTargets;

//       const startMonth = months.find((m) => m._id === rangeStartMonthId);
//       const endMonth = months.find((m) => m._id === rangeEndMonthId);
//       if (!startMonth || !endMonth) return allTargets;

//       const getKey = (m) =>
//         Number(m.year || 0) * 12 + Number(m.month_number || 0) - 1;

//       const startKey = getKey(startMonth);
//       const endKey = getKey(endMonth);
//       const minKey = Math.min(startKey, endKey);
//       const maxKey = Math.max(startKey, endKey);

//       return allTargets.filter((t) => {
//         const m = findMonth(t);
//         if (!m) return false;
//         const key = getKey(m);
//         return key >= minKey && key <= maxKey;
//       });
//     }

//     if (monthFilterMode === "next80") {
//       const today = new Date();
//       const start = new Date(
//         today.getFullYear(),
//         today.getMonth(),
//         today.getDate()
//       );
//       const end = new Date(start);
//       end.setDate(end.getDate() + 80);

//       const getMonthRange = (m) => {
//         // month_number is 1–12
//         const startDate = new Date(m.year, m.month_number - 1, 1);
//         const endDate = new Date(m.year, m.month_number, 0); // last day of month
//         return { startDate, endDate };
//       };

//       return allTargets.filter((t) => {
//         const m = findMonth(t);
//         if (!m) return false;
//         const { startDate, endDate } = getMonthRange(m);
//         // Include month if it overlaps with [start, end]
//         return endDate >= start && startDate <= end;
//       });
//     }

//     return allTargets;
//   };

//   const sortedMonths = getSortedMonths();

//   // ===================================================================
//   // GROUP TARGETS BY USER
//   // ===================================================================
//   const groupByUser = (list) => {
//     const out = {};
//     list.forEach((t) => {
//       if (!t.user_id?._id) return;

//       if (!out[t.user_id._id]) {
//         out[t.user_id._id] = {
//           user: t.user_id,
//           items: [],
//         };
//       }
//       out[t.user_id._id].items.push(t);
//     });
//     return Object.values(out);
//   };

//   // 1) Apply month filter at target level
//   const monthFilteredTargets = applyMonthFilter(targets);

//   // 2) Group filtered targets by user
//   const grouped = groupByUser(monthFilteredTargets);

//   // ===================================================================
//   // DEPARTMENT & USER OPTIONS (FROM FILTERED TARGET DATA)
//   // ===================================================================
//   const deptIdsInTargets = new Set();
//   grouped.forEach((u) => {
//     (u.user?.department_id || []).forEach((depId) => {
//       if (depId) deptIdsInTargets.add(depId);
//     });
//   });

//   const departmentOptions = departments.filter((d) =>
//     deptIdsInTargets.has(d.id)
//   );

//   const userOptions = grouped.filter((u) => {
//     if (!selectedDeptId) return true;
//     const deptIds = u.user?.department_id || [];
//     return deptIds.includes(selectedDeptId);
//   });

//   // ===================================================================
//   // FINAL FILTERED GROUPS (DEPT + USER + SEARCH)
//   // ===================================================================
//   const filtered = grouped.filter((u) => {
//     const deptIds = u.user?.department_id || [];

//     const matchDept = !selectedDeptId || deptIds.includes(selectedDeptId);
//     const matchUser = !selectedUserId || u.user._id === selectedUserId;
//     const matchSearch = u.user?.name
//       ?.toLowerCase()
//       .includes(search.toLowerCase());

//     return matchDept && matchUser && matchSearch;
//   });

//   // ===================================================================
//   // DELETE ALL TARGETS FOR A USER (Admin Only)
//   // ===================================================================
//   const deleteAllTargets = async (group) => {
//     if (!window.confirm(`Delete ALL targets for ${group.user.name}?`)) return;

//     try {
//       for (const item of group.items) {
//         await deleteUserTarget(item._id);
//       }
//       alert("All targets deleted");
//       loadAllData();
//     } catch (err) {
//       console.log(err);
//       alert("Failed to delete targets");
//     }
//   };

//   // ===================================================================
//   // MONTH MODAL HANDLERS
//   // ===================================================================
//   const openMonthModal = () => setMonthModalOpen(true);
//   const closeMonthModal = () => {
//     setMonthForm({ month_name: "", month_number: "", year: "" });
//     setEditMonthId(null);
//     setMonthModalOpen(false);
//   };

//   const handleMonthFormChange = (e) => {
//     setMonthForm((p) => ({ ...p, [e.target.name]: e.target.value }));
//   };

//   const saveMonth = async () => {
//     if (!monthForm.month_name || !monthForm.month_number || !monthForm.year) {
//       alert("All fields are required!");
//       return;
//     }

//     try {
//       if (editMonthId) {
//         await updateMonth(editMonthId, monthForm);
//         alert("Month updated!");
//       } else {
//         await createMonth(monthForm);
//         alert("Month added!");
//       }
//       closeMonthModal();
//       loadAllData();
//     } catch (err) {
//       console.log(err);
//       alert("Failed to save month");
//     }
//   };

//   const startEditMonth = (m) => {
//     setMonthForm({
//       month_name: m.month_name,
//       month_number: m.month_number,
//       year: m.year,
//     });
//     setEditMonthId(m._id);
//     setMonthModalOpen(true);
//   };

//   const removeMonth = async (id) => {
//     if (!window.confirm("Delete this month?")) return;
//     try {
//       await deleteMonth(id);
//       alert("Month deleted!");
//       loadAllData();
//     } catch (err) {
//       console.log(err);
//     }
//   };

//   const openUserView = (data) => setViewUser(data);
//   const closeUserView = () => setViewUser(null);

//   // Next 80 days info text
//   const today = new Date();
//   const next80 = new Date(today);
//   next80.setDate(next80.getDate() + 80);
//   const formatDate = (d) =>
//     d.toLocaleDateString("en-IN", {
//       day: "2-digit",
//       month: "short",
//       year: "numeric",
//     });

//   // ===================================================================
//   // RENDER
//   // ===================================================================
//   return (
//     <div className="flex h-screen max-h-screen">
//       <div className="min-w-44">
//         <TargetFTSLeadMenu />
//       </div>

//       <div className="flex-1 px-6 pt-6">
//         {/* HEADER */}
//         <div className="flex items-center justify-between pb-3 mb-4 border-b">
//           <h6 className="font-[700] text-[15px]">User Targets</h6>

//           {/* ADMIN ONLY BUTTONS */}
//           {isAdmin && (
//             <div className="flex gap-2">
//               <button
//                 onClick={openMonthModal}
//                 className="px-3 py-1.5 bg-purple-600 text-white text-[12px] rounded"
//               >
//                 + Add Month
//               </button>

//               <button
//                 onClick={() => navigate("/target_fts_leads/list/create")}
//                 className="px-3 py-1.5 bg-blue-600 text-white text-[12px] rounded"
//               >
//                 + Add Target
//               </button>
//             </div>
//           )}
//         </div>

//         {/* MONTH MODAL */}
//         {monthModalOpen && (
//           <MonthModal
//             form={monthForm}
//             handleChange={handleMonthFormChange}
//             onClose={closeMonthModal}
//             onSave={saveMonth}
//             months={months}
//             editMonth={startEditMonth}
//             deleteMonth={removeMonth}
//             isAdmin={isAdmin}
//             isEditMode={!!editMonthId}
//           />
//         )}

//         {/* DETAIL VIEW OR LIST */}
//         {viewUser ? (
//           <UserDetailView
//             data={viewUser}
//             getMonthName={getMonthName}
//             onBack={closeUserView}
//             navigate={navigate}
//             isAdmin={isAdmin}
//           />
//         ) : (
//           <>
//             {loading && <p>Loading...</p>}

//             {isAdminOrHodOrMd ? (
//               <>
//                 {/* MONTH FILTERS (Admin / HOD / MD Admin) */}
//                 <div className="mb-4 space-y-2">
//                   <div className="flex flex-wrap items-center gap-2">
//                     <span className="text-[12px] font-semibold text-gray-700">
//                       Month Filter:
//                     </span>

//                     <button
//                       onClick={() => {
//                         setMonthFilterMode("all");
//                         setRangeStartMonthId("");
//                         setRangeEndMonthId("");
//                       }}
//                       className={`px-3 py-1 rounded-full text-[11px] border ${
//                         monthFilterMode === "all"
//                           ? "bg-blue-600 text-white border-blue-600"
//                           : "bg-white text-gray-700 border-gray-300"
//                       }`}
//                     >
//                       All Months
//                     </button>

//                     <button
//                       onClick={() => setMonthFilterMode("range")}
//                       className={`px-3 py-1 rounded-full text-[11px] border ${
//                         monthFilterMode === "range"
//                           ? "bg-blue-600 text-white border-blue-600"
//                           : "bg-white text-gray-700 border-gray-300"
//                       }`}
//                     >
//                       Custom Range
//                     </button>

//                     <button
//                       onClick={() => {
//                         setMonthFilterMode("next80");
//                         setRangeStartMonthId("");
//                         setRangeEndMonthId("");
//                       }}
//                       className={`px-3 py-1 rounded-full text-[11px] border ${
//                         monthFilterMode === "next80"
//                           ? "bg-blue-600 text-white border-blue-600"
//                           : "bg-white text-gray-700 border-gray-300"
//                       }`}
//                     >
//                       Next 80 Days
//                     </button>
//                   </div>

//                   {/* RANGE SELECTORS */}
//                   {monthFilterMode === "range" && (
//                     <div className="flex flex-wrap items-center gap-2">
//                       <span className="text-[11px] text-gray-600">
//                         From:
//                       </span>
//                       <select
//                         className="px-3 py-1 border rounded text-[12px]"
//                         value={rangeStartMonthId}
//                         onChange={(e) => setRangeStartMonthId(e.target.value)}
//                       >
//                         <option value="">Select start month</option>
//                         {sortedMonths.map((m) => (
//                           <option key={m._id} value={m._id}>
//                             {m.month_name} {m.year}
//                           </option>
//                         ))}
//                       </select>

//                       <span className="text-[11px] text-gray-600">To:</span>
//                       <select
//                         className="px-3 py-1 border rounded text-[12px]"
//                         value={rangeEndMonthId}
//                         onChange={(e) => setRangeEndMonthId(e.target.value)}
//                       >
//                         <option value="">Select end month</option>
//                         {sortedMonths.map((m) => (
//                           <option key={m._id} value={m._id}>
//                             {m.month_name} {m.year}
//                           </option>
//                         ))}
//                       </select>
//                     </div>
//                   )}

//                   {/* NEXT 80 DAYS INFO */}
//                   {monthFilterMode === "next80" && (
//                     <p className="text-[11px] text-gray-600">
//                       Showing targets for months overlapping the next{" "}
//                       <span className="font-semibold">80 days</span> (
//                       {formatDate(today)} → {formatDate(next80)}).
//                     </p>
//                   )}
//                 </div>

//                 {/* DEPT / USER / SEARCH FILTERS */}
//                 <div className="flex flex-wrap gap-2 mb-3">
//                   {/* Department Filter */}
//                   <select
//                     className="px-3 py-1 border rounded text-[12px]"
//                     value={selectedDeptId}
//                     onChange={(e) => {
//                       setSelectedDeptId(e.target.value);
//                       setSelectedUserId("");
//                     }}
//                   >
//                     <option value="">All Departments</option>
//                     {departmentOptions.map((d) => (
//                       <option key={d.id} value={d.id}>
//                         {d.department_name}
//                       </option>
//                     ))}
//                   </select>

//                   {/* User Filter */}
//                   <select
//                     className="px-3 py-1 border rounded text-[12px]"
//                     value={selectedUserId}
//                     onChange={(e) => setSelectedUserId(e.target.value)}
//                   >
//                     <option value="">All Users</option>
//                     {userOptions.map((u) => (
//                       <option key={u.user._id} value={u.user._id}>
//                         {u.user.name}
//                       </option>
//                     ))}
//                   </select>

//                   {/* Search by Name */}
//                   <input
//                     type="text"
//                     placeholder="Search user..."
//                     className="px-3 py-1 text-sm border rounded"
//                     value={search}
//                     onChange={(e) => setSearch(e.target.value)}
//                   />
//                 </div>

//                 {/* ADMIN / HOD / MD TABLE */}
//                 <UserTargetTable
//                   users={filtered}
//                   openUserView={openUserView}
//                   deleteAllTargets={deleteAllTargets}
//                   isAdmin={isAdmin}
//                 />
//               </>
//             ) : (
//               // NORMAL USER: only see own summary (all months, no extra filters)
//               (() => {
//                 const myData =
//                   grouped.find((u) => u.user._id === auth.id) || {
//                     user: auth,
//                     items: [],
//                   };

//                 return (
//                   <UserDetailView
//                     data={myData}
//                     getMonthName={getMonthName}
//                     navigate={navigate}
//                     hideBack
//                     isAdmin={isAdmin}
//                   />
//                 );
//               })()
//             )}
//           </>
//         )}
//       </div>
//     </div>
//   );
// }

// /* -------------------------------------------------------------------------- */
// /*                               MONTH MODAL                                   */
// /* -------------------------------------------------------------------------- */

// function MonthModal({
//   form,
//   handleChange,
//   onClose,
//   onSave,
//   months,
//   editMonth,
//   deleteMonth,
//   isAdmin,
//   isEditMode,
// }) {
//   return (
//     <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40">
//       <div className="bg-white p-6 rounded-lg shadow-xl w-[420px] max-h-[85vh] overflow-y-auto">
//         <h3 className="text-[16px] font-[700] mb-4">
//           {isEditMode ? "Edit Month" : "Add New Month"}
//         </h3>

//         {/* FORM */}
//         <div className="mb-5 space-y-3">
//           <select
//             name="month_name"
//             value={form.month_name}
//             onChange={handleChange}
//             className="w-full border px-3 py-2 rounded text-[13px]"
//           >
//             <option value="">Select Month</option>
//             {[
//               "January",
//               "February",
//               "March",
//               "April",
//               "May",
//               "June",
//               "July",
//               "August",
//               "September",
//               "October",
//               "November",
//               "December",
//             ].map((m) => (
//               <option key={m} value={m}>
//                 {m}
//               </option>
//             ))}
//           </select>

//           <input
//             type="number"
//             name="month_number"
//             value={form.month_number}
//             onChange={handleChange}
//             placeholder="Month Number"
//             className="w-full border px-3 py-2 rounded text-[13px]"
//           />

//           <input
//             type="number"
//             name="year"
//             value={form.year}
//             onChange={handleChange}
//             placeholder="Year"
//             className="w-full border px-3 py-2 rounded text-[13px]"
//           />
//         </div>

//         {/* EXISTING MONTHS */}
//         <h4 className="font-[600] mb-2 text-[13px]">Existing Months</h4>

//         <div className="border rounded mb-4 max-h-[200px] overflow-y-auto">
//           {months.map((m) => (
//             <div
//               key={m._id}
//               className="flex justify-between items-center px-3 py-2 border-b text-[12px]"
//             >
//               <span>
//                 {m.month_name} ({m.year})
//               </span>

//               {isAdmin && (
//                 <div className="flex gap-3">
//                   <button
//                     onClick={() => editMonth(m)}
//                     className="text-blue-600 text-[11px] underline"
//                   >
//                     Edit
//                   </button>

//                   <button
//                     onClick={() => deleteMonth(m._id)}
//                     className="text-red-600 text-[11px] underline"
//                   >
//                     Delete
//                   </button>
//                 </div>
//               )}
//             </div>
//           ))}
//         </div>

//         {/* BUTTONS */}
//         <div className="flex justify-end gap-2">
//           <button
//             onClick={onClose}
//             className="px-3 py-1 text-[12px] border rounded"
//           >
//             Cancel
//           </button>

//           {isAdmin && (
//             <button
//               onClick={onSave}
//               className="px-3 py-1 text-[12px] bg-blue-600 text-white rounded"
//             >
//               {isEditMode ? "Update" : "Save"}
//             </button>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// }

// /* -------------------------------------------------------------------------- */
// /*                             ADMIN / HOD / MD TABLE                          */
// /* -------------------------------------------------------------------------- */

// function UserTargetTable({ users, openUserView, deleteAllTargets, isAdmin }) {
//   // 💰 Format money with commas + rupee symbol
//   const formatMoney = (num) => {
//     if (!num && num !== 0) return "₹0";
//     return "₹" + num.toLocaleString("en-IN");
//   };

//   return (
//     <div className="overflow-hidden bg-white border border-gray-300 rounded-lg shadow-sm">
//       {/* HEADER */}
//       <div
//         className="grid grid-cols-5 bg-gray-200 px-4 py-3 border-b
//                       text-[14px] font-bold text-gray-800 tracking-wide"
//       >
//         <span>Name</span>
//         <span className="text-center">Target</span>
//         <span className="text-center">Achieved</span>
//         <span className="text-center">Shortfall / Surplus</span>
//         <span className="text-center">Action</span>
//       </div>

//       {users.length === 0 ? (
//         <div className="p-4 text-sm text-center text-gray-500">
//           No users found
//         </div>
//       ) : (
//         users.map((u, idx) => {
//           const totalTarget = u.items.reduce((a, x) => a + x.target, 0);
//           const totalAchieved = u.items.reduce((a, x) => a + x.achieved, 0);

//           // REAL LOGIC
//           const difference = totalAchieved - totalTarget;
//           const isSurplus = difference >= 0;
//           const valueToShow = Math.abs(difference);

//           return (
//             <div
//               key={u.user._id}
//               className={`grid grid-cols-5 px-4 py-2 border-b text-[13px]
//                 ${idx % 2 === 0 ? "bg-white" : "bg-gray-50"}`}
//             >
//               {/* NAME */}
//               <span className="font-semibold text-[15px] text-[#1b709b]">
//                 {u.user.name}
//               </span>

//               {/* TARGET */}
//               <span className="font-bold text-center text-[14px] text-black/80">
//                 {formatMoney(totalTarget)}
//               </span>

//               {/* ACHIEVED */}
//               <span className="font-bold text-center text-[14px] text-black/80">
//                 {formatMoney(totalAchieved)}
//               </span>

//               {/* SHORTFALL / SURPLUS */}
//               <span className="text-center">
//                 {isSurplus ? (
//                   <span
//                     className="px-2 py-0.5 bg-green-100 
//                                    text-green-700 font-semibold 
//                                    rounded text-[13px]"
//                   >
//                     +{formatMoney(valueToShow)}
//                   </span>
//                 ) : (
//                   <span
//                     className="px-2 py-0.5 bg-red-100 
//                                    text-red-600 font-semibold 
//                                    rounded text-[13px]"
//                   >
//                     -{formatMoney(valueToShow)}
//                   </span>
//                 )}
//               </span>

//               {/* ACTION BUTTONS */}
//               <span className="flex justify-center gap-2">
//                 <button
//                   onClick={() => openUserView(u)}
//                   className="px-3 py-1 bg-blue-600 hover:bg-blue-700 
//                              text-white text-[12px] rounded-md transition"
//                 >
//                   View
//                 </button>

//                 {isAdmin && (
//                   <button
//                     onClick={() => deleteAllTargets(u)}
//                     className="px-3 py-1 bg-red-600 hover:bg-red-700 
//                                text-white text-[12px] rounded-md transition"
//                   >
//                     Delete
//                   </button>
//                 )}
//               </span>
//             </div>
//           );
//         })
//       )}
//     </div>
//   );
// }

// /* -------------------------------------------------------------------------- */
// /*                           USER DETAIL VIEW                                  */
// /* -------------------------------------------------------------------------- */

// function UserDetailView({
//   data,
//   getMonthName,
//   onBack,
//   navigate,
//   hideBack,
//   isAdmin,
// }) {
//   if (!data) return <p>No Target Found</p>;

//   // Format money as ₹ with Indian commas
//   const formatMoney = (num) => {
//     if (!num && num !== 0) return "₹0";
//     return "₹" + num.toLocaleString("en-IN");
//   };

//   const monthLabels = data.items.map((x) => getMonthName(x.month_id));
//   const targetData = data.items.map((x) => x.target);
//   const achievedData = data.items.map((x) => x.achieved);

//   const chartSeries = [
//     { name: "Target", data: targetData },
//     { name: "Achieved", data: achievedData },
//   ];

//   const chartOptions = {
//     chart: { type: "bar", height: 320, toolbar: { show: false } },
//     plotOptions: {
//       bar: { horizontal: false, columnWidth: "50%", endingShape: "rounded" },
//     },
//     dataLabels: { enabled: true },
//     xaxis: { categories: monthLabels, labels: { rotate: -45 } },
//     yaxis: { title: { text: "Amount" } },
//     colors: ["#3b82f6", "#10b981"],
//   };

//   const deleteSingle = async (id) => {
//     if (!window.confirm("Delete this target?")) return;

//     try {
//       await deleteUserTarget(id);
//       alert("Target deleted!");
//       window.location.reload();
//     } catch (err) {
//       alert("Error deleting target");
//     }
//   };

//   return (
//     <div className="p-4 bg-white border rounded-lg shadow-sm">
//       {!hideBack && (
//         <button
//           onClick={onBack}
//           className="mb-3 px-3 py-1 bg-slate-200 rounded text-[12px]"
//         >
//           ← Back
//         </button>
//       )}

//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-3">
//         <h6 className="font-[700] text-[15px] text-[#1b709b]">
//           {data.user.name}'s Target Summary
//         </h6>

//         {isAdmin && (
//           <button
//             onClick={() =>
//               navigate(`/target_fts_leads/list/create?user=${data.user._id}`)
//             }
//             className="px-3 py-1 bg-blue-600 hover:bg-blue-700 
//                        text-white text-[12px] rounded"
//           >
//             + Add Target
//           </button>
//         )}
//       </div>

//       {/* TABLE */}
//       <div className="mt-3 overflow-hidden bg-white border border-gray-300 rounded-lg shadow-sm">
//         {/* HEADER */}
//         <div
//           className="grid grid-cols-5 bg-gray-200 px-4 py-3 border-b
//                 text-[14px] font-bold text-gray-800 tracking-wide"
//         >
//           <span>Month</span>
//           <span className="text-center">Target</span>
//           <span className="text-center">Achieved</span>
//           <span className="text-center">Shortfall / Surplus</span>
//           <span className="text-center">Action</span>
//         </div>

//         {data.items.length === 0 ? (
//           <div className="p-4 text-sm text-center text-gray-500">
//             No targets found
//           </div>
//         ) : (
//           data.items.map((t, idx) => {
//             const target = t.target;
//             const achieved = t.achieved;

//             const diff = achieved - target;
//             const isSurplus = diff >= 0;
//             const valueToShow = Math.abs(diff);

//             return (
//               <div
//                 key={t._id}
//                 className={`grid grid-cols-5 px-4 py-2 border-b text-[13px]
//           ${idx % 2 === 0 ? "bg-white" : "bg-gray-50"}`}
//               >
//                 {/* MONTH */}
//                 <span className="font-semibold text-[15px] text-[#1b709b]">
//                   {getMonthName(t.month_id)}
//                 </span>

//                 {/* TARGET */}
//                 <span className="font-bold text-center text-[14px] text-black/80">
//                   {formatMoney(target)}
//                 </span>

//                 {/* ACHIEVED */}
//                 <span className="font-bold text-center text-[14px] text-black/80">
//                   {formatMoney(achieved)}
//                 </span>

//                 {/* SHORTFALL / SURPLUS */}
//                 <span className="text-center">
//                   {isSurplus ? (
//                     <span
//                       className="px-2 py-0.5 bg-green-100 
//                              text-green-700 font-semibold 
//                              rounded text-[13px]"
//                     >
//                       +{formatMoney(valueToShow)}
//                     </span>
//                   ) : (
//                     <span
//                       className="px-2 py-0.5 bg-red-100 
//                              text-red-600 font-semibold 
//                              rounded text-[13px]"
//                     >
//                       -{formatMoney(valueToShow)}
//                     </span>
//                   )}
//                 </span>

//                 {/* ACTION BUTTONS */}
//                 <span className="flex justify-center gap-2">
//                   {isAdmin && (
//                     <>
//                       <button
//                         onClick={() =>
//                           navigate(`/target_fts_leads/list/edit/${t._id}`)
//                         }
//                         className="px-3 py-1 bg-blue-600 hover:bg-blue-700 
//                            text-white text-[12px] rounded-md transition"
//                       >
//                         Edit
//                       </button>

//                       <button
//                         onClick={() => deleteSingle(t._id)}
//                         className="px-3 py-1 bg-red-600 hover:bg-red-700 
//                            text-white text-[12px] rounded-md transition"
//                       >
//                         Delete
//                       </button>
//                     </>
//                   )}
//                 </span>
//               </div>
//             );
//           })
//         )}
//       </div>

//       {/* CHART */}
//       <div className="p-4 mt-5 bg-white border rounded-lg shadow">
//         <h6 className="font-[700] text-[13px] mb-3">
//           Monthly Performance Chart
//         </h6>
//         <Chart
//           options={chartOptions}
//           series={chartSeries}
//           type="bar"
//           height={320}
//         />
//       </div>
//     </div>
//   );
// }
