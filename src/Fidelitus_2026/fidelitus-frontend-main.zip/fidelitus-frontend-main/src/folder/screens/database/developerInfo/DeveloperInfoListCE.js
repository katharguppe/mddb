import React, { useEffect, useState } from 'react'
import GoBack from '../../../components/back/GoBack'
import toast from 'react-hot-toast'
import { useLocation, useNavigate } from 'react-router-dom'
import DatabaseMenu from '../DatabaseMenu'
import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../../components/button'
import { TextAreaInput1, TextInput } from '../../../components/input'
import { CreateDBDeveloperInfoService, UpdateDBDeveloperInfoService } from '../../../services/database/DBDeveloperInfoServices'

function DeveloperInfoListCE() {
  
  const [data,setdata] = useState({name:'',mobile:'',alternate_name:'',alternate_contact:'',email:'',address:'',remarks:''})  
  const [error,seterror] = useState({name:'',mobile:'',alternate_name:'',alternate_contact:'',email:'',address:'',remarks:''})  


  const navigate = useNavigate()
  const  {state} = useLocation()

//   console.log("state",state)



  useEffect(()=>{
    if(state?._id !== undefined){
        let sendData = {...state}
        setdata(sendData)
    }
  },[state])


  async function submitform(){
    if(!data?.name){
        seterror({...error,name:'This Field is required*'})
    }else if(!data?.mobile){
        seterror({...error,mobile:'This Field is required*'})
    }else{
        let passData = {...data}
        delete passData?.created_by

        if(data?._id === undefined){
            const response = await CreateDBDeveloperInfoService(passData)
            if(response?.status === 201){
                toast.success("Developer Info Created Successfully")
                resetform()
            }
        }else{

            const response = await UpdateDBDeveloperInfoService(passData,state?._id)
            if(response?.status === 200){
                toast.success("Developer Info Updated Successfully")
                resetform()
            }
        }
    }
  }

  function resetform(){
    setdata({lead_id:'',requirment:'',remarks:'',file:'',status:''})
    seterror({lead_id:'',requirment:'',remarks:'',file:'',status:''})
    navigate(-1)

  }

  async function handlechange(e){
        setdata({...data,[e.target.name]:e.target.value})
        seterror({...error,[e.target.name]:''})
  }

 
  

  return (
    <div className='flex'>
        <div className='min-w-[180px] w-[180px] max-w-[180px]'>
        <DatabaseMenu /> 
        </div>
        <div className='ml-4 w-64 mt-4 pr-5 min-h-screen max-h-screen h-screen overflow-y-scroll'>
        <div>
        <GoBack />

        <div className='border-b  pb-2'>
        <h6 className='font-[800] mb-1'>Create / Edit Developer Info</h6> 
        <h6 className='text-[11px] leading-tight font-[500] p-2 bg-slate-100 '>Use the below form to create or update the developer info for the lead.</h6> 
        </div> 

        <TextInput 
              mandatory={true}
              label={'Developer Name'}  
              variant="standard"
              name="name"
              type="text"
              value={data.name}
              error={error.name}
              handlechange={handlechange}
              placeholder=""
              InputLabelProps={{
                  style: { color: '#fff', }, 
              }}/>  

        <TextInput 
              mandatory={true}
              label={'Mobile'}  
              variant="standard"
              name="mobile"
              type="text"
              value={data.mobile}
              error={error.mobile}
              handlechange={handlechange}
              placeholder=""
              InputLabelProps={{
                  style: { color: '#fff', }, 
              }}/>    

        <TextInput 
              mandatory={false}
              label={'Email'}  
              variant="standard"
              name="email"
              type="text"
              value={data.email}
              error={error.email}
              handlechange={handlechange}
              placeholder=""
              InputLabelProps={{
                  style: { color: '#fff', }, 
              }}/>    

        <TextInput 
              mandatory={false}
              label={'Alternate Name'}  
              variant="standard"
              name="alternate_name"
              type="text"
              value={data.alternate_name}
              error={error.alternate_name}
              handlechange={handlechange}
              placeholder=""
              InputLabelProps={{
                  style: { color: '#fff', }, 
              }}/>  

        <TextInput 
              mandatory={false}
              label={'Alternate Contact'}  
              variant="standard"
              name="alternate_contact"
              type="text"
              value={data.alternate_contact}
              error={error.alternate_contact}
              handlechange={handlechange}
              placeholder=""
              InputLabelProps={{
                  style: { color: '#fff', }, 
              }}/>                 
              

        <TextAreaInput1 
              mandatory={false}
              label={'Address'}  
              variant="standard"
              name="address"
              type="text"
              value={data.address}
              error={error.address}
              handlechange={handlechange}
              placeholder=""
              InputLabelProps={{
                  style: { color: '#fff', }, 
              }}/>  

        <TextAreaInput1 
              mandatory={false}
              label={'Remarks'}  
              variant="standard"
              name="remarks"
              type="text"
              value={data.remarks}
              error={error.remarks}
              handlechange={handlechange}
              placeholder=""
              InputLabelProps={{
                  style: { color: '#fff', }, 
              }}/>

       


        
              <div className='flex mt-2 justify-end border-t pt-2'>
               <ButtonOutlinedAutoWidth  btnName="Cancel" onClick={()=>navigate(-1)} />  
               <h6 className='w-[10px]'></h6>
               <ButtonFilledAutoWidth  btnName="Save" onClick={submitform} />  
              </div>    

        </div> 
    </div >
    </div>

  )
}

export default DeveloperInfoListCE