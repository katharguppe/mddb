import React, { useEffect, useState } from 'react'
import GoBack from '../../../components/back/GoBack'
import toast from 'react-hot-toast'
import { useLocation, useNavigate } from 'react-router-dom'
import { TextAreaInput1, TextInput } from '../../../components/input'
import DatabaseMenu from '../DatabaseMenu'
import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../../components/button'
// import { CreatePropertyTypeService, UpdatePropertyTypeService } from '../../../../services/database/databaseoptions/PropertyTypeServices'
import { GetApprovedTypeService } from '../../../services/database/databaseoptions/ApprovedTypeServices'
import { Select } from 'antd'
import {BiCheckbox,BiCheckboxSquare} from 'react-icons/bi'
import {IoClose} from 'react-icons/io5'
import { Tooltip } from '@mui/material'
import { GetPropertyZoneService } from '../../../services/database/databaseoptions/PropertyZoneServices'
import { GetPropertyAmenitiesService } from '../../../services/database/databaseoptions/PropertyAmenitiesServices'
import { FilterLocationBasedZoneService } from '../../../services/database/databaseoptions/LocationBasedZoneServices'
import { GetPropertyCategoryService } from '../../../services/database/databaseoptions/PropertyCategoryServices'
import { GetPropertyTypeService } from '../../../services/database/databaseoptions/PropertyTypeServices'
import { GetPropertyStatusService } from '../../../services/database/databaseoptions/PropertyStatusServices'
import ErrorComponent from '../../../components/errorDesign/ErrorComponent'
import { GetPropertyFacilityService } from '../../../services/database/databaseoptions/PropertyFacilityServices'
import { AiOutlineDelete } from 'react-icons/ai'
import { VscOpenPreview } from "react-icons/vsc";
import { CreateSaleBuildingService, GetSaleBuildingDetailService, UpdateSaleBuildingService, UploadSaleBuildingAttachmentService } from '../../../services/database/mainoptions/SaleBuildingServices'

function SaleBuildingCE() {
  
  const [data,setdata] = useState({main_image:'',multiple_image:[],image1:'',image2:'',image3:'',image4:'',presentation_ppt:'',project_name:'',location_and_landmark:'',land_area:'',total_built_up_area:'',no_of_floors:'',per_floor_area:'',power_and_backup:'',car_specifications:'',area_offered:'',floor_offered:'',car_parking_charges:'',posession_of_the_building:'',age_of_the_building:'',interior_details:'',contact_person:'',contact_no:'',is_deleted:false,remarks:''})  
  const [error,seterror] = useState({main_image:'',multiple_image:'',image1:'',image2:'',image3:'',image4:'',presentation_ppt:'',project_name:'',location_and_landmark:'',land_area:'',total_built_up_area:'',no_of_floors:'',per_floor_area:'',power_and_backup:'',car_specifications:'',area_offered:'',floor_offered:'',car_parking_charges:'',posession_of_the_building:'',age_of_the_building:'',interior_details:'',contact_person:'',contact_no:'',is_deleted:'',remarks:''})  

  const [step,setstep] = useState(1)

//   const [category,setcategory] = useState([])
//   const [basetypes,setbasetypes] = useState([])
//   const [zones,setzones] = useState([])
//   const [locations,setlocations] = useState([])
//   const [status,setstatus] = useState([])
//   const [amenities,setamenities] = useState([])
//   const [approvedTypes,setapprovedTypes] = useState([])
//   const [facility_type,setfacility_type] = useState([])


//   console.log("category",category)
//   console.log("zones",zones)
//   console.log("locations",locations)
//   console.log("amenities",amenities)
//   console.log("approvedTypes",approvedTypes)

  const navigate = useNavigate()
  const  {state} = useLocation()


  useEffect(()=>{
    // getdataoptions()
  },[])

  useEffect(()=>{
    if(state !== undefined && state !== null){
        getdata()
    }
  },[state])


  async function getdata() {
    const response = await GetSaleBuildingDetailService(state)
    let d = response?.data?.datas[0]
    let passData = {
       ...d,
       _id:d?._id,
    }
    setdata(passData)
  }


//   async function getdataoptions(){
//     const response = await GetPropertyZoneService(1,'','','',1)
//     const response1 = await GetPropertyAmenitiesService(1,'','','',1)
//     const response2 = await GetApprovedTypeService(1,'','','',1)
//     const response3 = await GetPropertyCategoryService(1,'','','',1)
//     const response4 = await GetPropertyTypeService(1,'','','',1)
//     const response5 = await GetPropertyStatusService(1,'','','',1)
//     const response6 = await GetPropertyFacilityService(1,'','','',1)
    
//     let arr = []
//     let arr1 = []
//     let arr2 = []
//     let arr3 = []
//     let arr4 = []
//     let arr5 = []
//     let arr6 = []

//     response?.data?.datas?.forEach((d1)=>{
//         arr.push({label:d1?.name,value:d1?._id})
//     })
//     response1?.data?.datas?.forEach((d1)=>{
//         arr1.push({label:d1?.name,value:d1?._id})
//     })
//     response2?.data?.datas?.forEach((d1)=>{
//         arr2.push({label:d1?.name,value:d1?._id})
//     })
//     response3?.data?.datas?.forEach((d1)=>{
//         arr3.push({label:d1?.name,value:d1?._id})
//     })
//     response4?.data?.datas?.forEach((d1)=>{
//         arr4.push({label:d1?.name,value:d1?._id})
//     })
//     response5?.data?.datas?.forEach((d1)=>{
//         arr5.push({label:d1?.name,value:d1?._id})
//     })
//     response6?.data?.datas?.forEach((d1)=>{
//         arr6.push({label:d1?.name,value:d1?._id})
//     })

//     setzones(arr)
//     setamenities(arr1)
//     setapprovedTypes(arr2)
//     setcategory(arr3)
//     setbasetypes(arr4)
//     setstatus(arr5)
//     setfacility_type(arr6)
//   }

//   async function getlocationbasedzone(id){
//     const response = await FilterLocationBasedZoneService(id)
//     let arr = []
//     response?.data?.datas?.forEach((d1)=>{
//         arr.push({label:d1?.name,value:d1?._id})
//     })
//     setlocations(arr)
//   }


  async function handlechange(e){
        setdata({...data,[e.target.name]:e.target.value})
        seterror({...error,[e.target.name]:''})
  }

  async function uploadfilefunc(v,name){
   
    const fd = new FormData()
    fd.append('image',v); 
    const response = await UploadSaleBuildingAttachmentService(fd)
    if(response?.status === 200){

      if(name !== 'multiple_image'){  
        setdata({...data,[name]:response?.data?.data})
        seterror({...error,[name]:''})
      }else{
        let oldDataImages = [...data.multiple_image,response?.data?.data]
        setdata({...data,[name]:oldDataImages})
        seterror({...error,[name]:''})
      }
      
    }
  }

//   async function handleSelect(v,type){
//     if(type === 'zone'){
//         getlocationbasedzone(v)
//         let d = zones?.find((f)=>f?.value === v)
//         setdata({...data,zone:d})
//         seterror({...error,zone:''})
//     }
//     if(type === 'base_type'){
//         let d = basetypes?.find((f)=>f?.value === v)
//         setdata({...data,base_type:d})
//         seterror({...error,base_type:''})
//     }
//     if(type === 'category'){
//         let d = category?.find((f)=>f?.value === v)
//         setdata({...data,property_category:d})
//         seterror({...error,property_category:''})
//     }
//     if(type === 'status'){
//         let d = status?.find((f)=>f?.value === v)
//         setdata({...data,status:d})
//         seterror({...error,status:''})
//     }
//     if(type === 'location_of_property'){
//         let d = locations?.find((f)=>f?.value === v)
//         setdata({...data,location_of_property:d})
//         seterror({...error,location_of_property:''})
//     }
//     if(type === 'facility_type'){
//         let d = facility_type?.find((f)=>f?.value === v)
//         setdata({...data,facility_type:d})
//         seterror({...error,facility_type:''})
//     }
//     if(type === 'amenities'){
//         // console.log("v here anna",v)
//         let arr = []
//         v?.forEach((v1)=>{
//            let d = amenities?.find((v2)=>v2?.value === v1)
//            if(d !== null){
//             arr.push(d)
//            }
//         })
//         setdata({...data,amenities:arr})
//     }
    
//   }

  async function submitform(){
     if(step === 1){
        // console.log("data",data)
        if(!data?.project_name){
            seterror({...error,project_name:'This Field is required'})
        }else if(!data?.location_and_landmark){
            seterror({...error,location_and_landmark:'This Field is required'})
        }else if(!data.area_offered){
            seterror({...error,area_offered:'This Field is required'})
        }else{
            setstep(2)
        }
     }else if(step === 2){
       if(!data?.main_image){
        seterror({...error,main_image:'This Field is requried'})
       }else{
        let send_data = {...data}
        if(state === undefined || state === null){
            const response = await CreateSaleBuildingService(send_data)
            if(response?.status === 201){
                resetform()
                toast.success("Sale Building Created Successfully")
            }
        }else{
            const response = await UpdateSaleBuildingService(send_data,state)
            if(response?.status === 200){
                resetform()
                navigate(-1)
                toast.success("Sale Building Updated Successfully")
            }
        }

        }
     }
  }

  async function resetform(){
    setdata({main_image:'',multiple_image:[],image1:'',image2:'',image3:'',image4:'',presentation_ppt:'',project_name:'',location_and_landmark:'',land_area:'',total_built_up_area:'',no_of_floors:'',per_floor_area:'',power_and_backup:'',car_specifications:'',area_offered:'',floor_offered:'',car_parking_charges:'',posession_of_the_building:'',age_of_the_building:'',interior_details:'',contact_person:'',contact_no:'',is_deleted:false,remarks:''})
    seterror({main_image:'',multiple_image:'',image1:'',image2:'',image3:'',image4:'',presentation_ppt:'',project_name:'',location_and_landmark:'',land_area:'',total_built_up_area:'',no_of_floors:'',per_floor_area:'',power_and_backup:'',car_specifications:'',area_offered:'',floor_offered:'',car_parking_charges:'',posession_of_the_building:'',age_of_the_building:'',interior_details:'',contact_person:'',contact_no:'',is_deleted:'',remarks:''})  
    // setlocations([])
    setstep(1)
   }

   function openFile(v){
    let url = `${process.env.REACT_APP_BACKEND_IMAGE_URL}${v}`
    window.open(url,'_blank')
   }


   function removeUploadImage(i){
    const newArr = [...data.multiple_image.slice(0, i), ...data.multiple_image.slice(i + 1)];
    setdata({...data,multiple_image:newArr})
   }

  return (
    <div className='flex'>
        <div className='min-w-[180px] w-[180px] max-w-[180px]'>
        <DatabaseMenu /> 
        </div>
        <div className='ml-4 w-[50%] mt-4 pr-5 min-h-screen max-h-screen h-screen overflow-y-scroll'>
        <div>
        <GoBack />

        <div className='border-b  pb-2'>
        <h6 className='font-[800] mb-1'>Create / Edit Sale Building</h6> 
        <h6 className='text-[11px] leading-tight font-[500] p-2 bg-slate-100 '>Use the below form to create or edit the Sale Building for the property function.</h6> 
        </div> 


        <div className='flex  border-b text-[11px]'>
           <h6 onClick={()=>setstep(1)} className={`w-[90px] cursor-pointer p-[4px] text-center ${step == 1 && 'bg-slate-600 text-white'} font-[600]`}>Basic Info</h6>
           <h6 onClick={()=>setstep(2)} className={`w-[90px] cursor-pointer p-[4px] text-center ${step == 2 && 'bg-slate-600 text-white'} font-[600]`}>Building Image</h6>
        </div>    

        {step === 1 && 
        <div className='flex items-start'>
            <div className='w-[48%] mr-[2%]'>


            <TextInput 
                mandatory={true}
                label={'Project Name'}  
                variant="standard"
                name="project_name"
                type="text"
                value={data.project_name}
                error={error.project_name}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>

            <TextInput 
                mandatory={true}
                label={'Location / Landmark'}  
                variant="standard"
                name="location_and_landmark"
                type="text"
                value={data.location_and_landmark}
                error={error.location_and_landmark}
                handlechange={handlechange}
                placeholder=""
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/> 

                <TextInput 
                mandatory={false}
                label={'Land Area'}  
                variant="standard"
                name="land_area"
                type="text"
                value={data.land_area}
                error={error.land_area}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/> 

            <TextInput 
                mandatory={false}
                label={'Total Built/Up Area'}  
                variant="standard"
                name="total_built_up_area"
                type="text"
                value={data.total_built_up_area}
                error={error.total_built_up_area}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>

            <TextInput 
                mandatory={false}
                label={'No of Floors'}  
                variant="standard"
                name="no_of_floors"
                type="text"
                value={data.no_of_floors}
                error={error.no_of_floors}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>  

            <TextInput 
                mandatory={false}
                label={'Per Floor Area'}  
                variant="standard"
                name="per_floor_area"
                type="text"
                value={data.per_floor_area}
                error={error.per_floor_area}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>  

<TextInput 
                mandatory={false}
                label={'Power And Backup'}  
                variant="standard"
                name="power_and_backup"
                type="text"
                value={data.power_and_backup}
                error={error.power_and_backup}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>  

            <TextInput 
                mandatory={false}
                label={'Car Specifications'}  
                variant="standard"
                name="car_specifications"
                type="text"
                value={data.car_specifications}
                error={error.car_specifications}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/> 


            <TextInput 
                mandatory={true}
                label={'Area Offered'}  
                variant="standard"
                name="area_offered"
                type="text"
                value={data.area_offered}
                error={error.area_offered}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/> 
    


            </div>

            <div className='w-[48%] ml-[2%]'>

            
            <TextInput 
                mandatory={false}
                label={'Floor Offered'}  
                variant="standard"
                name="floor_offered"
                type="text"
                value={data.floor_offered}
                error={error.floor_offered}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>   

            <TextInput 
                mandatory={false}
                label={'Sale For Warm Shell'}  
                variant="standard"
                name="sale_for_warm_shell"
                type="text"
                value={data.sale_for_warm_shell}
                error={error.sale_for_warm_shell}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>     


            <TextInput 
                mandatory={false}
                label={'Car Parking Charges'}  
                variant="standard"
                name="car_parking_charges"
                type="text"
                value={data.car_parking_charges}
                error={error.car_parking_charges}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>     

            <TextInput 
                mandatory={false}
                label={'Possession of the Building'}  
                variant="standard"
                name="posession_of_the_building"
                type="text"
                value={data.posession_of_the_building}
                error={error.posession_of_the_building}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>  

            <TextInput 
                mandatory={false}
                label={'Age of the Building'}  
                variant="standard"
                name="age_of_the_building"
                type="text"
                value={data.age_of_the_building}
                error={error.age_of_the_building}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>  


            <TextInput 
                mandatory={false}
                label={'Interior Details'}  
                variant="standard"
                name="interior_details"
                type="text"
                value={data.interior_details}
                error={error.interior_details}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>  

            <TextInput 
                mandatory={false}
                label={'Contact Person'}  
                variant="standard"
                name="contact_person"
                type="text"
                value={data.contact_person}
                error={error.contact_person}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>  

            <TextInput 
                mandatory={false}
                label={'Contact No'}  
                variant="standard"
                name="contact_no"
                type="text"
                value={data.contact_no}
                error={error.contact_no}
                handlechange={handlechange}
                placeholder="Enter contact name"
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>                           
               
            </div>


        </div>}

       

        {step === 2 && 
        <div className='flex flex-wrap'>

        <div className='w-[48%] mt-2 relative mr-[2%]'>
        <h6 className='text-[11px] font-[600] mb-1' >Main Image</h6>
        {!(data.main_image === '' || data.main_image == null) && <h6 onClick={()=>openFile(data?.main_image)} className='underline text-[10px] absolute cursor-pointer right-0 top-0 font-[600]'>View File</h6>}
        {(data.main_image === '' || data.main_image == null) ?
            <form onClick={()=>document.querySelector(`.input-field`).click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border border-l-4 border-l-slate-700 border-slate-300 `}>
                <input type='file' onChange={({target:{files}})=>{
                files[0] && uploadfilefunc(files[0],'main_image')
                }} accept="image/*" className='input-field' hidden />
            </form> 
        :
            <div className='p-2 border border-slate-300 border-l-4 border-l-slate-700 relative flex flex-col  cursor-pointer'>
                <Tooltip title='Delete'><IoClose className='absolute top-3 right-2' onClick={()=>setdata({...data,main_image:''})}/></Tooltip>
                <h6 className='text-[12px] truncate w-48 ml-0'>{data?.main_image}</h6>
            </div>
            
        }

        <ErrorComponent error={error?.main_image} />

        </div>


        <div className='w-[48%] mt-2 relative ml-[2%]'>
        <h6 className='text-[11px] font-[600] mb-1' >Image 1</h6>
        {!(data.image1 === '' || data.image1 == null) && <h6 onClick={()=>openFile(data?.image1)} className='underline text-[10px] absolute cursor-pointer right-0 top-0 font-[600]'>View File</h6>}
        {(data.image1 === '' || data.image1 == null) ?
            <form onClick={()=>document.querySelector(`.input-field1`).click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border border-slate-300 `}>
                <input type='file' onChange={({target:{files}})=>{
                files[0] && uploadfilefunc(files[0],'image1')
                }} accept="image/*" className='input-field1' hidden />
            </form> 
        :
            <div className='p-2 border border-slate-300 relative flex flex-col  cursor-pointer'>
                <Tooltip title='Delete'><IoClose className='absolute top-3 right-2' onClick={()=>setdata({...data,image1:''})}/></Tooltip>
                <h6 className='text-[12px] truncate w-48 ml-0'>{data?.image1}</h6>
            </div>
            
        }
        </div>

        <div className='w-[48%] mt-2 relative mr-[2%]'>
        <h6 className='text-[11px] font-[600] mb-1' >Image 2</h6>
        {!(data.image2 === '' || data.image2 == null) && <h6 onClick={()=>openFile(data?.image2)} className='underline text-[10px] absolute cursor-pointer right-0 top-0 font-[600]'>View File</h6>}
        {(data.image2 === '' || data.image2 == null) ?
            <form onClick={()=>document.querySelector(`.input-field2`).click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border border-slate-300 `}>
                <input type='file' onChange={({target:{files}})=>{
                files[0] && uploadfilefunc(files[0],'image2')
                }} accept="image/*" className='input-field2' hidden />
            </form> 
        :
            <div className='p-2 border border-slate-300 relative flex flex-col  cursor-pointer'>
                <Tooltip title='Delete'><IoClose className='absolute top-3 right-2' onClick={()=>setdata({...data,image2:''})}/></Tooltip>
                <h6 className='text-[12px] truncate w-48 ml-0'>{data?.image2}</h6>
            </div>
        }
        </div>

        <div className='w-[48%] mt-2 relative ml-[2%]'>
        <h6 className='text-[11px] font-[600] mb-1' >Image 3</h6>
        {!(data.image3 === '' || data.image3 == null) && <h6 onClick={()=>openFile(data?.image3)} className='underline text-[10px] absolute cursor-pointer right-0 top-0 font-[600]'>View File</h6>}
        {(data.image3 === '' || data.image3 == null) ?
            <form onClick={()=>document.querySelector(`.input-field3`).click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border border-slate-300 `}>
                <input type='file' onChange={({target:{files}})=>{
                files[0] && uploadfilefunc(files[0],'image3')
                }} accept="image/*" className='input-field3' hidden />
            </form> 
        :
            <div className='p-2 border border-slate-300 relative flex flex-col  cursor-pointer'>
                <Tooltip title='Delete'><IoClose className='absolute top-3 right-2' onClick={()=>setdata({...data,image3:''})}/></Tooltip>
                <h6 className='text-[12px] truncate w-48 ml-0'>{data?.image3}</h6>
            </div>
        }
        </div>

        <div className='w-[48%] mt-2 relative mr-[2%]'>
        <h6 className='text-[11px] font-[600] mb-1' >Image 4</h6>
        {!(data.image4 === '' || data.image4 == null) && <h6 onClick={()=>openFile(data?.image4)} className='underline text-[10px] absolute cursor-pointer right-0 top-0 font-[600]'>View File</h6>}
        {(data.image4 === '' || data.image4 == null) ?
            <form onClick={()=>document.querySelector(`.input-field4`).click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border  border-slate-300 `}>
                <input type='file' onChange={({target:{files}})=>{
                files[0] && uploadfilefunc(files[0],'image4')
                }} accept="image/*" className='input-field4' hidden />
            </form> 
        :
            <div className='p-2 border border-slate-300 relative flex flex-col  cursor-pointer'>
                <Tooltip title='Delete'><IoClose className='absolute top-3 right-2' onClick={()=>setdata({...data,image4:''})}/></Tooltip>
                <h6 className='text-[12px] truncate w-48 ml-0'>{data?.image4}</h6>
            </div>
        }
        </div>

        <div className='w-[48%] mt-2 relative ml-[2%]'>
        <h6 className='text-[11px] font-[600] mb-1' >Presentation PPT</h6>
        {!(data.presentation_ppt === '' || data.presentation_ppt == null) && <h6 onClick={()=>openFile(data?.presentation_ppt)} className='underline text-[10px] absolute cursor-pointer right-0 top-0 font-[600]'>View File</h6>}
        {(data.presentation_ppt === '' || data.presentation_ppt == null) ?
            <form onClick={()=>document.querySelector(`.input-field5`).click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border  border-slate-300 `}>
                <input type='file' onChange={({target:{files}})=>{
                files[0] && uploadfilefunc(files[0],'presentation_ppt')
                }} accept="*" className='input-field5' hidden />
            </form> 
        :
            <div className='p-2 border border-slate-300 relative flex flex-col  cursor-pointer'>
                <Tooltip title='Delete'><IoClose className='absolute top-3 right-2' onClick={()=>setdata({...data,presentation_ppt:''})}/></Tooltip>
                <h6 className='text-[12px] truncate w-48 ml-0'>{data?.presentation_ppt}</h6>
            </div>
        }
        </div>

        <div className='w-[48%] mt-2'>
            <h6 className='text-[11px] font-[600] mb-1' >Multiple Image</h6>
            <form onClick={()=>document.querySelector(`.input-field6`).click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border  border-slate-300 `}>
                <input type='file' onChange={({target:{files}})=>{
                files[0] && uploadfilefunc(files[0],'multiple_image')
                }} accept="image/*" className='input-field6' hidden />
            </form> 


            <div className='mt-2 flex flex-wrap'>
             {data?.multiple_image?.map((m,i)=>(
                <div key={i} className='flex border mr-1 mb-1 w-[70px] bg-slate-200'>
                   <img src={`${process.env.REACT_APP_BACKEND_IMAGE_URL}${m}`} className='w-[50px] h-[50px] object-cover' />
                   <div>
                       <AiOutlineDelete onClick={()=>removeUploadImage(i)} className='bg-white p-[2px] w-[18px] cursor-pointer border-b h-[50%]' />
                       <VscOpenPreview onClick={()=>openFile(m)} className='bg-white p-[2px] w-[18px] cursor-pointer h-[50%]' />
                   </div> 
                </div>    
             ))} 
            </div>    
        </div>    

        </div>}


        

        <div className='flex mt-2 justify-end border-t pt-2'>
            <ButtonOutlinedAutoWidth  btnName="Cancel" onClick={()=>navigate(-1)} />  
            <h6 className='w-[10px]'></h6>
            <ButtonFilledAutoWidth  btnName={step == 2 ? "Save" : "Next"} onClick={submitform} />  
        </div>    

        </div> 
    </div >
    </div>

  )
}

export default SaleBuildingCE