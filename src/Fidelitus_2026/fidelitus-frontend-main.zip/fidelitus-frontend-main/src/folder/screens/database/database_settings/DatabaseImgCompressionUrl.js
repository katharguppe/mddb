import React, { useState } from 'react';
import DatabaseMenu from '../DatabaseMenu';
import GoBack from '../../../components/back/GoBack';
import { Tooltip } from '@mui/material';
import { FiUpload } from 'react-icons/fi';
import { IoClose } from 'react-icons/io5';
import { ButtonFilledAutoWidth } from '../../../components/button';
import imageCompression from 'browser-image-compression';
import toast from 'react-hot-toast';
import {CopyToClipboard} from 'react-copy-to-clipboard';
import { UploadOfficeSpaceAttachmentService } from '../../../services/database/mainoptions/OfficeSpaceServices';
import { PiCopyDuotone } from "react-icons/pi";
import { AiOutlineClose } from 'react-icons/ai';
import { TextInput } from '../../../components/input';

function DatabaseImgCompressionUrl() {
  const [image, setImage] = useState(null);
  const [url, seturl] = useState(null);
  const [url1, seturl1] = useState(null);

  async function compressImages() {
    if (!image) return;

    const options = {
      maxSizeMB: 1.5,
      maxWidthOrHeight: 1920,
      useWebWorker: true,
    };

    try {
      const compressedFile = await imageCompression(image, options);

      // const a = document.createElement('a');
      // a.href = URL.createObjectURL(compressedFile);
      // a.download = `${image.name.split('.').slice(0, -1).join('.')}_compressed.${compressedFile.type.split('/')[1]}`;
      // a.click();
      // URL.revokeObjectURL(a.href);
      const formData = new FormData();
      formData.append('image', compressedFile,image.name);

      const response = await UploadOfficeSpaceAttachmentService(formData)
      seturl(response?.data?.data)
      // console.log("response?.data",response?.data)

      setImage(null);
      toast.success("Image has been compressed and downloaded.");
    } catch (error) {
      console.error("Compression error:", error);
      toast.error("Compression failed.");
    }
  }

  return (
    <div className='flex'>
      <div className='min-w-[180px] w-[180px] max-w-[180px]'>
        <DatabaseMenu /> 
      </div>


      <div className='ml-4 w-[300px] mt-4 pr-5 min-h-screen max-h-screen h-screen overflow-y-scroll'>
        <GoBack />
        <h6 className='font-[800] text-[13px] mb-1'>Upload The Images to get them compressed and get url</h6> 
        <h6 className='text-[11px] leading-tight mb-2 font-[500] p-2 bg-slate-100'>
          Use the below form to compress the images for the section.
        </h6> 
        {!image ? (
          <form
            onClick={() => document.querySelector('.input-field').click()}
            className='p-4 flex flex-col items-center justify-center cursor-pointer border-dashed border border-slate-400'
          >
            <FiUpload size={24} />
            <span className='font-bold text-[10px] mt-1 text-center'>Click To Upload Photo</span>
            <span className='font-bold text-[7px] mt-0 text-center'>
              Supported Types: JPEG, PNG, SVG, WEBP
            </span>
            <input
              type='file'
              onChange={({ target: { files } }) => {
                if (files?.[0]) setImage(files[0]);seturl(null)
              }}
              accept="image/*"
              className='input-field'
              hidden
            />
          </form>
        ) : (
          <div className='p-2 border relative flex flex-col'>
            <Tooltip title='Delete'>
              <IoClose
                className='absolute top-3 right-2 cursor-pointer'
                onClick={() => setImage(null)}
              />
            </Tooltip>
            <div className='text-[12px] font-medium'>{image.name}</div>
            <div className='text-[10px] text-gray-500'>
              Size: {(image.size / 1024 / 1024).toFixed(2)} MB
            </div>
          </div>
        )}

        {url && 
        <div className='flex relative text-[11px] mt-1 border p-1 border-dashed border-slate-400 rounded items-center'>
          <h6 className='mr-1 w-[95%] break-all truncate font-[600]'>URL : {url}</h6>
          <CopyToClipboard text={url} onCopy={()=>toast.success("Copied Successfully!")}>
            <PiCopyDuotone size={22} className='border cursor-pointer p-1 mr-2 rounded-full text-slate-400' />
          </CopyToClipboard>
          <AiOutlineClose className='cursor-pointer' onClick={()=>seturl('')} />
        </div>}
        
         {url && 
         <div className='border border-slate-200 rounded p-1 mt-2 h-[150px]'>
           <img src={`${process.env.REACT_APP_AWS_IMAGE_URL}${url}`} className='w-[100%] h-[100%] object-contain' />
         </div>}


        {image && (
          <div className='mt-4 flex justify-end'>
            <ButtonFilledAutoWidth onClick={compressImages} btnName="Compress & Generate URL" />
          </div>
        )}
        


        <div className='mt-2 pt-2 border-t'>
        
        <h6 className='font-[800] text-[13px] mb-1'>Preview Exisiting Image Based URL</h6>

        <TextInput type='text' value={url1} handlechange={(e)=>seturl1(e.target.value)} />

        {url1 && 
         <div className='border border-slate-200 rounded p-1 mt-2 h-[150px]'>
           <img src={`${process.env.REACT_APP_AWS_IMAGE_URL}${url1}`} alt="Image" className='w-[100%] h-[100%] object-contain' />
         </div>}
         </div>
     
      </div>

    </div>
  );
}

export default DatabaseImgCompressionUrl;




// import React, { useState } from 'react';
// import DatabaseMenu from '../DatabaseMenu';
// import GoBack from '../../../components/back/GoBack';
// import { Tooltip } from '@mui/material';
// import { FiUpload } from 'react-icons/fi';
// import { IoClose } from 'react-icons/io5';
// import { ButtonFilledAutoWidth } from '../../../components/button';
// import imageCompression from 'browser-image-compression';
// import toast from 'react-hot-toast';
// import {CopyToClipboard} from 'react-copy-to-clipboard';
// import { UploadOfficeSpaceAttachmentService } from '../../../services/database/mainoptions/OfficeSpaceServices';
// import { PiCopyDuotone } from "react-icons/pi";
// import { AiOutlineClose } from 'react-icons/ai';

// function DatabaseImgCompressionUrl() {
//   const [image, setImage] = useState(null);
//   const [url, seturl] = useState(null);

//   async function compressImages() {
//     if (!image) return;

//     const options = {
//       maxSizeMB: 1.5,
//       maxWidthOrHeight: 1920,
//       useWebWorker: true,
//     };

//     try {
//       const compressedFile = await imageCompression(image, options);

//       // const a = document.createElement('a');
//       // a.href = URL.createObjectURL(compressedFile);
//       // a.download = `${image.name.split('.').slice(0, -1).join('.')}_compressed.${compressedFile.type.split('/')[1]}`;
//       // a.click();
//       // URL.revokeObjectURL(a.href);
//       const formData = new FormData();
//       formData.append('image', compressedFile,image.name);

//       const response = await UploadOfficeSpaceAttachmentService(formData)
//       seturl(response?.data?.data)
//       // console.log("response?.data",response?.data)

//       setImage(null);
//       toast.success("Image has been compressed and downloaded.");
//     } catch (error) {
//       console.error("Compression error:", error);
//       toast.error("Compression failed.");
//     }
//   }

//   return (
//     <div className='flex'>
//       <div className='min-w-[180px] w-[180px] max-w-[180px]'>
//         <DatabaseMenu /> 
//       </div>
//       <div className='ml-4 w-[300px] mt-4 pr-5 min-h-screen max-h-screen h-screen overflow-y-scroll'>
//         <GoBack />
//         <h6 className='font-[800] text-[13px] mb-1'>Upload The Images to get them compressed and get url</h6> 
//         <h6 className='text-[11px] leading-tight mb-2 font-[500] p-2 bg-slate-100'>
//           Use the below form to compress the images for the section.
//         </h6> 
//         {!image ? (
//           <form
//             onClick={() => document.querySelector('.input-field').click()}
//             className='p-4 flex flex-col items-center justify-center cursor-pointer border-dashed border border-slate-400'
//           >
//             <FiUpload size={24} />
//             <span className='font-bold text-[10px] mt-1 text-center'>Click To Upload Photo</span>
//             <span className='font-bold text-[7px] mt-0 text-center'>
//               Supported Types: JPEG, PNG, SVG, WEBP
//             </span>
//             <input
//               type='file'
//               onChange={({ target: { files } }) => {
//                 if (files?.[0]) setImage(files[0]);seturl(null)
//               }}
//               accept="image/*"
//               className='input-field'
//               hidden
//             />
//           </form>
//         ) : (
//           <div className='p-2 border relative flex flex-col'>
//             <Tooltip title='Delete'>
//               <IoClose
//                 className='absolute top-3 right-2 cursor-pointer'
//                 onClick={() => setImage(null)}
//               />
//             </Tooltip>
//             <div className='text-[12px] font-medium'>{image.name}</div>
//             <div className='text-[10px] text-gray-500'>
//               Size: {(image.size / 1024 / 1024).toFixed(2)} MB
//             </div>
//           </div>
//         )}

//         {url && 
//         <div className='flex relative text-[11px] mt-1 border p-1 border-dashed border-slate-400 rounded items-center'>
//           <h6 className='mr-1 w-[95%] break-all truncate font-[600]'>URL : {url}</h6>
//           <CopyToClipboard text={url} onCopy={()=>toast.success("Copied Successfully!")}>
//             <PiCopyDuotone size={22} className='border cursor-pointer p-1 mr-2 rounded-full text-slate-400' />
//           </CopyToClipboard>
//           <AiOutlineClose className='cursor-pointer' onClick={()=>seturl('')} />
//         </div>}
//         {image && (
//           <div className='mt-4 flex justify-end'>
//             <ButtonFilledAutoWidth onClick={compressImages} btnName="Compress & Generate URL" />
//           </div>
//         )}
//       </div>
//     </div>
//   );
// }

// export default DatabaseImgCompressionUrl;
