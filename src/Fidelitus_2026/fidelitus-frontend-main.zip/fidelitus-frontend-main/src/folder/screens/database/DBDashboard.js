import React, { useEffect, useMemo, useState } from 'react'
import DatabaseMenu from './DatabaseMenu'
import { GetDBDashboardService, GetDBRequirmentinfoDashboardService } from '../../services/database/mainoptions/DBDashboardServices'
import {
  MdOutlineEventSeat,
  MdOutlinePendingActions,
  MdOutlineInventory2
} from "react-icons/md";
import { RiBuilding4Line } from "react-icons/ri";
import { CgToday } from "react-icons/cg";
import { LuCalendarCheck } from "react-icons/lu";
import { TbBrandBitbucket, TbProgressAlert } from "react-icons/tb";
import moment from 'moment';
import { AiOutlineDownload, AiOutlineEdit, AiOutlineSearch } from 'react-icons/ai';
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';
import fileDownload from "js-file-download";
import toast from 'react-hot-toast';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function DBDashboard() {

  const [data, setdata] = useState({})
  const [requirment, setrequirment] = useState({ datas: [], pagination: { total: 0 } })

  const [search, setsearch] = useState({
    from_date: '',
    to_date: '',
    text: '',
    limit: 10   // records per page
  })

  const [page, setPage] = useState(1)

  const navigate = useNavigate()

  async function getdata() {
    const response = await GetDBDashboardService()
    setdata(response?.data?.data)
  }

  async function getrequirmentInfo() {
    const response = await GetDBRequirmentinfoDashboardService(
      '',
      '',
      search.from_date,
      search.to_date,
      search.text,
      1000 // fetch all once, pagination handled in frontend
    )
    setrequirment(response?.data?.data)
  }

  useEffect(() => {
    getdata()
    getrequirmentInfo()
  }, [])

  /* ---------------- SEARCH FILTER LOGIC (UNCHANGED) ---------------- */
  let rupeeIndian = Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
});


  const filteredRequirements = useMemo(() => {
    if (!search.text) return requirment.datas || []

    const keyword = search.text.toLowerCase()

    return requirment.datas.filter(r => {
      const requirementText = r?.requirment?.toLowerCase() || ''
      const remarksText = r?.remarks?.toLowerCase() || ''
      const statusText = r?.status?.toLowerCase() || ''
      const fileName = r?.file
        ? r.file.split('/').pop().toLowerCase()
        : ''

      return (
        requirementText.includes(keyword) ||
        remarksText.includes(keyword) ||
        statusText.includes(keyword) ||
        fileName.includes(keyword)
      )
    })
  }, [search.text, requirment.datas])

  /* ---------------- FRONTEND PAGINATION LOGIC ---------------- */

  const totalPages = Math.ceil(filteredRequirements.length / search.limit)

  const paginatedData = useMemo(() => {
    const start = (page - 1) * search.limit
    const end = start + search.limit
    return filteredRequirements.slice(start, end)
  }, [filteredRequirements, page, search.limit])

  /* ---------------- DOWNLOAD ---------------- */

  const handleDownload = (url, filename) => {
    axios.get(url, { responseType: 'blob' }).then(res => {
      fileDownload(res.data, filename)
      toast.success("Attachment Downloaded")
    })
  }

  return (
    <div className='flex'>
      <div className='min-w-[180px]'>
        <DatabaseMenu />
      </div>

      <div className='w-full h-screen pr-5 mt-4 ml-4 overflow-y-scroll'>
      <div className='grid items-center grid-cols-6 border-t border-b border-l border-r justify-evenly border-slate-200'>
                <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/managed_office')}>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlineEventSeat size={23} className='mr-2 text-[#4070cf] p-1 bg-slate-100' />Managed Office</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.manage_office))?.split('.')[0].slice(1)}</h6>
                </div>

                <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/office_space')}>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><RiBuilding4Line size={23} className='mr-2 text-[#8a50b3] p-1 bg-slate-100' /> Office Space</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.office_space))?.split('.')[0].slice(1)}</h6>
                </div>

                <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200'>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><CgToday size={23} className='p-1 mr-2 text-yellow-500 bg-slate-100' /> Total Data</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.office_space + data?.manage_office))?.split('.')[0].slice(1)}</h6>
                </div>
                <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><TbBrandBitbucket size={23} className='p-1 mr-2 text-orange-500 bg-slate-100' /> Requirment Recieved</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.total_requirment_recieved))?.split('.')[0].slice(1)}</h6>
                </div>
                <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlinePendingActions size={23} className='p-1 mr-2 text-blue-500 bg-slate-100' /> Requirment Pending</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.total_requirment_pending))?.split('.')[0].slice(1)}</h6>
                </div>
                <div className='w-full px-2 py-2 bg-white border-b border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><LuCalendarCheck size={23} className='p-1 mr-2 text-green-500 bg-slate-100' /> Requirment Resolved</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.total_requirment_resolved))?.split('.')[0].slice(1)}</h6>
                </div>

                <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><CgToday size={23} className='p-1 mr-2 text-yellow-500 bg-slate-100' /> Today Data</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_data))?.split('.')[0].slice(1)}</h6>
                </div>
                <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><TbBrandBitbucket size={23} className='p-1 mr-2 text-orange-500 bg-slate-100' /> Today Reqr Recieved</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_requirment_recieved))?.split('.')[0].slice(1)}</h6>
                </div>
                <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlinePendingActions size={23} className='p-1 mr-2 text-blue-500 bg-slate-100' /> Today Reqr Pending</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_requirment_pending ))?.split('.')[0].slice(1)}</h6>
                </div>
                <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><LuCalendarCheck size={23} className='p-1 mr-2 text-green-500 bg-slate-100' /> Today Reqr Resolved</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_requirment_resolved))?.split('.')[0].slice(1)}</h6>
                </div>

                <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/investment_building')}>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlineInventory2 size={23} className='mr-2 text-[#6203fc] p-1 bg-slate-100' /> Investment Property</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.investment_building))?.split('.')[0].slice(1)}</h6>
                </div>

                <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/sale_building')}>
                    <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><TbProgressAlert size={23} className='mr-2 text-[#30eaff] p-1 bg-slate-100' /> Sale Property</h6>
                    <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.sale_building))?.split('.')[0].slice(1)}</h6>
                </div>
            </div>
        <div className='w-full p-2 mt-2 border'>

          {/* HEADER + SEARCH */}
        {/* HEADER + SEARCH + PAGINATION */}
<div className='flex items-center justify-between w-full mb-2'>

{/* LEFT : Title */}
<h6 className='text-slate-700 font-[800] text-[12px]'>
  Today Requirement ({filteredRequirements.length})
</h6>

{/* RIGHT : Pagination + Search */}
<div className='flex items-center gap-4'>

  {/* Pagination Controls */}
  <div className='flex items-center gap-2'>

    <button
      disabled={page === 1}
      onClick={() => setPage(prev => prev - 1)}
      className='px-2 py-1 bg-gray-200 rounded disabled:opacity-50'
    >
      <FiChevronLeft size={16} />
    </button>

    <span className='text-[12px] font-medium'>
      {page} / {totalPages || 1}
    </span>

    <button
      disabled={page === totalPages}
      onClick={() => setPage(prev => prev + 1)}
      className='px-2 py-1 bg-gray-200 rounded disabled:opacity-50'
    >
      <FiChevronRight size={16} />
    </button>

  </div>

  {/* Search Box */}
  <div className='relative w-[300px]'>
    <AiOutlineSearch className='absolute left-2 top-2.5 text-gray-400' />
    <input
      type="text"
      placeholder='Search requirement / file name / CBD / sqft...'
      className='w-full py-2 pl-8 pr-2 text-sm border rounded'
      value={search.text}
      onChange={(e) => {
        setPage(1)
        setsearch(prev => ({ ...prev, text: e.target.value }))
      }}
    />
  </div>

</div>

</div>


          <div className='mt-2 border'>
            <div className='flex text-[12px] font-[600] text-slate-600 border-b'>
              <h6 className='min-w-[10%] p-1 border-r'>SL NO</h6>
              <h6 className='min-w-[15%] p-1 border-r'>User</h6>
              <h6 className='min-w-[25%] p-1 border-r'>Requirement</h6>
              <h6 className='min-w-[15%] p-1 border-r'>Status</h6>
              <h6 className='min-w-[15%] p-1 border-r'>Remarks / File</h6>
              <h6 className='min-w-[10%] p-1 border-r'>Created</h6>
              <h6 className='min-w-[10%] p-1'>Actions</h6>
            </div>

            {paginatedData.map((r, i) => (
              <div key={r._id} className='flex text-[12px] border-t border-slate-200'>
                <h6 className='min-w-[10%] p-1 border-r'>
                  {(page - 1) * search.limit + i + 1}
                </h6>

                <h6 className='min-w-[15%] p-1 border-r font-[600]'>{r?.created_by?.name}</h6>

                <h6 className='min-w-[25%] p-1 border-r'>
                  {r?.requirment}
                  <br />
                  <h6
                    onClick={() => navigate('/leads/contacts/detail', { state: r?.lead_id?._id })}
                    className='text-blue-500 underline font-[600] cursor-pointer'
                  >
                    View Lead Info
                  </h6>
                </h6>

                <h6 className='min-w-[15%] p-1 border-r'>{r?.status}</h6>
                <h6 className='min-w-[15%] p-1 max-w-[15%] border-r '>
                                    {r?.remarks !== '' && `Remarks :`} <span className='font-[600]'>{r?.remarks}</span> <br></br>
                                        Handled By :
                                      <span className='font-[600]'>{r?.handled_by?.name}</span> 
                                    <br></br>
                                          {r?.file !== '' &&
                                       <div className='relative flex mt-1'>
                                           <img src="https://cdn-icons-png.flaticon.com/512/179/179483.png" className='z-0 object-contain w-5 h-5' />
                                            <h6 className='text-[9px] font-[800] ml-1 w-[65%]  overflow-hidden break-all line-clamp-2'>{r?.file?.split('/')[r?.file?.split('/')?.length - 1]}</h6>
                                            <AiOutlineDownload size={13} className='cursor-pointer absolute right-1 bg-slate-700 text-white p-1 text-[50px] rounded ' onClick={()=>handleDownload(`${process.env.REACT_APP_BACKEND_IMAGE_URL}${r?.file}`,r?.file?.split('/')[r?.file?.split('/')?.length - 1])} />
                                        </div>}
                                   </h6>

                <h6 className='min-w-[10%] p-1 border-r'>
                  {moment(r?.createdAt)?.format('LLL')}
                </h6>

                <h6 className='min-w-[10%] p-1'>
                  <AiOutlineEdit
                    className='mr-2 cursor-pointer'
                    onClick={() => navigate('/database/requirment_info/edit', { state: r })}
                  />
                </h6>
              </div>
            ))}

          </div>

          {/* PAGINATION CONTROLS */}
          <div className='flex items-center justify-between mt-4'>

            <button
              disabled={page === 1}
              onClick={() => setPage(prev => prev - 1)}
              className='px-3 py-1 bg-gray-200 rounded disabled:opacity-50'
            >
              <FiChevronLeft />
            </button>

            <span className='text-sm font-medium'>
              Page {page} of {totalPages || 1}
            </span>

            <button
              disabled={page === totalPages}
              onClick={() => setPage(prev => prev + 1)}
              className='px-3 py-1 bg-gray-200 rounded disabled:opacity-50'
            >
              <FiChevronRight />
            </button>

          </div>

        </div>

      </div>
    </div>
  )
}

export default DBDashboard








//================>> Old one 




// import React, { useEffect, useMemo, useState } from 'react'
// import DatabaseMenu from './DatabaseMenu'
// import { GetDBDashboardService, GetDBRequirmentinfoDashboardService } from '../../services/database/mainoptions/DBDashboardServices'
// import {
//   MdOutlineEventSeat,
//   MdOutlinePendingActions,
//   MdOutlineInventory2
// } from "react-icons/md";
// import { RiBuilding4Line } from "react-icons/ri";
// import { CgToday } from "react-icons/cg";
// import { LuCalendarCheck } from "react-icons/lu";
// import { TbBrandBitbucket, TbProgressAlert } from "react-icons/tb";
// import moment from 'moment';
// import { AiOutlineDownload, AiOutlineEdit, AiOutlineSearch } from 'react-icons/ai';
// import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';
// import fileDownload from "js-file-download";
// import toast from 'react-hot-toast';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';

// function DBDashboard() {

//   const [data, setdata] = useState({})
//   const [requirment, setrequirment] = useState({ datas: [], pagination: { total: 0 } })

//   const [search, setsearch] = useState({
//     from_date: '',
//     to_date: '',
//     text: '',
//     limit: 10   // records per page
//   })

//   const [page, setPage] = useState(1)

//   const navigate = useNavigate()

//   async function getdata() {
//     const response = await GetDBDashboardService()
//     setdata(response?.data?.data)
//   }

//   async function getrequirmentInfo() {
//     const response = await GetDBRequirmentinfoDashboardService(
//       '',
//       '',
//       search.from_date,
//       search.to_date,
//       search.text,
//       1000 // fetch all once, pagination handled in frontend
//     )
//     setrequirment(response?.data?.data)
//   }

//   useEffect(() => {
//     getdata()
//     getrequirmentInfo()
//   }, [])

//   /* ---------------- SEARCH FILTER LOGIC (UNCHANGED) ---------------- */

//   const filteredRequirements = useMemo(() => {
//     if (!search.text) return requirment.datas || []

//     const keyword = search.text.toLowerCase()

//     return requirment.datas.filter(r => {
//       const requirementText = r?.requirment?.toLowerCase() || ''
//       const remarksText = r?.remarks?.toLowerCase() || ''
//       const statusText = r?.status?.toLowerCase() || ''
//       const fileName = r?.file
//         ? r.file.split('/').pop().toLowerCase()
//         : ''

//       return (
//         requirementText.includes(keyword) ||
//         remarksText.includes(keyword) ||
//         statusText.includes(keyword) ||
//         fileName.includes(keyword)
//       )
//     })
//   }, [search.text, requirment.datas])

//   /* ---------------- FRONTEND PAGINATION LOGIC ---------------- */

//   const totalPages = Math.ceil(filteredRequirements.length / search.limit)

//   const paginatedData = useMemo(() => {
//     const start = (page - 1) * search.limit
//     const end = start + search.limit
//     return filteredRequirements.slice(start, end)
//   }, [filteredRequirements, page, search.limit])

//   /* ---------------- DOWNLOAD ---------------- */

//   const handleDownload = (url, filename) => {
//     axios.get(url, { responseType: 'blob' }).then(res => {
//       fileDownload(res.data, filename)
//       toast.success("Attachment Downloaded")
//     })
//   }

//   return (
//     <div className='flex'>
//       <div className='min-w-[180px]'>
//         <DatabaseMenu />
//       </div>

//       <div className='w-full h-screen pr-5 mt-4 ml-4 overflow-y-scroll'>

//         <div className='w-full p-2 mt-2 border'>

//           {/* HEADER + SEARCH */}
//           <div className='flex items-center justify-between w-full mb-2'>

//             <h6 className='text-slate-700 font-[800] text-[12px]'>
//               Today Requirement ({filteredRequirements.length})
//             </h6>

//             <div className='relative w-[350px]'>
//               <AiOutlineSearch className='absolute left-2 top-2.5 text-gray-400' />
//               <input
//                 type="text"
//                 placeholder='Search requirement / file name / CBD / sqft...'
//                 className='w-full py-2 pl-8 pr-2 text-sm border rounded'
//                 value={search.text}
//                 onChange={(e) => {
//                   setPage(1) // reset to first page when searching
//                   setsearch(prev => ({ ...prev, text: e.target.value }))
//                 }}
//               />
//             </div>
//           </div>

//           <div className='mt-2 border'>
//             <div className='flex text-[12px] font-[600] text-slate-600 border-b'>
//               <h6 className='min-w-[10%] p-1 border-r'>SL NO</h6>
//               <h6 className='min-w-[15%] p-1 border-r'>User</h6>
//               <h6 className='min-w-[25%] p-1 border-r'>Requirement</h6>
//               <h6 className='min-w-[15%] p-1 border-r'>Status</h6>
//               <h6 className='min-w-[15%] p-1 border-r'>Remarks / File</h6>
//               <h6 className='min-w-[10%] p-1 border-r'>Created</h6>
//               <h6 className='min-w-[10%] p-1'>Actions</h6>
//             </div>

//             {paginatedData.map((r, i) => (
//               <div key={r._id} className='flex text-[12px] border-t border-slate-200'>
//                 <h6 className='min-w-[10%] p-1 border-r'>
//                   {(page - 1) * search.limit + i + 1}
//                 </h6>

//                 <h6 className='min-w-[15%] p-1 border-r font-[600]'>{r?.created_by?.name}</h6>

//                 <h6 className='min-w-[25%] p-1 border-r'>
//                   {r?.requirment}
//                   <br />
//                   <h6
//                     onClick={() => navigate('/leads/contacts/detail', { state: r?.lead_id?._id })}
//                     className='text-blue-500 underline font-[600] cursor-pointer'
//                   >
//                     View Lead Info
//                   </h6>
//                 </h6>

//                 <h6 className='min-w-[15%] p-1 border-r'>{r?.status}</h6>
//                 <h6 className='min-w-[15%] p-1 max-w-[15%] border-r '>
//                                     {r?.remarks !== '' && `Remarks :`} <span className='font-[600]'>{r?.remarks}</span> <br></br>
//                                         Handled By :
//                                       <span className='font-[600]'>{r?.handled_by?.name}</span> 
//                                     <br></br>
//                                           {r?.file !== '' &&
//                                        <div className='relative flex mt-1'>
//                                            <img src="https://cdn-icons-png.flaticon.com/512/179/179483.png" className='z-0 object-contain w-5 h-5' />
//                                             <h6 className='text-[9px] font-[800] ml-1 w-[65%]  overflow-hidden break-all line-clamp-2'>{r?.file?.split('/')[r?.file?.split('/')?.length - 1]}</h6>
//                                             <AiOutlineDownload size={13} className='cursor-pointer absolute right-1 bg-slate-700 text-white p-1 text-[50px] rounded ' onClick={()=>handleDownload(`${process.env.REACT_APP_BACKEND_IMAGE_URL}${r?.file}`,r?.file?.split('/')[r?.file?.split('/')?.length - 1])} />
//                                         </div>}
//                                    </h6>

//                 <h6 className='min-w-[10%] p-1 border-r'>
//                   {moment(r?.createdAt)?.format('LLL')}
//                 </h6>

//                 <h6 className='min-w-[10%] p-1'>
//                   <AiOutlineEdit
//                     className='mr-2 cursor-pointer'
//                     onClick={() => navigate('/database/requirment_info/edit', { state: r })}
//                   />
//                 </h6>
//               </div>
//             ))}

//           </div>

//           {/* PAGINATION CONTROLS */}
//           <div className='flex items-center justify-between mt-4'>

//             <button
//               disabled={page === 1}
//               onClick={() => setPage(prev => prev - 1)}
//               className='px-3 py-1 bg-gray-200 rounded disabled:opacity-50'
//             >
//               <FiChevronLeft />
//             </button>

//             <span className='text-sm font-medium'>
//               Page {page} of {totalPages || 1}
//             </span>

//             <button
//               disabled={page === totalPages}
//               onClick={() => setPage(prev => prev + 1)}
//               className='px-3 py-1 bg-gray-200 rounded disabled:opacity-50'
//             >
//               <FiChevronRight />
//             </button>

//           </div>

//         </div>

//       </div>
//     </div>
//   )
// }

// export default DBDashboard






//=====>> Below is good 200 % old test 


// import React, { useEffect, useMemo, useState } from 'react'
// import DatabaseMenu from './DatabaseMenu'
// import { GetDBDashboardService, GetDBRequirmentinfoDashboardService } from '../../services/database/mainoptions/DBDashboardServices'
// import {
//   MdOutlineEventSeat,
//   MdOutlinePendingActions,
//   MdOutlineInventory2
// } from "react-icons/md";
// import { RiBuilding4Line } from "react-icons/ri";
// import { CgToday } from "react-icons/cg";
// import { LuCalendarCheck } from "react-icons/lu";
// import { TbBrandBitbucket, TbProgressAlert } from "react-icons/tb";
// import moment from 'moment';
// import { AiOutlineDownload, AiOutlineEdit, AiOutlineSearch } from 'react-icons/ai';
// import fileDownload from "js-file-download";
// import toast from 'react-hot-toast';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';

// function DBDashboard() {

//   const [data, setdata] = useState({})
//   const [requirment, setrequirment] = useState({ datas: [], pagination: { total: 0 } })
//   const [search, setsearch] = useState({
//     from_date: '',
//     to_date: '',
//     text: '',
//     limit: 100
//   })

//   const navigate = useNavigate()

//   async function getdata() {
//     const response = await GetDBDashboardService()
//     setdata(response?.data?.data)
//   }

//   async function getrequirmentInfo() {
//     const response = await GetDBRequirmentinfoDashboardService(
//       '',
//       '',
//       search.from_date,
//       search.to_date,
//       search.text,
//       search.limit
//     )
//     setrequirment(response?.data?.data)
//   }

//   useEffect(() => {
//     getdata()
//     getrequirmentInfo()
//   }, [])

  
//   let rupeeIndian = Intl.NumberFormat("en-IN", {
//     style: "currency",
//     currency: "INR",
// });

//   /* ---------------- SEARCH FILTER LOGIC ---------------- */

//   const filteredRequirements = useMemo(() => {
//     if (!search.text) return requirment.datas

//     const keyword = search.text.toLowerCase()

//     return requirment.datas.filter(r => {
//       const requirementText = r?.requirment?.toLowerCase() || ''
//       const remarksText = r?.remarks?.toLowerCase() || ''
//       const statusText = r?.status?.toLowerCase() || ''
//       const fileName = r?.file
//         ? r.file.split('/').pop().toLowerCase()
//         : ''

//       return (
//         requirementText.includes(keyword) ||
//         remarksText.includes(keyword) ||
//         statusText.includes(keyword) ||
//         fileName.includes(keyword)
//       )
//     })
//   }, [search.text, requirment.datas])

//   /* ---------------- DOWNLOAD ---------------- */

//   const handleDownload = (url, filename) => {
//     axios.get(url, { responseType: 'blob' }).then(res => {
//       fileDownload(res.data, filename)
//       toast.success("Attachment Downloaded")
//     })
//   }

//   return (
//     <div className='flex'>
//       <div className='min-w-[180px]'>
//         <DatabaseMenu />
//       </div>
     
//       <div className='w-full h-screen pr-5 mt-4 ml-4 overflow-y-scroll'>
  
//         {/* -------- TABLE -------- */}
//         <div className='w-full p-2 mt-2 border'>
//         {/* -------- HEADER + SEARCH (INLINE) -------- */}
// <div className='flex items-center justify-between w-full mb-2'>
  
//   {/* LEFT : Title */}
//   <h6 className='text-slate-700 font-[800] text-[12px]'>
//     Today Requirement123 ({filteredRequirements.length})
//   </h6>

//   {/* RIGHT : Search */}
//   <div className='relative w-[350px]'>
//     <AiOutlineSearch className='absolute left-2 top-2.5 text-gray-400' />
//     <input
//       type="text"
//       placeholder='Search requirement / file name / CBD / sqft...'
//       className='w-full py-2 pl-8 pr-2 text-sm border rounded'
//       value={search.text}
//       onChange={(e) =>
//         setsearch(prev => ({ ...prev, text: e.target.value }))
//       }
//     />
//   </div>

// </div>


//           <div className='mt-2 border'>
//             <div className='flex text-[12px] font-[600] text-slate-600 border-b'>
//               <h6 className='min-w-[10%] p-1 border-r'>SL NO</h6>
//               <h6 className='min-w-[15%] p-1 border-r'>User</h6>
//               <h6 className='min-w-[25%] p-1 border-r'>Requirement</h6>
//               <h6 className='min-w-[15%] p-1 border-r'>Status</h6>
//               <h6 className='min-w-[15%] p-1 border-r'>Remarks / File</h6>
//               <h6 className='min-w-[10%] p-1 border-r'>Created</h6>
//               <h6 className='min-w-[10%] p-1'>Actions</h6>
//             </div>

//             {filteredRequirements.map((r, i) => (
//                                      <div className='flex text-[12px] z-50 stickt top-0 border-t border-slate-200'>
//                                      <h6 className='min-w-[10%] p-1 max-w-[10%] border-r'>{i+1}</h6>
//                                      <h6 className='min-w-[15%] p-1 max-w-[15%] border-r font-[600]'>{r?.created_by?.name}</h6>
//                                      <h6 className='min-w-[25%] p-1 max-w-[25%] border-r'>{r?.requirment} <br></br>
//                              <h6  onClick={()=>navigate('/leads/contacts/detail',{state:r?.lead_id?._id})} className='text-blue-500 underline font-[600] cursor-pointer'>View Lead Info</h6>
         
//                                      </h6>
//                                      <h6 className='min-w-[15%] p-1 max-w-[15%] border-r'>{r?.status}</h6>
//                                      <h6 className='min-w-[15%] p-1 max-w-[15%] border-r '>
//                                      {r?.remarks !== '' && `Remarks :`} <span className='font-[600]'>{r?.remarks}</span> <br></br>
//                                         Handled By :
//                                         <span className='font-[600]'>{r?.handled_by?.name}</span> 
//                                         <br></br>
//                                          {r?.file !== '' &&
//                                          <div className='relative flex mt-1'>
//                                              <img src="https://cdn-icons-png.flaticon.com/512/179/179483.png" className='z-0 object-contain w-5 h-5' />
//                                              <h6 className='text-[9px] font-[800] ml-1 w-[65%]  overflow-hidden break-all line-clamp-2'>{r?.file?.split('/')[r?.file?.split('/')?.length - 1]}</h6>
//                                              <AiOutlineDownload size={13} className='cursor-pointer absolute right-1 bg-slate-700 text-white p-1 text-[50px] rounded ' onClick={()=>handleDownload(`${process.env.REACT_APP_BACKEND_IMAGE_URL}${r?.file}`,r?.file?.split('/')[r?.file?.split('/')?.length - 1])} />
//                                          </div>}
//                                       </h6>
//                                      <h6 className='min-w-[10%] p-1 max-w-[10%] border-r'>{moment(r?.createdAt)?.format('LLL')}</h6>
//                                      <h6 className='min-w-[10%] p-1 max-w-[10%] '>
//                                          <AiOutlineEdit className='mr-2' onClick={()=>navigate('/database/requirment_info/edit',{state:r})} />
//                                      </h6>
//                                  </div>
//             ))}
//           </div>
//         </div>

//       </div>
//     </div>
//   )
// }

// export default DBDashboard




//===========>> Pagination not working old is good



// import React, { useEffect, useMemo, useState } from 'react'
// import DatabaseMenu from './DatabaseMenu'
// import { GetDBDashboardService, GetDBRequirmentinfoDashboardService } from '../../services/database/mainoptions/DBDashboardServices'
// import {
//   MdOutlineEventSeat,
//   MdOutlinePendingActions,
//   MdOutlineInventory2
// } from "react-icons/md";
// import { RiBuilding4Line } from "react-icons/ri";
// import { CgToday } from "react-icons/cg";
// import { LuCalendarCheck } from "react-icons/lu";
// import { TbBrandBitbucket, TbProgressAlert } from "react-icons/tb";
// import moment from 'moment';
// import { AiOutlineDownload, AiOutlineEdit, AiOutlineSearch } from 'react-icons/ai';
// import fileDownload from "js-file-download";
// import toast from 'react-hot-toast';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';

// function DBDashboard() {

//   const [data, setdata] = useState({})
//   const [requirment, setrequirment] = useState({ datas: [], pagination: { total: 0 } })
//   const [search, setsearch] = useState({
//     from_date: '',
//     to_date: '',
//     text: '',
//     limit: 100
//   })

//   const navigate = useNavigate()

//   async function getdata() {
//     const response = await GetDBDashboardService()
//     setdata(response?.data?.data)
//   }

//   async function getrequirmentInfo() {
//     const response = await GetDBRequirmentinfoDashboardService(
//       '',
//       '',
//       search.from_date,
//       search.to_date,
//       search.text,
//       search.limit
//     )
//     setrequirment(response?.data?.data)
//   }

//   useEffect(() => {
//     getdata()
//     getrequirmentInfo()
//   }, [])

  
//   let rupeeIndian = Intl.NumberFormat("en-IN", {
//     style: "currency",
//     currency: "INR",
// });

//   /* ---------------- SEARCH FILTER LOGIC ---------------- */

//   const filteredRequirements = useMemo(() => {
//     if (!search.text) return requirment.datas

//     const keyword = search.text.toLowerCase()

//     return requirment.datas.filter(r => {
//       const requirementText = r?.requirment?.toLowerCase() || ''
//       const remarksText = r?.remarks?.toLowerCase() || ''
//       const statusText = r?.status?.toLowerCase() || ''
//       const fileName = r?.file
//         ? r.file.split('/').pop().toLowerCase()
//         : ''

//       return (
//         requirementText.includes(keyword) ||
//         remarksText.includes(keyword) ||
//         statusText.includes(keyword) ||
//         fileName.includes(keyword)
//       )
//     })
//   }, [search.text, requirment.datas])

//   /* ---------------- DOWNLOAD ---------------- */

//   const handleDownload = (url, filename) => {
//     axios.get(url, { responseType: 'blob' }).then(res => {
//       fileDownload(res.data, filename)
//       toast.success("Attachment Downloaded")
//     })
//   }

//   return (
//     <div className='flex'>
//       <div className='min-w-[180px]'>
//         <DatabaseMenu />
//       </div>
     
//       <div className='w-full h-screen pr-5 mt-4 ml-4 overflow-y-scroll'>
//       <div className='grid items-center grid-cols-6 border-t border-b border-l border-r justify-evenly border-slate-200'>
//                 <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/managed_office')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlineEventSeat size={23} className='mr-2 text-[#4070cf] p-1 bg-slate-100' />Managed Office</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.manage_office))?.split('.')[0].slice(1)}</h6>
//                 </div>

//                 <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/office_space')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><RiBuilding4Line size={23} className='mr-2 text-[#8a50b3] p-1 bg-slate-100' /> Office Space</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.office_space))?.split('.')[0].slice(1)}</h6>
//                 </div>

//                 <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200'>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><CgToday size={23} className='p-1 mr-2 text-yellow-500 bg-slate-100' /> Total Data</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.office_space + data?.manage_office))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><TbBrandBitbucket size={23} className='p-1 mr-2 text-orange-500 bg-slate-100' /> Requirment Recieved</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.total_requirment_recieved))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlinePendingActions size={23} className='p-1 mr-2 text-blue-500 bg-slate-100' /> Requirment Pending</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.total_requirment_pending))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-b border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><LuCalendarCheck size={23} className='p-1 mr-2 text-green-500 bg-slate-100' /> Requirment Resolved</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.total_requirment_resolved))?.split('.')[0].slice(1)}</h6>
//                 </div>

//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><CgToday size={23} className='p-1 mr-2 text-yellow-500 bg-slate-100' /> Today Data</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_data))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><TbBrandBitbucket size={23} className='p-1 mr-2 text-orange-500 bg-slate-100' /> Today Reqr Recieved</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_requirment_recieved))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlinePendingActions size={23} className='p-1 mr-2 text-blue-500 bg-slate-100' /> Today Reqr Pending</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_requirment_pending ))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><LuCalendarCheck size={23} className='p-1 mr-2 text-green-500 bg-slate-100' /> Today Reqr Resolved</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_requirment_resolved))?.split('.')[0].slice(1)}</h6>
//                 </div>

//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/investment_building')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlineInventory2 size={23} className='mr-2 text-[#6203fc] p-1 bg-slate-100' /> Investment Property</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.investment_building))?.split('.')[0].slice(1)}</h6>
//                 </div>

//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/sale_building')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><TbProgressAlert size={23} className='mr-2 text-[#30eaff] p-1 bg-slate-100' /> Sale Property</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.sale_building))?.split('.')[0].slice(1)}</h6>
//                 </div>
//             </div>

//         {/* -------- TABLE -------- */}
//         <div className='w-full p-2 mt-2 border'>
//           {/* <h6 className='text-slate-700 font-[800] text-[12px]'>
//             Today Requirement ({filteredRequirements.length})
//           </h6>
//         <div className='flex items-center mb-3'>
//           <div className='relative w-[350px]'>
//             <AiOutlineSearch className='absolute top-2.5 left-2 text-gray-400' />
//             <input
//               type="text"
//               placeholder='Search requirement / file name / CBD / sqft...'
//               className='w-full py-2 pl-8 pr-2 text-sm border rounded'
//               value={search.text}
//               onChange={(e) =>
//                 setsearch(prev => ({ ...prev, text: e.target.value }))
//               }
//             />
//           </div>
//         </div> */}

//         {/* -------- HEADER + SEARCH (INLINE) -------- */}
// <div className='flex items-center justify-between w-full mb-2'>
  
//   {/* LEFT : Title */}
//   <h6 className='text-slate-700 font-[800] text-[12px]'>
//     Today Requirement123 ({filteredRequirements.length})
//   </h6>

//   {/* RIGHT : Search */}
//   <div className='relative w-[350px]'>
//     <AiOutlineSearch className='absolute left-2 top-2.5 text-gray-400' />
//     <input
//       type="text"
//       placeholder='Search requirement / file name / CBD / sqft...'
//       className='w-full py-2 pl-8 pr-2 text-sm border rounded'
//       value={search.text}
//       onChange={(e) =>
//         setsearch(prev => ({ ...prev, text: e.target.value }))
//       }
//     />
//   </div>

// </div>


//           <div className='mt-2 border'>
//             <div className='flex text-[12px] font-[600] text-slate-600 border-b'>
//               <h6 className='min-w-[10%] p-1 border-r'>SL NO</h6>
//               <h6 className='min-w-[15%] p-1 border-r'>User</h6>
//               <h6 className='min-w-[25%] p-1 border-r'>Requirement</h6>
//               <h6 className='min-w-[15%] p-1 border-r'>Status</h6>
//               <h6 className='min-w-[15%] p-1 border-r'>Remarks / File</h6>
//               <h6 className='min-w-[10%] p-1 border-r'>Created</h6>
//               <h6 className='min-w-[10%] p-1'>Actions</h6>
//             </div>

//             {filteredRequirements.map((r, i) => (
//                                      <div className='flex text-[12px] z-50 stickt top-0 border-t border-slate-200'>
//                                      <h6 className='min-w-[10%] p-1 max-w-[10%] border-r'>{i+1}</h6>
//                                      <h6 className='min-w-[15%] p-1 max-w-[15%] border-r font-[600]'>{r?.created_by?.name}</h6>
//                                      <h6 className='min-w-[25%] p-1 max-w-[25%] border-r'>{r?.requirment} <br></br>
//                              <h6  onClick={()=>navigate('/leads/contacts/detail',{state:r?.lead_id?._id})} className='text-blue-500 underline font-[600] cursor-pointer'>View Lead Info</h6>
         
//                                      </h6>
//                                      <h6 className='min-w-[15%] p-1 max-w-[15%] border-r'>{r?.status}</h6>
//                                      <h6 className='min-w-[15%] p-1 max-w-[15%] border-r '>
//                                      {r?.remarks !== '' && `Remarks :`} <span className='font-[600]'>{r?.remarks}</span> <br></br>
//                                         Handled By :
//                                         <span className='font-[600]'>{r?.handled_by?.name}</span> 
//                                         <br></br>
//                                          {r?.file !== '' &&
//                                          <div className='relative flex mt-1'>
//                                              <img src="https://cdn-icons-png.flaticon.com/512/179/179483.png" className='z-0 object-contain w-5 h-5' />
//                                              <h6 className='text-[9px] font-[800] ml-1 w-[65%]  overflow-hidden break-all line-clamp-2'>{r?.file?.split('/')[r?.file?.split('/')?.length - 1]}</h6>
//                                              <AiOutlineDownload size={13} className='cursor-pointer absolute right-1 bg-slate-700 text-white p-1 text-[50px] rounded ' onClick={()=>handleDownload(`${process.env.REACT_APP_BACKEND_IMAGE_URL}${r?.file}`,r?.file?.split('/')[r?.file?.split('/')?.length - 1])} />
//                                          </div>}
//                                       </h6>
//                                      <h6 className='min-w-[10%] p-1 max-w-[10%] border-r'>{moment(r?.createdAt)?.format('LLL')}</h6>
//                                      <h6 className='min-w-[10%] p-1 max-w-[10%] '>
//                                          <AiOutlineEdit className='mr-2' onClick={()=>navigate('/database/requirment_info/edit',{state:r})} />
//                                      </h6>
//                                  </div>
//             ))}
//           </div>
//         </div>

//       </div>
//     </div>
//   )
// }

// export default DBDashboard



//=============>>Current deployes code below is without filter old code 2026 changes



// import React, { useEffect, useState } from 'react'
// import DatabaseMenu from './DatabaseMenu'
// import { GetDBDashboardService, GetDBRequirmentinfoDashboardService } from '../../services/database/mainoptions/DBDashboardServices'
// import { MdOutlineEventSeat } from "react-icons/md";
// import { RiBuilding4Line } from "react-icons/ri";
// import { CgToday } from "react-icons/cg";
// import { MdOutlinePendingActions } from "react-icons/md";
// import { LuCalendarCheck } from "react-icons/lu";
// import { TbBrandBitbucket } from "react-icons/tb";
// import { MdOutlineInventory2 } from "react-icons/md";
// import { TbProgressAlert } from "react-icons/tb";
// import moment from 'moment';
// import { AiOutlineDownload, AiOutlineEdit } from 'react-icons/ai';
// import fileDownload from "js-file-download";
// import toast from 'react-hot-toast';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';


// function DBDashboard() {

//     const [data,setdata] = useState({})
//     const [requirment,setrequirment] = useState({datas:[],pagination:{total:0}})
    

//     const [search,setsearch] = useState({from_date:'',to_date:'',text:'',limit:100,step:''})

//     const navigate = useNavigate()

//     async function getdata(){
//         const response = await GetDBDashboardService()
//         setdata(response?.data?.data)
//     }

//     async function getrequirmentInfo() {
//         const response = await GetDBRequirmentinfoDashboardService('','',search?.from_date,search?.to_date,search?.text,search?.limit)
//         setrequirment(response?.data?.data)
//     }

//     useEffect(()=>{
//         getdata()
//         getrequirmentInfo()
//     },[])

//     let rupeeIndian = Intl.NumberFormat("en-IN", {
//         style: "currency",
//         currency: "INR",
//     });


//     const handleDownload = (url, filename) => {
//         axios.get(url, {
//             responseType: 'blob',
//         })
//             .then((res) => {
//                 fileDownload(res.data, filename)
//                 toast.success("Attachment Downloaded") 
//             })
//       }

//     return (
//     <div className='flex'>
//         <div className='min-w-[180px] w-[180px] max-w-[180px]'>
//         <DatabaseMenu /> 
//         </div>
//         <div className='ml-4 w-[100%] mt-4 pr-5 min-h-screen max-h-screen h-screen overflow-y-scroll'>
//         <div>


//             <div className='grid items-center grid-cols-6 border-t border-b border-l border-r justify-evenly border-slate-200'>
//                 <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/managed_office')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlineEventSeat size={23} className='mr-2 text-[#4070cf] p-1 bg-slate-100' />Managed Office</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.manage_office))?.split('.')[0].slice(1)}</h6>
//                 </div>

//                 <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/office_space')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><RiBuilding4Line size={23} className='mr-2 text-[#8a50b3] p-1 bg-slate-100' /> Office Space</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.office_space))?.split('.')[0].slice(1)}</h6>
//                 </div>

//                 <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200'>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><CgToday size={23} className='p-1 mr-2 text-yellow-500 bg-slate-100' /> Total Data</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.office_space + data?.manage_office))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><TbBrandBitbucket size={23} className='p-1 mr-2 text-orange-500 bg-slate-100' /> Requirment Recieved</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.total_requirment_recieved))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-b border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlinePendingActions size={23} className='p-1 mr-2 text-blue-500 bg-slate-100' /> Requirment Pending</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.total_requirment_pending))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-b border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><LuCalendarCheck size={23} className='p-1 mr-2 text-green-500 bg-slate-100' /> Requirment Resolved</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.total_requirment_resolved))?.split('.')[0].slice(1)}</h6>
//                 </div>

//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><CgToday size={23} className='p-1 mr-2 text-yellow-500 bg-slate-100' /> Today Data</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_data))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><TbBrandBitbucket size={23} className='p-1 mr-2 text-orange-500 bg-slate-100' /> Today Reqr Recieved</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_requirment_recieved))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlinePendingActions size={23} className='p-1 mr-2 text-blue-500 bg-slate-100' /> Today Reqr Pending</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_requirment_pending ))?.split('.')[0].slice(1)}</h6>
//                 </div>
//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/requirment_info')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><LuCalendarCheck size={23} className='p-1 mr-2 text-green-500 bg-slate-100' /> Today Reqr Resolved</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.today_requirment_resolved))?.split('.')[0].slice(1)}</h6>
//                 </div>

//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/investment_building')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><MdOutlineInventory2 size={23} className='mr-2 text-[#6203fc] p-1 bg-slate-100' /> Investment Property</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.investment_building))?.split('.')[0].slice(1)}</h6>
//                 </div>

//                 <div className='w-full px-2 py-2 bg-white border-r border-slate-200' onClick={()=>navigate('/database/sale_building')}>
//                     <h6 className='text-[12px] text-slate-700 font-[800] flex items-center'><TbProgressAlert size={23} className='mr-2 text-[#30eaff] p-1 bg-slate-100' /> Sale Property</h6>
//                     <h6 className='text-[14px] mt-1'>{rupeeIndian?.format(JSON.stringify(data?.sale_building))?.split('.')[0].slice(1)}</h6>
//                 </div>
//             </div>


//             <div className='mt-2 w-[100%] border p-2'>
//                 <h6 className='text-slate-700 font-[800] text-[12px]'>Today Requirment ({requirment?.pagination?.total})</h6>



//                 <div className='mt-2 border'>
//                     <div className='flex text-[12px] font-[600] text-slate-600 z-50 stickt top-0  border-slate-200'>
//                         <h6 className='min-w-[10%] p-1 max-w-[10%] border-r'>SL NO</h6>
//                         <h6 className='min-w-[15%] p-1 max-w-[15%] border-r'>User Info</h6>
//                         <h6 className='min-w-[25%] p-1 max-w-[25%] border-r'>Requirement</h6>
//                         <h6 className='min-w-[15%] p-1 max-w-[15%] border-r'>Status</h6>
//                         <h6 className='min-w-[15%] p-1 max-w-[15%] border-r'>Remarks / Handled By</h6>
//                         <h6 className='min-w-[10%] p-1 max-w-[10%] border-r'>Created At</h6>
//                         <h6 className='min-w-[10%] p-1 max-w-[10%] '>Actions</h6>
//                     </div>
//                     {requirment?.datas?.map((r,i)=>(
//                         <div className='flex text-[12px] z-50 stickt top-0 border-t border-slate-200'>
//                             <h6 className='min-w-[10%] p-1 max-w-[10%] border-r'>{i+1}</h6>
//                             <h6 className='min-w-[15%] p-1 max-w-[15%] border-r font-[600]'>{r?.created_by?.name}</h6>
//                             <h6 className='min-w-[25%] p-1 max-w-[25%] border-r'>{r?.requirment} <br></br>
//                     <h6  onClick={()=>navigate('/leads/contacts/detail',{state:r?.lead_id?._id})} className='text-blue-500 underline font-[600] cursor-pointer'>View Lead Info</h6>

//                             </h6>
//                             <h6 className='min-w-[15%] p-1 max-w-[15%] border-r'>{r?.status}</h6>
//                             <h6 className='min-w-[15%] p-1 max-w-[15%] border-r '>
//                             {r?.remarks !== '' && `Remarks :`} <span className='font-[600]'>{r?.remarks}</span> <br></br>
//                                Handled By :
//                                <span className='font-[600]'>{r?.handled_by?.name}</span> 
//                                <br></br>
//                                 {r?.file !== '' &&
//                                 <div className='relative flex mt-1'>
//                                     <img src="https://cdn-icons-png.flaticon.com/512/179/179483.png" className='z-0 object-contain w-5 h-5' />
//                                     <h6 className='text-[9px] font-[800] ml-1 w-[65%]  overflow-hidden break-all line-clamp-2'>{r?.file?.split('/')[r?.file?.split('/')?.length - 1]}</h6>
//                                     <AiOutlineDownload size={13} className='cursor-pointer absolute right-1 bg-slate-700 text-white p-1 text-[50px] rounded ' onClick={()=>handleDownload(`${process.env.REACT_APP_BACKEND_IMAGE_URL}${r?.file}`,r?.file?.split('/')[r?.file?.split('/')?.length - 1])} />
//                                 </div>}
//                              </h6>
//                             <h6 className='min-w-[10%] p-1 max-w-[10%] border-r'>{moment(r?.createdAt)?.format('LLL')}</h6>
//                             <h6 className='min-w-[10%] p-1 max-w-[10%] '>
//                                 <AiOutlineEdit className='mr-2' onClick={()=>navigate('/database/requirment_info/edit',{state:r})} />
//                             </h6>
//                         </div>
//                     ))}

//                 </div>
//             </div>


//         </div>
//         </div>    
//     </div>
//   )
// }

// export default DBDashboard