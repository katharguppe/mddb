import React, { useState } from 'react';
import DatabaseMenu from '../DatabaseMenu';
import GoBack from '../../../components/back/GoBack';
import { Tooltip } from '@mui/material';
import { FiUpload } from 'react-icons/fi';
import { IoClose } from 'react-icons/io5';
import { ButtonFilledAutoWidth } from '../../../components/button';
import imageCompression from 'browser-image-compression';
import toast from 'react-hot-toast';

function DatabaseImgCompression() {
  
  const [images, setImages] = useState([]);

  async function compressImages() {
    const options = {
      maxSizeMB: 1.5,
      maxWidthOrHeight: 1920,
      useWebWorker: true,
    };
    try {
      const compressedFiles = await Promise.all(
        images.map(image => imageCompression(image, options))
      );
      compressedFiles.forEach((compressedFile, index) => {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(compressedFile);
        a.download = `${images[index].name}_compressed.jpg`;
        a.click();
        URL.revokeObjectURL(a.href);
      });
      setImages([]);
      toast.success("Your images have been compressed and downloaded.");
    } catch (error) {
      console.log(error);
    }
  }
  function convertFileSizeToMB(size) {
    return (size / 1024 / 1024).toFixed(2);
  }
  return (
    <div className='flex'>
      <div className='min-w-[180px] w-[180px] max-w-[180px]'>
        <DatabaseMenu /> 
      </div>
      <div className='ml-4 w-[300px] mt-4 pr-5 min-h-screen max-h-screen h-screen overflow-y-scroll'>
        <div>
          <GoBack />
          <h6 className='font-[800] text-[13px] mb-1'>Upload The Images to get them compressed</h6> 
          <h6 className='text-[11px] leading-tight mb-2 font-[500] p-2 bg-slate-100 '>Use the below form to compress the images for the section.</h6> 
          {(images.length === 0) ?
            <form onClick={() => document.querySelector('.input-field').click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border-dashed border border-slate-400`}>
              <FiUpload size={24} />
              <span className='font-bold text-[10px] mt-1 text-center'>Click To Upload Photos</span>
              <span className='font-bold text-[7px] mt-0 text-center'>Supported Types: JPEG, PNG, SVG, WEBP, PDF, XLSX, PPT</span>
              <input type='file' onChange={({ target: { files } }) => {
                const filesArray = Array.from(files);
                setImages(filesArray);
              }} accept="image/*" className='input-field' hidden multiple />
            </form> 
            :
            <div className='p-2 border relative flex flex-col cursor-pointer'>
              <Tooltip title='Delete'><IoClose className='absolute top-3 right-2' onClick={() => setImages([])} /></Tooltip>
              {images.map((image, index) => (
                <h6 key={index} className='text-[12px] truncate w-48 ml-0'>{image.name}</h6>
              ))}
            </div>
          }
          {(images.length > 0) &&
          <div>
            <h6 className='text-[12px] font-[500]'>Total File Size Uploaded: 
              <span className='font-[700]'> {(images.reduce((acc, img) => acc + img.size, 0) / 1024 / 1024).toFixed(2)} MB</span>
            </h6>
          </div>}
          {(images.length > 0) &&
          <div className='mt-4 flex justify-end'>
             <ButtonFilledAutoWidth onClick={compressImages} btnName="Compress & Download" />
          </div>}
        </div>
      </div>
    </div>  
  );
}
export default DatabaseImgCompression;