import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import * as XLSX from "xlsx";

import {
  createClientBusiness,
  getClientBusinessById,
  updateClientBusiness,
} from "../../services/ClientBusinessService";
import { GetDepartmentService } from "../../services/DepartmentServices";

export default function ClientMdCE() {
  const navigate = useNavigate();
  const auth = useSelector((state) => state.Auth);
  const { id } = useParams();

  const isEdit = Boolean(id);

  /* ===============================
     ROLE CHECKS
  ================================ */
  const isAdmin = auth?.roles?.includes("admin");
  const isMdAdmin = auth?.roles?.includes("md_admin");
  const isSuperAdmin = isAdmin || isMdAdmin;

  const userDepartmentId =
    auth?.department_id?.[0]?.id || auth?.department_id?.[0]?._id || "";

  /* ===============================
     STATE
  ================================ */
  const [loading, setLoading] = useState(false);
  const [departments, setDepartments] = useState([]);

  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const [form, setForm] = useState({
    company_name: "",
    client_name: "",
    email: "",
    phone: "",
    department_id: "",
    year: 2030, // 🔑 always master
  });

  /* ===============================
     EXCEL HEADER ALIASES
  ================================ */
  const HEADER_ALIASES = {
    company_name: ["company", "company name", "Company Name"],
    client_name: ["client", "client name", "Client Name"],
    email: ["email", "email id", "Email"],
    phone: ["phone", "phone number", "mobile", "Phone Number"],
  };

  const getValueByHeader = (row, aliases) => {
    for (const key of Object.keys(row)) {
      if (aliases.some(a => a.toLowerCase() === key.toLowerCase().trim())) {
        return row[key];
      }
    }
    return "";
  };

  /* ===============================
     INITIAL LOAD
  ================================ */
  useEffect(() => {
    loadDepartments();
    if (isEdit) loadData();
  }, [id]);

  const loadDepartments = async () => {
    try {
      const res = await GetDepartmentService();
      setDepartments(res?.data?.datas || []);
    } catch (err) {
      console.error(err);
    }
  };

  const loadData = async () => {
    try {
      const res = await getClientBusinessById(id);
      const data = res?.data?.data;

      setForm({
        company_name: data.company_name || "",
        client_name: data.client_name || "",
        email: data.email || "",
        phone: data.phone || "",
        department_id:
          typeof data.department_id === "object"
            ? data.department_id.id
            : data.department_id,
        year: 2030, // 🔒 force master
      });
    } catch (err) {
      alert("Failed to load Master Data");
      navigate("/client_md");
    }
  };

  /* ===============================
     HANDLE CHANGE
  ================================ */
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(p => ({ ...p, [name]: value }));
  };

  /* ===============================
     SAVE (CREATE / UPDATE)
  ================================ */
  const save = async () => {
    if (!form.company_name || !form.client_name) {
      alert("Company Name and Client Name are required");
      return;
    }

    const payload = {
      company_name: form.company_name,
      client_name: form.client_name,
      email: form.email || "",
      phone: form.phone || "",
      year: 2030, // 🔑 MASTER FLAG
      department_id: isSuperAdmin ? form.department_id : userDepartmentId,
    };

    if (!payload.department_id) {
      alert("Department is required");
      return;
    }

    setLoading(true);
    try {
      if (isEdit) {
        await updateClientBusiness(id, payload); // ✅ FIXED
        alert("Master Data updated successfully");
      } else {
        await createClientBusiness(payload);
        alert("Master Data added successfully");
      }
      navigate("/client_md");
    } catch (err) {
      alert("Failed to save Master Data");
    } finally {
      setLoading(false);
    }
  };

  /* ===============================
     EXCEL UPLOAD (ONLY CREATE MODE)
  ================================ */
  const handleExcelUpload = async (file) => {
    if (!file) return;

    if (isEdit) {
      alert("Excel upload is disabled in Edit mode");
      return;
    }

    if (isSuperAdmin && !form.department_id) {
      alert("Please select Department before uploading Excel");
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        const workbook = XLSX.read(e.target.result, { type: "binary" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet);

        if (!rows.length) throw new Error("Excel file is empty");

        let uploaded = 0;

        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          const rowNo = i + 2;

          const company = getValueByHeader(row, HEADER_ALIASES.company_name);
          const client = getValueByHeader(row, HEADER_ALIASES.client_name);

          if (!company || !client) {
            throw new Error(`Missing Company or Client at row ${rowNo}`);
          }

          await createClientBusiness({
            company_name: company,
            client_name: client,
            email: getValueByHeader(row, HEADER_ALIASES.email) || "",
            phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
            year: 2030,
            department_id: isSuperAdmin
              ? form.department_id
              : userDepartmentId,
          });

          uploaded++;
          setUploadProgress(Math.round((uploaded / rows.length) * 100));
        }

        alert("✅ Excel uploaded successfully");
        navigate("/client_md");
      } catch (err) {
        alert(err.message || "Excel upload failed");
      } finally {
        setUploading(false);
      }
    };

    reader.readAsBinaryString(file);
  };

  /* ===============================
     RENDER
  ================================ */
  return (
    <div className="max-w-xl p-6">
      <div className="flex justify-between mb-4">
        <h6 className="font-[700] text-[15px]">
          {isEdit ? "Edit Client Master Data" : "Add Client Master Data"}
        </h6>
        <button
          onClick={() => navigate("/client_md")}
          className="text-[12px] text-blue-600 underline"
        >
          Back to List
        </button>
      </div>

      <div className="p-5 space-y-3 bg-white border rounded shadow-sm">

        {/* DEPARTMENT */}
        {isSuperAdmin && (
          <select
            name="department_id"
            value={form.department_id}
            onChange={handleChange}
            className="w-full border px-3 py-2 rounded text-[13px]"
          >
            <option value="">Select Department *</option>
            {departments.map(d => (
              <option key={d.id} value={d.id}>
                {d.department_name}
              </option>
            ))}
          </select>
        )}

        {/* EXCEL UPLOAD */}
        {!isEdit && (
          <label className="block text-center px-3 py-2 bg-green-600 text-white rounded text-[12px] cursor-pointer">
            {uploading
              ? `Uploading ${uploadProgress}%`
              : "Upload Excel (Master Data)"}
            <input
              type="file"
              hidden
              accept=".xls,.xlsx"
              disabled={uploading}
              onChange={(e) => handleExcelUpload(e.target.files[0])}
            />
          </label>
        )}

        <div className="text-center text-[11px] text-gray-500">
          Excel columns: Company Name | Client Name | Email | Phone Number
        </div>

        <hr />

        {/* MANUAL ENTRY */}
        <input
          name="company_name"
          value={form.company_name}
          onChange={handleChange}
          placeholder="Company Name *"
          className="w-full border px-3 py-2 rounded text-[13px]"
        />

        <input
          name="client_name"
          value={form.client_name}
          onChange={handleChange}
          placeholder="Client Name *"
          className="w-full border px-3 py-2 rounded text-[13px]"
        />

        <input
          name="email"
          value={form.email}
          onChange={handleChange}
          placeholder="Email"
          className="w-full border px-3 py-2 rounded text-[13px]"
        />

        <input
          name="phone"
          value={form.phone}
          onChange={handleChange}
          placeholder="Phone"
          className="w-full border px-3 py-2 rounded text-[13px]"
        />

        <div className="flex gap-2 pt-3">
          <button
            onClick={() => navigate("/client_md")}
            className="px-4 py-1 border rounded text-[12px]"
          >
            Cancel
          </button>

          <button
            onClick={save}
            disabled={loading}
            className="px-4 py-1 bg-blue-600 text-white rounded text-[12px]"
          >
            {loading ? "Saving..." : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
}









//=======+>> Old 1/02/2026

// import React, { useEffect, useState } from "react";
// import { useNavigate, useParams } from "react-router-dom";
// import { useSelector } from "react-redux";
// import * as XLSX from "xlsx";

// import {
//   createClientBusiness,
//   getClientBusinessById,
//   updateClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService } from "../../services/DepartmentServices";

// export default function ClientMdCE() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);
//   const { id } = useParams();

//   const isEdit = Boolean(id);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isSuperAdmin = isAdmin || isMdAdmin;

//   const userDepartmentId =
//     auth?.department_id?.[0]?.id || auth?.department_id?.[0]?._id || "";

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(false);
//   const [departments, setDepartments] = useState([]);

//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);

//   const [form, setForm] = useState({
//     company_name: "",
//     client_name: "",
//     email: "",
//     phone: "",
//     department_id: "",
//     year: 2030, // 🔑 always master
//   });

//   /* ===============================
//      EXCEL HEADER ALIASES
//   ================================ */
//   const HEADER_ALIASES = {
//     company_name: ["company", "company name", "Company Name"],
//     client_name: ["client", "client name", "Client Name"],
//     email: ["email", "email id", "Email"],
//     phone: ["phone", "phone number", "mobile", "Phone Number"],
//   };

//   const getValueByHeader = (row, aliases) => {
//     for (const key of Object.keys(row)) {
//       if (aliases.some(a => a.toLowerCase() === key.toLowerCase().trim())) {
//         return row[key];
//       }
//     }
//     return "";
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadDepartments();
//     if (isEdit) loadData();
//   }, [id]);

//   const loadDepartments = async () => {
//     try {
//       const res = await GetDepartmentService();
//       setDepartments(res?.data?.datas || []);
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   const loadData = async () => {
//     try {
//       const res = await getClientBusinessById(id);
//       const data = res?.data?.data;

//       setForm({
//         company_name: data.company_name || "",
//         client_name: data.client_name || "",
//         email: data.email || "",
//         phone: data.phone || "",
//         department_id:
//           typeof data.department_id === "object"
//             ? data.department_id.id
//             : data.department_id,
//         year: 2030, // 🔒 force master
//       });
//     } catch (err) {
//       alert("Failed to load Master Data");
//       navigate("/client_md");
//     }
//   };

//   /* ===============================
//      HANDLE CHANGE
//   ================================ */
//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setForm(p => ({ ...p, [name]: value }));
//   };

//   /* ===============================
//      SAVE (CREATE / UPDATE)
//   ================================ */
//   const save = async () => {
//     if (!form.company_name || !form.client_name) {
//       alert("Company Name and Client Name are required");
//       return;
//     }

//     const payload = {
//       company_name: form.company_name,
//       client_name: form.client_name,
//       email: form.email || "",
//       phone: form.phone || "",
//       year: 2030, // 🔑 MASTER FLAG
//       department_id: isSuperAdmin ? form.department_id : userDepartmentId,
//     };

//     if (!payload.department_id) {
//       alert("Department is required");
//       return;
//     }

//     setLoading(true);
//     try {
//       if (isEdit) {
//         await updateClientBusiness(id, payload); // ✅ FIXED
//         alert("Master Data updated successfully");
//       } else {
//         await createClientBusiness(payload);
//         alert("Master Data added successfully");
//       }
//       navigate("/client_md");
//     } catch (err) {
//       alert("Failed to save Master Data");
//     } finally {
//       setLoading(false);
//     }
//   };

//   /* ===============================
//      EXCEL UPLOAD (ONLY CREATE MODE)
//   ================================ */
//   const handleExcelUpload = async (file) => {
//     if (!file) return;

//     if (isEdit) {
//       alert("Excel upload is disabled in Edit mode");
//       return;
//     }

//     if (isSuperAdmin && !form.department_id) {
//       alert("Please select Department before uploading Excel");
//       return;
//     }

//     setUploading(true);
//     setUploadProgress(0);

//     const reader = new FileReader();

//     reader.onload = async (e) => {
//       try {
//         const workbook = XLSX.read(e.target.result, { type: "binary" });
//         const sheet = workbook.Sheets[workbook.SheetNames[0]];
//         const rows = XLSX.utils.sheet_to_json(sheet);

//         if (!rows.length) throw new Error("Excel file is empty");

//         let uploaded = 0;

//         for (let i = 0; i < rows.length; i++) {
//           const row = rows[i];
//           const rowNo = i + 2;

//           const company = getValueByHeader(row, HEADER_ALIASES.company_name);
//           const client = getValueByHeader(row, HEADER_ALIASES.client_name);

//           if (!company || !client) {
//             throw new Error(`Missing Company or Client at row ${rowNo}`);
//           }

//           await createClientBusiness({
//             company_name: company,
//             client_name: client,
//             email: getValueByHeader(row, HEADER_ALIASES.email) || "",
//             phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
//             year: 2030,
//             department_id: isSuperAdmin
//               ? form.department_id
//               : userDepartmentId,
//           });

//           uploaded++;
//           setUploadProgress(Math.round((uploaded / rows.length) * 100));
//         }

//         alert("✅ Excel uploaded successfully");
//         navigate("/client_md");
//       } catch (err) {
//         alert(err.message || "Excel upload failed");
//       } finally {
//         setUploading(false);
//       }
//     };

//     reader.readAsBinaryString(file);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="max-w-xl p-6">
//       <div className="flex justify-between mb-4">
//         <h6 className="font-[700] text-[15px]">
//           {isEdit ? "Edit Client Master Data" : "Add Client Master Data"}
//         </h6>
//         <button
//           onClick={() => navigate("/client_md")}
//           className="text-[12px] text-blue-600 underline"
//         >
//           Back to List
//         </button>
//       </div>

//       <div className="p-5 space-y-3 bg-white border rounded shadow-sm">

//         {/* DEPARTMENT */}
//         {isSuperAdmin && (
//           <select
//             name="department_id"
//             value={form.department_id}
//             onChange={handleChange}
//             className="w-full border px-3 py-2 rounded text-[13px]"
//           >
//             <option value="">Select Department *</option>
//             {departments.map(d => (
//               <option key={d.id} value={d.id}>
//                 {d.department_name}
//               </option>
//             ))}
//           </select>
//         )}

//         {/* EXCEL UPLOAD */}
//         {!isEdit && (
//           <label className="block text-center px-3 py-2 bg-green-600 text-white rounded text-[12px] cursor-pointer">
//             {uploading
//               ? `Uploading ${uploadProgress}%`
//               : "Upload Excel (Master Data)"}
//             <input
//               type="file"
//               hidden
//               accept=".xls,.xlsx"
//               disabled={uploading}
//               onChange={(e) => handleExcelUpload(e.target.files[0])}
//             />
//           </label>
//         )}

//         <div className="text-center text-[11px] text-gray-500">
//           Excel columns: Company Name | Client Name | Email | Phone Number
//         </div>

//         <hr />

//         {/* MANUAL ENTRY */}
//         <input
//           name="company_name"
//           value={form.company_name}
//           onChange={handleChange}
//           placeholder="Company Name *"
//           className="w-full border px-3 py-2 rounded text-[13px]"
//         />

//         <input
//           name="client_name"
//           value={form.client_name}
//           onChange={handleChange}
//           placeholder="Client Name *"
//           className="w-full border px-3 py-2 rounded text-[13px]"
//         />

//         <input
//           name="email"
//           value={form.email}
//           onChange={handleChange}
//           placeholder="Email"
//           className="w-full border px-3 py-2 rounded text-[13px]"
//         />

//         <input
//           name="phone"
//           value={form.phone}
//           onChange={handleChange}
//           placeholder="Phone"
//           className="w-full border px-3 py-2 rounded text-[13px]"
//         />

//         <div className="flex gap-2 pt-3">
//           <button
//             onClick={() => navigate("/client_md")}
//             className="px-4 py-1 border rounded text-[12px]"
//           >
//             Cancel
//           </button>

//           <button
//             onClick={save}
//             disabled={loading}
//             className="px-4 py-1 bg-blue-600 text-white rounded text-[12px]"
//           >
//             {loading ? "Saving..." : "Save"}
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }
