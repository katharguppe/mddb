import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import {
  getMyClientBusiness,
  filterClientBusiness,
} from "../../services/ClientBusinessService";
import {
  GetDepartmentService,
  GetUsersByDepartment,
} from "../../services/DepartmentServices";

export default function ClientMdMatrix() {
  const navigate = useNavigate();
  const auth = useSelector((state) => state.Auth);

  /* ===============================
     ROLE CHECKS
  ================================ */
  const isAdmin = auth?.roles?.includes("admin");
  const isMdAdmin = auth?.roles?.includes("md_admin");
  const isHod = auth?.roles?.includes("hod");

  const isSuperAdmin = isAdmin || isMdAdmin;
  const isHodOnly = isHod && !isSuperAdmin;

  /* ===============================
     STATE
  ================================ */
  const [loading, setLoading] = useState(true);
  const [departments, setDepartments] = useState([]);
  const [matrixData, setMatrixData] = useState([]);
  const [sortedMatrixDepartments, setSortedMatrixDepartments] = useState([]);

  const [departmentId, setDepartmentId] = useState("");
  const [selectedUser, setSelectedUser] = useState("");
  const [usersList, setUsersList] = useState([]);

  // 🔍 SEARCH
  const [searchCompany, setSearchCompany] = useState("");

  // 👁 NA → Client toggle state
  const [showClientForNA, setShowClientForNA] = useState({});

  const [viewMode, setViewMode] = useState("analytics");

  /* ===============================
     ALLOWED MATRIX DEPARTMENTS
  ================================ */
  const MATRIX_DEPARTMENT_NAMES = [
    "Transaction Team",
    "FMS Team",
    "HR Team",
    "Project Team",
    "Shilpa Foundation",
    "Fidelitus Gallery",
    "FTS Team",
  ];

  /* ===============================
     TOGGLE HANDLER
  ================================ */
  const handleToggle = (mode) => {
    setViewMode(mode);
    if (mode === "overall") navigate("/client_business");
    if (mode === "master") navigate("/client_md");
    if (mode === "analytics") navigate("/client_md/analytics");
  };

  const toggleClientName = (key) => {
    setShowClientForNA((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  /* ===============================
     INITIAL LOAD
  ================================ */
  useEffect(() => {
    loadInitial();
  }, []);

  const loadInitial = async () => {
    setLoading(true);
    try {
      const depRes = await GetDepartmentService();
      const deps = depRes?.data?.datas || [];
      setDepartments(deps);

      let res;
      if (isSuperAdmin) {
        res = await filterClientBusiness({});
      } else if (isHodOnly) {
        res = await filterClientBusiness({
          department_id: auth?.department_id?.[0]?.id,
        });
      } else {
        res = await getMyClientBusiness();
      }

      const masterData = (res?.data?.data || []).filter(
        (c) => Number(c.year) === 2030
      );

      buildMatrix(masterData, deps);
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  /* ===============================
     BUILD MATRIX
  ================================ */
  const buildMatrix = (data, deps) => {
    const clientMap = {};
    const departmentClientMap = {};

    deps.forEach((d) => {
      departmentClientMap[d.id] = new Set();
    });

    data.forEach((c) => {
      const key = c.company_name;

      if (!clientMap[key]) {
        clientMap[key] = {
          company_name: c.company_name,
          client_name: c.client_name, // 👈 IMPORTANT
          departments: new Set(),
        };
      }

      const depId =
        typeof c.department_id === "object"
          ? c.department_id.id
          : c.department_id;

      clientMap[key].departments.add(depId);
      departmentClientMap[depId]?.add(key);
    });

    const rows = Object.values(clientMap)
      .map((row) => ({
        ...row,
        departments: Array.from(row.departments),
        departmentCount: row.departments.size,
      }))
      .sort((a, b) => b.departmentCount - a.departmentCount);

    const sortedDeps = deps
      .filter((d) => MATRIX_DEPARTMENT_NAMES.includes(d.department_name))
      .map((d) => ({
        ...d,
        clientCount: departmentClientMap[d.id]?.size || 0,
      }))
      .sort((a, b) => b.clientCount - a.clientCount);

    setMatrixData(rows);
    setSortedMatrixDepartments(sortedDeps);
  };

  /* ===============================
     SEARCH FILTER
  ================================ */
  const filteredMatrixData = matrixData.filter((row) =>
    row.company_name.toLowerCase().includes(searchCompany.toLowerCase())
  );

  /* ===============================
     RENDER
  ================================ */
  return (
    <div className="p-6">
      {/* HEADER */}
      <div className="flex items-center justify-between mb-4">
        <h6 className="font-bold text-[15px]">Client Master Data list</h6>

        <div className="flex border rounded overflow-hidden text-[12px]">
          <button
            onClick={() => handleToggle("overall")}
            className={`px-3 py-1 ${
              viewMode === "overall" ? "bg-blue-600 text-white" : "bg-white"
            }`}
          >
            Overall Data
          </button>
          <button
            onClick={() => handleToggle("master")}
            className={`px-3 py-1 ${
              viewMode === "master" ? "bg-blue-600 text-white" : "bg-white"
            }`}
          >
            Master Data
          </button>
          <button
            onClick={() => handleToggle("analytics")}
            className={`px-3 py-1 ${
              viewMode === "analytics" ? "bg-blue-600 text-white" : "bg-white"
            }`}
          >
            Clients Analytics
          </button>
        </div>

        <button
          onClick={() => navigate("/client_md/create")}
          className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
        >
          + Add Master Data
        </button>
      </div>

      {/* SEARCH */}
      <div className="mb-3">
        <input
          type="text"
          placeholder="Search by Company Name"
          value={searchCompany}
          onChange={(e) => setSearchCompany(e.target.value)}
          className="border px-3 py-1 text-[12px] rounded w-[260px]"
        />
      </div>

      {/* TABLE */}
      <div className="overflow-auto bg-white border rounded">
        <table className="min-w-full text-[12px]">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-2 text-left">Client Name</th>
              {sortedMatrixDepartments.map((d) => (
                <th key={d.id} className="p-2 text-center">
                  {d.department_name}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {loading ? (
              <tr>
                <td
                  colSpan={sortedMatrixDepartments.length + 1}
                  className="p-4 text-center"
                >
                  Loading...
                </td>
              </tr>
            ) : filteredMatrixData.length === 0 ? (
              <tr>
                <td
                  colSpan={sortedMatrixDepartments.length + 1}
                  className="p-4 text-center text-gray-500"
                >
                  No matching clients found
                </td>
              </tr>
            ) : (
              filteredMatrixData.map((row, i) => (
                <tr key={i} className="border-t">
                  <td className="p-2 font-semibold">
                    {row.company_name !== "NA" ? (
                      row.company_name
                    ) : (
                      <div className="flex items-center gap-2">
                        {!showClientForNA[row.company_name] ? (
                          <>
                            <span>NA</span>
                            <button
                              onClick={() =>
                                toggleClientName(row.company_name)
                              }
                              className="text-blue-600 underline text-[11px]"
                            >
                              View Client
                            </button>
                          </>
                        ) : (
                          <>
                            <span>{row.client_name}</span>
                            <button
                              onClick={() =>
                                toggleClientName(row.company_name)
                              }
                              className="text-gray-500 underline text-[11px]"
                            >
                              Hide
                            </button>
                          </>
                        )}
                      </div>
                    )}
                  </td>

                  {sortedMatrixDepartments.map((d) => (
                    <td key={d.id} className="p-2 text-center">
                      {row.departments.includes(d.id) ? (
                        <span className="font-bold text-green-600">✔</span>
                      ) : (
                        <span className="font-bold text-red-600">✖</span>
                      )}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}









//=========>>> Filter Done


// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import {
//   getMyClientBusiness,
//   filterClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdMatrix() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [departments, setDepartments] = useState([]);
//   const [matrixData, setMatrixData] = useState([]);
//   const [sortedMatrixDepartments, setSortedMatrixDepartments] = useState([]);

//   // filters
//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");
//   const [usersList, setUsersList] = useState([]);

//   // 🔍 SEARCH (NEW)
//   const [searchCompany, setSearchCompany] = useState("");

//   const [viewMode, setViewMode] = useState("analytics");

//   /* ===============================
//      ALLOWED MATRIX DEPARTMENTS
//   ================================ */
//   const MATRIX_DEPARTMENT_NAMES = [
//     "Transaction Team",
//     "FMS Team",
//     "HR Team",
//     "Project Team",
//     "Shilpa Foundation",
//     "Fidelitus Gallery",
//     "FTS Team",
//   ];

//   /* ===============================
//      TOGGLE HANDLER
//   ================================ */
//   const handleToggle = (mode) => {
//     setViewMode(mode);
//     if (mode === "overall") navigate("/client_business");
//     if (mode === "master") navigate("/client_md");
//     if (mode === "analytics") navigate("/client_md/analytics");
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       const deps = depRes?.data?.datas || [];
//       setDepartments(deps);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       buildMatrix(masterData, deps);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      BUILD MATRIX
//   ================================ */
//   const buildMatrix = (data, deps) => {
//     const clientMap = {};
//     const departmentClientMap = {};

//     deps.forEach((d) => {
//       departmentClientMap[d.id] = new Set();
//     });

//     data.forEach((c) => {
//       const key = c.company_name;

//       if (!clientMap[key]) {
//         clientMap[key] = {
//           company_name: c.company_name,
//           departments: new Set(),
//         };
//       }

//       const depId =
//         typeof c.department_id === "object"
//           ? c.department_id.id
//           : c.department_id;

//       clientMap[key].departments.add(depId);
//       departmentClientMap[depId]?.add(key);
//     });

//     // 🔝 SORT CLIENTS BY DEPARTMENT COUNT
//     const rows = Object.values(clientMap)
//       .map((row) => ({
//         ...row,
//         departments: Array.from(row.departments),
//         departmentCount: row.departments.size,
//       }))
//       .sort((a, b) => b.departmentCount - a.departmentCount);

//     // 🔝 SORT DEPARTMENTS BY CLIENT COUNT
//     const sortedDeps = deps
//       .filter((d) => MATRIX_DEPARTMENT_NAMES.includes(d.department_name))
//       .map((d) => ({
//         ...d,
//         clientCount: departmentClientMap[d.id]?.size || 0,
//       }))
//       .sort((a, b) => b.clientCount - a.clientCount);

//     setMatrixData(rows);
//     setSortedMatrixDepartments(sortedDeps);
//   };

//   /* ===============================
//      FILTER USERS BY DEPARTMENT
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     const res = await GetUsersByDepartment(deptId);
//     setUsersList(
//       (res?.data?.datas || []).map((u) => ({
//         label: u.name,
//         value: u._id,
//       }))
//     );
//   };

//   /* ===============================
//      SEARCH FILTER (CLIENT NAME)
//   ================================ */
//   const filteredMatrixData = matrixData.filter((row) =>
//     row.company_name
//       .toLowerCase()
//       .includes(searchCompany.toLowerCase())
//   );

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data list</h6>

//         {/* TOGGLE */}
//         <div className="flex border rounded overflow-hidden text-[12px]">
//           <button
//             onClick={() => handleToggle("overall")}
//             className={`px-3 py-1 ${
//               viewMode === "overall" ? "bg-blue-600 text-white" : "bg-white"
//             }`}
//           >
//             Overall Data
//           </button>

//           <button
//             onClick={() => handleToggle("master")}
//             className={`px-3 py-1 ${
//               viewMode === "master" ? "bg-blue-600 text-white" : "bg-white"
//             }`}
//           >
//             Master Data
//           </button>

//           <button
//             onClick={() => handleToggle("analytics")}
//             className={`px-3 py-1 ${
//               viewMode === "analytics" ? "bg-blue-600 text-white" : "bg-white"
//             }`}
//           >
//             Clients Analytics
//           </button>
//         </div>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div>

//       {/* 🔍 SEARCH */}
//       <div className="mb-3">
//         <input
//           type="text"
//           placeholder="Search by Company Name"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded w-[260px]"
//         />
//       </div>

//       {/* MATRIX TABLE */}
//       <div className="overflow-auto bg-white border rounded">
//         <table className="min-w-full text-[12px]">
//           <thead className="bg-gray-100">
//             <tr>
//               <th className="p-2 text-left">Client Name</th>
//               {sortedMatrixDepartments.map((d) => (
//                 <th key={d.id} className="p-2 text-center">
//                   {d.department_name}
//                 </th>
//               ))}
//             </tr>
//           </thead>

//           <tbody>
//             {loading ? (
//               <tr>
//                 <td
//                   colSpan={sortedMatrixDepartments.length + 1}
//                   className="p-4 text-center"
//                 >
//                   Loading...
//                 </td>
//               </tr>
//             ) : filteredMatrixData.length === 0 ? (
//               <tr>
//                 <td
//                   colSpan={sortedMatrixDepartments.length + 1}
//                   className="p-4 text-center text-gray-500"
//                 >
//                   No matching clients found
//                 </td>
//               </tr>
//             ) : (
//               filteredMatrixData.map((row, i) => (
//                 <tr key={i} className="border-t">
//                   <td className="p-2 font-semibold">
//                     {row.company_name}
//                   </td>

//                   {sortedMatrixDepartments.map((d) => (
//                     <td key={d.id} className="p-2 text-center">
//                       {row.departments.includes(d.id) ? (
//                         <span className="font-bold text-green-600">✔</span>
//                       ) : (
//                         <span className="font-bold text-red-600">✖</span>
//                       )}
//                     </td>
//                   ))}
//                 </tr>
//               ))
//             )}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// }









//=======>> Applying filter



// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import {
//   getMyClientBusiness,
//   filterClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdMatrix() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [departments, setDepartments] = useState([]);
//   const [matrixData, setMatrixData] = useState([]);
//   const [sortedMatrixDepartments, setSortedMatrixDepartments] = useState([]);

//   // filters (unchanged)
//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
//   const [viewMode, setViewMode] = useState("analytics");

//   /* ===============================
//      ALLOWED MATRIX DEPARTMENTS
//   ================================ */
//   const MATRIX_DEPARTMENT_NAMES = [
//     "Transaction Team",
//     "FMS Team",
//     "HR Team",
//     "Project Team",
//     "Shilpa Foundation",
//     "Fidelitus Gallery",
//     "FTS Team",
//   ];

//   /* ===============================
//      TOGGLE HANDLER
//   ================================ */
//   const handleToggle = (mode) => {
//     setViewMode(mode);
//     if (mode === "overall") navigate("/client_business");
//     if (mode === "master") navigate("/client_md");
//     if (mode === "analytics") navigate("/client_md/analytics");
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       const deps = depRes?.data?.datas || [];
//       setDepartments(deps);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       buildMatrix(masterData, deps);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      BUILD MATRIX
//      ✔ Sort departments by client count
//      ✔ Sort clients by department count
//   ================================ */
//   const buildMatrix = (data, deps) => {
//     const clientMap = {};
//     const departmentClientMap = {};

//     // init department sets
//     deps.forEach((d) => {
//       departmentClientMap[d.id] = new Set();
//     });

//     data.forEach((c) => {
//       const key = c.company_name;

//       if (!clientMap[key]) {
//         clientMap[key] = {
//           company_name: c.company_name,
//           departments: new Set(),
//         };
//       }

//       const depId =
//         typeof c.department_id === "object"
//           ? c.department_id.id
//           : c.department_id;

//       clientMap[key].departments.add(depId);
//       departmentClientMap[depId]?.add(key);
//     });

//     /* ===============================
//        SORT CLIENTS BY MAX DEPARTMENTS (DESC)
//     ================================ */
//     const rows = Object.values(clientMap)
//       .map((row) => ({
//         ...row,
//         departments: Array.from(row.departments),
//         departmentCount: row.departments.size,
//       }))
//       .sort((a, b) => b.departmentCount - a.departmentCount);

//     /* ===============================
//        SORT DEPARTMENTS BY CLIENT COUNT (DESC)
//     ================================ */
//     const sortedDeps = deps
//       .filter((d) => MATRIX_DEPARTMENT_NAMES.includes(d.department_name))
//       .map((d) => ({
//         ...d,
//         clientCount: departmentClientMap[d.id]?.size || 0,
//       }))
//       .sort((a, b) => b.clientCount - a.clientCount);

//     setMatrixData(rows);
//     setSortedMatrixDepartments(sortedDeps);
//   };

//   /* ===============================
//      FILTER USERS BY DEPARTMENT
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     const res = await GetUsersByDepartment(deptId);
//     setUsersList(
//       (res?.data?.datas || []).map((u) => ({
//         label: u.name,
//         value: u._id,
//       }))
//     );
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data list</h6>

//         {/* TOGGLE */}
//         <div className="flex border rounded overflow-hidden text-[12px]">
//           <button
//             onClick={() => handleToggle("overall")}
//             className={`px-3 py-1 ${
//               viewMode === "overall" ? "bg-blue-600 text-white" : "bg-white"
//             }`}
//           >
//             Overall Data
//           </button>

//           <button
//             onClick={() => handleToggle("master")}
//             className={`px-3 py-1 ${
//               viewMode === "master" ? "bg-blue-600 text-white" : "bg-white"
//             }`}
//           >
//             Master Data
//           </button>

//           <button
//             onClick={() => handleToggle("analytics")}
//             className={`px-3 py-1 ${
//               viewMode === "analytics" ? "bg-blue-600 text-white" : "bg-white"
//             }`}
//           >
//             Clients Analytics
//           </button>
//         </div>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div>

//       {/* MATRIX TABLE */}
//       <div className="overflow-auto bg-white border rounded">
//         <table className="min-w-full text-[12px]">
//           <thead className="bg-gray-100">
//             <tr>
//               <th className="p-2 text-left">Client Name</th>
//               {sortedMatrixDepartments.map((d) => (
//                 <th key={d.id} className="p-2 text-center">
//                   {d.department_name}
//                 </th>
//               ))}
//             </tr>
//           </thead>

//           <tbody>
//             {loading ? (
//               <tr>
//                 <td
//                   colSpan={sortedMatrixDepartments.length + 1}
//                   className="p-4 text-center"
//                 >
//                   Loading...
//                 </td>
//               </tr>
//             ) : (
//               matrixData.map((row, i) => (
//                 <tr key={i} className="border-t">
//                   <td className="p-2 font-semibold">
//                     {row.company_name}
//                   </td>

//                   {sortedMatrixDepartments.map((d) => (
//                     <td key={d.id} className="p-2 text-center">
//                       {row.departments.includes(d.id) ? (
//                         <span className="font-bold text-green-600">✔</span>
//                       ) : (
//                         <span className="font-bold text-red-600">✖</span>
//                       )}
//                     </td>
//                   ))}
//                 </tr>
//               ))
//             )}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// }









//=====>> Old one 


// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import {
//   getMyClientBusiness,
//   filterClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdMatrix() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [departments, setDepartments] = useState([]);
//   const [matrixData, setMatrixData] = useState([]);
//   const [sortedMatrixDepartments, setSortedMatrixDepartments] = useState([]);

//   // filters (unchanged)
//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
//   const [viewMode, setViewMode] = useState("analytics");

//   /* ===============================
//      ALLOWED MATRIX DEPARTMENTS
//   ================================ */
//   const MATRIX_DEPARTMENT_NAMES = [
//     "Transaction Team",
//     "FMS Team",
//     "HR Team",
//     "Project Team",
//     "Shilpa Foundation",
//     "Fidelitus Gallery",
//     "FTS Team",
//   ];

//   /* ===============================
//      TOGGLE HANDLER
//   ================================ */
//   const handleToggle = (mode) => {
//     setViewMode(mode);

//     if (mode === "overall") navigate("/client_business");
//     if (mode === "master") navigate("/client_md");
//     if (mode === "analytics") navigate("/client_md/analytics");
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       const deps = depRes?.data?.datas || [];
//       setDepartments(deps);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       buildMatrix(masterData, deps);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      BUILD MATRIX + SORT DEPARTMENTS
//   ================================ */
//   const buildMatrix = (data, deps) => {
//     const clientMap = {};
//     const departmentClientMap = {};

//     // init department sets
//     deps.forEach((d) => {
//       departmentClientMap[d.id] = new Set();
//     });

//     data.forEach((c) => {
//       const key = c.company_name;

//       if (!clientMap[key]) {
//         clientMap[key] = {
//           company_name: c.company_name,
//           departments: new Set(),
//         };
//       }

//       const depId =
//         typeof c.department_id === "object"
//           ? c.department_id.id
//           : c.department_id;

//       clientMap[key].departments.add(depId);
//       departmentClientMap[depId]?.add(key);
//     });

//     // rows
//     const rows = Object.values(clientMap).map((row) => ({
//       ...row,
//       departments: Array.from(row.departments),
//     }));

//     // 🔑 SORT DEPARTMENTS BY CLIENT COUNT (DESC)
//     const sortedDeps = deps
//       .filter((d) => MATRIX_DEPARTMENT_NAMES.includes(d.department_name))
//       .map((d) => ({
//         ...d,
//         clientCount: departmentClientMap[d.id]?.size || 0,
//       }))
//       .sort((a, b) => b.clientCount - a.clientCount);

//     setMatrixData(rows);
//     setSortedMatrixDepartments(sortedDeps);
//   };

//   /* ===============================
//      FILTER USERS BY DEPARTMENT
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     const res = await GetUsersByDepartment(deptId);
//     setUsersList(
//       (res?.data?.datas || []).map((u) => ({
//         label: u.name,
//         value: u._id,
//       }))
//     );
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data</h6>

//         {/* TOGGLE */}
//         <div className="flex border rounded overflow-hidden text-[12px]">
//           <button
//             onClick={() => handleToggle("overall")}
//             className={`px-3 py-1 ${
//               viewMode === "overall" ? "bg-blue-600 text-white" : "bg-white"
//             }`}
//           >
//             Overall Data
//           </button>

//           <button
//             onClick={() => handleToggle("master")}
//             className={`px-3 py-1 ${
//               viewMode === "master" ? "bg-blue-600 text-white" : "bg-white"
//             }`}
//           >
//             Master Data
//           </button>

//           <button
//             onClick={() => handleToggle("analytics")}
//             className={`px-3 py-1 ${
//               viewMode === "analytics" ? "bg-blue-600 text-white" : "bg-white"
//             }`}
//           >
//             Clients Analytics
//           </button>
//         </div>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div>

//       {/* FILTERS (AS IS) */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded"
//         />
//       </div>

//       {/* MATRIX TABLE */}
//       <div className="overflow-auto bg-white border rounded">
//         <table className="min-w-full text-[12px]">
//           <thead className="bg-gray-100">
//             <tr>
//               <th className="p-2 text-left">Client Name</th>
//               {sortedMatrixDepartments.map((d) => (
//                 <th key={d.id} className="p-2 text-center">
//                   {d.department_name}
//                 </th>
//               ))}
//             </tr>
//           </thead>

//           <tbody>
//             {loading ? (
//               <tr>
//                 <td
//                   colSpan={sortedMatrixDepartments.length + 1}
//                   className="p-4 text-center"
//                 >
//                   Loading...
//                 </td>
//               </tr>
//             ) : (
//               matrixData.map((row, i) => (
//                 <tr key={i} className="border-t">
//                   <td className="p-2 font-semibold">{row.company_name}</td>

//                   {sortedMatrixDepartments.map((d) => (
//                     <td key={d.id} className="p-2 text-center">
//                       {row.departments.includes(d.id) ? (
//                         <span className="font-bold text-green-600">✔</span>
//                       ) : (
//                         <span className="font-bold text-red-600">✖</span>
//                       )}
//                     </td>
//                   ))}
//                 </tr>
//               ))
//             )}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// }









//======>> Old 2




// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import { getMyClientBusiness, filterClientBusiness } from "../../services/ClientBusinessService";
// import { GetDepartmentService, GetUsersByDepartment } from "../../services/DepartmentServices";

// export default function ClientMdMatrix() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [departments, setDepartments] = useState([]);
//   const [matrixData, setMatrixData] = useState([]);

//   // filters (UNCHANGED)
//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
//   const [viewMode, setViewMode] = useState("analytics");
//   /* ===============================
//      INITIAL LOAD
//   ================================ */

  
//   const MATRIX_DEPARTMENT_NAMES = [
//     "Transaction Team",
//     "FMS Team",
//     "HR Team",
//     "Project Team",
//     "Shilpa Foundation",
//     "Fidelitus Gallery",
//     "FTS Team",
//   ];
  

//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const handleToggle = (mode) => {
//     setViewMode(mode);
  
//     if (mode === "overall") {
//       navigate("/client_business");
//     }
  
//     if (mode === "master") {
//       navigate("/client_md");
//     }
  
//     if (mode === "analytics") {
//       navigate("/client_md/analytics");
//     }
//   };
  

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       const deps = depRes?.data?.datas || [];
//       setDepartments(deps);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       buildMatrix(masterData, deps);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      BUILD MATRIX
//   ================================ */
//   const buildMatrix = (data, deps) => {
//     const map = {};

//     data.forEach((c) => {
//       const key = c.company_name; // or company_name if needed
//       if (!map[key]) {
//         map[key] = {
//           company_name: c.company_name,
//           phone: c.phone || "-",
//           departments: new Set(),
//         };
//       }

//       const depId =
//         typeof c.department_id === "object"
//           ? c.department_id.id
//           : c.department_id;

//       map[key].departments.add(depId);
//     });

//     const rows = Object.values(map).map((row) => ({
//       ...row,
//       departments: Array.from(row.departments),
//     }));

//     setMatrixData(rows);
//   };

//   /* ===============================
//      FILTER USERS BY DEPARTMENT
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     const res = await GetUsersByDepartment(deptId);
//     setUsersList(
//       (res?.data?.datas || []).map((u) => ({
//         label: u.name,
//         value: u._id,
//       }))
//     );
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   const matrixDepartments = departments.filter((d) =>
//     MATRIX_DEPARTMENT_NAMES.includes(d.department_name)
//   );
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data</h6>

//         <div className="flex border rounded overflow-hidden text-[12px]">
//   <button
//     onClick={() => handleToggle("overall")}
//     className={`px-3 py-1 ${
//       viewMode === "overall"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Overall Data
//   </button>

//   <button
//     onClick={() => handleToggle("master")}
//     className={`px-3 py-1 ${
//       viewMode === "master"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Master Data
//   </button>

//   <button
//     onClick={() => handleToggle("analytics")}
//     className={`px-3 py-1 ${
//       viewMode === "analytics"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Clients Analytics
//   </button>
// </div>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div>


//       {/* FILTERS (AS-IS) */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded"
//         />
//       </div>

//       {/* MATRIX TABLE */}
//       <div className="overflow-auto bg-white border rounded">
//         <table className="min-w-full text-[12px]">
//           <thead className="bg-gray-100">
//             <tr>
//               <th className="p-2 text-left">Client Name</th>
//               {/* <th className="p-2 text-left">Phone</th> */}
//               {matrixDepartments.map((d) => (
//   <th key={d.id} className="p-2 text-center">
//     {d.department_name}
//   </th>
// ))}

//             </tr>
//           </thead>

//           <tbody>
//             {loading ? (
//               <tr>
//                 <td colSpan={departments.length + 2} className="p-4 text-center">
//                   Loading...
//                 </td>
//               </tr>
//             ) : (
//               matrixData.map((row, i) => (
//                 <tr key={i} className="border-t">
//                   <td className="p-2 font-semibold">{row.company_name}</td>
//                   {/* <td className="p-2">{row.phone}</td> */}

//                   {matrixDepartments.map((d) => (
//   <td key={d.id} className="p-2 text-center">
//     {row.departments.includes(d.id) ? (
//       <span className="font-bold text-green-600">✔</span>
//     ) : (
//       <span className="font-bold text-red-600">✖</span>
//     )}
//   </td>
// ))}

//                 </tr>
//               ))
//             )}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// }












//======>> Old updating clint  6/2026


// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import { getMyClientBusiness, filterClientBusiness } from "../../services/ClientBusinessService";
// import { GetDepartmentService, GetUsersByDepartment } from "../../services/DepartmentServices";

// export default function ClientMdMatrix() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [departments, setDepartments] = useState([]);
//   const [matrixData, setMatrixData] = useState([]);

//   // filters (UNCHANGED)
//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
//   const [viewMode, setViewMode] = useState("analytics");
//   /* ===============================
//      INITIAL LOAD
//   ================================ */

  
//   const MATRIX_DEPARTMENT_NAMES = [
//     "Transaction Team",
//     "FMS Team",
//     "HR Team",
//     "Project Team",
//     "Shilpa Foundation",
//     "Fidelitus Gallery",
//     "FTS Team",
//   ];
  

//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const handleToggle = (mode) => {
//     setViewMode(mode);
  
//     if (mode === "overall") {
//       navigate("/client_business");
//     }
  
//     if (mode === "master") {
//       navigate("/client_md");
//     }
  
//     if (mode === "analytics") {
//       navigate("/client_md/analytics");
//     }
//   };
  

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       const deps = depRes?.data?.datas || [];
//       setDepartments(deps);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       buildMatrix(masterData, deps);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      BUILD MATRIX
//   ================================ */
//   const buildMatrix = (data, deps) => {
//     const map = {};

//     data.forEach((c) => {
//       const key = c.client_name; // or company_name if needed
//       if (!map[key]) {
//         map[key] = {
//           client_name: c.client_name,
//           phone: c.phone || "-",
//           departments: new Set(),
//         };
//       }

//       const depId =
//         typeof c.department_id === "object"
//           ? c.department_id.id
//           : c.department_id;

//       map[key].departments.add(depId);
//     });

//     const rows = Object.values(map).map((row) => ({
//       ...row,
//       departments: Array.from(row.departments),
//     }));

//     setMatrixData(rows);
//   };

//   /* ===============================
//      FILTER USERS BY DEPARTMENT
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     const res = await GetUsersByDepartment(deptId);
//     setUsersList(
//       (res?.data?.datas || []).map((u) => ({
//         label: u.name,
//         value: u._id,
//       }))
//     );
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   const matrixDepartments = departments.filter((d) =>
//     MATRIX_DEPARTMENT_NAMES.includes(d.department_name)
//   );
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data</h6>

//         <div className="flex border rounded overflow-hidden text-[12px]">
//   <button
//     onClick={() => handleToggle("overall")}
//     className={`px-3 py-1 ${
//       viewMode === "overall"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Overall Data
//   </button>

//   <button
//     onClick={() => handleToggle("master")}
//     className={`px-3 py-1 ${
//       viewMode === "master"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Master Data
//   </button>

//   <button
//     onClick={() => handleToggle("analytics")}
//     className={`px-3 py-1 ${
//       viewMode === "analytics"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Clients Analytics
//   </button>
// </div>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div>


//       {/* FILTERS (AS-IS) */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded"
//         />
//       </div>

//       {/* MATRIX TABLE */}
//       <div className="overflow-auto bg-white border rounded">
//         <table className="min-w-full text-[12px]">
//           <thead className="bg-gray-100">
//             <tr>
//               <th className="p-2 text-left">Client Name</th>
//               <th className="p-2 text-left">Phone</th>
//               {matrixDepartments.map((d) => (
//   <th key={d.id} className="p-2 text-center">
//     {d.department_name}
//   </th>
// ))}

//             </tr>
//           </thead>

//           <tbody>
//             {loading ? (
//               <tr>
//                 <td colSpan={departments.length + 2} className="p-4 text-center">
//                   Loading...
//                 </td>
//               </tr>
//             ) : (
//               matrixData.map((row, i) => (
//                 <tr key={i} className="border-t">
//                   <td className="p-2 font-semibold">{row.client_name}</td>
//                   <td className="p-2">{row.phone}</td>

//                   {matrixDepartments.map((d) => (
//   <td key={d.id} className="p-2 text-center">
//     {row.departments.includes(d.id) ? (
//       <span className="font-bold text-green-600">✔</span>
//     ) : (
//       <span className="font-bold text-red-600">✖</span>
//     )}
//   </td>
// ))}

//                 </tr>
//               ))
//             )}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// }










//========>> Old one with alla deprtment



// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import { getMyClientBusiness, filterClientBusiness } from "../../services/ClientBusinessService";
// import { GetDepartmentService, GetUsersByDepartment } from "../../services/DepartmentServices";

// export default function ClientMdMatrix() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [departments, setDepartments] = useState([]);
//   const [matrixData, setMatrixData] = useState([]);

//   // filters (UNCHANGED)
//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
//   const [viewMode, setViewMode] = useState("analytics");
//   /* ===============================
//      INITIAL LOAD
//   ================================ */



//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const handleToggle = (mode) => {
//     setViewMode(mode);
  
//     if (mode === "overall") {
//       navigate("/client_business");
//     }
  
//     if (mode === "master") {
//       navigate("/client_md");
//     }
  
//     if (mode === "analytics") {
//       navigate("/client_md/analytics");
//     }
//   };
  

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       const deps = depRes?.data?.datas || [];
//       setDepartments(deps);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       buildMatrix(masterData, deps);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      BUILD MATRIX
//   ================================ */
//   const buildMatrix = (data, deps) => {
//     const map = {};

//     data.forEach((c) => {
//       const key = c.client_name; // or company_name if needed
//       if (!map[key]) {
//         map[key] = {
//           client_name: c.client_name,
//           phone: c.phone || "-",
//           departments: new Set(),
//         };
//       }

//       const depId =
//         typeof c.department_id === "object"
//           ? c.department_id.id
//           : c.department_id;

//       map[key].departments.add(depId);
//     });

//     const rows = Object.values(map).map((row) => ({
//       ...row,
//       departments: Array.from(row.departments),
//     }));

//     setMatrixData(rows);
//   };

//   /* ===============================
//      FILTER USERS BY DEPARTMENT
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     const res = await GetUsersByDepartment(deptId);
//     setUsersList(
//       (res?.data?.datas || []).map((u) => ({
//         label: u.name,
//         value: u._id,
//       }))
//     );
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data</h6>

//         <div className="flex border rounded overflow-hidden text-[12px]">
//   <button
//     onClick={() => handleToggle("overall")}
//     className={`px-3 py-1 ${
//       viewMode === "overall"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Overall Data
//   </button>

//   <button
//     onClick={() => handleToggle("master")}
//     className={`px-3 py-1 ${
//       viewMode === "master"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Master Data
//   </button>

//   <button
//     onClick={() => handleToggle("analytics")}
//     className={`px-3 py-1 ${
//       viewMode === "analytics"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Clients Analytics
//   </button>
// </div>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div>


//       {/* FILTERS (AS-IS) */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded"
//         />
//       </div>

//       {/* MATRIX TABLE */}
//       <div className="overflow-auto bg-white border rounded">
//         <table className="min-w-full text-[12px]">
//           <thead className="bg-gray-100">
//             <tr>
//               <th className="p-2 text-left">Client Name</th>
//               <th className="p-2 text-left">Phone</th>
//               {departments.map((d) => (
//                 <th key={d.id} className="p-2 text-center">
//                   {d.department_name}
//                 </th>
//               ))}
//             </tr>
//           </thead>

//           <tbody>
//             {loading ? (
//               <tr>
//                 <td colSpan={departments.length + 2} className="p-4 text-center">
//                   Loading...
//                 </td>
//               </tr>
//             ) : (
//               matrixData.map((row, i) => (
//                 <tr key={i} className="border-t">
//                   <td className="p-2 font-semibold">{row.client_name}</td>
//                   <td className="p-2">{row.phone}</td>

//                   {departments.map((d) => (
//                     <td key={d.id} className="p-2 text-center">
//                       {row.departments.includes(d.id) ? (
//                         <span className="font-bold text-green-600">✔</span>
//                       ) : (
//                         <span className="font-bold text-red-600">✖</span>
//                       )}
//                     </td>
//                   ))}
//                 </tr>
//               ))
//             )}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// }









//=========>> Old one updtaing toggle



// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import { getMyClientBusiness, filterClientBusiness } from "../../services/ClientBusinessService";
// import { GetDepartmentService, GetUsersByDepartment } from "../../services/DepartmentServices";

// export default function ClientMdMatrix() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [departments, setDepartments] = useState([]);
//   const [matrixData, setMatrixData] = useState([]);

//   // filters (UNCHANGED)
//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       const deps = depRes?.data?.datas || [];
//       setDepartments(deps);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       buildMatrix(masterData, deps);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      BUILD MATRIX
//   ================================ */
//   const buildMatrix = (data, deps) => {
//     const map = {};

//     data.forEach((c) => {
//       const key = c.client_name; // or company_name if needed
//       if (!map[key]) {
//         map[key] = {
//           client_name: c.client_name,
//           phone: c.phone || "-",
//           departments: new Set(),
//         };
//       }

//       const depId =
//         typeof c.department_id === "object"
//           ? c.department_id.id
//           : c.department_id;

//       map[key].departments.add(depId);
//     });

//     const rows = Object.values(map).map((row) => ({
//       ...row,
//       departments: Array.from(row.departments),
//     }));

//     setMatrixData(rows);
//   };

//   /* ===============================
//      FILTER USERS BY DEPARTMENT
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     const res = await GetUsersByDepartment(deptId);
//     setUsersList(
//       (res?.data?.datas || []).map((u) => ({
//         label: u.name,
//         value: u._id,
//       }))
//     );
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">
//           Client Master Data – Department Matrix
//         </h6>

//         <button
//           onClick={() => navigate("/client_business")}
//           className="px-3 py-1 border text-[12px] rounded"
//         >
//           Back
//         </button>
//       </div>

//       {/* FILTERS (AS-IS) */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded"
//         />
//       </div>

//       {/* MATRIX TABLE */}
//       <div className="overflow-auto bg-white border rounded">
//         <table className="min-w-full text-[12px]">
//           <thead className="bg-gray-100">
//             <tr>
//               <th className="p-2 text-left">Client Name</th>
//               <th className="p-2 text-left">Phone</th>
//               {departments.map((d) => (
//                 <th key={d.id} className="p-2 text-center">
//                   {d.department_name}
//                 </th>
//               ))}
//             </tr>
//           </thead>

//           <tbody>
//             {loading ? (
//               <tr>
//                 <td colSpan={departments.length + 2} className="p-4 text-center">
//                   Loading...
//                 </td>
//               </tr>
//             ) : (
//               matrixData.map((row, i) => (
//                 <tr key={i} className="border-t">
//                   <td className="p-2 font-semibold">{row.client_name}</td>
//                   <td className="p-2">{row.phone}</td>

//                   {departments.map((d) => (
//                     <td key={d.id} className="p-2 text-center">
//                       {row.departments.includes(d.id) ? (
//                         <span className="font-bold text-green-600">✔</span>
//                       ) : (
//                         <span className="font-bold text-red-600">✖</span>
//                       )}
//                     </td>
//                   ))}
//                 </tr>
//               ))
//             )}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// }
