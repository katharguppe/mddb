import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import * as XLSX from "xlsx";

import {
  createClientBusiness,
  getClientBusinessById,
  updateClientBusiness,
} from "../../services/ClientBusinessService";
import { GetDepartmentService } from "../../services/DepartmentServices";

export default function ClientBusinessCE() {
  const navigate = useNavigate();
  const { id } = useParams();
  const auth = useSelector((state) => state.Auth);

  const isEdit = Boolean(id);

  /* ===============================
     ROLE CHECKS
  ================================ */
  const isAdmin = auth?.roles?.includes("admin");
  const isMdAdmin = auth?.roles?.includes("md_admin");
  const isSuperAdmin = isAdmin || isMdAdmin;

  const userDepartmentId =
    auth?.department_id?.[0]?.id || auth?.department_id?.[0]?._id || "";

  /* ===============================
     STATE
  ================================ */
  const [loading, setLoading] = useState(false);
  const [departments, setDepartments] = useState([]);

  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const [form, setForm] = useState({
    company_name: "",
    client_name: "",
    email: "",
    phone: "",
    year: "",
    department_id: "",
  });

  /* ===============================
     EXCEL HEADER ALIASES
  ================================ */
  const HEADER_ALIASES = {
    company_name: ["company name", "company", "Company Name"],
    client_name: ["client name", "client", "Client Name"],
    email: ["email", "email id", "Email"],
    phone: ["phone", "phone number", "mobile", "Phone Number"],
  };

  const getValueByHeader = (row, aliases) => {
    for (const key of Object.keys(row)) {
      if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
        return row[key];
      }
    }
    return "";
  };

  /* ===============================
     LOAD INITIAL
  ================================ */
  useEffect(() => {
    loadDepartments();
    if (isEdit) loadData();
  }, [id]);

  const loadDepartments = async () => {
    try {
      const res = await GetDepartmentService();
      setDepartments(res?.data?.datas || []);
    } catch (err) {
      console.log(err);
    }
  };

  const loadData = async () => {
    try {
      const res = await getClientBusinessById(id);
      const data = res?.data?.data;

      setForm({
        company_name: data.company_name || "",
        client_name: data.client_name || "",
        email: data.email || "",
        phone: data.phone || "",
        year: data.year || "",
        department_id:
          typeof data.department_id === "object"
            ? data.department_id.id
            : data.department_id,
      });
    } catch (err) {
      alert("Failed to load client details");
    }
  };

  /* ===============================
     HANDLE CHANGE
  ================================ */
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
  };

  /* ===============================
     SAVE (SINGLE ENTRY)
  ================================ */
  const save = async () => {
    if (!form.company_name || !form.client_name || !form.year) {
      alert("Company Name, Client Name and Year are required");
      return;
    }

    const payload = {
      ...form,
      department_id: isSuperAdmin ? form.department_id : userDepartmentId,
    };

    if (!payload.department_id) {
      alert("Department is required");
      return;
    }

    setLoading(true);
    try {
      if (isEdit) {
        await updateClientBusiness(id, payload);
        alert("Client updated successfully");
      } else {
        await createClientBusiness(payload);
        alert("Client added successfully");
      }
      navigate("/client_business");
    } catch (err) {
      alert("Failed to save client");
    }
    setLoading(false);
  };

  /* ===============================
     EXCEL UPLOAD
  ================================ */
  const handleExcelUpload = async (file) => {
    if (!file) return;

    if (!form.year) {
      alert("Please select Year before uploading Excel");
      return;
    }

    if (isSuperAdmin && !form.department_id) {
      alert("Please select Department before uploading Excel");
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        const workbook = XLSX.read(e.target.result, { type: "binary" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet);

        if (!rows.length) throw new Error("Excel file is empty");

        let uploaded = 0;

        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          const rowNo = i + 2;

          const company = getValueByHeader(row, HEADER_ALIASES.company_name);
          const client = getValueByHeader(row, HEADER_ALIASES.client_name);

          if (!company || !client) {
            throw new Error(`Missing Company or Client at row ${rowNo}`);
          }

          await createClientBusiness({
            year: Number(form.year),
            department_id: isSuperAdmin
              ? form.department_id
              : userDepartmentId,
            company_name: company,
            client_name: client,
            email: getValueByHeader(row, HEADER_ALIASES.email) || "",
            phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
          });

          uploaded++;
          setUploadProgress(Math.round((uploaded / rows.length) * 100));
        }

        alert("✅ Excel uploaded successfully");
        navigate("/client_business");
      } catch (err) {
        alert(err.message || "Excel upload failed");
      } finally {
        setUploading(false);
      }
    };

    reader.readAsBinaryString(file);
  };

  // const years = Array.from({ length: 13 }, (_, i) => 2013 + i);
/* ===============================
   YEARS (2013 to 2026 ONLY)
=============================== */
const years = Array.from(
  { length: 2026 - 2013 + 1 },
  (_, i) => 2013 + i
);

  /* ===============================
     RENDER
  ================================ */
  return (
    <div className="max-w-xl p-6">
      <div className="flex justify-between mb-4">
        <h6 className="font-[700] text-[15px]">
          {isEdit ? "Edit Client Business" : "Add Client Business"}
        </h6>
        <button
          onClick={() => navigate("/client_business")}
          className="text-[12px] text-blue-600 underline"
        >
          Back to List
        </button>
      </div>

      <div className="p-5 space-y-3 bg-white border rounded">
        {/* YEAR */}
        <select
          name="year"
          value={form.year}
          onChange={handleChange}
          className="w-full border px-3 py-2 rounded text-[13px]"
        >
          <option value="">Select Year *</option>
          {years.map((y) => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>

        {/* DEPARTMENT */}
        {isSuperAdmin && (
          <select
            name="department_id"
            value={form.department_id}
            onChange={handleChange}
            className="w-full border px-3 py-2 rounded text-[13px]"
          >
            <option value="">Select Department *</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.department_name}
              </option>
            ))}
          </select>
        )}

        {/* EXCEL UPLOAD */}
        {!isEdit && (
          <label className="block text-center px-3 py-2 bg-green-600 text-white rounded text-[12px] cursor-pointer">
            {uploading ? `Uploading ${uploadProgress}%` : "Upload Excel"}
            <input
              type="file"
              hidden
              accept=".xls,.xlsx"
              disabled={uploading}
              onChange={(e) => handleExcelUpload(e.target.files[0])}
            />
          </label>
        )}

        <div className="text-center text-[11px] text-gray-500">
          Excel columns: Company Name | Client Name | Email | Phone
        </div>

        <hr />

        {/* MANUAL ENTRY */}
        <input
          name="company_name"
          value={form.company_name}
          onChange={handleChange}
          placeholder="Company Name *"
          className="w-full border px-3 py-2 rounded text-[13px]"
        />

        <input
          name="client_name"
          value={form.client_name}
          onChange={handleChange}
          placeholder="Client Name *"
          className="w-full border px-3 py-2 rounded text-[13px]"
        />

        <input
          name="email"
          value={form.email}
          onChange={handleChange}
          placeholder="Email"
          className="w-full border px-3 py-2 rounded text-[13px]"
        />

        <input
          name="phone"
          value={form.phone}
          onChange={handleChange}
          placeholder="Phone"
          className="w-full border px-3 py-2 rounded text-[13px]"
        />

        <div className="flex gap-2 pt-3">
          <button
            onClick={() => navigate("/client_business")}
            className="px-4 py-1 border rounded text-[12px]"
          >
            Cancel
          </button>

          <button
            onClick={save}
            disabled={loading}
            className="px-4 py-1 bg-blue-600 text-white rounded text-[12px]"
          >
            {loading ? "Saving..." : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
}








//==>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Old jan2026 27 updating the 

// import React, { useEffect, useState } from "react";
// import { useNavigate, useParams } from "react-router-dom";
// import { useSelector } from "react-redux";

// import {
//   createClientBusiness,
//   getClientBusinessById,
//   updateClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService } from "../../services/DepartmentServices";

// export default function ClientBusinessCE() {
//   const navigate = useNavigate();
//   const { id } = useParams();
//   const auth = useSelector((state) => state.Auth);

//   const isEdit = Boolean(id);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isSuperAdmin = isAdmin || isMdAdmin;

//   const userDepartmentId =
//     auth?.department_id?.[0]?.id || auth?.department_id?.[0]?._id || "";

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(false);
//   const [departments, setDepartments] = useState([]);

//   const [form, setForm] = useState({
//     company_name: "",
//     client_name: "",
//     email: "",
//     phone: "",
//     year: "",
//     department_id: "", // ✅ IMPORTANT
//   });

//   /* ===============================
//      LOAD INITIAL
//   ================================ */
//   useEffect(() => {
//     loadDepartments();
//     if (isEdit) loadData();
//   }, [id]);

//   const loadDepartments = async () => {
//     try {
//       const res = await GetDepartmentService();
//       setDepartments(res?.data?.datas || []);
//     } catch (err) {
//       console.log(err);
//     }
//   };

//   const loadData = async () => {
//     try {
//       const res = await getClientBusinessById(id);
//       const data = res?.data?.data;

//       setForm({
//         company_name: data.company_name || "",
//         client_name: data.client_name || "",
//         email: data.email || "",
//         phone: data.phone || "",
//         year: data.year || "",
//         department_id:
//           typeof data.department_id === "object"
//             ? data.department_id.id
//             : data.department_id,
//       });
//     } catch (err) {
//       alert("Failed to load client details");
//     }
//   };

//   /* ===============================
//      HANDLE CHANGE
//   ================================ */
//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setForm((p) => ({ ...p, [name]: value }));
//   };

//   /* ===============================
//      SAVE
//   ================================ */
//   const save = async () => {
//     if (!form.company_name || !form.client_name || !form.year) {
//       alert("Company Name, Client Name and Year are required");
//       return;
//     }

//     const payload = {
//       ...form,
//       // 🔒 HOD / BD USER → force own department
//       department_id: isSuperAdmin ? form.department_id : userDepartmentId,
//     };

//     if (!payload.department_id) {
//       alert("Department is required");
//       return;
//     }

//     setLoading(true);
//     try {
//       if (isEdit) {
//         await updateClientBusiness(id, payload);
//         alert("Client updated successfully");
//       } else {
//         await createClientBusiness(payload);
//         alert("Client added successfully");
//       }
//       navigate("/client_business");
//     } catch (err) {
//       alert("Failed to save client");
//     }
//     setLoading(false);
//   };

//   const years = Array.from({ length: 13 }, (_, i) => 2013 + i);

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="max-w-xl p-6">
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-[700] text-[15px]">
//           {isEdit ? "Edit Client Business" : "Add Client Business"}
//         </h6>

//         <button
//           onClick={() => navigate("/client_business")}
//           className="text-[12px] text-blue-600 underline"
//         >
//           Back to List
//         </button>
//       </div>

//       <div className="p-5 space-y-3 bg-white border rounded shadow-sm">
//         {/* COMPANY */}
//         <input
//           name="company_name"
//           value={form.company_name}
//           onChange={handleChange}
//           placeholder="Company Name *"
//           className="w-full border px-3 py-2 rounded text-[13px]"
//         />

//         {/* CLIENT */}
//         <input
//           name="client_name"
//           value={form.client_name}
//           onChange={handleChange}
//           placeholder="Client Name *"
//           className="w-full border px-3 py-2 rounded text-[13px]"
//         />

//         {/* EMAIL */}
//         <input
//           name="email"
//           value={form.email}
//           onChange={handleChange}
//           placeholder="Email"
//           className="w-full border px-3 py-2 rounded text-[13px]"
//         />

//         {/* PHONE */}
//         <input
//           name="phone"
//           value={form.phone}
//           onChange={handleChange}
//           placeholder="Phone"
//           className="w-full border px-3 py-2 rounded text-[13px]"
//         />

//         {/* YEAR */}
//         <select
//           name="year"
//           value={form.year}
//           onChange={handleChange}
//           className="w-full border px-3 py-2 rounded text-[13px]"
//         >
//           <option value="">Select Year *</option>
//           {years.map((y) => (
//             <option key={y} value={y}>
//               {y}
//             </option>
//           ))}
//         </select>

//         {/* DEPARTMENT (ADMIN ONLY) */}
//         {isSuperAdmin && (
//           <select
//             name="department_id"
//             value={form.department_id}
//             onChange={handleChange}
//             className="w-full border px-3 py-2 rounded text-[13px]"
//           >
//             <option value="">Select Department *</option>
//             {departments.map((d) => (
//               <option key={d.id} value={d.id}>
//                 {d.department_name}
//               </option>
//             ))}
//           </select>
//         )}

//         {/* ACTIONS */}
//         <div className="flex gap-2 pt-3">
//           <button
//             onClick={() => navigate("/client_business")}
//             className="px-4 py-1 border rounded text-[12px]"
//           >
//             Cancel
//           </button>

//           <button
//             onClick={save}
//             disabled={loading}
//             className="px-4 py-1 bg-blue-600 text-white rounded text-[12px]"
//           >
//             {loading ? "Saving..." : "Save"}
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }







///  old 2026 


// import React, { useEffect, useState } from "react";
// import { useNavigate, useParams } from "react-router-dom";

// import {
//   createClientBusiness,
//   getClientBusinessById,
//   updateClientBusiness,
// } from "../../services/ClientBusinessService";

// export default function ClientBusinessCE() {
//   const navigate = useNavigate();
//   const { id } = useParams(); // if id exists → edit mode

//   const isEdit = Boolean(id);

//   const [loading, setLoading] = useState(false);
//   const [form, setForm] = useState({
//     company_name: "",
//     client_name: "",
//     email: "",
//     phone: "",
//     year: "",
//   });

//   /* ===============================
//      LOAD DATA FOR EDIT
//   ================================ */
//   useEffect(() => {
//     if (isEdit) loadData();
//   }, [id]);

//   const loadData = async () => {
//     try {
//       const res = await getClientBusinessById(id);
//       const data = res?.data?.data;

//       setForm({
//         company_name: data.company_name || "",
//         client_name: data.client_name || "",
//         email: data.email || "",
//         phone: data.phone || "",
//         year: data.year || "",
//       });
//     } catch (err) {
//       console.log(err);
//       alert("Failed to load client details");
//     }
//   };

//   /* ===============================
//      HANDLE CHANGE
//   ================================ */
//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setForm((p) => ({ ...p, [name]: value }));
//   };

//   /* ===============================
//      SAVE (CREATE / UPDATE)
//   ================================ */
//   const save = async () => {
//     if (!form.company_name || !form.client_name || !form.year) {
//       alert("Company Name, Client Name and Year are required");
//       return;
//     }

//     setLoading(true);
//     try {
//       if (isEdit) {
//         await updateClientBusiness(id, form);
//         alert("Client updated successfully");
//       } else {
//         await createClientBusiness(form);
//         alert("Client added successfully");
//       }
//       navigate("/client_business");
//     } catch (err) {
//       console.log(err);
//       alert("Failed to save client");
//     }
//     setLoading(false);
//   };

//   const years = Array.from({ length: 13 }, (_, i) => 2013 + i);

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="max-w-xl p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-[700] text-[15px]">
//           {isEdit ? "Edit Client Business" : "Add Client Business"}
//         </h6>

//         <button
//           onClick={() => navigate("/client_business")}
//           className="text-[12px] text-blue-600 underline"
//         >
//           Back to List
//         </button>
//       </div>

//       {/* FORM */}
//       <div className="p-5 space-y-3 bg-white border rounded shadow-sm">
//         {/* COMPANY NAME */}
//         <div>
//           <label className="block text-[12px] font-semibold mb-1">
//             Company Name *
//           </label>
//           <input
//             type="text"
//             name="company_name"
//             value={form.company_name}
//             onChange={handleChange}
//             placeholder="Enter company name"
//             className="w-full border px-3 py-2 rounded text-[13px]"
//           />
//         </div>

//         {/* CLIENT NAME */}
//         <div>
//           <label className="block text-[12px] font-semibold mb-1">
//             Client Name *
//           </label>
//           <input
//             type="text"
//             name="client_name"
//             value={form.client_name}
//             onChange={handleChange}
//             placeholder="Enter client name"
//             className="w-full border px-3 py-2 rounded text-[13px]"
//           />
//         </div>

//         {/* EMAIL */}
//         <div>
//           <label className="block text-[12px] font-semibold mb-1">
//             Email
//           </label>
//           <input
//             type="email"
//             name="email"
//             value={form.email}
//             onChange={handleChange}
//             placeholder="Enter email"
//             className="w-full border px-3 py-2 rounded text-[13px]"
//           />
//         </div>

//         {/* PHONE */}
//         <div>
//           <label className="block text-[12px] font-semibold mb-1">
//             Phone Number
//           </label>
//           <input
//             type="text"
//             name="phone"
//             value={form.phone}
//             onChange={handleChange}
//             placeholder="Enter phone number"
//             className="w-full border px-3 py-2 rounded text-[13px]"
//           />
//         </div>

//         {/* YEAR */}
//         <div>
//           <label className="block text-[12px] font-semibold mb-1">
//             Year *
//           </label>
//           <select
//             name="year"
//             value={form.year}
//             onChange={handleChange}
//             className="w-full border px-3 py-2 rounded text-[13px]"
//           >
//             <option value="">Select Year</option>
//             {years.map((y) => (
//               <option key={y} value={y}>
//                 {y}
//               </option>
//             ))}
//           </select>
//         </div>

//         {/* ACTION BUTTONS */}
//         <div className="flex gap-2 pt-3">
//           <button
//             onClick={() => navigate("/client_business")}
//             className="px-4 py-1 border rounded text-[12px]"
//             disabled={loading}
//           >
//             Cancel
//           </button>

//           <button
//             onClick={save}
//             disabled={loading}
//             className="px-4 py-1 bg-blue-600 hover:bg-blue-700 
//                        text-white rounded text-[12px]"
//           >
//             {loading ? "Saving..." : "Save"}
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }
