import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";

import {
  getMyClientBusiness,
  filterClientBusiness,
  deleteClientBusiness,
} from "../../services/ClientBusinessService";
import {
  GetDepartmentService,
  GetUsersByDepartment,
} from "../../services/DepartmentServices";

export default function ClientMdList() {
  const navigate = useNavigate();
  const auth = useSelector((state) => state.Auth);

  /* ===============================
     ROLE CHECKS
  ================================ */
  const isAdmin = auth?.roles?.includes("admin");
  const isMdAdmin = auth?.roles?.includes("md_admin");
  const isHod = auth?.roles?.includes("hod");

  const isSuperAdmin = isAdmin || isMdAdmin;
  const isHodOnly = isHod && !isSuperAdmin;

  const isOnlyBdUser =
    auth?.roles?.includes("bd_user") &&
    !isAdmin &&
    !isMdAdmin &&
    !isHod;

  /* ===============================
     STATE
  ================================ */
  const [loading, setLoading] = useState(true);
  const [allClients, setAllClients] = useState([]);
  const [clients, setClients] = useState([]);

  const [departments, setDepartments] = useState([]);
  const [usersList, setUsersList] = useState([]);

  const [departmentId, setDepartmentId] = useState("");
  const [selectedUser, setSelectedUser] = useState("");

  const [searchCompany, setSearchCompany] = useState("");
  const [searchClient, setSearchClient] = useState("");

  const [viewMode, setViewMode] = useState("master");

  const handleToggle = (mode) => {
    setViewMode(mode);
    if (mode === "overall") navigate("/client_business");
    if (mode === "master") navigate("/client_md");
    if (mode === "analytics") navigate("/client_md/analytics");
  };

  /* ===============================
     INITIAL LOAD
  ================================ */
  useEffect(() => {
    loadInitial();
  }, []);

  const loadInitial = async () => {
    setLoading(true);
    try {
      const depRes = await GetDepartmentService();
      setDepartments(depRes?.data?.datas || []);

      let res;
      if (isSuperAdmin) {
        res = await filterClientBusiness({});
      } else if (isHodOnly) {
        res = await filterClientBusiness({
          department_id: auth?.department_id?.[0]?.id,
        });
      } else {
        res = await getMyClientBusiness();
      }

      const masterData = (res?.data?.data || []).filter(
        (c) => Number(c.year) === 2030
      );

      setAllClients(masterData);
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  /* ===============================
     FILTER PIPELINE
  ================================ */
  /* ===============================
   FILTER PIPELINE (WITH DUPLICATE REMOVAL)
================================ */
// useEffect(() => {
//   let data = [...allClients];

//   if (departmentId) {
//     data = data.filter(
//       (c) =>
//         (typeof c.department_id === "object"
//           ? c.department_id.id
//           : c.department_id) === departmentId
//     );
//   }

//   if (selectedUser) {
//     data = data.filter(
//       (c) =>
//         (typeof c.user_id === "object"
//           ? c.user_id._id || c.user_id.id
//           : c.user_id) === selectedUser
//     );
//   }

//   if (searchCompany.trim()) {
//     data = data.filter((c) =>
//       c.company_name?.toLowerCase().includes(searchCompany.toLowerCase())
//     );
//   }

//   if (searchClient.trim()) {
//     data = data.filter((c) =>
//       c.client_name?.toLowerCase().includes(searchClient.toLowerCase())
//     );
//   }

//   // 🔥 REMOVE DUPLICATES HERE (UI + Excel both clean)
//   const uniqueData = Array.from(
//     new Map(
//       data.map((item) => [
//         `${item.company_name}_${item.client_name}_${item.email}_${item.phone}`,
//         item,
//       ])
//     ).values()
//   );

//   setClients(uniqueData);

// }, [departmentId, selectedUser, searchCompany, searchClient, allClients]);


/* ===============================
   FILTER + DUPLICATE + SORT (A → Z)
================================ */
useEffect(() => {
  let data = [...allClients];

  // 🔹 Department filter
  if (departmentId) {
    data = data.filter(
      (c) =>
        (typeof c.department_id === "object"
          ? c.department_id.id
          : c.department_id) === departmentId
    );
  }

  // 🔹 User filter
  if (selectedUser) {
    data = data.filter(
      (c) =>
        (typeof c.user_id === "object"
          ? c.user_id._id || c.user_id.id
          : c.user_id) === selectedUser
    );
  }

  // 🔹 Company search
  if (searchCompany.trim()) {
    data = data.filter((c) =>
      c.company_name?.toLowerCase().includes(searchCompany.toLowerCase())
    );
  }

  // 🔹 Client search
  if (searchClient.trim()) {
    data = data.filter((c) =>
      c.client_name?.toLowerCase().includes(searchClient.toLowerCase())
    );
  }

  // 🔥 Remove duplicates
  const uniqueData = Array.from(
    new Map(
      data.map((item) => [
        `${item.company_name}_${item.client_name}_${item.email}_${item.phone}`,
        item,
      ])
    ).values()
  );

  // 🔥 SORT A → Z by Company Name (case insensitive)
  uniqueData.sort((a, b) =>
    (a.company_name || "").localeCompare(b.company_name || "", undefined, {
      sensitivity: "base",
    })
  );

  setClients(uniqueData);

}, [departmentId, selectedUser, searchCompany, searchClient, allClients]);
  /* ===============================
     EXCEL DOWNLOAD (REMOVE DUPLICATES)
  ================================ */
  const handleDownloadExcel = async () => {
    if (!clients.length) {
      alert("No data to export");
      return;
    }

    // 🔥 Remove duplicates safely
    const uniqueData = Array.from(
      new Map(
        clients.map((item) => [
          `${item.company_name}_${item.client_name}_${item.email}_${item.phone}`,
          item,
        ])
      ).values()
    );

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Client Master Data");

    const columns = [
      { header: "Company", key: "company", width: 25 },
      { header: "Client", key: "client", width: 25 },
      { header: "Email", key: "email", width: 30 },
      { header: "Phone", key: "phone", width: 20 },
    ];

    if (!isOnlyBdUser) {
      columns.push(
        { header: "Department", key: "department", width: 25 },
        { header: "Created By", key: "createdBy", width: 25 }
      );
    }

    worksheet.columns = columns;

    uniqueData.forEach((c) => {
      worksheet.addRow({
        company: c.company_name || "-",
        client: c.client_name || "-",
        email: c.email || "-",
        phone: c.phone || "-",
        department: !isOnlyBdUser
          ? typeof c.department_id === "object"
            ? c.department_id?.department_name
            : "-"
          : undefined,
        createdBy: !isOnlyBdUser
          ? typeof c.user_id === "object"
            ? c.user_id?.name
            : "-"
          : undefined,
      });
    });

    worksheet.getRow(1).font = { bold: true };

    const buffer = await workbook.xlsx.writeBuffer();

    saveAs(
      new Blob([buffer]),
      `Client_Master_Data_${new Date().toISOString().slice(0, 10)}.xlsx`
    );
  };

  /* ===============================
     DEPARTMENT → USERS
  ================================ */
  const handleDeptChange = async (e) => {
    const deptId = e.target.value;
    setDepartmentId(deptId);
    setSelectedUser("");
    setUsersList([]);

    if (!deptId) return;

    try {
      const res = await GetUsersByDepartment(deptId);
      const list = res?.data?.datas || [];

      setUsersList(
        list.map((u) => ({
          label: u.name,
          value: u._id,
        }))
      );
    } catch (err) {
      console.error(err);
    }
  };

  const getDepartmentName = (department) =>
    department && typeof department === "object"
      ? department.department_name
      : "-";

  const getUserName = (user) =>
    user && typeof user === "object" ? user.name : "-";

  const removeClient = async (id) => {
    if (!window.confirm("Delete this record?")) return;
    await deleteClientBusiness(id);
    loadInitial();
  };

  const clearFilter = () => {
    setDepartmentId("");
    setSelectedUser("");
    setSearchCompany("");
    setSearchClient("");
    setUsersList([]);
  };

  /* ===============================
     RENDER
  ================================ */
  return (
    <div className="p-6">
     <div className="relative flex items-center justify-between mb-4">

{/* LEFT SIDE */}
<h6 className="font-bold text-[15px]">
  Client Master Data123
</h6>

{/* CENTER (True Center - Absolute Positioned) */}
<div className="absolute transform -translate-x-1/2 left-1/2">
  <div className="flex border rounded overflow-hidden text-[12px]">
    <button
      onClick={() => handleToggle("overall")}
      className={`px-3 py-1 ${
        viewMode === "overall"
          ? "bg-blue-600 text-white"
          : "bg-white"
      }`}
    >
      Overall Data
    </button>

    <button
      onClick={() => handleToggle("master")}
      className={`px-3 py-1 ${
        viewMode === "master"
          ? "bg-blue-600 text-white"
          : "bg-white"
      }`}
    >
      Master Data
    </button>

    <button
      onClick={() => handleToggle("analytics")}
      className={`px-3 py-1 ${
        viewMode === "analytics"
          ? "bg-blue-600 text-white"
          : "bg-white"
      }`}
    >
      Clients Analytics
    </button>
  </div>
</div>

{/* RIGHT SIDE */}
<div className="flex items-center gap-3">
  <button
    onClick={handleDownloadExcel}
    className="px-3 py-1 bg-green-600 text-white text-[12px] rounded"
  >
    Download Excel
  </button>

  <button
    onClick={() => navigate("/client_md/create")}
    className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
  >
    + Add Master Data
  </button>
</div>
</div>


      {/* FILTERS (UNCHANGED – FOR ALL ROLES) */}
      <div className="flex flex-wrap gap-2 mb-4">
        <select
          value={departmentId}
          onChange={handleDeptChange}
          className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
        >
          <option value="">All Departments</option>
          {departments.map((d) => (
            <option key={d.id} value={d.id}>
              {d.department_name}
            </option>
          ))}
        </select>

        <select
          value={selectedUser}
          onChange={(e) => setSelectedUser(e.target.value)}
          disabled={!departmentId}
          className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
        >
          <option value="">All Users</option>
          {usersList.map((u) => (
            <option key={u.value} value={u.value}>
              {u.label}
            </option>
          ))}
        </select>

        <input
          placeholder="Search Company"
          value={searchCompany}
          onChange={(e) => setSearchCompany(e.target.value)}
          className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
        />

        <input
          placeholder="Search Client"
          value={searchClient}
          onChange={(e) => setSearchClient(e.target.value)}
          className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
        />

        <button
          onClick={clearFilter}
          className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded"
        >
          Clear
        </button>

        <div className="ml-auto text-[12px] font-semibold text-gray-600">
          Total: {clients.length}
        </div>
      </div>

      {/* TABLE */}
      <div className="bg-white border rounded">
        <div
          className={`grid ${
            isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
          } bg-gray-100 px-4 py-2 text-[13px] font-semibold`}
        >
          <span>Company</span>
          <span>Client</span>
          <span>Email</span>
          <span>Phone</span>
          {!isOnlyBdUser && <span>Department</span>}
          {!isOnlyBdUser && <span>Created By</span>}
          <span className="text-center">Action</span>
        </div>

        {loading ? (
          <div className="p-4 text-center">Loading...</div>
        ) : clients.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            No master data found
          </div>
        ) : (
          clients.map((c) => (
            <div
              key={c.id}
              className={`grid ${
                isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
              } px-4 py-2 text-[12px] border-t`}
            >
              <span>{c.company_name}</span>
              <span className="font-semibold">{c.client_name}</span>
              <span>{c.email || "-"}</span>
              <span>{c.phone || "-"}</span>
              {!isOnlyBdUser && (
                <span>{getDepartmentName(c.department_id)}</span>
              )}
              {!isOnlyBdUser && <span>{getUserName(c.user_id)}</span>}
              <span className="flex justify-center gap-1">
                <button
                  onClick={() => navigate(`/client_md/edit/${c.id}`)}
                  className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
                >
                  Edit
                </button>
                <button
                  onClick={() => removeClient(c.id)}
                  className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
                >
                  Delete
                </button>
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}










//====>> Filter while download

// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import ExcelJS from "exceljs";
// import { saveAs } from "file-saver";

// import {
//   getMyClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   const isOnlyBdUser =
//     auth?.roles?.includes("bd_user") &&
//     !isAdmin &&
//     !isMdAdmin &&
//     !isHod;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [allClients, setAllClients] = useState([]);
//   const [clients, setClients] = useState([]);

//   const [departments, setDepartments] = useState([]);
//   const [usersList, setUsersList] = useState([]);

//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");

//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");

//   const [viewMode, setViewMode] = useState("master");

//   const handleToggle = (mode) => {
//     setViewMode(mode);
//     if (mode === "overall") navigate("/client_business");
//     if (mode === "master") navigate("/client_md");
//     if (mode === "analytics") navigate("/client_md/analytics");
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       setAllClients(masterData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      FILTER PIPELINE
//   ================================ */
//   useEffect(() => {
//     let data = [...allClients];

//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }

//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }

//     if (searchCompany.trim()) {
//       data = data.filter((c) =>
//         c.company_name?.toLowerCase().includes(searchCompany.toLowerCase())
//       );
//     }

//     if (searchClient.trim()) {
//       data = data.filter((c) =>
//         c.client_name?.toLowerCase().includes(searchClient.toLowerCase())
//       );
//     }

//     setClients(data);
//   }, [departmentId, selectedUser, searchCompany, searchClient, allClients]);

//   /* ===============================
//      EXCEL DOWNLOAD (REMOVE DUPLICATES)
//   ================================ */
//   const handleDownloadExcel = async () => {
//     if (!clients.length) {
//       alert("No data to export");
//       return;
//     }

//     // 🔥 Remove duplicates safely
//     const uniqueData = Array.from(
//       new Map(
//         clients.map((item) => [
//           `${item.company_name}_${item.client_name}_${item.email}_${item.phone}`,
//           item,
//         ])
//       ).values()
//     );

//     const workbook = new ExcelJS.Workbook();
//     const worksheet = workbook.addWorksheet("Client Master Data");

//     const columns = [
//       { header: "Company", key: "company", width: 25 },
//       { header: "Client", key: "client", width: 25 },
//       { header: "Email", key: "email", width: 30 },
//       { header: "Phone", key: "phone", width: 20 },
//     ];

//     if (!isOnlyBdUser) {
//       columns.push(
//         { header: "Department", key: "department", width: 25 },
//         { header: "Created By", key: "createdBy", width: 25 }
//       );
//     }

//     worksheet.columns = columns;

//     uniqueData.forEach((c) => {
//       worksheet.addRow({
//         company: c.company_name || "-",
//         client: c.client_name || "-",
//         email: c.email || "-",
//         phone: c.phone || "-",
//         department: !isOnlyBdUser
//           ? typeof c.department_id === "object"
//             ? c.department_id?.department_name
//             : "-"
//           : undefined,
//         createdBy: !isOnlyBdUser
//           ? typeof c.user_id === "object"
//             ? c.user_id?.name
//             : "-"
//           : undefined,
//       });
//     });

//     worksheet.getRow(1).font = { bold: true };

//     const buffer = await workbook.xlsx.writeBuffer();

//     saveAs(
//       new Blob([buffer]),
//       `Client_Master_Data_${new Date().toISOString().slice(0, 10)}.xlsx`
//     );
//   };

//   /* ===============================
//      DEPARTMENT → USERS
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];

//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   const getDepartmentName = (department) =>
//     department && typeof department === "object"
//       ? department.department_name
//       : "-";

//   const getUserName = (user) =>
//     user && typeof user === "object" ? user.name : "-";

//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   const clearFilter = () => {
//     setDepartmentId("");
//     setSelectedUser("");
//     setSearchCompany("");
//     setSearchClient("");
//     setUsersList([]);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data123</h6>

//         <div className="flex items-center gap-3">
//           <div className="flex border rounded overflow-hidden text-[12px]">
//             <button onClick={() => handleToggle("overall")} className={`px-3 py-1 ${viewMode === "overall" ? "bg-blue-600 text-white" : "bg-white"}`}>Overall Data</button>
//             <button onClick={() => handleToggle("master")} className={`px-3 py-1 ${viewMode === "master" ? "bg-blue-600 text-white" : "bg-white"}`}>Master Data</button>
//             <button onClick={() => handleToggle("analytics")} className={`px-3 py-1 ${viewMode === "analytics" ? "bg-blue-600 text-white" : "bg-white"}`}>Clients Analytics</button>
//           </div>

//           <button onClick={handleDownloadExcel} className="px-3 py-1 bg-green-600 text-white text-[12px] rounded">
//             Download Excel
//           </button>

//           <button onClick={() => navigate("/client_md/create")} className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded">
//             + Add Master Data
//           </button>
//         </div>
//       </div>

//       {/* Your Filters + Table remain EXACTLY SAME below (no changes) */}

//       {/* FILTERS + TABLE BELOW REMAIN 100% SAME AS YOUR ORIGINAL */}

//       {/* FILTERS (UNCHANGED – FOR ALL ROLES) */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <button
//           onClick={clearFilter}
//           className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded"
//         >
//           Clear
//         </button>

//         <div className="ml-auto text-[12px] font-semibold text-gray-600">
//           Total: {clients.length}
//         </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         <div
//           className={`grid ${
//             isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//           } bg-gray-100 px-4 py-2 text-[13px] font-semibold`}
//         >
//           <span>Company</span>
//           <span>Client</span>
//           <span>Email</span>
//           <span>Phone</span>
//           {!isOnlyBdUser && <span>Department</span>}
//           {!isOnlyBdUser && <span>Created By</span>}
//           <span className="text-center">Action</span>
//         </div>

//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">
//             No master data found
//           </div>
//         ) : (
//           clients.map((c) => (
//             <div
//               key={c.id}
//               className={`grid ${
//                 isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//               } px-4 py-2 text-[12px] border-t`}
//             >
//               <span>{c.company_name}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               {!isOnlyBdUser && (
//                 <span>{getDepartmentName(c.department_id)}</span>
//               )}
//               {!isOnlyBdUser && <span>{getUserName(c.user_id)}</span>}
//               <span className="flex justify-center gap-1">
//                 <button
//                   onClick={() => navigate(`/client_md/edit/${c.id}`)}
//                   className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
//                 >
//                   Edit
//                 </button>
//                 <button
//                   onClick={() => removeClient(c.id)}
//                   className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
//                 >
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }









//========+>> Old good 100%


// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import ExcelJS from "exceljs";
// import { saveAs } from "file-saver";

// import {
//   getMyClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   const isOnlyBdUser =
//     auth?.roles?.includes("bd_user") &&
//     !isAdmin &&
//     !isMdAdmin &&
//     !isHod;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [allClients, setAllClients] = useState([]);
//   const [clients, setClients] = useState([]);

//   const [departments, setDepartments] = useState([]);
//   const [usersList, setUsersList] = useState([]);

//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");

//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");

//   const [viewMode, setViewMode] = useState("master");

//   const handleToggle = (mode) => {
//     setViewMode(mode);

//     if (mode === "overall") navigate("/client_business");
//     if (mode === "master") navigate("/client_md");
//     if (mode === "analytics") navigate("/client_md/analytics");
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       setAllClients(masterData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      FILTER PIPELINE
//   ================================ */
//   useEffect(() => {
//     let data = [...allClients];

//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }

//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }

//     if (searchCompany.trim()) {
//       data = data.filter((c) =>
//         c.company_name?.toLowerCase().includes(searchCompany.toLowerCase())
//       );
//     }

//     if (searchClient.trim()) {
//       data = data.filter((c) =>
//         c.client_name?.toLowerCase().includes(searchClient.toLowerCase())
//       );
//     }

//     setClients(data);
//   }, [departmentId, selectedUser, searchCompany, searchClient, allClients]);

//   /* ===============================
//      EXCEL DOWNLOAD (100% FRONTEND)
//   ================================ */
//   const handleDownloadExcel = async () => {
//     if (!clients.length) {
//       alert("No data to export");
//       return;
//     }

//     const workbook = new ExcelJS.Workbook();
//     const worksheet = workbook.addWorksheet("Client Master Data");

//     const columns = [
//       { header: "Company", key: "company", width: 25 },
//       { header: "Client", key: "client", width: 25 },
//       { header: "Email", key: "email", width: 30 },
//       { header: "Phone", key: "phone", width: 20 },
//     ];

//     if (!isOnlyBdUser) {
//       columns.push(
//         { header: "Department", key: "department", width: 25 },
//         { header: "Created By", key: "createdBy", width: 25 }
//       );
//     }

//     worksheet.columns = columns;

//     clients.forEach((c) => {
//       worksheet.addRow({
//         company: c.company_name || "-",
//         client: c.client_name || "-",
//         email: c.email || "-",
//         phone: c.phone || "-",
//         department: !isOnlyBdUser
//           ? typeof c.department_id === "object"
//             ? c.department_id?.department_name
//             : "-"
//           : undefined,
//         createdBy: !isOnlyBdUser
//           ? typeof c.user_id === "object"
//             ? c.user_id?.name
//             : "-"
//           : undefined,
//       });
//     });

//     worksheet.getRow(1).font = { bold: true };

//     const buffer = await workbook.xlsx.writeBuffer();

//     saveAs(
//       new Blob([buffer]),
//       `Client_Master_Data_${new Date().toISOString().slice(0,10)}.xlsx`
//     );
//   };

//   /* ===============================
//      DEPARTMENT → USERS
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];

//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   const getDepartmentName = (department) =>
//     department && typeof department === "object"
//       ? department.department_name
//       : "-";

//   const getUserName = (user) =>
//     user && typeof user === "object" ? user.name : "-";

//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   const clearFilter = () => {
//     setDepartmentId("");
//     setSelectedUser("");
//     setSearchCompany("");
//     setSearchClient("");
//     setUsersList([]);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data123</h6>

//         <div className="flex items-center gap-3">
//           <div className="flex border rounded overflow-hidden text-[12px]">
//             <button onClick={() => handleToggle("overall")} className={`px-3 py-1 ${viewMode === "overall" ? "bg-blue-600 text-white" : "bg-white"}`}>Overall Data</button>
//             <button onClick={() => handleToggle("master")} className={`px-3 py-1 ${viewMode === "master" ? "bg-blue-600 text-white" : "bg-white"}`}>Master Data</button>
//             <button onClick={() => handleToggle("analytics")} className={`px-3 py-1 ${viewMode === "analytics" ? "bg-blue-600 text-white" : "bg-white"}`}>Clients Analytics</button>
//           </div>

//           {/* ✅ Excel Button */}
//           <button
//             onClick={handleDownloadExcel}
//             className="px-3 py-1 bg-green-600 text-white text-[12px] rounded"
//           >
//             Download Excel
//           </button>

//           <button
//             onClick={() => navigate("/client_md/create")}
//             className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//           >
//             + Add Master Data
//           </button>
//         </div>
//       </div>

//       {/* FILTERS + TABLE BELOW REMAIN 100% SAME AS YOUR ORIGINAL */}

//       {/* FILTERS (UNCHANGED – FOR ALL ROLES) */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <button
//           onClick={clearFilter}
//           className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded"
//         >
//           Clear
//         </button>

//         <div className="ml-auto text-[12px] font-semibold text-gray-600">
//           Total: {clients.length}
//         </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         <div
//           className={`grid ${
//             isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//           } bg-gray-100 px-4 py-2 text-[13px] font-semibold`}
//         >
//           <span>Company</span>
//           <span>Client</span>
//           <span>Email</span>
//           <span>Phone</span>
//           {!isOnlyBdUser && <span>Department</span>}
//           {!isOnlyBdUser && <span>Created By</span>}
//           <span className="text-center">Action</span>
//         </div>

//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">
//             No master data found
//           </div>
//         ) : (
//           clients.map((c) => (
//             <div
//               key={c.id}
//               className={`grid ${
//                 isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//               } px-4 py-2 text-[12px] border-t`}
//             >
//               <span>{c.company_name}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               {!isOnlyBdUser && (
//                 <span>{getDepartmentName(c.department_id)}</span>
//               )}
//               {!isOnlyBdUser && <span>{getUserName(c.user_id)}</span>}
//               <span className="flex justify-center gap-1">
//                 <button
//                   onClick={() => navigate(`/client_md/edit/${c.id}`)}
//                   className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
//                 >
//                   Edit
//                 </button>
//                 <button
//                   onClick={() => removeClient(c.id)}
//                   className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
//                 >
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }








//======>> old one 2


// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import ExcelJS from "exceljs";
// import { saveAs } from "file-saver";

// import {
//   getMyClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   const isOnlyBdUser =
//     auth?.roles?.includes("bd_user") &&
//     !isAdmin &&
//     !isMdAdmin &&
//     !isHod;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [allClients, setAllClients] = useState([]);
//   const [clients, setClients] = useState([]);

//   const [departments, setDepartments] = useState([]);
//   const [usersList, setUsersList] = useState([]);

//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");

//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");

//   const [viewMode, setViewMode] = useState("master");

//   const handleToggle = (mode) => {
//     setViewMode(mode);

//     if (mode === "overall") navigate("/client_business");
//     if (mode === "master") navigate("/client_md");
//     if (mode === "analytics") navigate("/client_md/analytics");
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       setAllClients(masterData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      FILTER PIPELINE
//   ================================ */
//   useEffect(() => {
//     let data = [...allClients];

//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }

//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }

//     if (searchCompany.trim()) {
//       data = data.filter((c) =>
//         c.company_name?.toLowerCase().includes(searchCompany.toLowerCase())
//       );
//     }

//     if (searchClient.trim()) {
//       data = data.filter((c) =>
//         c.client_name?.toLowerCase().includes(searchClient.toLowerCase())
//       );
//     }

//     setClients(data);
//   }, [departmentId, selectedUser, searchCompany, searchClient, allClients]);

//   /* ===============================
//      EXCEL DOWNLOAD
//   ================================ */
//   const handleDownloadExcel = async () => {
//     const workbook = new ExcelJS.Workbook();
//     const worksheet = workbook.addWorksheet("Client Master Data");

//     const columns = [
//       { header: "Company", key: "company_name", width: 25 },
//       { header: "Client", key: "client_name", width: 25 },
//       { header: "Email", key: "email", width: 30 },
//       { header: "Phone", key: "phone", width: 20 },
//     ];

//     if (!isOnlyBdUser) {
//       columns.push(
//         { header: "Department", key: "department", width: 25 },
//         { header: "Created By", key: "created_by", width: 25 }
//       );
//     }

//     worksheet.columns = columns;

//     clients.forEach((c) => {
//       worksheet.addRow({
//         company_name: c.company_name || "-",
//         client_name: c.client_name || "-",
//         email: c.email || "-",
//         phone: c.phone || "-",
//         department: !isOnlyBdUser
//           ? (typeof c.department_id === "object"
//               ? c.department_id?.department_name
//               : "-")
//           : undefined,
//         created_by: !isOnlyBdUser
//           ? (typeof c.user_id === "object"
//               ? c.user_id?.name
//               : "-")
//           : undefined,
//       });
//     });

//     worksheet.getRow(1).font = { bold: true };

//     const buffer = await workbook.xlsx.writeBuffer();
//     saveAs(
//       new Blob([buffer]),
//       `Client_Master_Data_${Date.now()}.xlsx`
//     );
//   };

//   /* ===============================
//      DEPARTMENT → USERS
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];

//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   const getDepartmentName = (department) =>
//     department && typeof department === "object"
//       ? department.department_name
//       : "-";

//   const getUserName = (user) =>
//     user && typeof user === "object" ? user.name : "-";

//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   const clearFilter = () => {
//     setDepartmentId("");
//     setSelectedUser("");
//     setSearchCompany("");
//     setSearchClient("");
//     setUsersList([]);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data123</h6>

//         <div className="flex items-center gap-3">

//           {/* Toggle Buttons - UNCHANGED */}
//           <div className="flex border rounded overflow-hidden text-[12px]">
//             <button
//               onClick={() => handleToggle("overall")}
//               className={`px-3 py-1 ${
//                 viewMode === "overall"
//                   ? "bg-blue-600 text-white"
//                   : "bg-white"
//               }`}
//             >
//               Overall Data
//             </button>

//             <button
//               onClick={() => handleToggle("master")}
//               className={`px-3 py-1 ${
//                 viewMode === "master"
//                   ? "bg-blue-600 text-white"
//                   : "bg-white"
//               }`}
//             >
//               Master Data
//             </button>

//             <button
//               onClick={() => handleToggle("analytics")}
//               className={`px-3 py-1 ${
//                 viewMode === "analytics"
//                   ? "bg-blue-600 text-white"
//                   : "bg-white"
//               }`}
//             >
//               Clients Analytics
//             </button>
//           </div>

//           {/* Download Excel Button - ADDED */}
//           <button
//             onClick={handleDownloadExcel}
//             className="px-3 py-1 bg-green-600 text-white text-[12px] rounded"
//           >
//             Download Excel
//           </button>

//           <button
//             onClick={() => navigate("/client_md/create")}
//             className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//           >
//             + Add Master Data
//           </button>
//         </div>
//       </div>

//       {/* FILTERS & TABLE — COMPLETELY UNCHANGED BELOW */}

//       {/* FILTERS */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <button
//           onClick={clearFilter}
//           className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded"
//         >
//           Clear
//         </button>

//         <div className="ml-auto text-[12px] font-semibold text-gray-600">
//           Total: {clients.length}
//         </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         <div
//           className={`grid ${
//             isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//           } bg-gray-100 px-4 py-2 text-[13px] font-semibold`}
//         >
//           <span>Company</span>
//           <span>Client</span>
//           <span>Email</span>
//           <span>Phone</span>
//           {!isOnlyBdUser && <span>Department</span>}
//           {!isOnlyBdUser && <span>Created By</span>}
//           <span className="text-center">Action</span>
//         </div>

//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">
//             No master data found
//           </div>
//         ) : (
//           clients.map((c) => (
//             <div
//               key={c.id}
//               className={`grid ${
//                 isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//               } px-4 py-2 text-[12px] border-t`}
//             >
//               <span>{c.company_name}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               {!isOnlyBdUser && (
//                 <span>{getDepartmentName(c.department_id)}</span>
//               )}
//               {!isOnlyBdUser && <span>{getUserName(c.user_id)}</span>}
//               <span className="flex justify-center gap-1">
//                 <button
//                   onClick={() => navigate(`/client_md/edit/${c.id}`)}
//                   className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
//                 >
//                   Edit
//                 </button>
//                 <button
//                   onClick={() => removeClient(c.id)}
//                   className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
//                 >
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }




//=====>> Old one

// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";

// import {
//   getMyClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   // ✅ ONLY BD USER
//   const isOnlyBdUser =
//     auth?.roles?.includes("bd_user") &&
//     !isAdmin &&
//     !isMdAdmin &&
//     !isHod;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [allClients, setAllClients] = useState([]);
//   const [clients, setClients] = useState([]);

//   const [departments, setDepartments] = useState([]);
//   const [usersList, setUsersList] = useState([]);

//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");

//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");

//   const [viewMode, setViewMode] = useState("master");

//   const handleToggle = (mode) => {
//     setViewMode(mode);
  
//     if (mode === "overall") {
//       navigate("/client_business");
//     }
  
//     if (mode === "master") {
//       navigate("/client_md");
//     }
  
//     if (mode === "analytics") {
//       navigate("/client_md/analytics");
//     }
//   };
  

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       setAllClients(masterData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      FILTER PIPELINE (UNCHANGED)
//   ================================ */
//   useEffect(() => {
//     let data = [...allClients];

//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }

//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }

//     if (searchCompany.trim()) {
//       data = data.filter((c) =>
//         c.company_name?.toLowerCase().includes(searchCompany.toLowerCase())
//       );
//     }

//     if (searchClient.trim()) {
//       data = data.filter((c) =>
//         c.client_name?.toLowerCase().includes(searchClient.toLowerCase())
//       );
//     }

//     setClients(data);
//   }, [departmentId, selectedUser, searchCompany, searchClient, allClients]);

//   /* ===============================
//      DEPARTMENT → USERS
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];

//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   /* ===============================
//      HELPERS
//   ================================ */
//   const getDepartmentName = (department) =>
//     department && typeof department === "object"
//       ? department.department_name
//       : "-";

//   const getUserName = (user) =>
//     user && typeof user === "object" ? user.name : "-";

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setDepartmentId("");
//     setSelectedUser("");
//     setSearchCompany("");
//     setSearchClient("");
//     setUsersList([]);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data123</h6>

//         <div className="flex border rounded overflow-hidden text-[12px]">
//   <button
//     onClick={() => handleToggle("overall")}
//     className={`px-3 py-1 ${
//       viewMode === "overall"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Overall Data
//   </button>

//   <button
//     onClick={() => handleToggle("master")}
//     className={`px-3 py-1 ${
//       viewMode === "master"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Master Data
//   </button>

//   <button
//     onClick={() => handleToggle("analytics")}
//     className={`px-3 py-1 ${
//       viewMode === "analytics"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Clients Analytics
//   </button>
// </div>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div>

//       {/* FILTERS (UNCHANGED – FOR ALL ROLES) */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <button
//           onClick={clearFilter}
//           className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded"
//         >
//           Clear
//         </button>

//         <div className="ml-auto text-[12px] font-semibold text-gray-600">
//           Total: {clients.length}
//         </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         <div
//           className={`grid ${
//             isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//           } bg-gray-100 px-4 py-2 text-[13px] font-semibold`}
//         >
//           <span>Company</span>
//           <span>Client</span>
//           <span>Email</span>
//           <span>Phone</span>
//           {!isOnlyBdUser && <span>Department</span>}
//           {!isOnlyBdUser && <span>Created By</span>}
//           <span className="text-center">Action</span>
//         </div>

//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">
//             No master data found
//           </div>
//         ) : (
//           clients.map((c) => (
//             <div
//               key={c.id}
//               className={`grid ${
//                 isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//               } px-4 py-2 text-[12px] border-t`}
//             >
//               <span>{c.company_name}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               {!isOnlyBdUser && (
//                 <span>{getDepartmentName(c.department_id)}</span>
//               )}
//               {!isOnlyBdUser && <span>{getUserName(c.user_id)}</span>}
//               <span className="flex justify-center gap-1">
//                 <button
//                   onClick={() => navigate(`/client_md/edit/${c.id}`)}
//                   className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
//                 >
//                   Edit
//                 </button>
//                 <button
//                   onClick={() => removeClient(c.id)}
//                   className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
//                 >
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }









//=====>> Updating excell download 2026 




// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";

// import {
//   getMyClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   // ✅ ONLY BD USER
//   const isOnlyBdUser =
//     auth?.roles?.includes("bd_user") &&
//     !isAdmin &&
//     !isMdAdmin &&
//     !isHod;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [allClients, setAllClients] = useState([]);
//   const [clients, setClients] = useState([]);

//   const [departments, setDepartments] = useState([]);
//   const [usersList, setUsersList] = useState([]);

//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");

//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");

//   const [viewMode, setViewMode] = useState("master");

//   const handleToggle = (mode) => {
//     setViewMode(mode);
  
//     if (mode === "overall") {
//       navigate("/client_business");
//     }
  
//     if (mode === "master") {
//       navigate("/client_md");
//     }
  
//     if (mode === "analytics") {
//       navigate("/client_md/analytics");
//     }
//   };
  

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       setAllClients(masterData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      FILTER PIPELINE (UNCHANGED)
//   ================================ */
//   useEffect(() => {
//     let data = [...allClients];

//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }

//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }

//     if (searchCompany.trim()) {
//       data = data.filter((c) =>
//         c.company_name?.toLowerCase().includes(searchCompany.toLowerCase())
//       );
//     }

//     if (searchClient.trim()) {
//       data = data.filter((c) =>
//         c.client_name?.toLowerCase().includes(searchClient.toLowerCase())
//       );
//     }

//     setClients(data);
//   }, [departmentId, selectedUser, searchCompany, searchClient, allClients]);

//   /* ===============================
//      DEPARTMENT → USERS
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];

//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   /* ===============================
//      HELPERS
//   ================================ */
//   const getDepartmentName = (department) =>
//     department && typeof department === "object"
//       ? department.department_name
//       : "-";

//   const getUserName = (user) =>
//     user && typeof user === "object" ? user.name : "-";

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setDepartmentId("");
//     setSelectedUser("");
//     setSearchCompany("");
//     setSearchClient("");
//     setUsersList([]);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data123</h6>

//         <div className="flex border rounded overflow-hidden text-[12px]">
//   <button
//     onClick={() => handleToggle("overall")}
//     className={`px-3 py-1 ${
//       viewMode === "overall"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Overall Data
//   </button>

//   <button
//     onClick={() => handleToggle("master")}
//     className={`px-3 py-1 ${
//       viewMode === "master"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Master Data
//   </button>

//   <button
//     onClick={() => handleToggle("analytics")}
//     className={`px-3 py-1 ${
//       viewMode === "analytics"
//         ? "bg-blue-600 text-white"
//         : "bg-white"
//     }`}
//   >
//     Clients Analytics
//   </button>
// </div>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div>

//       {/* FILTERS (UNCHANGED – FOR ALL ROLES) */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <button
//           onClick={clearFilter}
//           className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded"
//         >
//           Clear
//         </button>

//         <div className="ml-auto text-[12px] font-semibold text-gray-600">
//           Total: {clients.length}
//         </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         <div
//           className={`grid ${
//             isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//           } bg-gray-100 px-4 py-2 text-[13px] font-semibold`}
//         >
//           <span>Company</span>
//           <span>Client</span>
//           <span>Email</span>
//           <span>Phone</span>
//           {!isOnlyBdUser && <span>Department</span>}
//           {!isOnlyBdUser && <span>Created By</span>}
//           <span className="text-center">Action</span>
//         </div>

//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">
//             No master data found
//           </div>
//         ) : (
//           clients.map((c) => (
//             <div
//               key={c.id}
//               className={`grid ${
//                 isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//               } px-4 py-2 text-[12px] border-t`}
//             >
//               <span>{c.company_name}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               {!isOnlyBdUser && (
//                 <span>{getDepartmentName(c.department_id)}</span>
//               )}
//               {!isOnlyBdUser && <span>{getUserName(c.user_id)}</span>}
//               <span className="flex justify-center gap-1">
//                 <button
//                   onClick={() => navigate(`/client_md/edit/${c.id}`)}
//                   className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
//                 >
//                   Edit
//                 </button>
//                 <button
//                   onClick={() => removeClient(c.id)}
//                   className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
//                 >
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }











//===========>>> Updating the toggle button 3



// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";

// import {
//   getMyClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   // ✅ ONLY BD USER
//   const isOnlyBdUser =
//     auth?.roles?.includes("bd_user") &&
//     !isAdmin &&
//     !isMdAdmin &&
//     !isHod;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [allClients, setAllClients] = useState([]);
//   const [clients, setClients] = useState([]);

//   const [departments, setDepartments] = useState([]);
//   const [usersList, setUsersList] = useState([]);

//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");

//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");

//   const [viewMode, setViewMode] = useState("master");

//   const handleToggle = (mode) => {
//     setViewMode(mode);
//     if (mode === "overall") navigate("/client_business");
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       setAllClients(masterData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      FILTER PIPELINE (UNCHANGED)
//   ================================ */
//   useEffect(() => {
//     let data = [...allClients];

//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }

//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }

//     if (searchCompany.trim()) {
//       data = data.filter((c) =>
//         c.company_name?.toLowerCase().includes(searchCompany.toLowerCase())
//       );
//     }

//     if (searchClient.trim()) {
//       data = data.filter((c) =>
//         c.client_name?.toLowerCase().includes(searchClient.toLowerCase())
//       );
//     }

//     setClients(data);
//   }, [departmentId, selectedUser, searchCompany, searchClient, allClients]);

//   /* ===============================
//      DEPARTMENT → USERS
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];

//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   /* ===============================
//      HELPERS
//   ================================ */
//   const getDepartmentName = (department) =>
//     department && typeof department === "object"
//       ? department.department_name
//       : "-";

//   const getUserName = (user) =>
//     user && typeof user === "object" ? user.name : "-";

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setDepartmentId("");
//     setSelectedUser("");
//     setSearchCompany("");
//     setSearchClient("");
//     setUsersList([]);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data</h6>

//         <div className="flex border rounded overflow-hidden text-[12px]">
//           <button
//             onClick={() => handleToggle("overall")}
//             className={`px-3 py-1 ${
//               viewMode === "overall"
//                 ? "bg-blue-600 text-white"
//                 : "bg-white"
//             }`}
//           >
//             Overall Data
//           </button>
//           <button
//             onClick={() => handleToggle("master")}
//             className={`px-3 py-1 ${
//               viewMode === "master"
//                 ? "bg-blue-600 text-white"
//                 : "bg-white"
//             }`}
//           >
//             Master Data
//           </button>
//         </div>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div>

//       {/* FILTERS (UNCHANGED – FOR ALL ROLES) */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <button
//           onClick={clearFilter}
//           className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded"
//         >
//           Clear
//         </button>

//         <div className="ml-auto text-[12px] font-semibold text-gray-600">
//           Total: {clients.length}
//         </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         <div
//           className={`grid ${
//             isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//           } bg-gray-100 px-4 py-2 text-[13px] font-semibold`}
//         >
//           <span>Company</span>
//           <span>Client</span>
//           <span>Email</span>
//           <span>Phone</span>
//           {!isOnlyBdUser && <span>Department</span>}
//           {!isOnlyBdUser && <span>Created By</span>}
//           <span className="text-center">Action</span>
//         </div>

//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">
//             No master data found
//           </div>
//         ) : (
//           clients.map((c) => (
//             <div
//               key={c.id}
//               className={`grid ${
//                 isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//               } px-4 py-2 text-[12px] border-t`}
//             >
//               <span>{c.company_name}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               {!isOnlyBdUser && (
//                 <span>{getDepartmentName(c.department_id)}</span>
//               )}
//               {!isOnlyBdUser && <span>{getUserName(c.user_id)}</span>}
//               <span className="flex justify-center gap-1">
//                 <button
//                   onClick={() => navigate(`/client_md/edit/${c.id}`)}
//                   className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
//                 >
//                   Edit
//                 </button>
//                 <button
//                   onClick={() => removeClient(c.id)}
//                   className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
//                 >
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }







//////////=======>>

// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";

// import {
//   getMyClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   // ✅ ONLY BD USER (no admin / md / hod)
//   const isOnlyBdUser =
//     auth?.roles?.includes("bd_user") &&
//     !isAdmin &&
//     !isMdAdmin &&
//     !isHod;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [allClients, setAllClients] = useState([]);
//   const [clients, setClients] = useState([]);

//   const [departments, setDepartments] = useState([]);
//   const [usersList, setUsersList] = useState([]);

//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");

//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");

//   const [viewMode, setViewMode] = useState("master");

//   const handleToggle = (mode) => {
//     setViewMode(mode);
//     if (mode === "overall") navigate("/client_business");
//   };

//   /* ===============================
//      LOAD DATA
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       const masterData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );

//       setAllClients(masterData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      FILTER
//   ================================ */
//   useEffect(() => {
//     let data = [...allClients];

//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }

//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }

//     if (searchCompany.trim()) {
//       data = data.filter((c) =>
//         c.company_name?.toLowerCase().includes(searchCompany.toLowerCase())
//       );
//     }

//     if (searchClient.trim()) {
//       data = data.filter((c) =>
//         c.client_name?.toLowerCase().includes(searchClient.toLowerCase())
//       );
//     }

//     setClients(data);
//   }, [departmentId, selectedUser, searchCompany, searchClient, allClients]);

//   /* ===============================
//      HELPERS
//   ================================ */
//   const getDepartmentName = (department) =>
//     department && typeof department === "object"
//       ? department.department_name
//       : "-";

//   const getUserName = (user) =>
//     user && typeof user === "object" ? user.name : "-";

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data</h6>

//         <div className="flex border rounded overflow-hidden text-[12px]">
//           <button
//             onClick={() => handleToggle("overall")}
//             className={`px-3 py-1 ${
//               viewMode === "overall"
//                 ? "bg-blue-600 text-white"
//                 : "bg-white"
//             }`}
//           >
//             Overall Data
//           </button>
//           <button
//             onClick={() => handleToggle("master")}
//             className={`px-3 py-1 ${
//               viewMode === "master"
//                 ? "bg-blue-600 text-white"
//                 : "bg-white"
//             }`}
//           >
//             Master Data
//           </button>
//         </div>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         <div
//           className={`grid ${
//             isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//           } bg-gray-100 px-4 py-2 text-[13px] font-semibold`}
//         >
//           <span>Company</span>
//           <span>Client</span>
//           <span>Email</span>
//           <span>Phone</span>
//           {!isOnlyBdUser && <span>Department</span>}
//           {!isOnlyBdUser && <span>Created By</span>}
//           <span className="text-center">Action</span>
//         </div>

//         {clients.map((c) => (
//           <div
//             key={c.id}
//             className={`grid ${
//               isOnlyBdUser ? "grid-cols-5" : "grid-cols-7"
//             } px-4 py-2 text-[12px] border-t`}
//           >
//             <span>{c.company_name}</span>
//             <span className="font-semibold">{c.client_name}</span>
//             <span>{c.email || "-"}</span>
//             <span>{c.phone || "-"}</span>
//             {!isOnlyBdUser && (
//               <span>{getDepartmentName(c.department_id)}</span>
//             )}
//             {!isOnlyBdUser && <span>{getUserName(c.user_id)}</span>}
//             <span className="flex justify-center gap-1">
//               <button
//                 onClick={() => navigate(`/client_md/edit/${c.id}`)}
//                 className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
//               >
//                 Edit
//               </button>
//               <button
//                 onClick={() => removeClient(c.id)}
//                 className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
//               >
//                 Delete
//               </button>
//             </span>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }


//==========>> Old one move button impliemnted




// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";

// import {
//   getMyClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);

//   const [allClients, setAllClients] = useState([]); // source
//   const [clients, setClients] = useState([]);       // filtered

//   const [departments, setDepartments] = useState([]);
//   const [usersList, setUsersList] = useState([]);

//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");

//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
// // toggle state
// const [viewMode, setViewMode] = useState("master"); // master | overall

// const handleToggle = (mode) => {
//   setViewMode(mode);
//   if (mode === "overall") {
//     navigate("/client_business");
//   }
// };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       // 🔑 MASTER DATA ONLY (NO YEAR)
//       const masterData =
//       (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );
    

//       setAllClients(masterData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      FILTER PIPELINE
//   ================================ */
//   useEffect(() => {
//     let data = [...allClients];

//     /* DEPARTMENT FILTER */
//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }

//     /* USER FILTER */
//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }

//     /* COMPANY SEARCH */
//     if (searchCompany.trim()) {
//       const q = searchCompany.toLowerCase();
//       data = data.filter((c) =>
//         (c.company_name || "").toLowerCase().includes(q)
//       );
//     }

//     /* CLIENT SEARCH */
//     if (searchClient.trim()) {
//       const q = searchClient.toLowerCase();
//       data = data.filter((c) =>
//         (c.client_name || "").toLowerCase().includes(q)
//       );
//     }

//     setClients(data);
//   }, [
//     departmentId,
//     selectedUser,
//     searchCompany,
//     searchClient,
//     allClients,
//   ]);

//   /* ===============================
//      DEPARTMENT → USERS
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];

//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      HELPERS
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name;
//     }
//     return "-";
//   };

//   const getUserName = (user) => {
//     if (user && typeof user === "object") {
//       return user.name;
//     }
//     return "-";
//   };

//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setDepartmentId("");
//     setSelectedUser("");
//     setSearchCompany("");
//     setSearchClient("");
//     setUsersList([]);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       {/* <div className="flex justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data</h6>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div> */}

// <div className="flex items-center justify-between mb-4">
//   <h6 className="font-bold text-[15px]">Client Master Data</h6>

//   {/* TOGGLE */}
//   <div className="flex border rounded overflow-hidden text-[12px]">
//     <button
//       onClick={() => handleToggle("overall")}
//       className={`px-3 py-1 ${
//         viewMode === "overall"
//           ? "bg-blue-600 text-white"
//           : "bg-white text-gray-700"
//       }`}
//     >
//       Overall Data
//     </button>

//     <button
//       onClick={() => handleToggle("master")}
//       className={`px-3 py-1 ${
//         viewMode === "master"
//           ? "bg-blue-600 text-white"
//           : "bg-white text-gray-700"
//       }`}
//     >
//       Master Data
//     </button>
//   </div>

//   <button
//     onClick={() => navigate("/client_md/create")}
//     className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//   >
//     + Add Master Data
//   </button>
// </div>


//       {/* FILTERS */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <button
//           onClick={clearFilter}
//           className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded"
//         >
//           Clear
//         </button>

//         <div className="ml-auto text-[12px] font-semibold text-gray-600">
//           Total: {clients.length}
//         </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         <div className="grid grid-cols-7 bg-gray-100 px-4 py-2 text-[13px] font-semibold">
//           <span>Company</span>
//           <span>Client</span>
//           <span>Email</span>
//           <span>Phone</span>
//           <span>Department</span>
//           <span>Created By</span>
//           <span className="text-center">Action</span>
//         </div>

//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">
//             No master data found
//           </div>
//         ) : (
//           clients.map((c) => (
//             <div
//               key={c.id}
//               className="grid grid-cols-7 px-4 py-2 text-[12px] border-t"
//             >
//               <span>{c.company_name}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span>{getUserName(c.user_id)}</span>

//               <span className="flex justify-center gap-1">
//                 <button
//                   onClick={() => navigate(`/client_md/edit/${c.id}`)}
//                   className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
//                 >
//                   Edit
//                 </button>
//                 <button
//                   onClick={() => removeClient(c.id)}
//                   className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
//                 >
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }











//=========================================================>> Additional move button ading 




// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";

// import {
//   getMyClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import {
//   GetDepartmentService,
//   GetUsersByDepartment,
// } from "../../services/DepartmentServices";

// export default function ClientMdList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);

//   const [allClients, setAllClients] = useState([]); // source
//   const [clients, setClients] = useState([]);       // filtered

//   const [departments, setDepartments] = useState([]);
//   const [usersList, setUsersList] = useState([]);

//   const [departmentId, setDepartmentId] = useState("");
//   const [selectedUser, setSelectedUser] = useState("");

//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
// // toggle state
// const [viewMode, setViewMode] = useState("master"); // master | overall

// const handleToggle = (mode) => {
//   setViewMode(mode);
//   if (mode === "overall") {
//     navigate("/client_business");
//   }
// };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({
//           department_id: auth?.department_id?.[0]?.id,
//         });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       // 🔑 MASTER DATA ONLY (NO YEAR)
//       const masterData =
//       (res?.data?.data || []).filter(
//         (c) => Number(c.year) === 2030
//       );
    

//       setAllClients(masterData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      FILTER PIPELINE
//   ================================ */
//   useEffect(() => {
//     let data = [...allClients];

//     /* DEPARTMENT FILTER */
//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }

//     /* USER FILTER */
//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }

//     /* COMPANY SEARCH */
//     if (searchCompany.trim()) {
//       const q = searchCompany.toLowerCase();
//       data = data.filter((c) =>
//         (c.company_name || "").toLowerCase().includes(q)
//       );
//     }

//     /* CLIENT SEARCH */
//     if (searchClient.trim()) {
//       const q = searchClient.toLowerCase();
//       data = data.filter((c) =>
//         (c.client_name || "").toLowerCase().includes(q)
//       );
//     }

//     setClients(data);
//   }, [
//     departmentId,
//     selectedUser,
//     searchCompany,
//     searchClient,
//     allClients,
//   ]);

//   /* ===============================
//      DEPARTMENT → USERS
//   ================================ */
//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);

//     if (!deptId) return;

//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];

//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      HELPERS
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name;
//     }
//     return "-";
//   };

//   const getUserName = (user) => {
//     if (user && typeof user === "object") {
//       return user.name;
//     }
//     return "-";
//   };

//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setDepartmentId("");
//     setSelectedUser("");
//     setSearchCompany("");
//     setSearchClient("");
//     setUsersList([]);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       {/* <div className="flex justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Master Data</h6>

//         <button
//           onClick={() => navigate("/client_md/create")}
//           className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//         >
//           + Add Master Data
//         </button>
//       </div> */}

// <div className="flex items-center justify-between mb-4">
//   <h6 className="font-bold text-[15px]">Client Master Data</h6>

//   {/* TOGGLE */}
//   <div className="flex border rounded overflow-hidden text-[12px]">
//     <button
//       onClick={() => handleToggle("overall")}
//       className={`px-3 py-1 ${
//         viewMode === "overall"
//           ? "bg-blue-600 text-white"
//           : "bg-white text-gray-700"
//       }`}
//     >
//       Overall Data
//     </button>

//     <button
//       onClick={() => handleToggle("master")}
//       className={`px-3 py-1 ${
//         viewMode === "master"
//           ? "bg-blue-600 text-white"
//           : "bg-white text-gray-700"
//       }`}
//     >
//       Master Data
//     </button>
//   </div>

//   <button
//     onClick={() => navigate("/client_md/create")}
//     className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//   >
//     + Add Master Data
//   </button>
// </div>


//       {/* FILTERS */}
//       <div className="flex flex-wrap gap-2 mb-4">
//         <select
//           value={departmentId}
//           onChange={handleDeptChange}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Departments</option>
//           {departments.map((d) => (
//             <option key={d.id} value={d.id}>
//               {d.department_name}
//             </option>
//           ))}
//         </select>

//         <select
//           value={selectedUser}
//           onChange={(e) => setSelectedUser(e.target.value)}
//           disabled={!departmentId}
//           className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
//         >
//           <option value="">All Users</option>
//           {usersList.map((u) => (
//             <option key={u.value} value={u.value}>
//               {u.label}
//             </option>
//           ))}
//         </select>

//         <input
//           placeholder="Search Company"
//           value={searchCompany}
//           onChange={(e) => setSearchCompany(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <input
//           placeholder="Search Client"
//           value={searchClient}
//           onChange={(e) => setSearchClient(e.target.value)}
//           className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
//         />

//         <button
//           onClick={clearFilter}
//           className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded"
//         >
//           Clear
//         </button>

//         <div className="ml-auto text-[12px] font-semibold text-gray-600">
//           Total: {clients.length}
//         </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         <div className="grid grid-cols-7 bg-gray-100 px-4 py-2 text-[13px] font-semibold">
//           <span>Company</span>
//           <span>Client</span>
//           <span>Email</span>
//           <span>Phone</span>
//           <span>Department</span>
//           <span>Created By</span>
//           <span className="text-center">Action</span>
//         </div>

//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">
//             No master data found
//           </div>
//         ) : (
//           clients.map((c) => (
//             <div
//               key={c.id}
//               className="grid grid-cols-7 px-4 py-2 text-[12px] border-t"
//             >
//               <span>{c.company_name}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span>{getUserName(c.user_id)}</span>

//               <span className="flex justify-center gap-1">
//                 <button
//                   onClick={() => navigate(`/client_md/edit/${c.id}`)}
//                   className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
//                 >
//                   Edit
//                 </button>
//                 <button
//                   onClick={() => removeClient(c.id)}
//                   className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
//                 >
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }


//=======>> Adding the toggle 


