import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import * as XLSX from "xlsx";

import {
  getMyClientBusiness,
  createClientBusiness,
  filterClientBusiness,
  deleteClientBusiness,
} from "../../services/ClientBusinessService";
import { GetDepartmentService,GetUsersByDepartment } from "../../services/DepartmentServices";
import { updateClientBusiness } from "../../services/ClientBusinessService";


export default function ClientBusinessList() {
  const navigate = useNavigate();
  const auth = useSelector((state) => state.Auth);

  /* ===============================
     ROLE CHECKS
  ================================ */
  const isAdmin = auth?.roles?.includes("admin");
  const isMdAdmin = auth?.roles?.includes("md_admin");
  const isHod = auth?.roles?.includes("hod");
  const isBdUser = auth?.roles?.includes("bd_user");

  const isSuperAdmin = isAdmin || isMdAdmin;
  const isHodOnly = isHod && !isSuperAdmin;
  const canUpload = isSuperAdmin || isHodOnly || isBdUser;
  const [searchCompany, setSearchCompany] = useState("");
  const [searchClient, setSearchClient] = useState("");
  
  /* ===============================
     STATE
  ================================ */
  const [loading, setLoading] = useState(true);

  const [allClients, setAllClients] = useState([]); // 🔐 source of truth
  const [clients, setClients] = useState([]);       // derived data
  const [departments, setDepartments] = useState([]);

  const [year, setYear] = useState(null); // number | null
  const [departmentId, setDepartmentId] = useState("");

  /* ===============================
     UPLOAD STATE
  ================================ */
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadMessage, setUploadMessage] = useState("");
  const [uploadError, setUploadError] = useState("");
  const [usersList, setUsersList] = useState([]);
  const [selectedUser, setSelectedUser] = useState("");
  // Move to Master modal state
const [showMoveModal, setShowMoveModal] = useState(false);
const [selectedClient, setSelectedClient] = useState(null);
const [moving, setMoving] = useState(false);


  //toggle state
  const [viewMode, setViewMode] = useState("overall"); // overall | master

  const handleToggle = (mode) => {
    setViewMode(mode);
  
    if (mode === "overall") {
      navigate("/client_business");
    }
  
    if (mode === "master") {
      navigate("/client_md");
    }
  
    if (mode === "analytics") {
      navigate("/client_md/analytics");
    }
  };
  
  
  /* ===============================
     USER DEPARTMENTS
  ================================ */
  const hodDepartmentIds = (auth?.department_id || []).map(
    (d) => d?.id || d?._id
  );

  const userDepartmentNames = (auth?.department_id || []).map(
    (d) => d?.department_name
  );

  /* ===============================
     EXCEL HELPERS
  ================================ */
  const HEADER_ALIASES = {
    year: ["year", "Year", "YEAR"],
    department_name: ["department", "department name", "department_name"],
    client_name: ["client", "client name", "client_name"],
    company_name: ["company", "company name", "company_name"],
    email: ["email", "email id", "email_id"],
    phone: ["phone", "mobile", "mobile number"],
  };

  const getValueByHeader = (row, aliases) => {
    for (const key of Object.keys(row)) {
      if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
        return row[key];
      }
    }
    return "";
  };

  /* ===============================
     INITIAL LOAD
  ================================ */
  useEffect(() => {
    loadInitial();
  }, []);

  const loadInitial = async () => {
    setLoading(true);
    try {
      const depRes = await GetDepartmentService();
      setDepartments(depRes?.data?.datas || []);
  
      let res;
      if (isSuperAdmin) {
        res = await filterClientBusiness({});
      } else if (isHodOnly) {
        res = await filterClientBusiness({ department_id: hodDepartmentIds[0] });
      } else {
        res = await getMyClientBusiness();
      }
  
      // ✅ EXCLUDE MASTER DATA (year === 2030)
      const overallData = (res?.data?.data || []).filter(
        (c) => Number(c.year) !== 2030
      );
  
      setAllClients(overallData);
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };
  


  useEffect(() => {
    let data = [...allClients];
  
    /* ===============================
       YEAR FILTER
    ================================ */
    if (year !== null) {
      data = data.filter(
        (c) => Number(c.year) === Number(year)
      );
    }
  
    /* ===============================
       DEPARTMENT FILTER
    ================================ */
    if (departmentId) {
      data = data.filter(
        (c) =>
          (typeof c.department_id === "object"
            ? c.department_id.id
            : c.department_id) === departmentId
      );
    }
  
    /* ===============================
       USER FILTER
    ================================ */
    if (selectedUser) {
      data = data.filter(
        (c) =>
          (typeof c.user_id === "object"
            ? c.user_id._id || c.user_id.id
            : c.user_id) === selectedUser
      );
    }
  
    /* ===============================
       COMPANY NAME SEARCH
    ================================ */
    if (searchCompany.trim()) {
      const q = searchCompany.toLowerCase();
      data = data.filter((c) =>
        (c.company_name || "").toLowerCase().includes(q)
      );
    }
  
    /* ===============================
       CLIENT NAME SEARCH
    ================================ */
    if (searchClient.trim()) {
      const q = searchClient.toLowerCase();
      data = data.filter((c) =>
        (c.client_name || "").toLowerCase().includes(q)
      );
    }
  
    setClients(data);
  }, [
    year,
    departmentId,
    selectedUser,
    searchCompany,
    searchClient,
    allClients,
  ]);
  
  /* ===============================
     CLEAR FILTER
  ================================ */
  const clearFilter = () => {
    setYear(null);
    setDepartmentId("");
    setSelectedUser("");
    setUsersList([]);
  };
  

  /* ===============================
     DELETE
  ================================ */
  const removeClient = async (id) => {
    if (!window.confirm("Delete this client record?")) return;
    await deleteClientBusiness(id);
    loadInitial();
  };

  /* ===============================
     YEARS
  ================================ */
  // const years = Array.from({ length: 13 }, (_, i) => 2013 + i);
/* ===============================
   YEARS (2013 to 2026 ONLY)
=============================== */
const years = Array.from(
  { length: 2026 - 2013 + 1 },
  (_, i) => 2013 + i
);


  
  /* ===============================
     DEPARTMENT NAME
  ================================ */
  const getDepartmentName = (department) => {
    if (department && typeof department === "object") {
      return department.department_name || "-";
    }
    if (typeof department === "string") {
      return (
        departments.find((d) => d.id === department)?.department_name || "-"
      );
    }
    return "-";
  };


  const handleDeptChange = async (e) => {
    const deptId = e.target.value;
    setDepartmentId(deptId);
    setSelectedUser("");
    setUsersList([]);
  
    if (!deptId) return;
  
    try {
      const res = await GetUsersByDepartment(deptId);
      const list = res?.data?.datas || [];
  
      setUsersList(
        list.map((u) => ({
          label: u.name,
          value: u._id,
        }))
      );
    } catch (err) {
      console.error("Error loading users:", err);
    }
  };
  const handleUserChange = (e) => {
    setSelectedUser(e.target.value);
  };
    
  /* ===============================
     EXCEL UPLOAD
  ================================ */
  const handleExcelUpload = async (file) => {
    if (!file) return;

    setUploading(true);
    setUploadProgress(0);
    setUploadMessage("Uploading Excel…");
    setUploadError("");

    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        const workbook = XLSX.read(e.target.result, { type: "binary" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet);

        const departmentMap = {};
        departments.forEach((d) => {
          departmentMap[d.department_name.toLowerCase().trim()] = d.id;
        });

        let uploaded = 0;
        for (const row of rows) {
          const deptName = String(
            getValueByHeader(row, HEADER_ALIASES.department_name)
          )
            .toLowerCase()
            .trim();

          if (!isSuperAdmin && !userDepartmentNames.map(d => d.toLowerCase()).includes(deptName)) {
            throw new Error(`Department mismatch: ${deptName}`);
          }

          await createClientBusiness({
            year: Number(getValueByHeader(row, HEADER_ALIASES.year)),
            client_name: getValueByHeader(row, HEADER_ALIASES.client_name),
            company_name: getValueByHeader(row, HEADER_ALIASES.company_name),
            email: getValueByHeader(row, HEADER_ALIASES.email) || "",
            phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
            department_id: departmentMap[deptName],
          });

          uploaded++;
          setUploadProgress(Math.round((uploaded / rows.length) * 100));
        }

        setUploadMessage("✅ Upload successful");
        loadInitial();
      } catch (err) {
        setUploadError(err.message);
      } finally {
        setUploading(false);
      }
    };

    reader.readAsBinaryString(file);
  };

  //move button handling
  // const moveToMaster = async (client) => {
  //   if (!window.confirm("Move this record to Master Data?")) return;
  
  //   try {
  //     await updateClientBusiness(client.id, {
  //       year: 2030, // 🔑 MASTER FLAG
  //     });
  
  //     alert("Moved to Master Data successfully");
  //     loadInitial(); // refresh list
  //   } catch (err) {
  //     alert("Failed to move to Master Data");
  //   }
  // };
  
  const openMoveModal = (client) => {
    setSelectedClient(client);
    setShowMoveModal(true);
  };
  
  const closeMoveModal = () => {
    setShowMoveModal(false);
    setSelectedClient(null);
  };
  
  const confirmMoveToMaster = async () => {
    if (!selectedClient) return;
  
    setMoving(true);
    try {
      await updateClientBusiness(selectedClient.id, {
        year: 2030, // 🔑 MASTER FLAG
      });
  
      closeMoveModal();
      loadInitial();
    } catch (err) {
      alert("Failed to move record to Master Data");
    } finally {
      setMoving(false);
    }
  };
  

  /* ===============================
     RENDER
  ================================ */
  return (
    <div className="p-6">
      {/* HEADER */}
  {/* HEADER */}
<div className="flex items-center justify-between mb-4">
  <h6 className="font-bold text-[15px]">Client Details</h6>

  {/* TOGGLE */}
  <div className="flex border rounded overflow-hidden text-[12px]">
  <button
    onClick={() => handleToggle("overall")}
    className={`px-3 py-1 ${
      viewMode === "overall"
        ? "bg-blue-600 text-white"
        : "bg-white text-gray-700"
    }`}
  >
    Overall Data
  </button>

  <button
    onClick={() => handleToggle("master")}
    className={`px-3 py-1 ${
      viewMode === "master"
        ? "bg-blue-600 text-white"
        : "bg-white text-gray-700"
    }`}
  >
    Master Data
  </button>

  <button
    onClick={() => handleToggle("analytics")}
    className={`px-3 py-1 ${
      viewMode === "analytics"
        ? "bg-blue-600 text-white"
        : "bg-white text-gray-700"
    }`}
  >
    Clients Analytics
  </button>
</div>


  <button
    onClick={() => navigate("/client_business/create")}
    className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
  >
    + Add Data
  </button>
</div>


      {/* FILTERS */}
      <div className="flex gap-2 mb-4">
        <select
          value={year ?? ""}
          onChange={(e) => setYear(e.target.value ? Number(e.target.value) : null)}
          className="border px-3 py-1 text-[12px] rounded"
        >
          <option value="">All Years</option>
          {years.map((y) => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>

        {/* {isSuperAdmin && (
          <select
            value={departmentId}
            onChange={(e) => setDepartmentId(e.target.value)}
            className="border px-3 py-1 text-[12px] rounded"
          >
            <option value="">All Departments</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>{d.department_name}</option>
            ))}
          </select>
        )} */}

<select
  value={departmentId}
  onChange={handleDeptChange}
  className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
>
  <option value="">All Departments</option>
  {departments.map((d) => (
    <option key={d.id} value={d.id}>
      {d.department_name}
    </option>
  ))}
</select>
<select
  value={selectedUser}
  onChange={handleUserChange}
  disabled={!departmentId}
  className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
>
  <option value="">All Users</option>
  {usersList.map((u) => (
    <option key={u.value} value={u.value}>
      {u.label}
    </option>
  ))}
</select>
<input
  type="text"
  placeholder="Search Company"
  value={searchCompany}
  onChange={(e) => setSearchCompany(e.target.value)}
  className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
/>

<input
  type="text"
  placeholder="Search Client"
  value={searchClient}
  onChange={(e) => setSearchClient(e.target.value)}
  className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
/>


        <button onClick={clearFilter} className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded">
          Clear
        </button>

        <div className="text-[12px] py-3 text-gray-600 font-semibold">
        Total: ({clients.length})
       </div>
      </div>

      {/* TABLE */}
      <div className="bg-white border rounded">
        {loading ? (
          <div className="p-4 text-center">Loading...</div>
        ) : clients.length === 0 ? (
          <div className="p-4 text-center text-gray-500">No records found</div>
        ) : (
          clients.map((c) => (
            <div key={c.id} className="grid grid-cols-7 px-4 py-2 border-t text-[12px]">
              <span>{c.year}</span>
              <span>{getDepartmentName(c.department_id)}</span>
              <span className="font-semibold">{c.client_name}</span>
              <span>{c.company_name}</span>
              <span>{c.email || "-"}</span>
              <span>{c.phone || "-"}</span>
              <span className="flex justify-center gap-1">
  <button
    onClick={() => navigate(`/client_business/edit/${c.id}`)}
    className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
  >
    Edit
  </button>

  <button
    onClick={() => removeClient(c.id)}
    className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
  >
    Delete
  </button>

  {Number(c.year) !== 2030 && (
    <button
    onClick={() => openMoveModal(c)}
      className="px-2 py-1 bg-purple-600 text-white text-[11px] rounded"
    >
      Move to MD
    </button>
  )}
</span>

            </div>
          ))
        )}
        {showMoveModal && (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
    <div className="bg-white rounded-lg w-[360px] shadow-lg">
      {/* Header */}
      <div className="px-4 py-3 border-b font-semibold text-[14px]">
        Move to Master Data
      </div>

      {/* Body */}
      <div className="px-4 py-3 text-[13px] text-gray-700">
        Are you sure you want to move
        <span className="font-semibold"> {selectedClient?.client_name}</span>{" "}
        from <span className="font-semibold">Overall Data</span> to{" "}
        <span className="font-semibold">Master Data</span>?
      </div>

      {/* Footer */}
      <div className="flex justify-end gap-2 px-4 py-3 border-t">
        <button
          onClick={closeMoveModal}
          disabled={moving}
          className="px-3 py-1 text-[12px] border rounded"
        >
          Cancel
        </button>

        <button
          onClick={confirmMoveToMaster}
          disabled={moving}
          className="px-3 py-1 text-[12px] bg-purple-600 text-white rounded"
        >
          {moving ? "Moving..." : "Confirm"}
        </button>
      </div>
    </div>
  </div>
)}

      </div>
    </div>
  );
}










//==========>>> Toggle three creating




// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import * as XLSX from "xlsx";

// import {
//   getMyClientBusiness,
//   createClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService,GetUsersByDepartment } from "../../services/DepartmentServices";
// import { updateClientBusiness } from "../../services/ClientBusinessService";


// export default function ClientBusinessList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");
//   const isBdUser = auth?.roles?.includes("bd_user");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;
//   const canUpload = isSuperAdmin || isHodOnly || isBdUser;
//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
  
//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);

//   const [allClients, setAllClients] = useState([]); // 🔐 source of truth
//   const [clients, setClients] = useState([]);       // derived data
//   const [departments, setDepartments] = useState([]);

//   const [year, setYear] = useState(null); // number | null
//   const [departmentId, setDepartmentId] = useState("");

//   /* ===============================
//      UPLOAD STATE
//   ================================ */
//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [uploadMessage, setUploadMessage] = useState("");
//   const [uploadError, setUploadError] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [selectedUser, setSelectedUser] = useState("");
//   // Move to Master modal state
// const [showMoveModal, setShowMoveModal] = useState(false);
// const [selectedClient, setSelectedClient] = useState(null);
// const [moving, setMoving] = useState(false);


//   //toggle state
//   const [viewMode, setViewMode] = useState("overall"); // overall | master

//   const handleToggle = (mode) => {
//     setViewMode(mode);
//     if (mode === "master") {
//       navigate("/client_md");
//     }
//   };
  
//   /* ===============================
//      USER DEPARTMENTS
//   ================================ */
//   const hodDepartmentIds = (auth?.department_id || []).map(
//     (d) => d?.id || d?._id
//   );

//   const userDepartmentNames = (auth?.department_id || []).map(
//     (d) => d?.department_name
//   );

//   /* ===============================
//      EXCEL HELPERS
//   ================================ */
//   const HEADER_ALIASES = {
//     year: ["year", "Year", "YEAR"],
//     department_name: ["department", "department name", "department_name"],
//     client_name: ["client", "client name", "client_name"],
//     company_name: ["company", "company name", "company_name"],
//     email: ["email", "email id", "email_id"],
//     phone: ["phone", "mobile", "mobile number"],
//   };

//   const getValueByHeader = (row, aliases) => {
//     for (const key of Object.keys(row)) {
//       if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
//         return row[key];
//       }
//     }
//     return "";
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);
  
//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({ department_id: hodDepartmentIds[0] });
//       } else {
//         res = await getMyClientBusiness();
//       }
  
//       // ✅ EXCLUDE MASTER DATA (year === 2030)
//       const overallData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) !== 2030
//       );
  
//       setAllClients(overallData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };
  


//   useEffect(() => {
//     let data = [...allClients];
  
//     /* ===============================
//        YEAR FILTER
//     ================================ */
//     if (year !== null) {
//       data = data.filter(
//         (c) => Number(c.year) === Number(year)
//       );
//     }
  
//     /* ===============================
//        DEPARTMENT FILTER
//     ================================ */
//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }
  
//     /* ===============================
//        USER FILTER
//     ================================ */
//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }
  
//     /* ===============================
//        COMPANY NAME SEARCH
//     ================================ */
//     if (searchCompany.trim()) {
//       const q = searchCompany.toLowerCase();
//       data = data.filter((c) =>
//         (c.company_name || "").toLowerCase().includes(q)
//       );
//     }
  
//     /* ===============================
//        CLIENT NAME SEARCH
//     ================================ */
//     if (searchClient.trim()) {
//       const q = searchClient.toLowerCase();
//       data = data.filter((c) =>
//         (c.client_name || "").toLowerCase().includes(q)
//       );
//     }
  
//     setClients(data);
//   }, [
//     year,
//     departmentId,
//     selectedUser,
//     searchCompany,
//     searchClient,
//     allClients,
//   ]);
  
//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setYear(null);
//     setDepartmentId("");
//     setSelectedUser("");
//     setUsersList([]);
//   };
  

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this client record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      YEARS
//   ================================ */
//   // const years = Array.from({ length: 13 }, (_, i) => 2013 + i);
// /* ===============================
//    YEARS (2013 to 2026 ONLY)
// =============================== */
// const years = Array.from(
//   { length: 2026 - 2013 + 1 },
//   (_, i) => 2013 + i
// );


  
//   /* ===============================
//      DEPARTMENT NAME
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name || "-";
//     }
//     if (typeof department === "string") {
//       return (
//         departments.find((d) => d.id === department)?.department_name || "-"
//       );
//     }
//     return "-";
//   };


//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);
  
//     if (!deptId) return;
  
//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];
  
//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error("Error loading users:", err);
//     }
//   };
//   const handleUserChange = (e) => {
//     setSelectedUser(e.target.value);
//   };
    
//   /* ===============================
//      EXCEL UPLOAD
//   ================================ */
//   const handleExcelUpload = async (file) => {
//     if (!file) return;

//     setUploading(true);
//     setUploadProgress(0);
//     setUploadMessage("Uploading Excel…");
//     setUploadError("");

//     const reader = new FileReader();

//     reader.onload = async (e) => {
//       try {
//         const workbook = XLSX.read(e.target.result, { type: "binary" });
//         const sheet = workbook.Sheets[workbook.SheetNames[0]];
//         const rows = XLSX.utils.sheet_to_json(sheet);

//         const departmentMap = {};
//         departments.forEach((d) => {
//           departmentMap[d.department_name.toLowerCase().trim()] = d.id;
//         });

//         let uploaded = 0;
//         for (const row of rows) {
//           const deptName = String(
//             getValueByHeader(row, HEADER_ALIASES.department_name)
//           )
//             .toLowerCase()
//             .trim();

//           if (!isSuperAdmin && !userDepartmentNames.map(d => d.toLowerCase()).includes(deptName)) {
//             throw new Error(`Department mismatch: ${deptName}`);
//           }

//           await createClientBusiness({
//             year: Number(getValueByHeader(row, HEADER_ALIASES.year)),
//             client_name: getValueByHeader(row, HEADER_ALIASES.client_name),
//             company_name: getValueByHeader(row, HEADER_ALIASES.company_name),
//             email: getValueByHeader(row, HEADER_ALIASES.email) || "",
//             phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
//             department_id: departmentMap[deptName],
//           });

//           uploaded++;
//           setUploadProgress(Math.round((uploaded / rows.length) * 100));
//         }

//         setUploadMessage("✅ Upload successful");
//         loadInitial();
//       } catch (err) {
//         setUploadError(err.message);
//       } finally {
//         setUploading(false);
//       }
//     };

//     reader.readAsBinaryString(file);
//   };

//   //move button handling
//   // const moveToMaster = async (client) => {
//   //   if (!window.confirm("Move this record to Master Data?")) return;
  
//   //   try {
//   //     await updateClientBusiness(client.id, {
//   //       year: 2030, // 🔑 MASTER FLAG
//   //     });
  
//   //     alert("Moved to Master Data successfully");
//   //     loadInitial(); // refresh list
//   //   } catch (err) {
//   //     alert("Failed to move to Master Data");
//   //   }
//   // };
  
//   const openMoveModal = (client) => {
//     setSelectedClient(client);
//     setShowMoveModal(true);
//   };
  
//   const closeMoveModal = () => {
//     setShowMoveModal(false);
//     setSelectedClient(null);
//   };
  
//   const confirmMoveToMaster = async () => {
//     if (!selectedClient) return;
  
//     setMoving(true);
//     try {
//       await updateClientBusiness(selectedClient.id, {
//         year: 2030, // 🔑 MASTER FLAG
//       });
  
//       closeMoveModal();
//       loadInitial();
//     } catch (err) {
//       alert("Failed to move record to Master Data");
//     } finally {
//       setMoving(false);
//     }
//   };
  

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//   {/* HEADER */}
// <div className="flex items-center justify-between mb-4">
//   <h6 className="font-bold text-[15px]">Client Details</h6>

//   {/* TOGGLE */}
//   <div className="flex border rounded overflow-hidden text-[12px]">
//     <button
//       onClick={() => handleToggle("overall")}
//       className={`px-3 py-1 ${
//         viewMode === "overall"
//           ? "bg-blue-600 text-white"
//           : "bg-white text-gray-700"
//       }`}
//     >
//       Overall Data
//     </button>

//     <button
//       onClick={() => handleToggle("master")}
//       className={`px-3 py-1 ${
//         viewMode === "master"
//           ? "bg-blue-600 text-white"
//           : "bg-white text-gray-700"
//       }`}
//     >
//       Master Data
//     </button>
//   </div>

//   <button
//     onClick={() => navigate("/client_business/create")}
//     className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//   >
//     + Add Data
//   </button>
// </div>


//       {/* FILTERS */}
//       <div className="flex gap-2 mb-4">
//         <select
//           value={year ?? ""}
//           onChange={(e) => setYear(e.target.value ? Number(e.target.value) : null)}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Years</option>
//           {years.map((y) => (
//             <option key={y} value={y}>{y}</option>
//           ))}
//         </select>

//         {/* {isSuperAdmin && (
//           <select
//             value={departmentId}
//             onChange={(e) => setDepartmentId(e.target.value)}
//             className="border px-3 py-1 text-[12px] rounded"
//           >
//             <option value="">All Departments</option>
//             {departments.map((d) => (
//               <option key={d.id} value={d.id}>{d.department_name}</option>
//             ))}
//           </select>
//         )} */}

// <select
//   value={departmentId}
//   onChange={handleDeptChange}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Departments</option>
//   {departments.map((d) => (
//     <option key={d.id} value={d.id}>
//       {d.department_name}
//     </option>
//   ))}
// </select>
// <select
//   value={selectedUser}
//   onChange={handleUserChange}
//   disabled={!departmentId}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Users</option>
//   {usersList.map((u) => (
//     <option key={u.value} value={u.value}>
//       {u.label}
//     </option>
//   ))}
// </select>
// <input
//   type="text"
//   placeholder="Search Company"
//   value={searchCompany}
//   onChange={(e) => setSearchCompany(e.target.value)}
//   className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
// />

// <input
//   type="text"
//   placeholder="Search Client"
//   value={searchClient}
//   onChange={(e) => setSearchClient(e.target.value)}
//   className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
// />


//         <button onClick={clearFilter} className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded">
//           Clear
//         </button>

//         <div className="text-[12px] py-3 text-gray-600 font-semibold">
//         Total: ({clients.length})
//        </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">No records found</div>
//         ) : (
//           clients.map((c) => (
//             <div key={c.id} className="grid grid-cols-7 px-4 py-2 border-t text-[12px]">
//               <span>{c.year}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.company_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               <span className="flex justify-center gap-1">
//   <button
//     onClick={() => navigate(`/client_business/edit/${c.id}`)}
//     className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
//   >
//     Edit
//   </button>

//   <button
//     onClick={() => removeClient(c.id)}
//     className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
//   >
//     Delete
//   </button>

//   {Number(c.year) !== 2030 && (
//     <button
//     onClick={() => openMoveModal(c)}
//       className="px-2 py-1 bg-purple-600 text-white text-[11px] rounded"
//     >
//       Move to MD
//     </button>
//   )}
// </span>

//             </div>
//           ))
//         )}
//         {showMoveModal && (
//   <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
//     <div className="bg-white rounded-lg w-[360px] shadow-lg">
//       {/* Header */}
//       <div className="px-4 py-3 border-b font-semibold text-[14px]">
//         Move to Master Data
//       </div>

//       {/* Body */}
//       <div className="px-4 py-3 text-[13px] text-gray-700">
//         Are you sure you want to move
//         <span className="font-semibold"> {selectedClient?.client_name}</span>{" "}
//         from <span className="font-semibold">Overall Data</span> to{" "}
//         <span className="font-semibold">Master Data</span>?
//       </div>

//       {/* Footer */}
//       <div className="flex justify-end gap-2 px-4 py-3 border-t">
//         <button
//           onClick={closeMoveModal}
//           disabled={moving}
//           className="px-3 py-1 text-[12px] border rounded"
//         >
//           Cancel
//         </button>

//         <button
//           onClick={confirmMoveToMaster}
//           disabled={moving}
//           className="px-3 py-1 text-[12px] bg-purple-600 text-white rounded"
//         >
//           {moving ? "Moving..." : "Confirm"}
//         </button>
//       </div>
//     </div>
//   </div>
// )}

//       </div>
//     </div>
//   );
// }










//===================>> Old one till 2025




// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import * as XLSX from "xlsx";

// import {
//   getMyClientBusiness,
//   createClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService,GetUsersByDepartment } from "../../services/DepartmentServices";
// import { updateClientBusiness } from "../../services/ClientBusinessService";


// export default function ClientBusinessList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");
//   const isBdUser = auth?.roles?.includes("bd_user");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;
//   const canUpload = isSuperAdmin || isHodOnly || isBdUser;
//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
  
//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);

//   const [allClients, setAllClients] = useState([]); // 🔐 source of truth
//   const [clients, setClients] = useState([]);       // derived data
//   const [departments, setDepartments] = useState([]);

//   const [year, setYear] = useState(null); // number | null
//   const [departmentId, setDepartmentId] = useState("");

//   /* ===============================
//      UPLOAD STATE
//   ================================ */
//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [uploadMessage, setUploadMessage] = useState("");
//   const [uploadError, setUploadError] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [selectedUser, setSelectedUser] = useState("");
//   // Move to Master modal state
// const [showMoveModal, setShowMoveModal] = useState(false);
// const [selectedClient, setSelectedClient] = useState(null);
// const [moving, setMoving] = useState(false);


//   //toggle state
//   const [viewMode, setViewMode] = useState("overall"); // overall | master

//   const handleToggle = (mode) => {
//     setViewMode(mode);
//     if (mode === "master") {
//       navigate("/client_md");
//     }
//   };
  
//   /* ===============================
//      USER DEPARTMENTS
//   ================================ */
//   const hodDepartmentIds = (auth?.department_id || []).map(
//     (d) => d?.id || d?._id
//   );

//   const userDepartmentNames = (auth?.department_id || []).map(
//     (d) => d?.department_name
//   );

//   /* ===============================
//      EXCEL HELPERS
//   ================================ */
//   const HEADER_ALIASES = {
//     year: ["year", "Year", "YEAR"],
//     department_name: ["department", "department name", "department_name"],
//     client_name: ["client", "client name", "client_name"],
//     company_name: ["company", "company name", "company_name"],
//     email: ["email", "email id", "email_id"],
//     phone: ["phone", "mobile", "mobile number"],
//   };

//   const getValueByHeader = (row, aliases) => {
//     for (const key of Object.keys(row)) {
//       if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
//         return row[key];
//       }
//     }
//     return "";
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);
  
//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({ department_id: hodDepartmentIds[0] });
//       } else {
//         res = await getMyClientBusiness();
//       }
  
//       // ✅ EXCLUDE MASTER DATA (year === 2030)
//       const overallData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) !== 2030
//       );
  
//       setAllClients(overallData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };
  


//   useEffect(() => {
//     let data = [...allClients];
  
//     /* ===============================
//        YEAR FILTER
//     ================================ */
//     if (year !== null) {
//       data = data.filter(
//         (c) => Number(c.year) === Number(year)
//       );
//     }
  
//     /* ===============================
//        DEPARTMENT FILTER
//     ================================ */
//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }
  
//     /* ===============================
//        USER FILTER
//     ================================ */
//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }
  
//     /* ===============================
//        COMPANY NAME SEARCH
//     ================================ */
//     if (searchCompany.trim()) {
//       const q = searchCompany.toLowerCase();
//       data = data.filter((c) =>
//         (c.company_name || "").toLowerCase().includes(q)
//       );
//     }
  
//     /* ===============================
//        CLIENT NAME SEARCH
//     ================================ */
//     if (searchClient.trim()) {
//       const q = searchClient.toLowerCase();
//       data = data.filter((c) =>
//         (c.client_name || "").toLowerCase().includes(q)
//       );
//     }
  
//     setClients(data);
//   }, [
//     year,
//     departmentId,
//     selectedUser,
//     searchCompany,
//     searchClient,
//     allClients,
//   ]);
  
//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setYear(null);
//     setDepartmentId("");
//     setSelectedUser("");
//     setUsersList([]);
//   };
  

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this client record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      YEARS
//   ================================ */
//   const years = Array.from({ length: 13 }, (_, i) => 2013 + i);


  
//   /* ===============================
//      DEPARTMENT NAME
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name || "-";
//     }
//     if (typeof department === "string") {
//       return (
//         departments.find((d) => d.id === department)?.department_name || "-"
//       );
//     }
//     return "-";
//   };


//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);
  
//     if (!deptId) return;
  
//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];
  
//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error("Error loading users:", err);
//     }
//   };
//   const handleUserChange = (e) => {
//     setSelectedUser(e.target.value);
//   };
    
//   /* ===============================
//      EXCEL UPLOAD
//   ================================ */
//   const handleExcelUpload = async (file) => {
//     if (!file) return;

//     setUploading(true);
//     setUploadProgress(0);
//     setUploadMessage("Uploading Excel…");
//     setUploadError("");

//     const reader = new FileReader();

//     reader.onload = async (e) => {
//       try {
//         const workbook = XLSX.read(e.target.result, { type: "binary" });
//         const sheet = workbook.Sheets[workbook.SheetNames[0]];
//         const rows = XLSX.utils.sheet_to_json(sheet);

//         const departmentMap = {};
//         departments.forEach((d) => {
//           departmentMap[d.department_name.toLowerCase().trim()] = d.id;
//         });

//         let uploaded = 0;
//         for (const row of rows) {
//           const deptName = String(
//             getValueByHeader(row, HEADER_ALIASES.department_name)
//           )
//             .toLowerCase()
//             .trim();

//           if (!isSuperAdmin && !userDepartmentNames.map(d => d.toLowerCase()).includes(deptName)) {
//             throw new Error(`Department mismatch: ${deptName}`);
//           }

//           await createClientBusiness({
//             year: Number(getValueByHeader(row, HEADER_ALIASES.year)),
//             client_name: getValueByHeader(row, HEADER_ALIASES.client_name),
//             company_name: getValueByHeader(row, HEADER_ALIASES.company_name),
//             email: getValueByHeader(row, HEADER_ALIASES.email) || "",
//             phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
//             department_id: departmentMap[deptName],
//           });

//           uploaded++;
//           setUploadProgress(Math.round((uploaded / rows.length) * 100));
//         }

//         setUploadMessage("✅ Upload successful");
//         loadInitial();
//       } catch (err) {
//         setUploadError(err.message);
//       } finally {
//         setUploading(false);
//       }
//     };

//     reader.readAsBinaryString(file);
//   };

//   //move button handling
//   // const moveToMaster = async (client) => {
//   //   if (!window.confirm("Move this record to Master Data?")) return;
  
//   //   try {
//   //     await updateClientBusiness(client.id, {
//   //       year: 2030, // 🔑 MASTER FLAG
//   //     });
  
//   //     alert("Moved to Master Data successfully");
//   //     loadInitial(); // refresh list
//   //   } catch (err) {
//   //     alert("Failed to move to Master Data");
//   //   }
//   // };
  
//   const openMoveModal = (client) => {
//     setSelectedClient(client);
//     setShowMoveModal(true);
//   };
  
//   const closeMoveModal = () => {
//     setShowMoveModal(false);
//     setSelectedClient(null);
//   };
  
//   const confirmMoveToMaster = async () => {
//     if (!selectedClient) return;
  
//     setMoving(true);
//     try {
//       await updateClientBusiness(selectedClient.id, {
//         year: 2030, // 🔑 MASTER FLAG
//       });
  
//       closeMoveModal();
//       loadInitial();
//     } catch (err) {
//       alert("Failed to move record to Master Data");
//     } finally {
//       setMoving(false);
//     }
//   };
  

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//   {/* HEADER */}
// <div className="flex items-center justify-between mb-4">
//   <h6 className="font-bold text-[15px]">Client Details</h6>

//   {/* TOGGLE */}
//   <div className="flex border rounded overflow-hidden text-[12px]">
//     <button
//       onClick={() => handleToggle("overall")}
//       className={`px-3 py-1 ${
//         viewMode === "overall"
//           ? "bg-blue-600 text-white"
//           : "bg-white text-gray-700"
//       }`}
//     >
//       Overall Data
//     </button>

//     <button
//       onClick={() => handleToggle("master")}
//       className={`px-3 py-1 ${
//         viewMode === "master"
//           ? "bg-blue-600 text-white"
//           : "bg-white text-gray-700"
//       }`}
//     >
//       Master Data
//     </button>
//   </div>

//   <button
//     onClick={() => navigate("/client_business/create")}
//     className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//   >
//     + Add Data
//   </button>
// </div>


//       {/* FILTERS */}
//       <div className="flex gap-2 mb-4">
//         <select
//           value={year ?? ""}
//           onChange={(e) => setYear(e.target.value ? Number(e.target.value) : null)}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Years</option>
//           {years.map((y) => (
//             <option key={y} value={y}>{y}</option>
//           ))}
//         </select>

//         {/* {isSuperAdmin && (
//           <select
//             value={departmentId}
//             onChange={(e) => setDepartmentId(e.target.value)}
//             className="border px-3 py-1 text-[12px] rounded"
//           >
//             <option value="">All Departments</option>
//             {departments.map((d) => (
//               <option key={d.id} value={d.id}>{d.department_name}</option>
//             ))}
//           </select>
//         )} */}

// <select
//   value={departmentId}
//   onChange={handleDeptChange}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Departments</option>
//   {departments.map((d) => (
//     <option key={d.id} value={d.id}>
//       {d.department_name}
//     </option>
//   ))}
// </select>
// <select
//   value={selectedUser}
//   onChange={handleUserChange}
//   disabled={!departmentId}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Users</option>
//   {usersList.map((u) => (
//     <option key={u.value} value={u.value}>
//       {u.label}
//     </option>
//   ))}
// </select>
// <input
//   type="text"
//   placeholder="Search Company"
//   value={searchCompany}
//   onChange={(e) => setSearchCompany(e.target.value)}
//   className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
// />

// <input
//   type="text"
//   placeholder="Search Client"
//   value={searchClient}
//   onChange={(e) => setSearchClient(e.target.value)}
//   className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
// />


//         <button onClick={clearFilter} className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded">
//           Clear
//         </button>

//         <div className="text-[12px] py-3 text-gray-600 font-semibold">
//         Total: ({clients.length})
//        </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">No records found</div>
//         ) : (
//           clients.map((c) => (
//             <div key={c.id} className="grid grid-cols-7 px-4 py-2 border-t text-[12px]">
//               <span>{c.year}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.company_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               <span className="flex justify-center gap-1">
//   <button
//     onClick={() => navigate(`/client_business/edit/${c.id}`)}
//     className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded"
//   >
//     Edit
//   </button>

//   <button
//     onClick={() => removeClient(c.id)}
//     className="px-2 py-1 bg-red-600 text-white text-[11px] rounded"
//   >
//     Delete
//   </button>

//   {Number(c.year) !== 2030 && (
//     <button
//     onClick={() => openMoveModal(c)}
//       className="px-2 py-1 bg-purple-600 text-white text-[11px] rounded"
//     >
//       Move to MD
//     </button>
//   )}
// </span>

//             </div>
//           ))
//         )}
//         {showMoveModal && (
//   <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
//     <div className="bg-white rounded-lg w-[360px] shadow-lg">
//       {/* Header */}
//       <div className="px-4 py-3 border-b font-semibold text-[14px]">
//         Move to Master Data
//       </div>

//       {/* Body */}
//       <div className="px-4 py-3 text-[13px] text-gray-700">
//         Are you sure you want to move
//         <span className="font-semibold"> {selectedClient?.client_name}</span>{" "}
//         from <span className="font-semibold">Overall Data</span> to{" "}
//         <span className="font-semibold">Master Data</span>?
//       </div>

//       {/* Footer */}
//       <div className="flex justify-end gap-2 px-4 py-3 border-t">
//         <button
//           onClick={closeMoveModal}
//           disabled={moving}
//           className="px-3 py-1 text-[12px] border rounded"
//         >
//           Cancel
//         </button>

//         <button
//           onClick={confirmMoveToMaster}
//           disabled={moving}
//           className="px-3 py-1 text-[12px] bg-purple-600 text-white rounded"
//         >
//           {moving ? "Moving..." : "Confirm"}
//         </button>
//       </div>
//     </div>
//   </div>
// )}

//       </div>
//     </div>
//   );
// }











//======================>>> Additional move button adding 



// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import * as XLSX from "xlsx";

// import {
//   getMyClientBusiness,
//   createClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService,GetUsersByDepartment } from "../../services/DepartmentServices";

// export default function ClientBusinessList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");
//   const isBdUser = auth?.roles?.includes("bd_user");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;
//   const canUpload = isSuperAdmin || isHodOnly || isBdUser;
//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
  
//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);

//   const [allClients, setAllClients] = useState([]); // 🔐 source of truth
//   const [clients, setClients] = useState([]);       // derived data
//   const [departments, setDepartments] = useState([]);

//   const [year, setYear] = useState(null); // number | null
//   const [departmentId, setDepartmentId] = useState("");

//   /* ===============================
//      UPLOAD STATE
//   ================================ */
//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [uploadMessage, setUploadMessage] = useState("");
//   const [uploadError, setUploadError] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [selectedUser, setSelectedUser] = useState("");

//   //toggle state
//   const [viewMode, setViewMode] = useState("overall"); // overall | master

//   const handleToggle = (mode) => {
//     setViewMode(mode);
//     if (mode === "master") {
//       navigate("/client_md");
//     }
//   };
  
//   /* ===============================
//      USER DEPARTMENTS
//   ================================ */
//   const hodDepartmentIds = (auth?.department_id || []).map(
//     (d) => d?.id || d?._id
//   );

//   const userDepartmentNames = (auth?.department_id || []).map(
//     (d) => d?.department_name
//   );

//   /* ===============================
//      EXCEL HELPERS
//   ================================ */
//   const HEADER_ALIASES = {
//     year: ["year", "Year", "YEAR"],
//     department_name: ["department", "department name", "department_name"],
//     client_name: ["client", "client name", "client_name"],
//     company_name: ["company", "company name", "company_name"],
//     email: ["email", "email id", "email_id"],
//     phone: ["phone", "mobile", "mobile number"],
//   };

//   const getValueByHeader = (row, aliases) => {
//     for (const key of Object.keys(row)) {
//       if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
//         return row[key];
//       }
//     }
//     return "";
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);
  
//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({ department_id: hodDepartmentIds[0] });
//       } else {
//         res = await getMyClientBusiness();
//       }
  
//       // ✅ EXCLUDE MASTER DATA (year === 2030)
//       const overallData = (res?.data?.data || []).filter(
//         (c) => Number(c.year) !== 2030
//       );
  
//       setAllClients(overallData);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };
  


//   useEffect(() => {
//     let data = [...allClients];
  
//     /* ===============================
//        YEAR FILTER
//     ================================ */
//     if (year !== null) {
//       data = data.filter(
//         (c) => Number(c.year) === Number(year)
//       );
//     }
  
//     /* ===============================
//        DEPARTMENT FILTER
//     ================================ */
//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }
  
//     /* ===============================
//        USER FILTER
//     ================================ */
//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }
  
//     /* ===============================
//        COMPANY NAME SEARCH
//     ================================ */
//     if (searchCompany.trim()) {
//       const q = searchCompany.toLowerCase();
//       data = data.filter((c) =>
//         (c.company_name || "").toLowerCase().includes(q)
//       );
//     }
  
//     /* ===============================
//        CLIENT NAME SEARCH
//     ================================ */
//     if (searchClient.trim()) {
//       const q = searchClient.toLowerCase();
//       data = data.filter((c) =>
//         (c.client_name || "").toLowerCase().includes(q)
//       );
//     }
  
//     setClients(data);
//   }, [
//     year,
//     departmentId,
//     selectedUser,
//     searchCompany,
//     searchClient,
//     allClients,
//   ]);
  
//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setYear(null);
//     setDepartmentId("");
//     setSelectedUser("");
//     setUsersList([]);
//   };
  

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this client record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      YEARS
//   ================================ */
//   const years = Array.from({ length: 13 }, (_, i) => 2013 + i);


  
//   /* ===============================
//      DEPARTMENT NAME
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name || "-";
//     }
//     if (typeof department === "string") {
//       return (
//         departments.find((d) => d.id === department)?.department_name || "-"
//       );
//     }
//     return "-";
//   };


//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);
  
//     if (!deptId) return;
  
//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];
  
//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error("Error loading users:", err);
//     }
//   };
//   const handleUserChange = (e) => {
//     setSelectedUser(e.target.value);
//   };
    
//   /* ===============================
//      EXCEL UPLOAD
//   ================================ */
//   const handleExcelUpload = async (file) => {
//     if (!file) return;

//     setUploading(true);
//     setUploadProgress(0);
//     setUploadMessage("Uploading Excel…");
//     setUploadError("");

//     const reader = new FileReader();

//     reader.onload = async (e) => {
//       try {
//         const workbook = XLSX.read(e.target.result, { type: "binary" });
//         const sheet = workbook.Sheets[workbook.SheetNames[0]];
//         const rows = XLSX.utils.sheet_to_json(sheet);

//         const departmentMap = {};
//         departments.forEach((d) => {
//           departmentMap[d.department_name.toLowerCase().trim()] = d.id;
//         });

//         let uploaded = 0;
//         for (const row of rows) {
//           const deptName = String(
//             getValueByHeader(row, HEADER_ALIASES.department_name)
//           )
//             .toLowerCase()
//             .trim();

//           if (!isSuperAdmin && !userDepartmentNames.map(d => d.toLowerCase()).includes(deptName)) {
//             throw new Error(`Department mismatch: ${deptName}`);
//           }

//           await createClientBusiness({
//             year: Number(getValueByHeader(row, HEADER_ALIASES.year)),
//             client_name: getValueByHeader(row, HEADER_ALIASES.client_name),
//             company_name: getValueByHeader(row, HEADER_ALIASES.company_name),
//             email: getValueByHeader(row, HEADER_ALIASES.email) || "",
//             phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
//             department_id: departmentMap[deptName],
//           });

//           uploaded++;
//           setUploadProgress(Math.round((uploaded / rows.length) * 100));
//         }

//         setUploadMessage("✅ Upload successful");
//         loadInitial();
//       } catch (err) {
//         setUploadError(err.message);
//       } finally {
//         setUploading(false);
//       }
//     };

//     reader.readAsBinaryString(file);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//   {/* HEADER */}
// <div className="flex items-center justify-between mb-4">
//   <h6 className="font-bold text-[15px]">Client Details</h6>

//   {/* TOGGLE */}
//   <div className="flex border rounded overflow-hidden text-[12px]">
//     <button
//       onClick={() => handleToggle("overall")}
//       className={`px-3 py-1 ${
//         viewMode === "overall"
//           ? "bg-blue-600 text-white"
//           : "bg-white text-gray-700"
//       }`}
//     >
//       Overall Data
//     </button>

//     <button
//       onClick={() => handleToggle("master")}
//       className={`px-3 py-1 ${
//         viewMode === "master"
//           ? "bg-blue-600 text-white"
//           : "bg-white text-gray-700"
//       }`}
//     >
//       Master Data
//     </button>
//   </div>

//   <button
//     onClick={() => navigate("/client_business/create")}
//     className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//   >
//     + Add Data
//   </button>
// </div>


//       {/* FILTERS */}
//       <div className="flex gap-2 mb-4">
//         <select
//           value={year ?? ""}
//           onChange={(e) => setYear(e.target.value ? Number(e.target.value) : null)}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Years</option>
//           {years.map((y) => (
//             <option key={y} value={y}>{y}</option>
//           ))}
//         </select>

//         {/* {isSuperAdmin && (
//           <select
//             value={departmentId}
//             onChange={(e) => setDepartmentId(e.target.value)}
//             className="border px-3 py-1 text-[12px] rounded"
//           >
//             <option value="">All Departments</option>
//             {departments.map((d) => (
//               <option key={d.id} value={d.id}>{d.department_name}</option>
//             ))}
//           </select>
//         )} */}

// <select
//   value={departmentId}
//   onChange={handleDeptChange}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Departments</option>
//   {departments.map((d) => (
//     <option key={d.id} value={d.id}>
//       {d.department_name}
//     </option>
//   ))}
// </select>
// <select
//   value={selectedUser}
//   onChange={handleUserChange}
//   disabled={!departmentId}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Users</option>
//   {usersList.map((u) => (
//     <option key={u.value} value={u.value}>
//       {u.label}
//     </option>
//   ))}
// </select>
// <input
//   type="text"
//   placeholder="Search Company"
//   value={searchCompany}
//   onChange={(e) => setSearchCompany(e.target.value)}
//   className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
// />

// <input
//   type="text"
//   placeholder="Search Client"
//   value={searchClient}
//   onChange={(e) => setSearchClient(e.target.value)}
//   className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
// />


//         <button onClick={clearFilter} className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded">
//           Clear
//         </button>

//         <div className="text-[12px] py-3 text-gray-600 font-semibold">
//         Total: ({clients.length})
//        </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">No records found</div>
//         ) : (
//           clients.map((c) => (
//             <div key={c.id} className="grid grid-cols-7 px-4 py-2 border-t text-[12px]">
//               <span>{c.year}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.company_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               <span className="flex justify-center gap-1">
//                 <button onClick={() => navigate(`/client_business/edit/${c.id}`)} className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded">
//                   Edit
//                 </button>
//                 <button onClick={() => removeClient(c.id)} className="px-2 py-1 bg-red-600 text-white text-[11px] rounded">
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }











//===========>>> Updating Toglle button





// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import * as XLSX from "xlsx";

// import {
//   getMyClientBusiness,
//   createClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService,GetUsersByDepartment } from "../../services/DepartmentServices";

// export default function ClientBusinessList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");
//   const isBdUser = auth?.roles?.includes("bd_user");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;
//   const canUpload = isSuperAdmin || isHodOnly || isBdUser;
//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
  
//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);

//   const [allClients, setAllClients] = useState([]); // 🔐 source of truth
//   const [clients, setClients] = useState([]);       // derived data
//   const [departments, setDepartments] = useState([]);

//   const [year, setYear] = useState(null); // number | null
//   const [departmentId, setDepartmentId] = useState("");

//   /* ===============================
//      UPLOAD STATE
//   ================================ */
//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [uploadMessage, setUploadMessage] = useState("");
//   const [uploadError, setUploadError] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [selectedUser, setSelectedUser] = useState("");
  
//   /* ===============================
//      USER DEPARTMENTS
//   ================================ */
//   const hodDepartmentIds = (auth?.department_id || []).map(
//     (d) => d?.id || d?._id
//   );

//   const userDepartmentNames = (auth?.department_id || []).map(
//     (d) => d?.department_name
//   );

//   /* ===============================
//      EXCEL HELPERS
//   ================================ */
//   const HEADER_ALIASES = {
//     year: ["year", "Year", "YEAR"],
//     department_name: ["department", "department name", "department_name"],
//     client_name: ["client", "client name", "client_name"],
//     company_name: ["company", "company name", "company_name"],
//     email: ["email", "email id", "email_id"],
//     phone: ["phone", "mobile", "mobile number"],
//   };

//   const getValueByHeader = (row, aliases) => {
//     for (const key of Object.keys(row)) {
//       if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
//         return row[key];
//       }
//     }
//     return "";
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({ department_id: hodDepartmentIds[0] });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       setAllClients(res?.data?.data || []);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

  
//   // useEffect(() => {
//   //   let data = [...allClients];
  
//   //   /* ✅ YEAR FILTER */
//   //   if (year !== null) {
//   //     data = data.filter(
//   //       (c) => Number(c.year) === Number(year)
//   //     );
//   //   }
  
//   //   /* ✅ DEPARTMENT FILTER */
//   //   if (departmentId) {
//   //     data = data.filter(
//   //       (c) =>
//   //         (typeof c.department_id === "object"
//   //           ? c.department_id.id
//   //           : c.department_id) === departmentId
//   //     );
//   //   }
  
//   //   /* ✅ USER FILTER (NEW) */
//   //   if (selectedUser) {
//   //     data = data.filter(
//   //       (c) =>
//   //         (typeof c.user_id === "object"
//   //           ? c.user_id.id || c.user_id._id
//   //           : c.user_id) === selectedUser
//   //     );
//   //   }
  
//   //   setClients(data);
//   // }, [year, departmentId, selectedUser, allClients]);
  


//   useEffect(() => {
//     let data = [...allClients];
  
//     /* ===============================
//        YEAR FILTER
//     ================================ */
//     if (year !== null) {
//       data = data.filter(
//         (c) => Number(c.year) === Number(year)
//       );
//     }
  
//     /* ===============================
//        DEPARTMENT FILTER
//     ================================ */
//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }
  
//     /* ===============================
//        USER FILTER
//     ================================ */
//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }
  
//     /* ===============================
//        COMPANY NAME SEARCH
//     ================================ */
//     if (searchCompany.trim()) {
//       const q = searchCompany.toLowerCase();
//       data = data.filter((c) =>
//         (c.company_name || "").toLowerCase().includes(q)
//       );
//     }
  
//     /* ===============================
//        CLIENT NAME SEARCH
//     ================================ */
//     if (searchClient.trim()) {
//       const q = searchClient.toLowerCase();
//       data = data.filter((c) =>
//         (c.client_name || "").toLowerCase().includes(q)
//       );
//     }
  
//     setClients(data);
//   }, [
//     year,
//     departmentId,
//     selectedUser,
//     searchCompany,
//     searchClient,
//     allClients,
//   ]);
  
//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setYear(null);
//     setDepartmentId("");
//     setSelectedUser("");
//     setUsersList([]);
//   };
  

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this client record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      YEARS
//   ================================ */
//   const years = Array.from({ length: 13 }, (_, i) => 2013 + i);


  
//   /* ===============================
//      DEPARTMENT NAME
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name || "-";
//     }
//     if (typeof department === "string") {
//       return (
//         departments.find((d) => d.id === department)?.department_name || "-"
//       );
//     }
//     return "-";
//   };


//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);
  
//     if (!deptId) return;
  
//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];
  
//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error("Error loading users:", err);
//     }
//   };
//   const handleUserChange = (e) => {
//     setSelectedUser(e.target.value);
//   };
    
//   /* ===============================
//      EXCEL UPLOAD
//   ================================ */
//   const handleExcelUpload = async (file) => {
//     if (!file) return;

//     setUploading(true);
//     setUploadProgress(0);
//     setUploadMessage("Uploading Excel…");
//     setUploadError("");

//     const reader = new FileReader();

//     reader.onload = async (e) => {
//       try {
//         const workbook = XLSX.read(e.target.result, { type: "binary" });
//         const sheet = workbook.Sheets[workbook.SheetNames[0]];
//         const rows = XLSX.utils.sheet_to_json(sheet);

//         const departmentMap = {};
//         departments.forEach((d) => {
//           departmentMap[d.department_name.toLowerCase().trim()] = d.id;
//         });

//         let uploaded = 0;
//         for (const row of rows) {
//           const deptName = String(
//             getValueByHeader(row, HEADER_ALIASES.department_name)
//           )
//             .toLowerCase()
//             .trim();

//           if (!isSuperAdmin && !userDepartmentNames.map(d => d.toLowerCase()).includes(deptName)) {
//             throw new Error(`Department mismatch: ${deptName}`);
//           }

//           await createClientBusiness({
//             year: Number(getValueByHeader(row, HEADER_ALIASES.year)),
//             client_name: getValueByHeader(row, HEADER_ALIASES.client_name),
//             company_name: getValueByHeader(row, HEADER_ALIASES.company_name),
//             email: getValueByHeader(row, HEADER_ALIASES.email) || "",
//             phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
//             department_id: departmentMap[deptName],
//           });

//           uploaded++;
//           setUploadProgress(Math.round((uploaded / rows.length) * 100));
//         }

//         setUploadMessage("✅ Upload successful");
//         loadInitial();
//       } catch (err) {
//         setUploadError(err.message);
//       } finally {
//         setUploading(false);
//       }
//     };

//     reader.readAsBinaryString(file);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Details</h6>

//         <div className="flex gap-2">
//           {/* {canUpload && (
//             <label className={`px-3 py-1 text-white text-[12px] rounded cursor-pointer ${uploading ? "bg-gray-400" : "bg-green-600"}`}>
//               Upload Excel
//               <input type="file" hidden accept=".xls,.xlsx" onChange={(e) => handleExcelUpload(e.target.files[0])} />
//             </label>
//           )} */}
//           <button onClick={() => navigate("/client_business/create")} className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded">
//             + Add Data
//           </button>
//         </div>
//       </div>

//       {/* FILTERS */}
//       <div className="flex gap-2 mb-4">
//         <select
//           value={year ?? ""}
//           onChange={(e) => setYear(e.target.value ? Number(e.target.value) : null)}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Years</option>
//           {years.map((y) => (
//             <option key={y} value={y}>{y}</option>
//           ))}
//         </select>

//         {/* {isSuperAdmin && (
//           <select
//             value={departmentId}
//             onChange={(e) => setDepartmentId(e.target.value)}
//             className="border px-3 py-1 text-[12px] rounded"
//           >
//             <option value="">All Departments</option>
//             {departments.map((d) => (
//               <option key={d.id} value={d.id}>{d.department_name}</option>
//             ))}
//           </select>
//         )} */}

// <select
//   value={departmentId}
//   onChange={handleDeptChange}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Departments</option>
//   {departments.map((d) => (
//     <option key={d.id} value={d.id}>
//       {d.department_name}
//     </option>
//   ))}
// </select>
// <select
//   value={selectedUser}
//   onChange={handleUserChange}
//   disabled={!departmentId}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Users</option>
//   {usersList.map((u) => (
//     <option key={u.value} value={u.value}>
//       {u.label}
//     </option>
//   ))}
// </select>
// <input
//   type="text"
//   placeholder="Search Company"
//   value={searchCompany}
//   onChange={(e) => setSearchCompany(e.target.value)}
//   className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
// />

// <input
//   type="text"
//   placeholder="Search Client"
//   value={searchClient}
//   onChange={(e) => setSearchClient(e.target.value)}
//   className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
// />


//         <button onClick={clearFilter} className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded">
//           Clear
//         </button>

//         <div className="text-[12px] py-3 text-gray-600 font-semibold">
//         Total: ({clients.length})
//        </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">No records found</div>
//         ) : (
//           clients.map((c) => (
//             <div key={c.id} className="grid grid-cols-7 px-4 py-2 border-t text-[12px]">
//               <span>{c.year}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.company_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               <span className="flex justify-center gap-1">
//                 <button onClick={() => navigate(`/client_business/edit/${c.id}`)} className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded">
//                   Edit
//                 </button>
//                 <button onClick={() => removeClient(c.id)} className="px-2 py-1 bg-red-600 text-white text-[11px] rounded">
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }










//=======>> Old one with Jana 27 not updating just checking





// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import * as XLSX from "xlsx";

// import {
//   getMyClientBusiness,
//   createClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService,GetUsersByDepartment } from "../../services/DepartmentServices";

// export default function ClientBusinessList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");
//   const isBdUser = auth?.roles?.includes("bd_user");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;
//   const canUpload = isSuperAdmin || isHodOnly || isBdUser;
//   const [searchCompany, setSearchCompany] = useState("");
//   const [searchClient, setSearchClient] = useState("");
  
//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);

//   const [allClients, setAllClients] = useState([]); // 🔐 source of truth
//   const [clients, setClients] = useState([]);       // derived data
//   const [departments, setDepartments] = useState([]);

//   const [year, setYear] = useState(null); // number | null
//   const [departmentId, setDepartmentId] = useState("");

//   /* ===============================
//      UPLOAD STATE
//   ================================ */
//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [uploadMessage, setUploadMessage] = useState("");
//   const [uploadError, setUploadError] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [selectedUser, setSelectedUser] = useState("");
  
//   /* ===============================
//      USER DEPARTMENTS
//   ================================ */
//   const hodDepartmentIds = (auth?.department_id || []).map(
//     (d) => d?.id || d?._id
//   );

//   const userDepartmentNames = (auth?.department_id || []).map(
//     (d) => d?.department_name
//   );

//   /* ===============================
//      EXCEL HELPERS
//   ================================ */
//   const HEADER_ALIASES = {
//     year: ["year", "Year", "YEAR"],
//     department_name: ["department", "department name", "department_name"],
//     client_name: ["client", "client name", "client_name"],
//     company_name: ["company", "company name", "company_name"],
//     email: ["email", "email id", "email_id"],
//     phone: ["phone", "mobile", "mobile number"],
//   };

//   const getValueByHeader = (row, aliases) => {
//     for (const key of Object.keys(row)) {
//       if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
//         return row[key];
//       }
//     }
//     return "";
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({ department_id: hodDepartmentIds[0] });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       setAllClients(res?.data?.data || []);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

  
//   // useEffect(() => {
//   //   let data = [...allClients];
  
//   //   /* ✅ YEAR FILTER */
//   //   if (year !== null) {
//   //     data = data.filter(
//   //       (c) => Number(c.year) === Number(year)
//   //     );
//   //   }
  
//   //   /* ✅ DEPARTMENT FILTER */
//   //   if (departmentId) {
//   //     data = data.filter(
//   //       (c) =>
//   //         (typeof c.department_id === "object"
//   //           ? c.department_id.id
//   //           : c.department_id) === departmentId
//   //     );
//   //   }
  
//   //   /* ✅ USER FILTER (NEW) */
//   //   if (selectedUser) {
//   //     data = data.filter(
//   //       (c) =>
//   //         (typeof c.user_id === "object"
//   //           ? c.user_id.id || c.user_id._id
//   //           : c.user_id) === selectedUser
//   //     );
//   //   }
  
//   //   setClients(data);
//   // }, [year, departmentId, selectedUser, allClients]);
  


//   useEffect(() => {
//     let data = [...allClients];
  
//     /* ===============================
//        YEAR FILTER
//     ================================ */
//     if (year !== null) {
//       data = data.filter(
//         (c) => Number(c.year) === Number(year)
//       );
//     }
  
//     /* ===============================
//        DEPARTMENT FILTER
//     ================================ */
//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }
  
//     /* ===============================
//        USER FILTER
//     ================================ */
//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id._id || c.user_id.id
//             : c.user_id) === selectedUser
//       );
//     }
  
//     /* ===============================
//        COMPANY NAME SEARCH
//     ================================ */
//     if (searchCompany.trim()) {
//       const q = searchCompany.toLowerCase();
//       data = data.filter((c) =>
//         (c.company_name || "").toLowerCase().includes(q)
//       );
//     }
  
//     /* ===============================
//        CLIENT NAME SEARCH
//     ================================ */
//     if (searchClient.trim()) {
//       const q = searchClient.toLowerCase();
//       data = data.filter((c) =>
//         (c.client_name || "").toLowerCase().includes(q)
//       );
//     }
  
//     setClients(data);
//   }, [
//     year,
//     departmentId,
//     selectedUser,
//     searchCompany,
//     searchClient,
//     allClients,
//   ]);
  
//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setYear(null);
//     setDepartmentId("");
//     setSelectedUser("");
//     setUsersList([]);
//   };
  

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this client record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      YEARS
//   ================================ */
//   const years = Array.from({ length: 13 }, (_, i) => 2013 + i);


  
//   /* ===============================
//      DEPARTMENT NAME
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name || "-";
//     }
//     if (typeof department === "string") {
//       return (
//         departments.find((d) => d.id === department)?.department_name || "-"
//       );
//     }
//     return "-";
//   };


//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);
  
//     if (!deptId) return;
  
//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];
  
//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error("Error loading users:", err);
//     }
//   };
//   const handleUserChange = (e) => {
//     setSelectedUser(e.target.value);
//   };
    
//   /* ===============================
//      EXCEL UPLOAD
//   ================================ */
//   const handleExcelUpload = async (file) => {
//     if (!file) return;

//     setUploading(true);
//     setUploadProgress(0);
//     setUploadMessage("Uploading Excel…");
//     setUploadError("");

//     const reader = new FileReader();

//     reader.onload = async (e) => {
//       try {
//         const workbook = XLSX.read(e.target.result, { type: "binary" });
//         const sheet = workbook.Sheets[workbook.SheetNames[0]];
//         const rows = XLSX.utils.sheet_to_json(sheet);

//         const departmentMap = {};
//         departments.forEach((d) => {
//           departmentMap[d.department_name.toLowerCase().trim()] = d.id;
//         });

//         let uploaded = 0;
//         for (const row of rows) {
//           const deptName = String(
//             getValueByHeader(row, HEADER_ALIASES.department_name)
//           )
//             .toLowerCase()
//             .trim();

//           if (!isSuperAdmin && !userDepartmentNames.map(d => d.toLowerCase()).includes(deptName)) {
//             throw new Error(`Department mismatch: ${deptName}`);
//           }

//           await createClientBusiness({
//             year: Number(getValueByHeader(row, HEADER_ALIASES.year)),
//             client_name: getValueByHeader(row, HEADER_ALIASES.client_name),
//             company_name: getValueByHeader(row, HEADER_ALIASES.company_name),
//             email: getValueByHeader(row, HEADER_ALIASES.email) || "",
//             phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
//             department_id: departmentMap[deptName],
//           });

//           uploaded++;
//           setUploadProgress(Math.round((uploaded / rows.length) * 100));
//         }

//         setUploadMessage("✅ Upload successful");
//         loadInitial();
//       } catch (err) {
//         setUploadError(err.message);
//       } finally {
//         setUploading(false);
//       }
//     };

//     reader.readAsBinaryString(file);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Details</h6>

//         <div className="flex gap-2">
//           {canUpload && (
//             <label className={`px-3 py-1 text-white text-[12px] rounded cursor-pointer ${uploading ? "bg-gray-400" : "bg-green-600"}`}>
//               Upload Excel
//               <input type="file" hidden accept=".xls,.xlsx" onChange={(e) => handleExcelUpload(e.target.files[0])} />
//             </label>
//           )}
//           <button onClick={() => navigate("/client_business/create")} className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded">
//             + Add Data
//           </button>
//         </div>
//       </div>

//       {/* FILTERS */}
//       <div className="flex gap-2 mb-4">
//         <select
//           value={year ?? ""}
//           onChange={(e) => setYear(e.target.value ? Number(e.target.value) : null)}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Years</option>
//           {years.map((y) => (
//             <option key={y} value={y}>{y}</option>
//           ))}
//         </select>

//         {/* {isSuperAdmin && (
//           <select
//             value={departmentId}
//             onChange={(e) => setDepartmentId(e.target.value)}
//             className="border px-3 py-1 text-[12px] rounded"
//           >
//             <option value="">All Departments</option>
//             {departments.map((d) => (
//               <option key={d.id} value={d.id}>{d.department_name}</option>
//             ))}
//           </select>
//         )} */}

// <select
//   value={departmentId}
//   onChange={handleDeptChange}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Departments</option>
//   {departments.map((d) => (
//     <option key={d.id} value={d.id}>
//       {d.department_name}
//     </option>
//   ))}
// </select>
// <select
//   value={selectedUser}
//   onChange={handleUserChange}
//   disabled={!departmentId}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Users</option>
//   {usersList.map((u) => (
//     <option key={u.value} value={u.value}>
//       {u.label}
//     </option>
//   ))}
// </select>
// <input
//   type="text"
//   placeholder="Search Company"
//   value={searchCompany}
//   onChange={(e) => setSearchCompany(e.target.value)}
//   className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
// />

// <input
//   type="text"
//   placeholder="Search Client"
//   value={searchClient}
//   onChange={(e) => setSearchClient(e.target.value)}
//   className="border px-3 py-1 text-[12px] rounded min-w-[180px]"
// />


//         <button onClick={clearFilter} className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded">
//           Clear
//         </button>

//         <div className="text-[12px] py-3 text-gray-600 font-semibold">
//         Total123: ({clients.length})
//        </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">No records found</div>
//         ) : (
//           clients.map((c) => (
//             <div key={c.id} className="grid grid-cols-7 px-4 py-2 border-t text-[12px]">
//               <span>{c.year}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.company_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               <span className="flex justify-center gap-1">
//                 <button onClick={() => navigate(`/client_business/edit/${c.id}`)} className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded">
//                   Edit
//                 </button>
//                 <button onClick={() => removeClient(c.id)} className="px-2 py-1 bg-red-600 text-white text-[11px] rounded">
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }









//================>>> Old 2




// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import * as XLSX from "xlsx";

// import {
//   getMyClientBusiness,
//   createClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService,GetUsersByDepartment } from "../../services/DepartmentServices";

// export default function ClientBusinessList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");
//   const isBdUser = auth?.roles?.includes("bd_user");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;
//   const canUpload = isSuperAdmin || isHodOnly || isBdUser;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);

//   const [allClients, setAllClients] = useState([]); // 🔐 source of truth
//   const [clients, setClients] = useState([]);       // derived data
//   const [departments, setDepartments] = useState([]);

//   const [year, setYear] = useState(null); // number | null
//   const [departmentId, setDepartmentId] = useState("");

//   /* ===============================
//      UPLOAD STATE
//   ================================ */
//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [uploadMessage, setUploadMessage] = useState("");
//   const [uploadError, setUploadError] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [selectedUser, setSelectedUser] = useState("");
  
//   /* ===============================
//      USER DEPARTMENTS
//   ================================ */
//   const hodDepartmentIds = (auth?.department_id || []).map(
//     (d) => d?.id || d?._id
//   );

//   const userDepartmentNames = (auth?.department_id || []).map(
//     (d) => d?.department_name
//   );

//   /* ===============================
//      EXCEL HELPERS
//   ================================ */
//   const HEADER_ALIASES = {
//     year: ["year", "Year", "YEAR"],
//     department_name: ["department", "department name", "department_name"],
//     client_name: ["client", "client name", "client_name"],
//     company_name: ["company", "company name", "company_name"],
//     email: ["email", "email id", "email_id"],
//     phone: ["phone", "mobile", "mobile number"],
//   };

//   const getValueByHeader = (row, aliases) => {
//     for (const key of Object.keys(row)) {
//       if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
//         return row[key];
//       }
//     }
//     return "";
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({ department_id: hodDepartmentIds[0] });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       setAllClients(res?.data?.data || []);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      🔥 AUTO FILTER (THE REAL FIX)
//   ================================ */
//   // useEffect(() => {
//   //   let data = [...allClients];

//   //   // ✅ YEAR FILTER (NUMBER === NUMBER)
//   //   if (year !== null) {
//   //     data = data.filter((c) => Number(c.year) === Number(year));
//   //   }

//   //   // ✅ DEPARTMENT FILTER (ONLY FOR SUPER ADMIN)
//   //   if (isSuperAdmin && departmentId) {
//   //     data = data.filter(
//   //       (c) =>
//   //         (typeof c.department_id === "object"
//   //           ? c.department_id.id
//   //           : c.department_id) === departmentId
//   //     );
//   //   }

//   //   setClients(data);
//   // }, [year, departmentId, allClients, isSuperAdmin]);


//   useEffect(() => {
//     let data = [...allClients];
  
//     /* ✅ YEAR FILTER */
//     if (year !== null) {
//       data = data.filter(
//         (c) => Number(c.year) === Number(year)
//       );
//     }
  
//     /* ✅ DEPARTMENT FILTER */
//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }
  
//     /* ✅ USER FILTER (NEW) */
//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id.id || c.user_id._id
//             : c.user_id) === selectedUser
//       );
//     }
  
//     setClients(data);
//   }, [year, departmentId, selectedUser, allClients]);
  
//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setYear(null);
//     setDepartmentId("");
//     setSelectedUser("");
//     setUsersList([]);
//   };
  

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this client record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      YEARS
//   ================================ */
//   const years = Array.from({ length: 13 }, (_, i) => 2013 + i);


  
//   /* ===============================
//      DEPARTMENT NAME
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name || "-";
//     }
//     if (typeof department === "string") {
//       return (
//         departments.find((d) => d.id === department)?.department_name || "-"
//       );
//     }
//     return "-";
//   };


//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);
  
//     if (!deptId) return;
  
//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];
  
//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error("Error loading users:", err);
//     }
//   };
//   const handleUserChange = (e) => {
//     setSelectedUser(e.target.value);
//   };
    
//   /* ===============================
//      EXCEL UPLOAD
//   ================================ */
//   const handleExcelUpload = async (file) => {
//     if (!file) return;

//     setUploading(true);
//     setUploadProgress(0);
//     setUploadMessage("Uploading Excel…");
//     setUploadError("");

//     const reader = new FileReader();

//     reader.onload = async (e) => {
//       try {
//         const workbook = XLSX.read(e.target.result, { type: "binary" });
//         const sheet = workbook.Sheets[workbook.SheetNames[0]];
//         const rows = XLSX.utils.sheet_to_json(sheet);

//         const departmentMap = {};
//         departments.forEach((d) => {
//           departmentMap[d.department_name.toLowerCase().trim()] = d.id;
//         });

//         let uploaded = 0;
//         for (const row of rows) {
//           const deptName = String(
//             getValueByHeader(row, HEADER_ALIASES.department_name)
//           )
//             .toLowerCase()
//             .trim();

//           if (!isSuperAdmin && !userDepartmentNames.map(d => d.toLowerCase()).includes(deptName)) {
//             throw new Error(`Department mismatch: ${deptName}`);
//           }

//           await createClientBusiness({
//             year: Number(getValueByHeader(row, HEADER_ALIASES.year)),
//             client_name: getValueByHeader(row, HEADER_ALIASES.client_name),
//             company_name: getValueByHeader(row, HEADER_ALIASES.company_name),
//             email: getValueByHeader(row, HEADER_ALIASES.email) || "",
//             phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
//             department_id: departmentMap[deptName],
//           });

//           uploaded++;
//           setUploadProgress(Math.round((uploaded / rows.length) * 100));
//         }

//         setUploadMessage("✅ Upload successful");
//         loadInitial();
//       } catch (err) {
//         setUploadError(err.message);
//       } finally {
//         setUploading(false);
//       }
//     };

//     reader.readAsBinaryString(file);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Details</h6>

//         <div className="flex gap-2">
//           {canUpload && (
//             <label className={`px-3 py-1 text-white text-[12px] rounded cursor-pointer ${uploading ? "bg-gray-400" : "bg-green-600"}`}>
//               Upload Excel
//               <input type="file" hidden accept=".xls,.xlsx" onChange={(e) => handleExcelUpload(e.target.files[0])} />
//             </label>
//           )}
//           <button onClick={() => navigate("/client_business/create")} className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded">
//             + Add Data
//           </button>
//         </div>
//       </div>

//       {/* FILTERS */}
//       <div className="flex gap-2 mb-4">
//         <select
//           value={year ?? ""}
//           onChange={(e) => setYear(e.target.value ? Number(e.target.value) : null)}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Years</option>
//           {years.map((y) => (
//             <option key={y} value={y}>{y}</option>
//           ))}
//         </select>

//         {/* {isSuperAdmin && (
//           <select
//             value={departmentId}
//             onChange={(e) => setDepartmentId(e.target.value)}
//             className="border px-3 py-1 text-[12px] rounded"
//           >
//             <option value="">All Departments</option>
//             {departments.map((d) => (
//               <option key={d.id} value={d.id}>{d.department_name}</option>
//             ))}
//           </select>
//         )} */}

// <select
//   value={departmentId}
//   onChange={handleDeptChange}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Departments</option>
//   {departments.map((d) => (
//     <option key={d.id} value={d.id}>
//       {d.department_name}
//     </option>
//   ))}
// </select>
// <select
//   value={selectedUser}
//   onChange={handleUserChange}
//   disabled={!departmentId}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Users</option>
//   {usersList.map((u) => (
//     <option key={u.value} value={u.value}>
//       {u.label}
//     </option>
//   ))}
// </select>


//         <button onClick={clearFilter} className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded">
//           Clear
//         </button>

//         <div className="text-[12px] py-3 text-gray-600 font-semibold">
//         Total123: ({clients.length})
//        </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">No records found</div>
//         ) : (
//           clients.map((c) => (
//             <div key={c.id} className="grid grid-cols-7 px-4 py-2 border-t text-[12px]">
//               <span>{c.year}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.company_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               <span className="flex justify-center gap-1">
//                 <button onClick={() => navigate(`/client_business/edit/${c.id}`)} className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded">
//                   Edit
//                 </button>
//                 <button onClick={() => removeClient(c.id)} className="px-2 py-1 bg-red-600 text-white text-[11px] rounded">
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }










//===================================================================>>>>old file working as its good

// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import * as XLSX from "xlsx";

// import {
//   getMyClientBusiness,
//   createClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService,GetUsersByDepartment } from "../../services/DepartmentServices";

// export default function ClientBusinessList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");
//   const isBdUser = auth?.roles?.includes("bd_user");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;
//   const canUpload = isSuperAdmin || isHodOnly || isBdUser;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);

//   const [allClients, setAllClients] = useState([]); // 🔐 source of truth
//   const [clients, setClients] = useState([]);       // derived data
//   const [departments, setDepartments] = useState([]);

//   const [year, setYear] = useState(null); // number | null
//   const [departmentId, setDepartmentId] = useState("");

//   /* ===============================
//      UPLOAD STATE
//   ================================ */
//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [uploadMessage, setUploadMessage] = useState("");
//   const [uploadError, setUploadError] = useState("");
//   const [usersList, setUsersList] = useState([]);
//   const [selectedUser, setSelectedUser] = useState("");
  
//   /* ===============================
//      USER DEPARTMENTS
//   ================================ */
//   const hodDepartmentIds = (auth?.department_id || []).map(
//     (d) => d?.id || d?._id
//   );

//   const userDepartmentNames = (auth?.department_id || []).map(
//     (d) => d?.department_name
//   );

//   /* ===============================
//      EXCEL HELPERS
//   ================================ */
//   const HEADER_ALIASES = {
//     year: ["year", "Year", "YEAR"],
//     department_name: ["department", "department name", "department_name"],
//     client_name: ["client", "client name", "client_name"],
//     company_name: ["company", "company name", "company_name"],
//     email: ["email", "email id", "email_id"],
//     phone: ["phone", "mobile", "mobile number"],
//   };

//   const getValueByHeader = (row, aliases) => {
//     for (const key of Object.keys(row)) {
//       if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
//         return row[key];
//       }
//     }
//     return "";
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({ department_id: hodDepartmentIds[0] });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       setAllClients(res?.data?.data || []);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      🔥 AUTO FILTER (THE REAL FIX)
//   ================================ */
//   // useEffect(() => {
//   //   let data = [...allClients];

//   //   // ✅ YEAR FILTER (NUMBER === NUMBER)
//   //   if (year !== null) {
//   //     data = data.filter((c) => Number(c.year) === Number(year));
//   //   }

//   //   // ✅ DEPARTMENT FILTER (ONLY FOR SUPER ADMIN)
//   //   if (isSuperAdmin && departmentId) {
//   //     data = data.filter(
//   //       (c) =>
//   //         (typeof c.department_id === "object"
//   //           ? c.department_id.id
//   //           : c.department_id) === departmentId
//   //     );
//   //   }

//   //   setClients(data);
//   // }, [year, departmentId, allClients, isSuperAdmin]);


//   useEffect(() => {
//     let data = [...allClients];
  
//     /* ✅ YEAR FILTER */
//     if (year !== null) {
//       data = data.filter(
//         (c) => Number(c.year) === Number(year)
//       );
//     }
  
//     /* ✅ DEPARTMENT FILTER */
//     if (departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }
  
//     /* ✅ USER FILTER (NEW) */
//     if (selectedUser) {
//       data = data.filter(
//         (c) =>
//           (typeof c.user_id === "object"
//             ? c.user_id.id || c.user_id._id
//             : c.user_id) === selectedUser
//       );
//     }
  
//     setClients(data);
//   }, [year, departmentId, selectedUser, allClients]);
  
//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setYear(null);
//     setDepartmentId("");
//     setSelectedUser("");
//     setUsersList([]);
//   };
  

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this client record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      YEARS
//   ================================ */
//   const years = Array.from({ length: 13 }, (_, i) => 2013 + i);


  
//   /* ===============================
//      DEPARTMENT NAME
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name || "-";
//     }
//     if (typeof department === "string") {
//       return (
//         departments.find((d) => d.id === department)?.department_name || "-"
//       );
//     }
//     return "-";
//   };


//   const handleDeptChange = async (e) => {
//     const deptId = e.target.value;
//     setDepartmentId(deptId);
//     setSelectedUser("");
//     setUsersList([]);
  
//     if (!deptId) return;
  
//     try {
//       const res = await GetUsersByDepartment(deptId);
//       const list = res?.data?.datas || [];
  
//       setUsersList(
//         list.map((u) => ({
//           label: u.name,
//           value: u._id,
//         }))
//       );
//     } catch (err) {
//       console.error("Error loading users:", err);
//     }
//   };
//   const handleUserChange = (e) => {
//     setSelectedUser(e.target.value);
//   };
    
//   /* ===============================
//      EXCEL UPLOAD
//   ================================ */
//   const handleExcelUpload = async (file) => {
//     if (!file) return;

//     setUploading(true);
//     setUploadProgress(0);
//     setUploadMessage("Uploading Excel…");
//     setUploadError("");

//     const reader = new FileReader();

//     reader.onload = async (e) => {
//       try {
//         const workbook = XLSX.read(e.target.result, { type: "binary" });
//         const sheet = workbook.Sheets[workbook.SheetNames[0]];
//         const rows = XLSX.utils.sheet_to_json(sheet);

//         const departmentMap = {};
//         departments.forEach((d) => {
//           departmentMap[d.department_name.toLowerCase().trim()] = d.id;
//         });

//         let uploaded = 0;
//         for (const row of rows) {
//           const deptName = String(
//             getValueByHeader(row, HEADER_ALIASES.department_name)
//           )
//             .toLowerCase()
//             .trim();

//           if (!isSuperAdmin && !userDepartmentNames.map(d => d.toLowerCase()).includes(deptName)) {
//             throw new Error(`Department mismatch: ${deptName}`);
//           }

//           await createClientBusiness({
//             year: Number(getValueByHeader(row, HEADER_ALIASES.year)),
//             client_name: getValueByHeader(row, HEADER_ALIASES.client_name),
//             company_name: getValueByHeader(row, HEADER_ALIASES.company_name),
//             email: getValueByHeader(row, HEADER_ALIASES.email) || "",
//             phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
//             department_id: departmentMap[deptName],
//           });

//           uploaded++;
//           setUploadProgress(Math.round((uploaded / rows.length) * 100));
//         }

//         setUploadMessage("✅ Upload successful");
//         loadInitial();
//       } catch (err) {
//         setUploadError(err.message);
//       } finally {
//         setUploading(false);
//       }
//     };

//     reader.readAsBinaryString(file);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Details</h6>

//         <div className="flex gap-2">
//           {canUpload && (
//             <label className={`px-3 py-1 text-white text-[12px] rounded cursor-pointer ${uploading ? "bg-gray-400" : "bg-green-600"}`}>
//               Upload Excel
//               <input type="file" hidden accept=".xls,.xlsx" onChange={(e) => handleExcelUpload(e.target.files[0])} />
//             </label>
//           )}
//           <button onClick={() => navigate("/client_business/create")} className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded">
//             + Add Data
//           </button>
//         </div>
//       </div>

//       {/* FILTERS */}
//       <div className="flex gap-2 mb-4">
//         <select
//           value={year ?? ""}
//           onChange={(e) => setYear(e.target.value ? Number(e.target.value) : null)}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Years</option>
//           {years.map((y) => (
//             <option key={y} value={y}>{y}</option>
//           ))}
//         </select>

//         {/* {isSuperAdmin && (
//           <select
//             value={departmentId}
//             onChange={(e) => setDepartmentId(e.target.value)}
//             className="border px-3 py-1 text-[12px] rounded"
//           >
//             <option value="">All Departments</option>
//             {departments.map((d) => (
//               <option key={d.id} value={d.id}>{d.department_name}</option>
//             ))}
//           </select>
//         )} */}

// <select
//   value={departmentId}
//   onChange={handleDeptChange}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Departments</option>
//   {departments.map((d) => (
//     <option key={d.id} value={d.id}>
//       {d.department_name}
//     </option>
//   ))}
// </select>
// <select
//   value={selectedUser}
//   onChange={handleUserChange}
//   disabled={!departmentId}
//   className="border px-3 py-1 text-[12px] rounded min-w-[160px]"
// >
//   <option value="">All Users</option>
//   {usersList.map((u) => (
//     <option key={u.value} value={u.value}>
//       {u.label}
//     </option>
//   ))}
// </select>


//         <button onClick={clearFilter} className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded">
//           Clear
//         </button>

//         <div className="text-[12px] py-3 text-gray-600 font-semibold">
//         Total123: ({clients.length})
//        </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">No records found</div>
//         ) : (
//           clients.map((c) => (
//             <div key={c.id} className="grid grid-cols-7 px-4 py-2 border-t text-[12px]">
//               <span>{c.year}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.company_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               <span className="flex justify-center gap-1">
//                 <button onClick={() => navigate(`/client_business/edit/${c.id}`)} className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded">
//                   Edit
//                 </button>
//                 <button onClick={() => removeClient(c.id)} className="px-2 py-1 bg-red-600 text-white text-[11px] rounded">
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }










//===========>>> Old one working 2000 %


// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import * as XLSX from "xlsx";

// import {
//   getMyClientBusiness,
//   createClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService } from "../../services/DepartmentServices";

// export default function ClientBusinessList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");
//   const isBdUser = auth?.roles?.includes("bd_user");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;
//   const canUpload = isSuperAdmin || isHodOnly || isBdUser;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);

//   const [allClients, setAllClients] = useState([]); // 🔐 source of truth
//   const [clients, setClients] = useState([]);       // derived data
//   const [departments, setDepartments] = useState([]);

//   const [year, setYear] = useState(null); // number | null
//   const [departmentId, setDepartmentId] = useState("");

//   /* ===============================
//      UPLOAD STATE
//   ================================ */
//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [uploadMessage, setUploadMessage] = useState("");
//   const [uploadError, setUploadError] = useState("");

//   /* ===============================
//      USER DEPARTMENTS
//   ================================ */
//   const hodDepartmentIds = (auth?.department_id || []).map(
//     (d) => d?.id || d?._id
//   );

//   const userDepartmentNames = (auth?.department_id || []).map(
//     (d) => d?.department_name
//   );

//   /* ===============================
//      EXCEL HELPERS
//   ================================ */
//   const HEADER_ALIASES = {
//     year: ["year", "Year", "YEAR"],
//     department_name: ["department", "department name", "department_name"],
//     client_name: ["client", "client name", "client_name"],
//     company_name: ["company", "company name", "company_name"],
//     email: ["email", "email id", "email_id"],
//     phone: ["phone", "mobile", "mobile number"],
//   };

//   const getValueByHeader = (row, aliases) => {
//     for (const key of Object.keys(row)) {
//       if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
//         return row[key];
//       }
//     }
//     return "";
//   };

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   useEffect(() => {
//     loadInitial();
//   }, []);

//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       let res;
//       if (isSuperAdmin) {
//         res = await filterClientBusiness({});
//       } else if (isHodOnly) {
//         res = await filterClientBusiness({ department_id: hodDepartmentIds[0] });
//       } else {
//         res = await getMyClientBusiness();
//       }

//       setAllClients(res?.data?.data || []);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      🔥 AUTO FILTER (THE REAL FIX)
//   ================================ */
//   useEffect(() => {
//     let data = [...allClients];

//     // ✅ YEAR FILTER (NUMBER === NUMBER)
//     if (year !== null) {
//       data = data.filter((c) => Number(c.year) === Number(year));
//     }

//     // ✅ DEPARTMENT FILTER (ONLY FOR SUPER ADMIN)
//     if (isSuperAdmin && departmentId) {
//       data = data.filter(
//         (c) =>
//           (typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id) === departmentId
//       );
//     }

//     setClients(data);
//   }, [year, departmentId, allClients, isSuperAdmin]);

//   /* ===============================
//      CLEAR FILTER
//   ================================ */
//   const clearFilter = () => {
//     setYear(null);
//     setDepartmentId("");
//   };

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this client record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   /* ===============================
//      YEARS
//   ================================ */
//   const years = Array.from({ length: 13 }, (_, i) => 2013 + i);

//   /* ===============================
//      DEPARTMENT NAME
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name || "-";
//     }
//     if (typeof department === "string") {
//       return (
//         departments.find((d) => d.id === department)?.department_name || "-"
//       );
//     }
//     return "-";
//   };

//   /* ===============================
//      EXCEL UPLOAD
//   ================================ */
//   const handleExcelUpload = async (file) => {
//     if (!file) return;

//     setUploading(true);
//     setUploadProgress(0);
//     setUploadMessage("Uploading Excel…");
//     setUploadError("");

//     const reader = new FileReader();

//     reader.onload = async (e) => {
//       try {
//         const workbook = XLSX.read(e.target.result, { type: "binary" });
//         const sheet = workbook.Sheets[workbook.SheetNames[0]];
//         const rows = XLSX.utils.sheet_to_json(sheet);

//         const departmentMap = {};
//         departments.forEach((d) => {
//           departmentMap[d.department_name.toLowerCase().trim()] = d.id;
//         });

//         let uploaded = 0;
//         for (const row of rows) {
//           const deptName = String(
//             getValueByHeader(row, HEADER_ALIASES.department_name)
//           )
//             .toLowerCase()
//             .trim();

//           if (!isSuperAdmin && !userDepartmentNames.map(d => d.toLowerCase()).includes(deptName)) {
//             throw new Error(`Department mismatch: ${deptName}`);
//           }

//           await createClientBusiness({
//             year: Number(getValueByHeader(row, HEADER_ALIASES.year)),
//             client_name: getValueByHeader(row, HEADER_ALIASES.client_name),
//             company_name: getValueByHeader(row, HEADER_ALIASES.company_name),
//             email: getValueByHeader(row, HEADER_ALIASES.email) || "",
//             phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
//             department_id: departmentMap[deptName],
//           });

//           uploaded++;
//           setUploadProgress(Math.round((uploaded / rows.length) * 100));
//         }

//         setUploadMessage("✅ Upload successful");
//         loadInitial();
//       } catch (err) {
//         setUploadError(err.message);
//       } finally {
//         setUploading(false);
//       }
//     };

//     reader.readAsBinaryString(file);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       {/* HEADER */}
//       <div className="flex justify-between mb-4">
//         <h6 className="font-bold text-[15px]">Client Details</h6>

//         <div className="flex gap-2">
//           {canUpload && (
//             <label className={`px-3 py-1 text-white text-[12px] rounded cursor-pointer ${uploading ? "bg-gray-400" : "bg-green-600"}`}>
//               Upload Excel
//               <input type="file" hidden accept=".xls,.xlsx" onChange={(e) => handleExcelUpload(e.target.files[0])} />
//             </label>
//           )}
//           <button onClick={() => navigate("/client_business/create")} className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded">
//             + Add Data
//           </button>
//         </div>
//       </div>

//       {/* FILTERS */}
//       <div className="flex gap-2 mb-4">
//         <select
//           value={year ?? ""}
//           onChange={(e) => setYear(e.target.value ? Number(e.target.value) : null)}
//           className="border px-3 py-1 text-[12px] rounded"
//         >
//           <option value="">All Years</option>
//           {years.map((y) => (
//             <option key={y} value={y}>{y}</option>
//           ))}
//         </select>

//         {isSuperAdmin && (
//           <select
//             value={departmentId}
//             onChange={(e) => setDepartmentId(e.target.value)}
//             className="border px-3 py-1 text-[12px] rounded"
//           >
//             <option value="">All Departments</option>
//             {departments.map((d) => (
//               <option key={d.id} value={d.id}>{d.department_name}</option>
//             ))}
//           </select>
//         )}

//         <button onClick={clearFilter} className="px-3 py-1 bg-gray-500 text-white text-[12px] rounded">
//           Clear
//         </button>

//         <div className="text-[12px] py-3 text-gray-600 font-semibold">
//         Total: ({clients.length})
//        </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-white border rounded">
//         {loading ? (
//           <div className="p-4 text-center">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-center text-gray-500">No records found</div>
//         ) : (
//           clients.map((c) => (
//             <div key={c.id} className="grid grid-cols-7 px-4 py-2 border-t text-[12px]">
//               <span>{c.year}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.company_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>
//               <span className="flex justify-center gap-1">
//                 <button onClick={() => navigate(`/client_business/edit/${c.id}`)} className="px-2 py-1 bg-blue-600 text-white text-[11px] rounded">
//                   Edit
//                 </button>
//                 <button onClick={() => removeClient(c.id)} className="px-2 py-1 bg-red-600 text-white text-[11px] rounded">
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }





//--------->>>

// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import * as XLSX from "xlsx";

// import {
//   getMyClientBusiness,
//   createClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService } from "../../services/DepartmentServices";

// export default function ClientBusinessList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");
//   const isBdUser = auth?.roles?.includes("bd_user");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;
//   const canFilter = isSuperAdmin || isHodOnly || isBdUser;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [clients, setClients] = useState([]);
//   const [allClients, setAllClients] = useState([]); // 🔐 BD USER SAFE COPY
//   const [departments, setDepartments] = useState([]);

//   const [year, setYear] = useState("");
//   const [departmentId, setDepartmentId] = useState("");

//   /* ===============================
//      UPLOAD UI STATE
//   ================================ */
//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [uploadMessage, setUploadMessage] = useState("");
//   const [uploadError, setUploadError] = useState("");

//   /* ===============================
//      USER DEPARTMENTS
//   ================================ */
//   const hodDepartmentIds = (auth?.department_id || []).map(
//     (d) => d?.id || d?._id
//   );

//   const userDepartmentNames = (auth?.department_id || []).map(
//     (d) => d?.department_name
//   );

//   /* ===============================
//      EXCEL HEADER ALIASES ✅ (FIXED)
//   ================================ */
//   const HEADER_ALIASES = {
//     year: ["year", "Year", "YEAR"],
//     department_name: [
//       "department",
//       "department name",
//       "department_name",
//       "Department",
//       "Department Name",
//     ],
//     client_name: ["client", "client name", "client_name", "Client Name"],
//     company_name: ["company", "company name", "company_name", "Company Name"],
//     email: ["email", "email id", "email_id", "Email", "Email ID"],
//     phone: [
//       "phone",
//       "mobile",
//       "mobile number",
//       "phone number",
//       "Mobile Number",
//       "Phone Number",
//     ],
//   };

//   const getValueByHeader = (row, aliases) => {
//     for (const key of Object.keys(row)) {
//       if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
//         return row[key];
//       }
//     }
//     return "";
//   };

//   useEffect(() => {
//     loadInitial();
//   }, []);

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       if (isSuperAdmin) {
//         const res = await filterClientBusiness({});
//         setClients(res?.data?.data || []);
//       } else if (isHodOnly) {
//         const res = await filterClientBusiness({
//           department_id: hodDepartmentIds[0],
//         });
//         setClients(res?.data?.data || []);
//       } else if (isBdUser) {
//         const res = await getMyClientBusiness();
//         setClients(res?.data?.data || []);
//         setAllClients(res?.data?.data || []); // 🔐 SAFE COPY
//       }
//     } catch (err) {
//       console.log(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      APPLY FILTER (BD USER SAFE)
//   ================================ */
//   // const applyFilter = async () => {
//   //   try {
//   //     const payload = {
//   //       ...(year && { year: Number(year) }), // ✅ ensure number
//   //       ...(!isHodOnly && departmentId && { department_id: departmentId }),
//   //       ...(isHodOnly && { department_id: hodDepartmentIds[0] }),
//   //     };
  
//   //     const res = await filterClientBusiness(payload);
//   //     let data = res?.data?.data || [];
  
//   //     // ✅ keep HOD safety filter
//   //     if (isHodOnly) {
//   //       data = data.filter((c) =>
//   //         hodDepartmentIds.includes(
//   //           typeof c.department_id === "object"
//   //             ? c.department_id.id
//   //             : c.department_id
//   //         )
//   //       );
//   //     }
  
//   //     setClients(data);
//   //   } catch (err) {
//   //     console.log(err);
//   //   }
//   // };
  
//   /* ===============================
//    APPLY FILTER (BD USER FIXED)
// =============================== */
// // const applyFilter = async () => {
// //   try {
// //     // 🔐 BD USER → LOCAL FILTER ONLY (NO API CALL)
// //     if (isBdUser) {
// //       let data = [...allClients];

// //       // Year selected
// //       if (year) {
// //         data = data.filter(
// //           (c) => String(c.year) === String(year)
// //         );
// //       }

// //       // All Years → show all OWN data
// //       setClients(data);
// //       return;
// //     }

// //     // ✅ ADMIN / MD / HOD → SERVER FILTER (UNCHANGED)
// //     const payload = {
// //       ...(year && { year: Number(year) }),
// //       ...(!isHodOnly && departmentId && { department_id: departmentId }),
// //       ...(isHodOnly && { department_id: hodDepartmentIds[0] }),
// //     };

// //     const res = await filterClientBusiness(payload);
// //     let data = res?.data?.data || [];

// //     // Extra HOD safety
// //     if (isHodOnly) {
// //       data = data.filter((c) =>
// //         hodDepartmentIds.includes(
// //           typeof c.department_id === "object"
// //             ? c.department_id.id
// //             : c.department_id
// //         )
// //       );
// //     }

// //     setClients(data);
// //   } catch (err) {
// //     console.log(err);
// //   }
// // };

// const applyFilter = async () => {
//   try {
//     /* ===============================
//        🔐 BD USER → CLIENT-SIDE FILTER ONLY
//     ================================ */
//     if (isBdUser) {
//       let data = [...allClients]; // ✅ ALWAYS start from safe copy

//       // Year selected
//       if (year) {
//         data = data.filter(
//           (c) => String(c.year) === String(year)
//         );
//       }

//       // All Years → still ONLY own data
//       setClients(data);
//       return;
//     }

//     /* ===============================
//        ADMIN / MD / HOD → SERVER FILTER
//     ================================ */
//     const payload = {
//       ...(year && { year: Number(year) }),
//       ...(!isHodOnly && departmentId && { department_id: departmentId }),
//       ...(isHodOnly && { department_id: hodDepartmentIds[0] }),
//     };

//     const res = await filterClientBusiness(payload);
//     let data = res?.data?.data || [];

//     // Extra HOD safety
//     if (isHodOnly) {
//       data = data.filter((c) =>
//         hodDepartmentIds.includes(
//           typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id
//         )
//       );
//     }

//     setClients(data);
//   } catch (err) {
//     console.log(err);
//   }
// };

//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this client record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   const years = Array.from({ length: 13 }, (_, i) => 2013 + i);

//   /* ===============================
//      DEPARTMENT NAME RESOLVER
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name || "-";
//     }
//     if (typeof department === "string") {
//       return (
//         departments.find((d) => d.id === department)?.department_name || "-"
//       );
//     }
//     return "-";
//   };

//   /* ===============================
//      EXCEL UPLOAD (UNCHANGED + SAFE)
//   ================================ */
//   const handleExcelUpload = async (file) => {
//     if (!file) return;

//     setUploading(true);
//     setUploadProgress(0);
//     setUploadMessage("Uploading Excel… Please wait");
//     setUploadError("");

//     const reader = new FileReader();

//     reader.onload = async (e) => {
//       try {
//         const workbook = XLSX.read(e.target.result, { type: "binary" });
//         const sheet = workbook.Sheets[workbook.SheetNames[0]];
//         const rows = XLSX.utils.sheet_to_json(sheet);

//         if (!rows.length) throw new Error("Excel file is empty");

//         const departmentMap = {};
//         departments.forEach((d) => {
//           departmentMap[d.department_name.replace(/\s+/g, " ").trim().toLowerCase()] =
//             d.id;
//         });

//         const userDepts = userDepartmentNames.map((d) =>
//           d.replace(/\s+/g, " ").trim().toLowerCase()
//         );

//         const CHUNK_SIZE = 10;
//         let uploaded = 0;

//         for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
//           const batch = rows.slice(i, i + CHUNK_SIZE);

//           await Promise.all(
//             batch.map((row, index) => {
//               const excelRow = i + index + 2;

//               const excelDept = String(
//                 getValueByHeader(row, HEADER_ALIASES.department_name) || ""
//               )
//                 .replace(/\s+/g, " ")
//                 .trim()
//                 .toLowerCase();

//               if (!isSuperAdmin && !userDepts.includes(excelDept)) {
//                 throw new Error(
//                   `Upload blocked at row ${excelRow}. Allowed: ${userDepartmentNames.join(
//                     ", "
//                   )}`
//                 );
//               }

//               return createClientBusiness({
//                 year: Number(getValueByHeader(row, HEADER_ALIASES.year)),
//                 client_name: getValueByHeader(row, HEADER_ALIASES.client_name),
//                 company_name: getValueByHeader(row, HEADER_ALIASES.company_name),
//                 email: getValueByHeader(row, HEADER_ALIASES.email) || "",
//                 phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
//                 department_id: departmentMap[excelDept],
//               });
//             })
//           );

//           uploaded += batch.length;
//           setUploadProgress(Math.round((uploaded / rows.length) * 100));
//         }

//         setUploadMessage("✅ Excel uploaded successfully");
//         loadInitial();
//       } catch (err) {
//         setUploadError(err.message || "Upload failed");
//       } finally {
//         setUploading(false);
//         setTimeout(() => {
//           setUploadMessage("");
//           setUploadProgress(0);
//         }, 3000);
//       }
//     };

//     reader.readAsBinaryString(file);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-[700] text-[15px]">Client Details</h6>

//         <div className="flex gap-2">
//           {canFilter && (
//             <label
//               className={`px-3 py-1 text-white text-[12px] rounded cursor-pointer ${
//                 uploading ? "bg-gray-400" : "bg-green-600"
//               }`}
//             >
//               {uploading ? "Uploading..." : "Upload Excel"}
//               <input
//                 type="file"
//                 accept=".xlsx,.xls"
//                 className="hidden"
//                 disabled={uploading}
//                 onChange={(e) => handleExcelUpload(e.target.files[0])}
//               />
//             </label>
//           )}

//           <button
//             onClick={() => navigate("/client_business/create")}
//             className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//           >
//             + Add Data
//           </button>
//         </div>
//       </div>

//       {canFilter && (
//         <div className="flex gap-2 mb-4">
//           <select
//             value={year}
//             onChange={(e) => setYear(e.target.value)}
//             className="border px-3 py-1 text-[12px] rounded"
//           >
//             <option value="">All Years</option>
//             {years.map((y) => (
//               <option key={y}>{y}</option>
//             ))}
//           </select>

//           {isSuperAdmin && (
//             <select
//               value={departmentId}
//               onChange={(e) => setDepartmentId(e.target.value)}
//               className="border px-3 py-1 text-[12px] rounded"
//             >
//               <option value="">All Departments</option>
//               {departments.map((d) => (
//                 <option key={d.id} value={d.id}>
//                   {d.department_name}
//                 </option>
//               ))}
//             </select>
//           )}

//           <button
//             onClick={applyFilter}
//             className="px-3 py-1 bg-slate-700 text-white text-[12px] rounded"
//           >
//             Apply
//           </button>
//           <div className="text-[12px] text-gray-600 font-semibold">
//   Total: ({clients.length})
// </div>

//         </div>
//       )}

//       <div className="bg-white border rounded">
//         <div className="grid grid-cols-7 bg-gray-200 px-3 py-2 text-[13px] font-semibold">
//           <span>Year</span>
//           <span>Department</span>
//           <span>Client Name</span>
//           <span>Company</span>
//           <span>Email</span>
//           <span>Phone</span>
//           <span className="text-center">Action</span>
//         </div>

//         {loading ? (
//           <div className="p-4">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-gray-500">No records found</div>
//         ) : (
//           clients.map((c, i) => (
//             <div
//               key={c.id}
//               className={`grid grid-cols-7 px-3 py-2 text-[12px] border-t ${
//                 i % 2 === 0 ? "bg-white" : "bg-gray-50"
//               }`}
//             >
//               <span>{c.year}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.company_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>

//               <span className="flex justify-center gap-2">
//                 <button
//                   onClick={() => navigate(`/client_business/edit/${c.id}`)}
//                   className="px-2 py-0.5 bg-blue-600 text-white text-[11px] rounded"
//                 >
//                   Edit
//                 </button>
//                 <button
//                   onClick={() => removeClient(c.id)}
//                   className="px-2 py-0.5 bg-red-600 text-white text-[11px] rounded"
//                 >
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }











//==========+>>>  Old one




// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import * as XLSX from "xlsx";

// import {
//   getMyClientBusiness,
//   createClientBusiness,
//   filterClientBusiness,
//   deleteClientBusiness,
// } from "../../services/ClientBusinessService";
// import { GetDepartmentService } from "../../services/DepartmentServices";

// export default function ClientBusinessList() {
//   const navigate = useNavigate();
//   const auth = useSelector((state) => state.Auth);

//   /* ===============================
//      ROLE CHECKS
//   ================================ */
//   const isAdmin = auth?.roles?.includes("admin");
//   const isMdAdmin = auth?.roles?.includes("md_admin");
//   const isHod = auth?.roles?.includes("hod");
//   const isBdUser = auth?.roles?.includes("bd_user");

//   const isSuperAdmin = isAdmin || isMdAdmin;
//   const isHodOnly = isHod && !isSuperAdmin;
//   const canFilter = isSuperAdmin || isHodOnly || isBdUser;

//   /* ===============================
//      STATE
//   ================================ */
//   const [loading, setLoading] = useState(true);
//   const [clients, setClients] = useState([]);
//   const [allClients, setAllClients] = useState([]); // 🔐 BD USER SAFE COPY
//   const [departments, setDepartments] = useState([]);

//   const [year, setYear] = useState("");
//   const [departmentId, setDepartmentId] = useState("");

//   /* ===============================
//      UPLOAD UI STATE
//   ================================ */
//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [uploadMessage, setUploadMessage] = useState("");
//   const [uploadError, setUploadError] = useState("");

//   /* ===============================
//      USER DEPARTMENTS
//   ================================ */
//   const hodDepartmentIds = (auth?.department_id || []).map(
//     (d) => d?.id || d?._id
//   );

//   const userDepartmentNames = (auth?.department_id || []).map(
//     (d) => d?.department_name
//   );

//   /* ===============================
//      EXCEL HEADER ALIASES ✅ (FIXED)
//   ================================ */
//   const HEADER_ALIASES = {
//     year: ["year", "Year", "YEAR"],
//     department_name: [
//       "department",
//       "department name",
//       "department_name",
//       "Department",
//       "Department Name",
//     ],
//     client_name: ["client", "client name", "client_name", "Client Name"],
//     company_name: ["company", "company name", "company_name", "Company Name"],
//     email: ["email", "email id", "email_id", "Email", "Email ID"],
//     phone: [
//       "phone",
//       "mobile",
//       "mobile number",
//       "phone number",
//       "Mobile Number",
//       "Phone Number",
//     ],
//   };

//   const getValueByHeader = (row, aliases) => {
//     for (const key of Object.keys(row)) {
//       if (aliases.some((a) => a.toLowerCase() === key.toLowerCase().trim())) {
//         return row[key];
//       }
//     }
//     return "";
//   };

//   useEffect(() => {
//     loadInitial();
//   }, []);

//   /* ===============================
//      INITIAL LOAD
//   ================================ */
//   const loadInitial = async () => {
//     setLoading(true);
//     try {
//       const depRes = await GetDepartmentService();
//       setDepartments(depRes?.data?.datas || []);

//       if (isSuperAdmin) {
//         const res = await filterClientBusiness({});
//         setClients(res?.data?.data || []);
//       } else if (isHodOnly) {
//         const res = await filterClientBusiness({
//           department_id: hodDepartmentIds[0],
//         });
//         setClients(res?.data?.data || []);
//       } else if (isBdUser) {
//         const res = await getMyClientBusiness();
//         setClients(res?.data?.data || []);
//         setAllClients(res?.data?.data || []); // 🔐 SAFE COPY
//       }
//     } catch (err) {
//       console.log(err);
//     }
//     setLoading(false);
//   };

//   /* ===============================
//      APPLY FILTER (BD USER SAFE)
//   ================================ */
//   // const applyFilter = async () => {
//   //   try {
//   //     const payload = {
//   //       ...(year && { year: Number(year) }), // ✅ ensure number
//   //       ...(!isHodOnly && departmentId && { department_id: departmentId }),
//   //       ...(isHodOnly && { department_id: hodDepartmentIds[0] }),
//   //     };
  
//   //     const res = await filterClientBusiness(payload);
//   //     let data = res?.data?.data || [];
  
//   //     // ✅ keep HOD safety filter
//   //     if (isHodOnly) {
//   //       data = data.filter((c) =>
//   //         hodDepartmentIds.includes(
//   //           typeof c.department_id === "object"
//   //             ? c.department_id.id
//   //             : c.department_id
//   //         )
//   //       );
//   //     }
  
//   //     setClients(data);
//   //   } catch (err) {
//   //     console.log(err);
//   //   }
//   // };
  
//   /* ===============================
//    APPLY FILTER (BD USER FIXED)
// =============================== */
// const applyFilter = async () => {
//   try {
//     // 🔐 BD USER → LOCAL FILTER ONLY (NO API CALL)
//     if (isBdUser) {
//       let data = [...allClients];

//       // Year selected
//       if (year) {
//         data = data.filter(
//           (c) => String(c.year) === String(year)
//         );
//       }

//       // All Years → show all OWN data
//       setClients(data);
//       return;
//     }

//     // ✅ ADMIN / MD / HOD → SERVER FILTER (UNCHANGED)
//     const payload = {
//       ...(year && { year: Number(year) }),
//       ...(!isHodOnly && departmentId && { department_id: departmentId }),
//       ...(isHodOnly && { department_id: hodDepartmentIds[0] }),
//     };

//     const res = await filterClientBusiness(payload);
//     let data = res?.data?.data || [];

//     // Extra HOD safety
//     if (isHodOnly) {
//       data = data.filter((c) =>
//         hodDepartmentIds.includes(
//           typeof c.department_id === "object"
//             ? c.department_id.id
//             : c.department_id
//         )
//       );
//     }

//     setClients(data);
//   } catch (err) {
//     console.log(err);
//   }
// };


//   /* ===============================
//      DELETE
//   ================================ */
//   const removeClient = async (id) => {
//     if (!window.confirm("Delete this client record?")) return;
//     await deleteClientBusiness(id);
//     loadInitial();
//   };

//   const years = Array.from({ length: 13 }, (_, i) => 2013 + i);

//   /* ===============================
//      DEPARTMENT NAME RESOLVER
//   ================================ */
//   const getDepartmentName = (department) => {
//     if (department && typeof department === "object") {
//       return department.department_name || "-";
//     }
//     if (typeof department === "string") {
//       return (
//         departments.find((d) => d.id === department)?.department_name || "-"
//       );
//     }
//     return "-";
//   };

//   /* ===============================
//      EXCEL UPLOAD (UNCHANGED + SAFE)
//   ================================ */
//   const handleExcelUpload = async (file) => {
//     if (!file) return;

//     setUploading(true);
//     setUploadProgress(0);
//     setUploadMessage("Uploading Excel… Please wait");
//     setUploadError("");

//     const reader = new FileReader();

//     reader.onload = async (e) => {
//       try {
//         const workbook = XLSX.read(e.target.result, { type: "binary" });
//         const sheet = workbook.Sheets[workbook.SheetNames[0]];
//         const rows = XLSX.utils.sheet_to_json(sheet);

//         if (!rows.length) throw new Error("Excel file is empty");

//         const departmentMap = {};
//         departments.forEach((d) => {
//           departmentMap[d.department_name.replace(/\s+/g, " ").trim().toLowerCase()] =
//             d.id;
//         });

//         const userDepts = userDepartmentNames.map((d) =>
//           d.replace(/\s+/g, " ").trim().toLowerCase()
//         );

//         const CHUNK_SIZE = 10;
//         let uploaded = 0;

//         for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
//           const batch = rows.slice(i, i + CHUNK_SIZE);

//           await Promise.all(
//             batch.map((row, index) => {
//               const excelRow = i + index + 2;

//               const excelDept = String(
//                 getValueByHeader(row, HEADER_ALIASES.department_name) || ""
//               )
//                 .replace(/\s+/g, " ")
//                 .trim()
//                 .toLowerCase();

//               if (!isSuperAdmin && !userDepts.includes(excelDept)) {
//                 throw new Error(
//                   `Upload blocked at row ${excelRow}. Allowed: ${userDepartmentNames.join(
//                     ", "
//                   )}`
//                 );
//               }

//               return createClientBusiness({
//                 year: Number(getValueByHeader(row, HEADER_ALIASES.year)),
//                 client_name: getValueByHeader(row, HEADER_ALIASES.client_name),
//                 company_name: getValueByHeader(row, HEADER_ALIASES.company_name),
//                 email: getValueByHeader(row, HEADER_ALIASES.email) || "",
//                 phone: getValueByHeader(row, HEADER_ALIASES.phone) || "",
//                 department_id: departmentMap[excelDept],
//               });
//             })
//           );

//           uploaded += batch.length;
//           setUploadProgress(Math.round((uploaded / rows.length) * 100));
//         }

//         setUploadMessage("✅ Excel uploaded successfully");
//         loadInitial();
//       } catch (err) {
//         setUploadError(err.message || "Upload failed");
//       } finally {
//         setUploading(false);
//         setTimeout(() => {
//           setUploadMessage("");
//           setUploadProgress(0);
//         }, 3000);
//       }
//     };

//     reader.readAsBinaryString(file);
//   };

//   /* ===============================
//      RENDER
//   ================================ */
//   return (
//     <div className="p-6">
//       <div className="flex items-center justify-between mb-4">
//         <h6 className="font-[700] text-[15px]">Client Details</h6>

//         <div className="flex gap-2">
//           {canFilter && (
//             <label
//               className={`px-3 py-1 text-white text-[12px] rounded cursor-pointer ${
//                 uploading ? "bg-gray-400" : "bg-green-600"
//               }`}
//             >
//               {uploading ? "Uploading..." : "Upload Excel"}
//               <input
//                 type="file"
//                 accept=".xlsx,.xls"
//                 className="hidden"
//                 disabled={uploading}
//                 onChange={(e) => handleExcelUpload(e.target.files[0])}
//               />
//             </label>
//           )}

//           <button
//             onClick={() => navigate("/client_business/create")}
//             className="px-3 py-1 bg-blue-600 text-white text-[12px] rounded"
//           >
//             + Add Data
//           </button>
//         </div>
//       </div>

//       {canFilter && (
//         <div className="flex gap-2 mb-4">
//           <select
//             value={year}
//             onChange={(e) => setYear(e.target.value)}
//             className="border px-3 py-1 text-[12px] rounded"
//           >
//             <option value="">All Years</option>
//             {years.map((y) => (
//               <option key={y}>{y}</option>
//             ))}
//           </select>

//           {isSuperAdmin && (
//             <select
//               value={departmentId}
//               onChange={(e) => setDepartmentId(e.target.value)}
//               className="border px-3 py-1 text-[12px] rounded"
//             >
//               <option value="">All Departments</option>
//               {departments.map((d) => (
//                 <option key={d.id} value={d.id}>
//                   {d.department_name}
//                 </option>
//               ))}
//             </select>
//           )}

//           <button
//             onClick={applyFilter}
//             className="px-3 py-1 bg-slate-700 text-white text-[12px] rounded"
//           >
//             Apply
//           </button>
//           <div className="text-[12px] text-gray-600 font-semibold">
//   Total: ({clients.length})
// </div>

//         </div>
//       )}

//       <div className="bg-white border rounded">
//         <div className="grid grid-cols-7 bg-gray-200 px-3 py-2 text-[13px] font-semibold">
//           <span>Year</span>
//           <span>Department</span>
//           <span>Client Name</span>
//           <span>Company</span>
//           <span>Email</span>
//           <span>Phone</span>
//           <span className="text-center">Action</span>
//         </div>

//         {loading ? (
//           <div className="p-4">Loading...</div>
//         ) : clients.length === 0 ? (
//           <div className="p-4 text-gray-500">No records found</div>
//         ) : (
//           clients.map((c, i) => (
//             <div
//               key={c.id}
//               className={`grid grid-cols-7 px-3 py-2 text-[12px] border-t ${
//                 i % 2 === 0 ? "bg-white" : "bg-gray-50"
//               }`}
//             >
//               <span>{c.year}</span>
//               <span>{getDepartmentName(c.department_id)}</span>
//               <span className="font-semibold">{c.client_name}</span>
//               <span>{c.company_name}</span>
//               <span>{c.email || "-"}</span>
//               <span>{c.phone || "-"}</span>

//               <span className="flex justify-center gap-2">
//                 <button
//                   onClick={() => navigate(`/client_business/edit/${c.id}`)}
//                   className="px-2 py-0.5 bg-blue-600 text-white text-[11px] rounded"
//                 >
//                   Edit
//                 </button>
//                 <button
//                   onClick={() => removeClient(c.id)}
//                   className="px-2 py-0.5 bg-red-600 text-white text-[11px] rounded"
//                 >
//                   Delete
//                 </button>
//               </span>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }


