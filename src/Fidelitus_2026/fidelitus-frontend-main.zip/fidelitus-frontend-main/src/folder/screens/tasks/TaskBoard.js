import React from 'react'
import TeamTaskMenu from './TeamTaskMenu'

function TaskBoard() {
  return (
    <div className='flex min-h-screen max-h-screen h-screen '>
         <TeamTaskMenu />
         <div className='w-[20%] pl-5 min-h-screen max-h-screen h-screen overflow-y-screen overflow-x-hidden' >
           <h1>Team Task Menu</h1>
         </div>   
    </div>
  )
}

export default TaskBoard