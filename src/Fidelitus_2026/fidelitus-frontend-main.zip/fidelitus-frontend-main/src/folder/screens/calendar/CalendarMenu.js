import React, { useEffect } from 'react';
import {useLocation,useNavigate } from 'react-router-dom';
import { BsPhoneVibrate } from "react-icons/bs";
import { MdOutlineSpaceDashboard } from "react-icons/md";

function CalendarMenu() {

  const {pathname} = useLocation();
  const path = pathname.split('/')[pathname.split('/').length - 1]

  const navigate = useNavigate();

  const menu = [
    {name:'My Calendar',icon:BsPhoneVibrate,path:'/calendar/list',id:1,color:''},
    {name:'My Dashboard',icon:MdOutlineSpaceDashboard,path:'/calendar/dashboard',id:2,color:''},
  ]  

  useEffect(()=>{
    if(path === 'calendar'){
      navigate('list')
    }
  },[path])

 
  return (
    <div className='hidden min-h-screen px-2 mr-0 border-r md:block lg:block max-h-sceen min-w-44 w-44 max-w-44' >

        {/* {path !== 'daily_tasks'  && */}
        <div className='mt-5 mb-4'>
          <h6 className=' ml-2 mb-2 font-[700] text-[12px]'>Basic Option</h6>

          {menu.map((m)=>(
              <div key={m.path} className={`flex items-center my-1 hover:bg-[#f4f5f7] px-1.5 py-1 ml-2 rounded-md relative cursor-pointer ${pathname ===  m.path && 'bg-[#f4f5f7]'}`} onClick={()=>navigate(m?.path)}>
                {pathname ===  m.path &&  <span className='absolute h-6 -ml-3 border-2 rounded border-slate-800' ></span>}
                <m.icon color='#000' style={{backgroundColor:m?.color,padding:'2px'}} size={16}  />
                <span className='text-[#000] font-[500] ml-2 text-[12px]'>{m.name}</span>
              </div>    
          ))}


         </div>
    </div>
  )
}

export default CalendarMenu