import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import IlsMenu from './IlsMenu'
import { TextAreaInput1, TextInput } from '../../components/input'
import { Select } from 'antd'
import { ButtonFilled, ButtonOutlined } from '../../components/button'
import { CreateILSLandDataService, UpdateILSLandDataService, UploadFileILSLandDataService } from '../../services/IlsLandDataServices'
import toast from 'react-hot-toast'
import Uploader1 from '../../components/Uploader1'
import GoBack from '../../components/back/GoBack'
import DashboardMenu from '../dashboard/DashboardMenu'
import { CreateILSWareHouseDataService, UpdateILSWareHouseDataService, UploadFileILSWareHouseDataService } from '../../services/IlsWareHouseDataServices'
import ErrorComponent from '../../components/errorDesign/ErrorComponent'


function IlsWareHouseDataCE() {


  const {state,pathname} = useLocation() 

  const path = pathname.split('/')[2]
//   console.log("path",path)

//   console.log("state",state)
  const location = useLocation()  
  const navigate = useNavigate()

  const zones = [{label:'North',value:"North"},{label:'South',value:"South"},{label:'East',value:"East"},{label:'West',value:"West"}]
  const type_of_transactions = [{label:'Built-To-Suit',value:"Built-To-Suit"},{label:'Sale',value:"Sale"},{label:'Rent',value:"Rent"},{label:'JV/JD',value:"JV/JD"}]
  
  const [loader,setloader] = useState(false)
  const [data,setdata] = useState({location_of_property:'',landmark_to_the_property:'',total_land_area:'',no_of_floors:'',each_floor_area:'',no_of_docks:'',centre_height:'',power_and_backup:'',water_availability:'',road_width:'',possession:'',rent_per_sqft_per_month:'',primary_contact_name:'',primary_contact_no:'',seconday_contact_name:'',seconday_contact_no:'',propsal_attachment:'',comments:'',location_co_ordinates:'',zone:''})
  const [error,seterror] = useState({location_of_property:'',landmark_to_the_property:'',total_land_area:'',no_of_floors:'',each_floor_area:'',no_of_docks:'',centre_height:'',power_and_backup:'',water_availability:'',road_width:'',possession:'',rent_per_sqft_per_month:'',primary_contact_name:'',primary_contact_no:'',seconday_contact_name:'',seconday_contact_no:'',propsal_attachment:'',comments:'',location_co_ordinates:'',zone:''})
  

  useEffect(()=>{
      if(state?._id !== undefined){
        setdata({...state})
       
      }
  },[])

 

  async function handlechange(e){
    setdata({...data,[e.target.name]:e.target.value})
    seterror({...error,[e.target.name]:''})
  }

  async function handleSelect(v,name){
    setdata({...data,[name]:v})
    seterror({...error,[name]:''})
  }

  async function submitform(){
    if(!data?.location_of_property){
        seterror({...error,location_of_property:'This Field is required*'})
    }else if(!data?.landmark_to_the_property){
        seterror({...error,landmark_to_the_property:'This Field is required*'})
    }else if(!data?.total_land_area){
        seterror({...error,total_land_area:'This Field is required*'})
    }else if(!data?.total_built_up_area){
        seterror({...error,total_built_up_area:'This Field is required*'})
    }else if(!data?.no_of_floors){
        seterror({...error,no_of_floors:'This Field is required*'})
    }else if(!data?.each_floor_area){
        seterror({...error,each_floor_area:'This Field is required*'})
    }else if(!data?.no_of_docks){
        seterror({...error,no_of_docks:'This Field is required*'})
    }else if(!data?.zone){
        seterror({...error,zone:'This Field is required*'})
    }else{
        
        let sendData = {...data}
        
        if(state?._id === undefined){
            const response = await CreateILSWareHouseDataService(sendData)
            if(response?.status == 201){
                toast.success("WareHouse Data Created Successfully!")
                resetform()
            }
        }else{
            const response = await UpdateILSWareHouseDataService(state?._id,sendData)
            if(response?.status == 200){
                toast.success("WareHouse Data Updated Successfully!")
                resetform()
                navigate(-1)
            }
        }
    }

  }



  async function resetform(){
    setdata({location_of_property:'',landmark_to_the_property:'',total_land_area:'',no_of_floors:'',each_floor_area:'',no_of_docks:'',centre_height:'',power_and_backup:'',water_availability:'',road_width:'',possession:'',rent_per_sqft_per_month:'',primary_contact_name:'',primary_contact_no:'',seconday_contact_name:'',seconday_contact_no:'',propsal_attachment:'',comments:'',location_co_ordinates:'',zone:''})
    seterror({location_of_property:'',landmark_to_the_property:'',total_land_area:'',no_of_floors:'',each_floor_area:'',no_of_docks:'',centre_height:'',power_and_backup:'',water_availability:'',road_width:'',possession:'',rent_per_sqft_per_month:'',primary_contact_name:'',primary_contact_no:'',seconday_contact_name:'',seconday_contact_no:'',propsal_attachment:'',comments:'',location_co_ordinates:'',zone:''})
  }


  async function handleUpload(v){
    const response = await UploadFileILSWareHouseDataService({file:v})
    setdata({...data,propsal_attachment:response?.data?.data?.replace('public','')})
    seterror({...error,propsal_attachment:''})
  }

  return (
    <div className='h-screen max-h-screen overflow-hidden'>
    <div className='flex'>
        {path === 'land_data_admin' ? <DashboardMenu />  : <IlsMenu /> }
        <div className='w-[88%] h-[95vh] overflow-y-scroll px-4 mt-5'>
            <GoBack />
            <div className='w-[50%]'>

            <h6 className='font-[800] mb-1'>{location?.pathname?.split('/')[location?.pathname?.split('/').length -1] === 'edit' ? 'Edit' : 'Create'}  WareHouse Data</h6> 
            <h6 className='text-[11px] leading-tight font-[500] p-2 bg-slate-100 '>Use the below form to create or edit the Land Data for your reference to get the continous task progress made by you all the time.</h6> 
            
            <div className='flex justify-between'> 
             <div className='w-[46%] relative'>
               
                <TextInput 
                 mandatory={true}
                 label={'Location'}  
                 variant="standard"
                 name="location_of_property"
                 type="text"
                 value={data.location_of_property}
                 error={error.location_of_property}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 InputLabelProps={{
                     style: { color: '#fff', }, 
                 }}
                />

                <TextInput 
                 mandatory={true}
                 label={'LandMark to the Property'}  
                 variant="standard"
                 name="landmark_to_the_property"
                 type="text"
                 value={data.landmark_to_the_property}
                 error={error.landmark_to_the_property}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 InputLabelProps={{
                     style: { color: '#fff', }, 
                 }}
                />

                <TextInput 
                 mandatory={true}
                 label={'Total Land Area'}  
                 variant="standard"
                 name="total_land_area"
                 type="text"
                 value={data.total_land_area}
                 error={error.total_land_area}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

                <TextInput 
                 mandatory={true}
                 label={'Total Built Up Area'}  
                 variant="standard"
                 name="total_built_up_area"
                 type="text"
                 value={data.total_built_up_area}
                 error={error.total_built_up_area}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

                <TextInput 
                 mandatory={true}
                 label={'No of Floors'}  
                 variant="standard"
                 name="no_of_floors"
                 type="text"
                 value={data.no_of_floors}
                 error={error.no_of_floors}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

                <TextInput 
                 mandatory={true}
                 label={'Each Floor Area'}  
                 variant="standard"
                 name="each_floor_area"
                 type="text"
                 value={data.each_floor_area}
                 error={error.each_floor_area}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

                <TextInput 
                 mandatory={true}
                 label={'No of Docks'}  
                 variant="standard"
                 name="no_of_docks"
                 type="text"
                 value={data.no_of_docks}
                 error={error.no_of_docks}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

                <h6 className='text-[11px] font-semibold mb-1 mt-1'>Zone</h6>
                
                <Select
                    value={data?.zone} 
                    error={error?.zone}
                    bordered={false}
                    placeholder="" 
                    onChange={(e)=>handleSelect(e,'zone')} 
                    options={zones}
                    style={{borderRadius:'0px'}} 
                    className='border-l-4 border-l-slate-600 w-full border  outline-0 focus:outline-0 focus:ring-0 focus:border-none focus:border-red-900 focus:border-transparent focus:ring-offset-0 focus:shadow-none'
                />

                <ErrorComponent error={error?.zone} />

                {/* <h6 className='text-[11px] font-semibold mb-1 mt-1'>Zone</h6>

                <Select
                    value={data?.zone} 
                    error={error?.zone}
                    bordered={false}
                    placeholder="" 
                    onChange={(e)=>handleSelect(e,'zone')} 
                    options={zones}
                    style={{borderRadius:'0px'}} 
                    className='border-l-4 border-l-slate-600 w-full border  outline-0 focus:outline-0 focus:ring-0 focus:border-none focus:border-red-900 focus:border-transparent focus:ring-offset-0 focus:shadow-none'
                />

                <h6 className='text-[11px] font-semibold mb-1 mt-1'>Type Of Transaction</h6>

                <Select
                    value={data?.type_of_transaction} 
                    error={error?.type_of_transaction}
                    bordered={false}
                    placeholder="" 
                    onChange={(e)=>handleSelect(e,'type_of_transaction')} 
                    options={type_of_transactions}
                    style={{borderRadius:'0px'}} 
                    className='border-l-4 border-l-slate-600 w-full border  outline-0 focus:outline-0 focus:ring-0 focus:border-none focus:border-red-900 focus:border-transparent focus:ring-offset-0 focus:shadow-none'
                /> */}

            {/* {console.log("propsal_attachment",data?.propsal_attachment)} */}
            <div className='relative'>
            <h6 className='text-[11px] font-[600] mt-1 mb-1' >Attachment</h6>  
            {data?.propsal_attachment !== '' && <a target="_blank" href={`${process.env.REACT_APP_BACKEND_IMAGE_URL}${data?.propsal_attachment}`} ><h6 className='text-[8px] font-[700] cursor-pointer absolute right-0 bottom-9 underline'>View File</h6></a>}
            <Uploader1 image={data?.propsal_attachment}  setimagefunc={(e)=>{handleUpload(e)}}  removeimageuploadfunc = {()=>{setdata({...data,propsal_attachment:''});seterror({...error,propsal_attachment:''})}}/>    
            </div>
             </div>

             <div className='w-[46%]'>

             <TextInput 
                 mandatory={false}
                 label={'Centre Height'}  
                 variant="standard"
                 name="centre_height"
                 type="text"
                 value={data.centre_height}
                 error={error.centre_height}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

                <TextInput 
                 mandatory={false}
                 label={'Power And Backup'}  
                 variant="standard"
                 name="power_and_backup"
                 type="text"
                 value={data.power_and_backup}
                 error={error.power_and_backup}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

            <TextInput 
                 mandatory={false}
                 label={'Water Availability'}  
                 variant="standard"
                 name="water_availability"
                 type="text"
                 value={data.water_availability}
                 error={error.water_availability}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

            <TextInput 
                 label={'Road Width'}  
                 variant="standard"
                 name="road_width"
                 type="text"
                 value={data.road_width}
                 error={error.road_width}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

            <TextInput 
                 label={'Possession'}  
                 variant="standard"
                 name="possession"
                 type="text"
                 value={data.possession}
                 error={error.possession}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />    

            <TextInput 
                 label={'Rent Per Sqft/Month'}  
                 variant="standard"
                 name="rent_per_sqft_per_month"
                 type="text"
                 value={data.rent_per_sqft_per_month}
                 error={error.rent_per_sqft_per_month}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />    

            <TextInput 
                 label={'Location Co-ordinates'}  
                 variant="standard"
                 name="location_co_ordinates"
                 type="text"
                 value={data.location_co_ordinates}
                 error={error.location_co_ordinates}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />        

            <TextInput 
                 label={'Primary Contact Name'}  
                 variant="standard"
                 name="primary_contact_name"
                 type="text"
                 value={data.primary_contact_name}
                 error={error.primary_contact_name}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />  

            <TextInput 
                 label={'Primary Contact No'}  
                 variant="standard"
                 name="primary_contact_no"
                 type="text"
                 value={data.primary_contact_no}
                 error={error.primary_contact_no}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />  

            <TextInput 
                 label={'Secondary Contact Name'}  
                 variant="standard"
                 name="seconday_contact_name"
                 type="text"
                 value={data.seconday_contact_name}
                 error={error.seconday_contact_name}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />  

            <TextInput 
                 label={'Secondary Contact No'}  
                 variant="standard"
                 name="seconday_contact_no"
                 type="text"
                 value={data.seconday_contact_no}
                 error={error.seconday_contact_no}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />                     

            <TextAreaInput1 
                 label={'Comments'}  
                 variant="standard"
                 name="comments"
                 type="text"
                 value={data.comments}
                 error={error.comments}
                 handlechange={handlechange}
                 placeholder=""
                 
                />   
            
             </div>   
            </div>   

             <div className='flex items-center mt-5 mb-10  border-t pt-5'>
                <div className='mr-2'>
                <ButtonOutlined btnName={'Back'} onClick={()=>navigate(-1)} />
                </div>
                <div>
                {loader ?
                <ButtonFilled btnName={loader ? 'Uploading' : 'Save'}  />
                :
                <ButtonFilled btnName={loader ? 'Uploading' : 'Save'} onClick={()=>submitform()} />}
                </div>
            </div>

            </div>
        </div>
    </div>          
    </div>
  )
}

export default IlsWareHouseDataCE