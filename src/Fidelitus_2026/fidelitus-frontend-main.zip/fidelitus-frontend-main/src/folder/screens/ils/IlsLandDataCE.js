import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import IlsMenu from './IlsMenu'
import { TextAreaInput1, TextInput } from '../../components/input'
import { Select } from 'antd'
import { ButtonFilled, ButtonOutlined } from '../../components/button'
import { CreateILSLandDataService,GetILSLandDetailService, UpdateILSLandDataService, UploadFileILSLandDataService ,UploadILSLandDataImageService} from '../../services/IlsLandDataServices'
import toast from 'react-hot-toast'
import Uploader1 from '../../components/Uploader1'
import GoBack from '../../components/back/GoBack'
import { Tooltip } from '@mui/material';
// import ErrorComponent from '../../../components/errorDesign/ErrorComponent'
import ErrorComponent from '../../components/errorDesign/ErrorComponent';

import {IoClose} from 'react-icons/io5';
import DashboardMenu from '../dashboard/DashboardMenu';


function IlsLandDataCE() {
  const {state,pathname} = useLocation() 
  const path = pathname.split('/')[2]
//   console.log("path",path)
//   console.log("state",state)
  const location = useLocation()  
  const navigate = useNavigate()
  const zones = [{label:'North',value:"North"},{label:'South',value:"South"},{label:'East',value:"East"},{label:'West',value:"West"}]
  const type_of_transactions = [{label:'Built-To-Suit',value:"Built-To-Suit"},{label:'Sale',value:"Sale"},{label:'Rent',value:"Rent"},{label:'JV/JD',value:"JV/JD"}]
  const conversion_type = [{label:'Industries',value:"Industries"},{label:'Commercials',value:"Commercials"},{label:'Warehouse',value:"Warehouse"},{label:'Residentials',value:"Residentials"},{label:'Agriculture',value:"Agriculture"}]

  const [loader,setloader] = useState(false)
  const [data,setdata] = useState({main_image:'',zone:'',location:'',landstatus:'',frontage:'',access_road_width:'',land_area:'',landmark:'',surroundings:'',ownership_details:'',type_of_transaction:'',built_to_suit_rent_price: '', sale_price: '', rent_price: '', jvjd_ratio: '',conversion_type:'',point_of_contact_name:'',point_of_contact_mobile:'',primary_contact_name:'',primary_contact_mobile:'',secondary_contact_name:'',secondary_contact_mobile:'',point_of_contact_email:'',location:'',coordinate:'',attachment:''})
  const [error,seterror] = useState({main_image:'',zone:'',location:'',landstatus:'',frontage:'',access_road_width:'',land_area:'',landmark:'',surroundings:'',ownership_details:'',type_of_transaction:'',built_to_suit_rent_price: '', sale_price: '', rent_price: '', jvjd_ratio: '',conversion_type:'',point_of_contact_name:'',point_of_contact_mobile:'',primary_contact_name:'',primary_contact_mobile:'',secondary_contact_name:'',secondary_contact_mobile:'',point_of_contact_email:'',location:'',coordinate:'',attachment:''})
  
console.log("check state value",state)
  useEffect(()=>{
      if(state?._id !== undefined){
        setdata({...state})   
      }
  },[])
//
 //new
//  useEffect(() => {
//   if (state ) {
//     getdetail(state);
//   } else {
//     // Clear form on Add mode
//     resetform();
//   }
// }, [state]);

useEffect(() => {
  if (state) {
    if (typeof state === 'string' || (typeof state === 'object' && Object.keys(state).length === 1 && state._id)) {
      const id = typeof state === 'string' ? state : state._id;
      getdetail(id); // Detail page scenario
    } else if (typeof state === 'object' && state._id) {
      setdata(state); // Main list page scenario
    }
  } else {
    resetform(); // Add mode
  }
}, [state]);

 
async function getdetail() {
  const response = await GetILSLandDetailService(state);
  if (response?.status == 200) {
    setdata(response?.data?.datas[0]);
  } else {
    navigate(-1);
    toast.error("Data Not Found");
  }
}

  async function handlechange(e){
    setdata({...data,[e.target.name]:e.target.value})
    seterror({...error,[e.target.name]:''})
  }

  async function handleSelect(v,name){
    setdata({...data,[name]:v})
    seterror({...error,[name]:''})
  }

  function handleInputChange(e, name) {
    setdata({ ...data, [name]: e.target.value })
  }


// async function submitform() {
//     const newErrors = {};

//     if (!data?.land_area) newErrors.land_area = 'The Land Area Field is required*';
//     if (!data?.location) newErrors.location = 'The Location Field is required*';
//     if (!data?.zone) newErrors.zone = 'The Zone Field is required*';
//     if (!data?.type_of_transaction) newErrors.type_of_transaction = 'The Type of Transaction Field is required*';
//     if (!data?.conversion_type) newErrors.conversion_type = 'The Type of Conversion Field is required*';
//     if (!data?.point_of_contact_name) newErrors.point_of_contact_name = 'The Point Of Contact Name Field is required*';
//     if (!data?.point_of_contact_mobile) newErrors.point_of_contact_mobile = 'The Point Of Contact Mobile Field is required*';

//     // If there are any errors, set and return early
//     if (Object.keys(newErrors).length > 0) {
//         seterror(newErrors);
//         return;
//     }

//     let sendData = { ...data };

//     if (state === undefined) {
//       alert("create")
//         const response = await CreateILSLandDataService(sendData);
//         if (response?.status == 201) {
//             toast.success("ILS Land Data Created Successfully!");
//             resetform();
//         }
//     } else {
//       alert("Update")
//         const response = await UpdateILSLandDataService(state?._id, sendData);
//         if (response?.status == 200) {
//             toast.success("ILS Land Data Updated Successfully!");
//             resetform();
//             navigate(-1);
//         }
//     }
// }


async function submitform() {
  const newErrors = {};

  if (!data?.land_area) newErrors.land_area = 'The Land Area Field is required*';
  if (!data?.location) newErrors.location = 'The Location Field is required*';
  if (!data?.zone) newErrors.zone = 'The Zone Field is required*';
  if (!data?.type_of_transaction) newErrors.type_of_transaction = 'The Type of Transaction Field is required*';
  if (!data?.conversion_type) newErrors.conversion_type = 'The Type of Conversion Field is required*';
  if (!data?.point_of_contact_name) newErrors.point_of_contact_name = 'The Point Of Contact Name Field is required*';
  if (!data?.point_of_contact_mobile) newErrors.point_of_contact_mobile = 'The Point Of Contact Mobile Field is required*';

  if (Object.keys(newErrors).length > 0) {
    seterror(newErrors);
    return;
  }

  const sendData = { ...data };

  if (!data._id) {
    // ADD mode
    const response = await CreateILSLandDataService(sendData);
    if (response?.status === 201) {
      toast.success("ILS Land Data Created Successfully!");
      resetform();
    }
  } else {
    // EDIT mode
    const response = await UpdateILSLandDataService(data._id, sendData);
    if (response?.status === 200) {
      toast.success("ILS Land Data Updated Successfully!");
      resetform();
      navigate(-1);
    }
  }
}



  async function resetform(){
    setdata({main_image:'',zone:'',location:'',landstatus:'',frontage:'',access_road_width:'',land_area:'',landmark:'',surroundings:'',ownership_details:'',type_of_transaction:'',conversion_type:'',point_of_contact_name:'',point_of_contact_mobile:'',primary_contact_name:'',primary_contact_mobile:'',secondary_contact_name:'',secondary_contact_mobile:'',point_of_contact_email:'',location:'',coordinate:'',attachment:''})
    seterror({main_image:'',zone:'',location:'',landstatus:'',frontage:'',access_road_width:'',land_area:'',landmark:'',surroundings:'',ownership_details:'',type_of_transaction:'',conversion_type:'',point_of_contact_name:'',point_of_contact_mobile:'',primary_contact_name:'',primary_contact_mobile:'',secondary_contact_name:'',secondary_contact_mobile:'',point_of_contact_email:'',location:'',coordinate:'',attachment:''})
  }


  async function handleUpload(v){
    const response = await UploadFileILSLandDataService({file:v})
    setdata({...data,attachment:response?.data?.data?.replace('public','')})
    seterror({...error,attachment:''})
  }

  /// image 

   async function uploadfilefunc(v,name){
     
      const fd = new FormData()
      fd.append('image',v); 
      const response = await UploadILSLandDataImageService(fd)
      if(response?.status === 200){
  
        if(name !== 'multiple_image'){  
          setdata({...data,[name]:response?.data?.data})
          seterror({...error,[name]:''})
        }else{
          let oldDataImages = [...data.multiple_image,response?.data?.data]
          setdata({...data,[name]:oldDataImages})
          seterror({...error,[name]:''})
        }
        
      }
    }

  function openFile(v){
    let url = `${process.env.REACT_APP_BACKEND_IMAGE_URL}${v}`
    window.open(url,'_blank')
   }

  return (
    <div className='h-screen max-h-screen overflow-hidden'>
    <div className='h-screen max-h-screen overflow-hidden  flex'>
        {path === 'land_data_admin' ? <DashboardMenu />  : <IlsMenu /> }
        <div className='w-[88%] px-4 mt-5 flex flex-col'>
            <GoBack />
            <div className='w-full flex-1 overflow-y-auto'>

            <h6 className='font-[800] mb-1'>
            {location?.pathname?.split('/')[location?.pathname?.split('/').length - 1] === 'edit' ? 'Edit' : 'Create'} Land Data
          </h6>
          <h6 className='text-[11px] leading-tight font-[500] p-2 bg-slate-100'>
            Use the below form to create or edit the Land Data for your reference to get the continuous task progress made by you all the time.-----Updating
          </h6>
            <div className='flex justify-between'> 
             <div className='w-[46%] relative'>
                <TextInput 
                 mandatory={true}
                 label={'Land Area'}  
                 variant="standard"
                 name="land_area"
                 type="text"
                 value={data.land_area}
                 error={error.land_area}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                />
                <TextInput 
                 mandatory={true}
                 label={'Location'}  
                 variant="standard"
                 name="location"
                 type="text"
                 value={data.location}
                 error={error.location}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 InputLabelProps={{
                     style: { color: '#fff', }, 
                 }}
                />

                <TextInput 
                 mandatory={false}
                 label={'Land Status'}  
                 variant="standard"
                 name="landstatus"
                 type="text"
                 value={data.landstatus}
                 error={error.landstatus}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 InputLabelProps={{
                     style: { color: '#fff', }, 
                 }}
                />
                 <TextInput 
                 mandatory={false}
                 label={'Frontage'}  
                 variant="standard"
                 name="frontage"
                 type="text"
                 value={data.frontage}
                 error={error.frontage}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 InputLabelProps={{
                     style: { color: '#fff', }, 
                 }}
                />

                <TextInput 
                 mandatory={false}
                 label={'Access Road Width'}  
                 variant="standard"
                 name="access_road_width"
                 type="text"
                 value={data.access_road_width}
                 error={error.access_road_width}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 InputLabelProps={{
                     style: { color: '#fff', }, 
                 }}
                />
                 <TextInput 
                 mandatory={false}
                 label={'Landmark'}  
                 variant="standard"
                 name="landmark"
                 type="text"
                 value={data.landmark}
                 error={error.landmark}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 InputLabelProps={{
                     style: { color: '#fff', }, 
                 }}
                />
                 <TextInput 
                 mandatory={false}
                 label={'Surroundings'}  
                 variant="standard"
                 name="surroundings"
                 type="text"
                 value={data.surroundings}
                 error={error.surroundings}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 InputLabelProps={{
                     style: { color: '#fff', }, 
                 }}
                />

                <TextInput 
                 label={'Co-ordinates'}  
                 variant="standard"
                 name="coordinate"
                 type="text"
                 value={data.coordinate}
                 error={error.coordinate}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 InputLabelProps={{
                     style: { color: '#fff', }, 
                 }}
                />

                <h6 className='text-[11px] font-semibold mb-1 mt-1'>Zone</h6>

                <Select
                    value={data?.zone} 
                    error={error?.zone}
                    bordered={false}
                    placeholder="" 
                    onChange={(e)=>handleSelect(e,'zone')} 
                    options={zones}
                    style={{borderRadius:'0px'}} 
                    className='border-l-4 border-l-slate-600 w-full border  outline-0 focus:outline-0 focus:ring-0 focus:border-none focus:border-red-900 focus:border-transparent focus:ring-offset-0 focus:shadow-none'
                />
                {error?.zone && (
                <div className="text-red-500 text-[11px] mt-1">{error.zone}</div>
                 )}
                <h6 className='text-[11px] font-semibold mb-1 mt-1'>Type Of Transaction</h6>

              <Select
              value={data?.type_of_transaction}
              error={error?.type_of_transaction}
              bordered={false}
              placeholder=""
              onChange={(e) => handleSelect(e, 'type_of_transaction')}
              options={type_of_transactions}
              style={{ borderRadius: '0px' }}
              className='w-full border border-l-4 border-l-slate-600 outline-none focus:ring-0 focus:shadow-none'
              />
              {error?.type_of_transaction && (
                <div className="text-red-500 text-[11px] mt-1">{error.type_of_transaction}</div>
                 )}
              {data.type_of_transaction === 'Built-To-Suit' && (
             <div>
               <h6 className='text-[11px] font-semibold mb-1 mt-1'>Rent Price (Built-To-Suit)</h6>
              <input
              type="text"
               name="built_to_suit_rent_price"
               value={data.built_to_suit_rent_price}
               onChange={(e) => handleInputChange(e, 'built_to_suit_rent_price')}
               className='w-full border p-1 rounded-sm placeholder:text-[11px]'
               placeholder="Enter Rent Price"
              />
             </div>
             )}

          {data.type_of_transaction === 'Sale' && (
          <div>
          <h6 className='text-[11px] font-semibold mb-1 mt-1'>Sale Price</h6>
          <input
          type="text"
          name="sale_price"
          value={data.sale_price}
          onChange={(e) => handleInputChange(e, 'sale_price')}
          className='w-full border p-1 rounded-sm placeholder:text-[11px]'
          placeholder="Enter Sale Price"
          />
          </div>
          )}

          {data.type_of_transaction === 'Rent' && (
          <div>
          <h6 className='text-[11px] font-semibold mb-1 mt-1'>Rent Price</h6>
           <input
           type="text"
           name="rent_price"
           value={data.rent_price}
           onChange={(e) => handleInputChange(e, 'rent_price')}
           className='w-full border p-1 rounded-sm placeholder:text-[11px]'
           placeholder="Enter Rent Price"
           />
          </div>
           )}

          {data.type_of_transaction === 'JV/JD' && (
          <div>
          <h6 className='text-[11px] font-semibold mb-1 mt-1'>JV/JD Ratio</h6>
          <input
          type="text"
          name="jvjd_ratio"
          value={data.jvjd_ratio}
          onChange={(e) => handleInputChange(e, 'jvjd_ratio')}
          className='w-full border p-1 rounded-sm placeholder:text-[11px]'
          placeholder="Enter JV/JD Ratio"
          />
  </div>
)}


              <h6 className='text-[11px] font-semibold mb-1 mt-1'>Conversion Type</h6>

             <Select
              value={data?.conversion_type} 
              error={error?.conversion_type}
              bordered={false}
              placeholder="" 
              onChange={(e)=>handleSelect(e,'conversion_type')} 
              options={conversion_type}
              style={{borderRadius:'0px'}} 
              className='border-l-4 border-l-slate-600 w-full border  outline-0 focus:outline-0 focus:ring-0 focus:border-none focus:border-red-900 focus:border-transparent focus:ring-offset-0 focus:shadow-none'
              />
              {error?.conversion_type && (
                <div className="text-red-500 text-[11px] mt-1">{error.conversion_type}</div>
                 )}
            <h6 className='text-[11px] font-[600] mt-1 mb-1' >Attachment</h6>  
           {data?.attachment !== '' && <a target="_blank" href={`${process.env.REACT_APP_BACKEND_IMAGE_URL}${data?.attachment}`} ><h6 className='text-[8px] font-[700] cursor-pointer absolute right-0 bottom-9 underline'>View File</h6></a>}
            <Uploader1 image={data?.attachment}  setimagefunc={(e)=>{handleUpload(e)}}  removeimageuploadfunc = {()=>{setdata({...data,attachment:''});seterror({...error,attachment:''})}}/>    

             </div>

             <div className='w-[46%]'>
                <TextInput 
                 mandatory={true}
                 label={'Contact Name'}  
                 variant="standard"
                 name="point_of_contact_name"
                 type="text"
                 value={data.point_of_contact_name}
                 error={error.point_of_contact_name}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

            <TextInput 
                 mandatory={true}
                 label={'Contact Mobile'}  
                 variant="standard"
                 name="point_of_contact_mobile"
                 type="text"
                 value={data.point_of_contact_mobile}
                 error={error.point_of_contact_mobile}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

            <TextInput 
                 label={'Contact Email'}  
                 variant="standard"
                 name="point_of_contact_email"
                 type="text"
                 value={data.point_of_contact_email}
                 error={error.point_of_contact_email}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                />
                <TextInput 
                //  mandatory={true}
                 label={'Secondary Contact Name'}  
                 variant="standard"
                 name="primary_contact_name"
                 type="text"
                 value={data.primary_contact_name}
                 error={error.primary_contact_name}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />
                <TextInput 
                //  mandatory={true}
                 label={'Secondary Contact Mobile'}  
                 variant="standard"
                 name="primary_contact_mobile"
                 type="text"
                 value={data.primary_contact_mobile}
                 error={error.primary_contact_mobile}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                />
               <TextInput 
                //  mandatory={true}
                 label={'Additional Contact Name'}  
                 variant="standard"
                 name="secondary_contact_name"
                 type="text"
                 value={data.secondary_contact_name}
                 error={error.secondary_contact_name}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

                <TextInput 
                //  mandatory={true}
                 label={'Additional Contact Mobile'}  
                 variant="standard"
                 name="secondary_contact_mobile"
                 type="text"
                 value={data.secondary_contact_mobile}
                 error={error.secondary_contact_mobile}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 
                />

              <TextInput 
                 mandatory={false}
                 label={'Ownership Details'}  
                 variant="standard"
                 name="ownership_details"
                 type="text"
                 value={data.ownership_details}
                 error={error.ownership_details}
                 handlechange={handlechange}
                 placeholder="Enter contact name"
                 InputLabelProps={{
                     style: { color: '#fff', }, 
                 }}
                />
            <TextAreaInput1 
                label={'Summary'}  
                variant="standard"
                name="summary"
                type="text"
                value={data.summary}
                error={error.summary}
                handlechange={handlechange}
                placeholder=""
                />
             <div className='w-[100%] mt-2 relative mr-[2%]'>
           <h6 className='text-[11px] font-[600] mb-1' >Main Image</h6>            
           {!(data.main_image === '' || data.main_image == null) && <h6 onClick={()=>openFile(data?.main_image)} className='underline text-[8px] absolute cursor-pointer right-0 top-0 font-[600]'>View File</h6>}
           {(data.main_image === '' || data.main_image == null) ?
            <form onClick={()=>document.querySelector(`.input-field`).click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border border-l-4 border-l-slate-700 border-slate-300 `}>
                <input type='file' onChange={({target:{files}})=>{
                files[0] && uploadfilefunc(files[0],'main_image')
                }} accept="image/*" className='input-field' hidden />
            </form> 
        :
            <div className='p-2 border border-slate-300 border-l-4 border-l-slate-700 relative flex flex-col  cursor-pointer'>
                <Tooltip title='Delete'><IoClose className='absolute top-3 right-2' onClick={()=>setdata({...data,main_image:''})}/></Tooltip>
                <h6 className='text-[12px] truncate w-48 ml-0'>{data?.main_image}</h6>
            </div>
        }

        <ErrorComponent error={error?.main_image} />
             </div>  
             </div>
            </div>   

             <div className='flex items-center mt-5 mb-10  border-t pt-5'>
                <div className='mr-2'>
                <ButtonOutlined btnName={'Back'} onClick={()=>navigate(-1)} />
                </div>
                <div>
                {loader ?
                <ButtonFilled btnName={loader ? 'Uploading' : 'Save'}  />
                :
                <ButtonFilled btnName={loader ? 'Uploading' : 'Save'} onClick={()=>submitform()} />}
                </div>
            </div>

            </div>
        </div>
    </div>          
    </div>
  )
}

export default IlsLandDataCE;












//=====================>>> Old


// import React, { useEffect, useState } from 'react'
// import { useLocation, useNavigate } from 'react-router-dom'
// import IlsMenu from './IlsMenu'
// import { TextAreaInput1, TextInput } from '../../components/input'
// import { Select } from 'antd'
// import { ButtonFilled, ButtonOutlined } from '../../components/button'
// import { CreateILSLandDataService, UpdateILSLandDataService, UploadFileILSLandDataService ,UploadILSLandDataImageService} from '../../services/IlsLandDataServices'
// import toast from 'react-hot-toast'
// import Uploader1 from '../../components/Uploader1'
// import GoBack from '../../components/back/GoBack'
// import { Tooltip } from '@mui/material';
// // import ErrorComponent from '../../../components/errorDesign/ErrorComponent'
// import ErrorComponent from '../../components/errorDesign/ErrorComponent';

// import {IoClose} from 'react-icons/io5';
// import DashboardMenu from '../dashboard/DashboardMenu';


// function IlsLandDataCE() {
//   const {state,pathname} = useLocation() 
//   const path = pathname.split('/')[2]
// //   console.log("path",path)
// //   console.log("state",state)
//   const location = useLocation()  
//   const navigate = useNavigate()
//   const zones = [{label:'North',value:"North"},{label:'South',value:"South"},{label:'East',value:"East"},{label:'West',value:"West"}]
//   const type_of_transactions = [{label:'Built-To-Suit',value:"Built-To-Suit"},{label:'Sale',value:"Sale"},{label:'Rent',value:"Rent"},{label:'JV/JD',value:"JV/JD"}]
//   const conversion_type = [{label:'Industries',value:"Industries"},{label:'Commercials',value:"Commercials"},{label:'Warehouse',value:"Warehouse"},{label:'Residentials',value:"Residentials"},{label:'Agriculture',value:"Agriculture"}]

//   const [loader,setloader] = useState(false)
//   const [data,setdata] = useState({main_image:'',zone:'',location:'',landstatus:'',frontage:'',access_road_width:'',land_area:'',landmark:'',surroundings:'',ownership_details:'',type_of_transaction:'',built_to_suit_rent_price: '', sale_price: '', rent_price: '', jvjd_ratio: '',conversion_type:'',point_of_contact_name:'',point_of_contact_mobile:'',primary_contact_name:'',primary_contact_mobile:'',secondary_contact_name:'',secondary_contact_mobile:'',point_of_contact_email:'',location:'',coordinate:'',attachment:''})
//   const [error,seterror] = useState({main_image:'',zone:'',location:'',landstatus:'',frontage:'',access_road_width:'',land_area:'',landmark:'',surroundings:'',ownership_details:'',type_of_transaction:'',built_to_suit_rent_price: '', sale_price: '', rent_price: '', jvjd_ratio: '',conversion_type:'',point_of_contact_name:'',point_of_contact_mobile:'',primary_contact_name:'',primary_contact_mobile:'',secondary_contact_name:'',secondary_contact_mobile:'',point_of_contact_email:'',location:'',coordinate:'',attachment:''})
  

//   useEffect(()=>{
//       if(state?._id !== undefined){
//         setdata({...state})
       
//       }
//   },[])

 

//   async function handlechange(e){
//     setdata({...data,[e.target.name]:e.target.value})
//     seterror({...error,[e.target.name]:''})
//   }

//   async function handleSelect(v,name){
//     setdata({...data,[name]:v})
//     seterror({...error,[name]:''})
//   }

//   function handleInputChange(e, name) {
//     setdata({ ...data, [name]: e.target.value })
//   }

// //   async function submitform(){
// //     if(!data?.land_area){
// //         seterror({...error,land_area:'The Land Area Field is required*'})
// //     }else if(!data?.location){
// //         seterror({...error,location:'The Location Field is required*'})
// //     }else if(!data?.zone){
// //         seterror({...error,zone:'The Zone Field is required*'})
// //     }else if(!data?.type_of_transaction){
// //         seterror({...error,type_of_transaction:'The Type of Transaction Field is required*'})
// //     }else if(!data?.point_of_contact_name){
// //         seterror({...error,point_of_contact_name:'The Point Of Contact Name Field is required*'})
// //     }else if(!data?.point_of_contact_mobile){
// //         seterror({...error,point_of_contact_mobile:'The Point Of Contact Mobile Field is required*'})
// //     }else{
        
// //         let sendData = {...data}
        
// //         if(state?._id === undefined){
// //             const response = await CreateILSLandDataService(sendData)
// //             if(response?.status == 201){
// //                 toast.success("ILS Land Data Created Successfully!")
// //                 resetform()
// //             }
// //         }else{
// //             const response = await UpdateILSLandDataService(state?._id,sendData)
// //             if(response?.status == 200){
// //                 toast.success("ILS Land Data Updated Successfully!")
// //                 resetform()
// //                 navigate(-1)
// //             }
// //         }
// //     }

// //   }

// async function submitform() {
//     const newErrors = {};

//     if (!data?.land_area) newErrors.land_area = 'The Land Area Field is required*';
//     if (!data?.location) newErrors.location = 'The Location Field is required*';
//     if (!data?.zone) newErrors.zone = 'The Zone Field is required*';
//     if (!data?.type_of_transaction) newErrors.type_of_transaction = 'The Type of Transaction Field is required*';
//     if (!data?.conversion_type) newErrors.conversion_type = 'The Type of Conversion Field is required*';
//     if (!data?.point_of_contact_name) newErrors.point_of_contact_name = 'The Point Of Contact Name Field is required*';
//     if (!data?.point_of_contact_mobile) newErrors.point_of_contact_mobile = 'The Point Of Contact Mobile Field is required*';

//     // If there are any errors, set and return early
//     if (Object.keys(newErrors).length > 0) {
//         seterror(newErrors);
//         return;
//     }

//     let sendData = { ...data };

//     if (state?._id === undefined) {
//         const response = await CreateILSLandDataService(sendData);
//         if (response?.status == 201) {
//             toast.success("ILS Land Data Created Successfully!");
//             resetform();
//         }
//     } else {
//         const response = await UpdateILSLandDataService(state?._id, sendData);
//         if (response?.status == 200) {
//             toast.success("ILS Land Data Updated Successfully!");
//             resetform();
//             navigate(-1);
//         }
//     }
// }



//   async function resetform(){
//     setdata({main_image:'',zone:'',location:'',landstatus:'',frontage:'',access_road_width:'',land_area:'',landmark:'',surroundings:'',ownership_details:'',type_of_transaction:'',conversion_type:'',point_of_contact_name:'',point_of_contact_mobile:'',primary_contact_name:'',primary_contact_mobile:'',secondary_contact_name:'',secondary_contact_mobile:'',point_of_contact_email:'',location:'',coordinate:'',attachment:''})
//     seterror({main_image:'',zone:'',location:'',landstatus:'',frontage:'',access_road_width:'',land_area:'',landmark:'',surroundings:'',ownership_details:'',type_of_transaction:'',conversion_type:'',point_of_contact_name:'',point_of_contact_mobile:'',primary_contact_name:'',primary_contact_mobile:'',secondary_contact_name:'',secondary_contact_mobile:'',point_of_contact_email:'',location:'',coordinate:'',attachment:''})
//   }


//   async function handleUpload(v){
//     const response = await UploadFileILSLandDataService({file:v})
//     setdata({...data,attachment:response?.data?.data?.replace('public','')})
//     seterror({...error,attachment:''})
//   }

//   /// image 

//    async function uploadfilefunc(v,name){
     
//       const fd = new FormData()
//       fd.append('image',v); 
//       const response = await UploadILSLandDataImageService(fd)
//       if(response?.status === 200){
  
//         if(name !== 'multiple_image'){  
//           setdata({...data,[name]:response?.data?.data})
//           seterror({...error,[name]:''})
//         }else{
//           let oldDataImages = [...data.multiple_image,response?.data?.data]
//           setdata({...data,[name]:oldDataImages})
//           seterror({...error,[name]:''})
//         }
        
//       }
//     }

//   function openFile(v){
//     let url = `${process.env.REACT_APP_BACKEND_IMAGE_URL}${v}`
//     window.open(url,'_blank')
//    }

//   return (
//     <div className='h-screen max-h-screen overflow-hidden'>
//     <div className='h-screen max-h-screen overflow-hidden  flex'>
//         {path === 'land_data_admin' ? <DashboardMenu />  : <IlsMenu /> }
//         <div className='w-[88%] px-4 mt-5 flex flex-col'>
//             <GoBack />
//             <div className='w-full flex-1 overflow-y-auto'>

//             <h6 className='font-[800] mb-1'>
//             {location?.pathname?.split('/')[location?.pathname?.split('/').length - 1] === 'edit' ? 'Edit' : 'Create'} Land Data
//           </h6>
//           <h6 className='text-[11px] leading-tight font-[500] p-2 bg-slate-100'>
//             Use the below form to create or edit the Land Data for your reference to get the continuous task progress made by you all the time.-----Updating
//           </h6>
//             <div className='flex justify-between'> 
//              <div className='w-[46%] relative'>
//                 <TextInput 
//                  mandatory={true}
//                  label={'Land Area'}  
//                  variant="standard"
//                  name="land_area"
//                  type="text"
//                  value={data.land_area}
//                  error={error.land_area}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
//                 />
//                 <TextInput 
//                  mandatory={true}
//                  label={'Location'}  
//                  variant="standard"
//                  name="location"
//                  type="text"
//                  value={data.location}
//                  error={error.location}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
//                  InputLabelProps={{
//                      style: { color: '#fff', }, 
//                  }}
//                 />

//                 <TextInput 
//                  mandatory={false}
//                  label={'Land Status'}  
//                  variant="standard"
//                  name="landstatus"
//                  type="text"
//                  value={data.landstatus}
//                  error={error.landstatus}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
//                  InputLabelProps={{
//                      style: { color: '#fff', }, 
//                  }}
//                 />
//                  <TextInput 
//                  mandatory={false}
//                  label={'Frontage'}  
//                  variant="standard"
//                  name="frontage"
//                  type="text"
//                  value={data.frontage}
//                  error={error.frontage}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
//                  InputLabelProps={{
//                      style: { color: '#fff', }, 
//                  }}
//                 />

//                 <TextInput 
//                  mandatory={false}
//                  label={'Access Road Width'}  
//                  variant="standard"
//                  name="access_road_width"
//                  type="text"
//                  value={data.access_road_width}
//                  error={error.access_road_width}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
//                  InputLabelProps={{
//                      style: { color: '#fff', }, 
//                  }}
//                 />
//                  <TextInput 
//                  mandatory={false}
//                  label={'Landmark'}  
//                  variant="standard"
//                  name="landmark"
//                  type="text"
//                  value={data.landmark}
//                  error={error.landmark}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
//                  InputLabelProps={{
//                      style: { color: '#fff', }, 
//                  }}
//                 />
//                  <TextInput 
//                  mandatory={false}
//                  label={'Surroundings'}  
//                  variant="standard"
//                  name="surroundings"
//                  type="text"
//                  value={data.surroundings}
//                  error={error.surroundings}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
//                  InputLabelProps={{
//                      style: { color: '#fff', }, 
//                  }}
//                 />

//                 <TextInput 
//                  label={'Co-ordinates'}  
//                  variant="standard"
//                  name="coordinate"
//                  type="text"
//                  value={data.coordinate}
//                  error={error.coordinate}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
//                  InputLabelProps={{
//                      style: { color: '#fff', }, 
//                  }}
//                 />

//                 <h6 className='text-[11px] font-semibold mb-1 mt-1'>Zone</h6>

//                 <Select
//                     value={data?.zone} 
//                     error={error?.zone}
//                     bordered={false}
//                     placeholder="" 
//                     onChange={(e)=>handleSelect(e,'zone')} 
//                     options={zones}
//                     style={{borderRadius:'0px'}} 
//                     className='border-l-4 border-l-slate-600 w-full border  outline-0 focus:outline-0 focus:ring-0 focus:border-none focus:border-red-900 focus:border-transparent focus:ring-offset-0 focus:shadow-none'
//                 />
//                 {error?.zone && (
//                 <div className="text-red-500 text-[11px] mt-1">{error.zone}</div>
//                  )}
//                 <h6 className='text-[11px] font-semibold mb-1 mt-1'>Type Of Transaction</h6>

//               <Select
//               value={data?.type_of_transaction}
//               error={error?.type_of_transaction}
//               bordered={false}
//               placeholder=""
//               onChange={(e) => handleSelect(e, 'type_of_transaction')}
//               options={type_of_transactions}
//               style={{ borderRadius: '0px' }}
//               className='w-full border border-l-4 border-l-slate-600 outline-none focus:ring-0 focus:shadow-none'
//               />
//               {error?.type_of_transaction && (
//                 <div className="text-red-500 text-[11px] mt-1">{error.type_of_transaction}</div>
//                  )}
//               {data.type_of_transaction === 'Built-To-Suit' && (
//              <div>
//                <h6 className='text-[11px] font-semibold mb-1 mt-1'>Rent Price (Built-To-Suit)</h6>
//               <input
//               type="text"
//                name="built_to_suit_rent_price"
//                value={data.built_to_suit_rent_price}
//                onChange={(e) => handleInputChange(e, 'built_to_suit_rent_price')}
//                className='w-full border p-1 rounded-sm placeholder:text-[11px]'
//                placeholder="Enter Rent Price"
//               />
//              </div>
//              )}

//           {data.type_of_transaction === 'Sale' && (
//           <div>
//           <h6 className='text-[11px] font-semibold mb-1 mt-1'>Sale Price</h6>
//           <input
//           type="text"
//           name="sale_price"
//           value={data.sale_price}
//           onChange={(e) => handleInputChange(e, 'sale_price')}
//           className='w-full border p-1 rounded-sm placeholder:text-[11px]'
//           placeholder="Enter Sale Price"
//           />
//           </div>
//           )}

//           {data.type_of_transaction === 'Rent' && (
//           <div>
//           <h6 className='text-[11px] font-semibold mb-1 mt-1'>Rent Price</h6>
//            <input
//            type="text"
//            name="rent_price"
//            value={data.rent_price}
//            onChange={(e) => handleInputChange(e, 'rent_price')}
//            className='w-full border p-1 rounded-sm placeholder:text-[11px]'
//            placeholder="Enter Rent Price"
//            />
//           </div>
//            )}

//           {data.type_of_transaction === 'JV/JD' && (
//           <div>
//           <h6 className='text-[11px] font-semibold mb-1 mt-1'>JV/JD Ratio</h6>
//           <input
//           type="text"
//           name="jvjd_ratio"
//           value={data.jvjd_ratio}
//           onChange={(e) => handleInputChange(e, 'jvjd_ratio')}
//           className='w-full border p-1 rounded-sm placeholder:text-[11px]'
//           placeholder="Enter JV/JD Ratio"
//           />
//   </div>
// )}


//               <h6 className='text-[11px] font-semibold mb-1 mt-1'>Conversion Type</h6>

//              <Select
//               value={data?.conversion_type} 
//               error={error?.conversion_type}
//               bordered={false}
//               placeholder="" 
//               onChange={(e)=>handleSelect(e,'conversion_type')} 
//               options={conversion_type}
//               style={{borderRadius:'0px'}} 
//               className='border-l-4 border-l-slate-600 w-full border  outline-0 focus:outline-0 focus:ring-0 focus:border-none focus:border-red-900 focus:border-transparent focus:ring-offset-0 focus:shadow-none'
//               />
//               {error?.conversion_type && (
//                 <div className="text-red-500 text-[11px] mt-1">{error.conversion_type}</div>
//                  )}
//             <h6 className='text-[11px] font-[600] mt-1 mb-1' >Attachment</h6>  
//            {data?.attachment !== '' && <a target="_blank" href={`${process.env.REACT_APP_BACKEND_IMAGE_URL}${data?.attachment}`} ><h6 className='text-[8px] font-[700] cursor-pointer absolute right-0 bottom-9 underline'>View File</h6></a>}
//             <Uploader1 image={data?.attachment}  setimagefunc={(e)=>{handleUpload(e)}}  removeimageuploadfunc = {()=>{setdata({...data,attachment:''});seterror({...error,attachment:''})}}/>    

//              </div>

//              <div className='w-[46%]'>
//                 <TextInput 
//                  mandatory={true}
//                  label={'Contact Name'}  
//                  variant="standard"
//                  name="point_of_contact_name"
//                  type="text"
//                  value={data.point_of_contact_name}
//                  error={error.point_of_contact_name}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
                 
//                 />

//             <TextInput 
//                  mandatory={true}
//                  label={'Contact Mobile'}  
//                  variant="standard"
//                  name="point_of_contact_mobile"
//                  type="text"
//                  value={data.point_of_contact_mobile}
//                  error={error.point_of_contact_mobile}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
                 
//                 />

//             <TextInput 
//                  label={'Contact Email'}  
//                  variant="standard"
//                  name="point_of_contact_email"
//                  type="text"
//                  value={data.point_of_contact_email}
//                  error={error.point_of_contact_email}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
//                 />
//                 <TextInput 
//                 //  mandatory={true}
//                  label={'Secondary Contact Name'}  
//                  variant="standard"
//                  name="primary_contact_name"
//                  type="text"
//                  value={data.primary_contact_name}
//                  error={error.primary_contact_name}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
                 
//                 />
//                 <TextInput 
//                 //  mandatory={true}
//                  label={'Secondary Contact Mobile'}  
//                  variant="standard"
//                  name="primary_contact_mobile"
//                  type="text"
//                  value={data.primary_contact_mobile}
//                  error={error.primary_contact_mobile}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
//                 />
//                <TextInput 
//                 //  mandatory={true}
//                  label={'Additional Contact Name'}  
//                  variant="standard"
//                  name="secondary_contact_name"
//                  type="text"
//                  value={data.secondary_contact_name}
//                  error={error.secondary_contact_name}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
                 
//                 />

//                 <TextInput 
//                 //  mandatory={true}
//                  label={'Additional Contact Mobile'}  
//                  variant="standard"
//                  name="secondary_contact_mobile"
//                  type="text"
//                  value={data.secondary_contact_mobile}
//                  error={error.secondary_contact_mobile}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
                 
//                 />

//               <TextInput 
//                  mandatory={false}
//                  label={'Ownership Details'}  
//                  variant="standard"
//                  name="ownership_details"
//                  type="text"
//                  value={data.ownership_details}
//                  error={error.ownership_details}
//                  handlechange={handlechange}
//                  placeholder="Enter contact name"
//                  InputLabelProps={{
//                      style: { color: '#fff', }, 
//                  }}
//                 />
//             <TextAreaInput1 
//                 label={'Summary'}  
//                 variant="standard"
//                 name="summary"
//                 type="text"
//                 value={data.summary}
//                 error={error.summary}
//                 handlechange={handlechange}
//                 placeholder=""
//                 />
//              <div className='w-[100%] mt-2 relative mr-[2%]'>
//            <h6 className='text-[11px] font-[600] mb-1' >Main Image</h6>            
//            {!(data.main_image === '' || data.main_image == null) && <h6 onClick={()=>openFile(data?.main_image)} className='underline text-[8px] absolute cursor-pointer right-0 top-0 font-[600]'>View File</h6>}
//            {(data.main_image === '' || data.main_image == null) ?
//             <form onClick={()=>document.querySelector(`.input-field`).click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border border-l-4 border-l-slate-700 border-slate-300 `}>
//                 <input type='file' onChange={({target:{files}})=>{
//                 files[0] && uploadfilefunc(files[0],'main_image')
//                 }} accept="image/*" className='input-field' hidden />
//             </form> 
//         :
//             <div className='p-2 border border-slate-300 border-l-4 border-l-slate-700 relative flex flex-col  cursor-pointer'>
//                 <Tooltip title='Delete'><IoClose className='absolute top-3 right-2' onClick={()=>setdata({...data,main_image:''})}/></Tooltip>
//                 <h6 className='text-[12px] truncate w-48 ml-0'>{data?.main_image}</h6>
//             </div>
//         }

//         <ErrorComponent error={error?.main_image} />
//              </div>  
//              </div>
//             </div>   

//              <div className='flex items-center mt-5 mb-10  border-t pt-5'>
//                 <div className='mr-2'>
//                 <ButtonOutlined btnName={'Back'} onClick={()=>navigate(-1)} />
//                 </div>
//                 <div>
//                 {loader ?
//                 <ButtonFilled btnName={loader ? 'Uploading' : 'Save'}  />
//                 :
//                 <ButtonFilled btnName={loader ? 'Uploading' : 'Save'} onClick={()=>submitform()} />}
//                 </div>
//             </div>

//             </div>
//         </div>
//     </div>          
//     </div>
//   )
// }

// export default IlsLandDataCE;