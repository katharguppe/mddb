
import React, { useEffect, useState } from 'react';
import IlsMenu from './IlsMenu'
import { useLocation, useNavigate } from 'react-router-dom'
// import { DeleteOfficeSpaceHistoryService, GetOfficeSpaceDetailService, GetOfficeSpaceHistoryService, UpdateOfficeSpaceHistoryService } from '../../../services/database/mainoptions/OfficeSpaceServices'
import { DeleteOfficeSpaceHistoryService, GetOfficeSpaceDetailService, GetOfficeSpaceHistoryService, UpdateOfficeSpaceHistoryService } from '../../services/database/mainoptions/OfficeSpaceServices';
import { DeleteILSLandDataService,GetILSLandDetailService, GetILSLandDataService ,GetIlsLandHistoryService, DeleteIlsLandHistoryService,UpdateIlsLandHistoryService} from '../../services/IlsLandDataServices'
import toast from 'react-hot-toast'
import GoBack from '../../components/back/GoBack'
import { GrLocationPin } from "react-icons/gr";
import { CgPlayTrackPrevR } from "react-icons/cg";
import { AiOutlineClose, AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai'
import { Modal,Drawer } from 'antd'
import { useSelector } from 'react-redux'
import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
import { TextAreaInput1 } from '../../components/input'
import {FiChevronRight,FiChevronLeft} from 'react-icons/fi';
import { IconButton, } from '@mui/material'


function IlsLandDataDetail() {
  const roles = useSelector(state=>state.Auth.roles)
  const [openModal,setopenModal] = useState(null)  
  const {state} = useLocation() 
    const [data,setdata] = useState({})
    const [page,setpage] = useState(1)
    const [modal,setmodal] = useState(null)
    const [historyData,sethistoryData] = useState({datas:[],pagination:{total:0,totalPages:0,limit:25}})
    const [selectedhistoryData,setselectedhistoryData] = useState({})
    const [selectedhistoryDataErr,setselectedhistoryDataErr] = useState({})
    const [selectedImage,setselectedImage] = useState("")

  // const [floorSelected,setfloorSelected] = useState(null)

  useEffect(()=>{
    getilslandhistoryfun()
  },[page])

  const navigate = useNavigate()

  useEffect(()=>{
    getdetail()
  },[state])

  
  async function getdetail() {
    const response = await GetILSLandDetailService(state)
    if(response?.status == 200){
        setselectedImage(response?.data?.datas[0]?.main_image)
        setdata(response?.data?.datas[0])
    }else{
        navigate(-1)
        toast.error("Data Not Found")
    }
  }

 

  function openFile(v){
    let url = `${v}`
    window.open(url,'_blank')
   }




   async function getilslandhistoryfun(){
    const response = await GetIlsLandHistoryService(page,state)
    sethistoryData(response?.data?.data)
   }

   async function deletehistoryfunc() {
     if(!selectedhistoryData?._id){
        toast.error("Office Space History Data Not Selected ")
     }else{
        const response = await DeleteIlsLandHistoryService(selectedhistoryData?._id)
        if(response?.status == 200){
            toast.success("Office Space History Data Deleted")
            setmodal('')
            getilslandhistoryfun()
            setpage(1)
          }
     }
   }
       
   async function update_office_space_history_func() {
    if(!selectedhistoryData?.remarks){
       setselectedhistoryDataErr({...selectedhistoryDataErr,remarks:"This Field is required*"})
    }else{
      let sendData = {...selectedhistoryData}
      delete sendData.ils_land_data
      delete sendData.updated_by

      const response = await UpdateIlsLandHistoryService(sendData?._id,sendData)
      if(response?.status == 200){
        toast.success("Office Space History Data Updated")
        setmodal('')
        getilslandhistoryfun()
        setpage(1)
      }
    }
   }

return (
<div className="flex min-h-screen bg-gray-100">
      {/* Sidebar */}
      {/* <div className="w-[180px] bg-white shadow-md min-h-screen">
        <IlsMenu />
      </div> */}
           <Drawer placement='right' width={400}  footer={false} closable={false} open={openModal == 1}>
                  <div className='relative'>
                      <AiOutlineClose onClick={()=>setopenModal('')} size={18} className='absolute right-1 top-2 bg-slate-200 cursor-pointer p-1' />
                      <div className='mb-4'>
                        <h6 className='pt-1.5 font-[800] text-[13px]'>Data Update History ({historyData?.pagination?.total})</h6>
                      </div>   
      
                       {historyData?.datas?.map((d)=>(
                          <div className='border p-2 relative rounded-[10px] mt-2' key={d?._id}>
      
      
                              <div className='flex border-l border-b cursor-pointer items-center absolute right-0 top-0 p-1'>
                                <AiOutlineEdit onClick={()=>{setselectedhistoryData(d);setmodal(2)}} size={17} className='mr-1 pr-1 border-r' />
                                <AiOutlineDelete onClick={()=>{setselectedhistoryData(d);setmodal(1)}} size={12} className='' />
                              </div>     
      
                              
      
                              <h6 className='text-[13px] font-[800]'>Update Made : </h6>
                              <div className='flex items-center'>
                                  <h6 className='text-[11px] break-word' dangerouslySetInnerHTML={{__html:d?.updatedFields}}></h6>
                              </div>
      
                              <h6 className='bg-slate-100 p-1 mt-1 text-[11px]'><span className='font-[800]'>Remarks :</span> {d?.remarks}</h6>
                              
                              <div>
                                <h6 className='text-[10px]'><span className='font-[800]'>Modified By :</span> <span>{d?.updated_by?.name} / {d?.updated_by?.employee_id}</span></h6>
                              </div>
                          </div>  
      
                          ))}
      
                          <div className='flex items-center justify-center mx-auto mt-4'>
                              <IconButton onClick={()=>{page > 1 ? setpage(page-1) : console.log('')}}><FiChevronLeft className={`${page === 1 ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>
                              <h6 className='mx-2 bg-slate-100 w-[20px] text-center rounded'>{page}</h6>
                              <IconButton onClick={()=>{ page < historyData?.pagination?.totalPages  ? setpage(page+1) : console.log('')}}><FiChevronRight className={`${(historyData?.pagination?.totalPages === page || historyData?.datas?.length === 0)  ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>
                          </div>
                          
                  </div>
                   
              </Drawer>
      
               <Modal open={modal == 1 || modal == 2} className='absolute top-0 left-[42%]' width={300} footer={false} closable={false}>
                  {modal == 1 &&
                  <div>
                      <h6 className='text-[12px] font-[700]'>Delete Managed Office History Data</h6>
                      <h6 className='text-[10px] bg-slate-100 p-[4px] leading-[14px]'>Are you sure want to delete the selected managed office history data once deleted will not be retrieved</h6>
                      
                      <div className='flex mt-2 justify-end border-t pt-2'>
                      <ButtonOutlinedAutoWidth  btnName="Cancel" onClick={()=>setmodal('')} />  
                      <h6 className='w-[10px]'></h6>
                      <ButtonFilledAutoWidth  btnName="Save" onClick={()=>deletehistoryfunc()} />  
                      </div>    
                  </div>}
      
                  {modal == 2 &&
                  <div>
                      <h6 className='text-[12px] font-[700]'>Update Managed Office History Data</h6>
                      <h6 className='text-[10px] bg-slate-100 p-[4px] leading-[14px]'>Use the below form to update the remarks for the managed office history data</h6>
                      
      
                      <TextAreaInput1  error={selectedhistoryDataErr?.remarks} value={selectedhistoryData?.remarks} handlechange={(e)=>{setselectedhistoryData({...selectedhistoryData,remarks:e.target.value});setselectedhistoryDataErr({remarks:''})}} />
      
      
      
      
                      <div className='flex mt-2 justify-end border-t pt-2'>
                      <ButtonOutlinedAutoWidth  btnName="Cancel" onClick={()=>setmodal('')} />  
                      <h6 className='w-[10px]'></h6>
                      <ButtonFilledAutoWidth  btnName="Save" onClick={()=>update_office_space_history_func()} />  
                      </div>    
                  </div>}
              </Modal>
  <div className='min-w-[180px] w-[180px] max-w-[180px]'>
    <IlsMenu /> 
    </div>
      {/* Main Content */}
      <div className="flex-1 p-6 relative">
  {/* Top Right Button Group */}
  {(roles?.includes('admin') || roles?.includes('db_head')) && (
    <div className="absolute right-2 top-2 flex gap-2 z-50">
      {/* History Button */}
      <div
        onClick={() => {
          getilslandhistoryfun();
          setopenModal(1);
        }}
        className="flex items-center bg-slate-700 rounded px-3 py-1 cursor-pointer border border-slate-700 text-white"
      >
        <CgPlayTrackPrevR className="mr-2 text-[12px]" />
        <h6 className="text-[11px]">History</h6>
      </div>

      {/* Edit Button */}
      <div
        onClick={() => {
          console.log("daaaata", state);
          navigate("/ils/land_data/edit", { state: state });
        }}
        className="flex items-center bg-slate-100 rounded px-3 py-1 cursor-pointer border border-slate-400"
      >
        <AiOutlineEdit className="mr-2 text-[12px]" />
        <h6 className="text-[11px]">Edit</h6>
      </div>
    </div>
  )}

  {/* Back Button */}
  <div className="mb-3">
    <GoBack />
  </div>

        {/* Main Card */}
        <div className="card ml-4">
          <div className="flex flex-col md:flex-row justify-between mb-6  pb-4">
  <div className="flex items-start w-full md:w-auto">
   <div  className='w-[100%] h-[150px] bg-slate-100 object-contain'>
        {data?.main_image !== '' && <img alt="main_image" src={`${process.env.REACT_APP_AWS_IMAGE_URL}${data?.main_image}`} className='w-[100%] h-[150px] bg-slate-100 object-contain' />}
        </div>  
  <div>
    <h2 className="text-2xl font-bold text-blue-500 mb-1">LOGOS - INDIQUBE</h2>
    <p className="text-sm text-gray-500 whitespace-nowrap overflow-hidden text-ellipsis">
  Zone: <span className="italic text-green-500">{data?.zone}</span>
</p>

<p className="text-sm text-gray-500 mt-1 whitespace-nowrap overflow-hidden text-ellipsis">
  Area: <span className="italic text-green-500">{data?.location}</span>
</p>

<p className="text-sm text-gray-500 mt-1 whitespace-nowrap overflow-hidden text-ellipsis">
  Landmark: <span className="italic text-green-500">{data?.landmark}</span>
</p>

  </div>
</div>

          </div>

          {/* Property Info Grid */}
          <div className="grid  grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">


          <Section
              title="More Information"
              details={[
                { label: 'Land Area', value: `${data?.land_area}` },
                { label: 'Location', value: `${data?.location}` },
                { label: 'Land Status', value: `${data?.landstatus}` },
                { label: 'Frontage', value: `${data?.frontage}` },
                { label: 'Access Road Width', value:`${data?.access_road_width}` },
                { label: 'Landmark', value: `${data?.landmark}` },
                { label: 'Surroundings', value: `${data?.surroundings}` },
                { label: 'Conversion Type', value: `${data?.conversion_type}` },
                // { label: 'Coordinate', value: `${data?.coordinate}` },
                { label: 'Zone', value: data?.zone },
              ]}
            />

            {/* <Section
              title="Property Overview"
              details={[
                { label: 'Type Of Transaction', value: `${data?.type_of_transaction}` },
                { label: 'Built To Suit Rent Price', value: `Rs. ${data?.built_to_suit_rent_price}` },
                { label: 'Sale price', value: `Rs. ${data?.sale_price}` },
                { label: 'Rent Price', value: `Rs. ${data?.rent_price}` },
                { label: 'JV/JD Ratio', value: `Rs. ${data?.jvjd_ratio}` },
              ]}
            /> */}

<Section
  title="Property Overview"
  details={[
    { label: 'Type Of Transaction', value: data?.type_of_transaction || '-' },
    {
      label: 'Built To Suit Rent Price',
      value: data?.built_to_suit_rent_price ? `Rs. ${data.built_to_suit_rent_price}` : '-',
    },
    {
      label: 'Sale price',
      value: data?.sale_price ? `Rs. ${data.sale_price}` : '-',
    },
    {
      label: 'Rent Price',
      value: data?.rent_price ? `Rs. ${data.rent_price}` : '-',
    },
    {
      label: 'JV/JD Ratio',
      value: data?.jvjd_ratio ? `Rs. ${data.jvjd_ratio}` : '-',
    },
  ]}
/>


            <Section
              title="Contact Information"
              details={[
                { label: 'Primary Contact', value: data?.primary_contact_name },
                { label: 'Primary Phone', value: data?.primary_contact_mobile },
                { label: 'Secondary Contact', value: data?.secondary_contact_name },
                { label: 'Secondary Phone', value: data?.secondary_contact_mobile },
                { label: 'POC Name', value: data?.point_of_contact_name },
                { label: 'POC Mobile', value: data?.point_of_contact_mobile },
              ]}
            />

            <Section
              title="Creator Information"
              details={[
                { label: 'Ownership Details', value: data?.ownership_details },
                { label: 'Created At', value: new Date(data?.createdAt).toLocaleDateString() },
              ]}
            />

            <div className="md:col-span-2 lg:col-span-1">
            <h3 className="text-base font-bold text-gray-800 mb-2 border-b pb-1">Location Details</h3>
              <div className="space-y-0.5 divide-y divide-gray-100">
<Detail
  label="Coordinate"
  value={
    data?.coordinate ? (
      data.coordinate.startsWith('http') ? (

        <a
          href={data.coordinate}
          target="_blank"
          rel="noreferrer"
          className="text-blue-500 hover:underline"
        >
          {data.coordinate}
        </a>
      ) : (
        // Plain coordinate converted to Google Maps search link
        <a
          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
            data.coordinate
          )}`}
          target="_blank"
          rel="noreferrer"
          className="text-blue-500 hover:underline"
          title="Open in Google Maps"
        >
          {data.coordinate}
        </a>
      )
    ) : (
      '-'
    )
  }
/>

{data?.coordinate && !data.coordinate.includes('°') && (
    <div className="pt-3">
      <iframe
        className="rounded-md"
        src={`https://www.google.com/maps?q=${encodeURIComponent(
          data.coordinate
        )}&output=embed`}
        width="100%"
        height="200"
        style={{ border: 0 }}
        loading="lazy"
        allowFullScreen
        referrerPolicy="no-referrer-when-downgrade"
        title="Map Preview"
      />
    </div>
  )}
              </div>

            </div>
          </div>
        </div>
      </div> 
    </div>
  )
}





const Section = ({ title, details }) => (
  <div className="mb-4">
    <h3 className="text-sm font-bold text-gray-800 mb-1 border-b pb-0.5">{title}</h3>
    <div className="divide-y divide-gray-200">
      {details.map((item, index) => (
        <div
          key={index}
          className="grid grid-cols-2 items-center text-xs"
        >
          <div className="bg-gray-300 text-gray-900 px-2 py-1 font-medium border-b border-gray-200">
            {item.label}
          </div>
          <div className="bg-white text-gray-600 px-2 py-1 border-b border-gray-200 text-right">
            {item.value || '-'}
          </div>
        </div>
      ))}
    </div>
  </div>
);

const Detail = ({ label, value }) => (
  <div className="grid grid-cols-2 items-center text-xs">
    <div className="bg-gray-200 text-gray-800 px-2 py-1 font-medium border-b border-gray-200">
      {label}
    </div>
    <div className="bg-white text-gray-600 px-2 py-1 border-b border-gray-200 text-right">
      {value}
    </div>
  </div>
);

export default IlsLandDataDetail








/// old good

// import React, { useEffect, useState } from 'react';
// import IlsMenu from './IlsMenu'
// import { useLocation, useNavigate } from 'react-router-dom'
// // import { DeleteOfficeSpaceHistoryService, GetOfficeSpaceDetailService, GetOfficeSpaceHistoryService, UpdateOfficeSpaceHistoryService } from '../../../services/database/mainoptions/OfficeSpaceServices'
// import { DeleteOfficeSpaceHistoryService, GetOfficeSpaceDetailService, GetOfficeSpaceHistoryService, UpdateOfficeSpaceHistoryService } from '../../services/database/mainoptions/OfficeSpaceServices';
// import { DeleteILSLandDataService,GetILSLandDetailService, GetILSLandDataService ,GetIlsLandHistoryService, DeleteIlsLandHistoryService,UpdateIlsLandHistoryService} from '../../services/IlsLandDataServices'
// import toast from 'react-hot-toast'
// import GoBack from '../../components/back/GoBack'
// import { GrLocationPin } from "react-icons/gr";
// import { CgPlayTrackPrevR } from "react-icons/cg";
// import { AiOutlineClose, AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai'
// import { Modal,Drawer } from 'antd'
// import { useSelector } from 'react-redux'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
// import { TextAreaInput1 } from '../../components/input'
// import {FiChevronRight,FiChevronLeft} from 'react-icons/fi';
// import { IconButton, } from '@mui/material'


// function IlsLandDataDetail() {
//   const roles = useSelector(state=>state.Auth.roles)
//   const [openModal,setopenModal] = useState(null)  
//   const {state} = useLocation() 
//     const [data,setdata] = useState({})
//     const [page,setpage] = useState(1)
//     const [modal,setmodal] = useState(null)
//     const [historyData,sethistoryData] = useState({datas:[],pagination:{total:0,totalPages:0,limit:25}})
//     const [selectedhistoryData,setselectedhistoryData] = useState({})
//     const [selectedhistoryDataErr,setselectedhistoryDataErr] = useState({})
//     const [selectedImage,setselectedImage] = useState("")

//   // const [floorSelected,setfloorSelected] = useState(null)

//   useEffect(()=>{
//     getilslandhistoryfun()
//   },[page])

//   const navigate = useNavigate()

//   useEffect(()=>{
//     getdetail()
//   },[state])

  
//   async function getdetail() {
//     const response = await GetILSLandDetailService(state)
//     if(response?.status == 200){
//         setselectedImage(response?.data?.datas[0]?.main_image)
//         setdata(response?.data?.datas[0])
//     }else{
//         navigate(-1)
//         toast.error("Data Not Found")
//     }
//   }

 

//   function openFile(v){
//     let url = `${v}`
//     window.open(url,'_blank')
//    }




//    async function getilslandhistoryfun(){
//     const response = await GetIlsLandHistoryService(page,state)
//     sethistoryData(response?.data?.data)
//    }

//    async function deletehistoryfunc() {
//      if(!selectedhistoryData?._id){
//         toast.error("Office Space History Data Not Selected ")
//      }else{
//         const response = await DeleteIlsLandHistoryService(selectedhistoryData?._id)
//         if(response?.status == 200){
//             toast.success("Office Space History Data Deleted")
//             setmodal('')
//             getilslandhistoryfun()
//             setpage(1)
//           }
//      }
//    }
       
//    async function update_office_space_history_func() {
//     if(!selectedhistoryData?.remarks){
//        setselectedhistoryDataErr({...selectedhistoryDataErr,remarks:"This Field is required*"})
//     }else{
//       let sendData = {...selectedhistoryData}
//       delete sendData.ils_land_data
//       delete sendData.updated_by

//       const response = await UpdateIlsLandHistoryService(sendData?._id,sendData)
//       if(response?.status == 200){
//         toast.success("Office Space History Data Updated")
//         setmodal('')
//         getilslandhistoryfun()
//         setpage(1)
//       }
//     }
//    }

// return (
// <div className="flex min-h-screen bg-gray-100">
//       {/* Sidebar */}
//       {/* <div className="w-[180px] bg-white shadow-md min-h-screen">
//         <IlsMenu />
//       </div> */}
//            <Drawer placement='right' width={400}  footer={false} closable={false} open={openModal == 1}>
//                   <div className='relative'>
//                       <AiOutlineClose onClick={()=>setopenModal('')} size={18} className='absolute right-1 top-2 bg-slate-200 cursor-pointer p-1' />
//                       <div className='mb-4'>
//                         <h6 className='pt-1.5 font-[800] text-[13px]'>Data Update History ({historyData?.pagination?.total})</h6>
//                       </div>   
      
//                        {historyData?.datas?.map((d)=>(
//                           <div className='border p-2 relative rounded-[10px] mt-2' key={d?._id}>
      
      
//                               <div className='flex border-l border-b cursor-pointer items-center absolute right-0 top-0 p-1'>
//                                 <AiOutlineEdit onClick={()=>{setselectedhistoryData(d);setmodal(2)}} size={17} className='mr-1 pr-1 border-r' />
//                                 <AiOutlineDelete onClick={()=>{setselectedhistoryData(d);setmodal(1)}} size={12} className='' />
//                               </div>     
      
                              
      
//                               <h6 className='text-[13px] font-[800]'>Update Made : </h6>
//                               <div className='flex items-center'>
//                                   <h6 className='text-[11px] break-word' dangerouslySetInnerHTML={{__html:d?.updatedFields}}></h6>
//                               </div>
      
//                               <h6 className='bg-slate-100 p-1 mt-1 text-[11px]'><span className='font-[800]'>Remarks :</span> {d?.remarks}</h6>
                              
//                               <div>
//                                 <h6 className='text-[10px]'><span className='font-[800]'>Modified By :</span> <span>{d?.updated_by?.name} / {d?.updated_by?.employee_id}</span></h6>
//                               </div>
//                           </div>  
      
//                           ))}
      
//                           <div className='flex items-center justify-center mx-auto mt-4'>
//                               <IconButton onClick={()=>{page > 1 ? setpage(page-1) : console.log('')}}><FiChevronLeft className={`${page === 1 ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>
//                               <h6 className='mx-2 bg-slate-100 w-[20px] text-center rounded'>{page}</h6>
//                               <IconButton onClick={()=>{ page < historyData?.pagination?.totalPages  ? setpage(page+1) : console.log('')}}><FiChevronRight className={`${(historyData?.pagination?.totalPages === page || historyData?.datas?.length === 0)  ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>
//                           </div>
                          
//                   </div>
                   
//               </Drawer>
      
//                <Modal open={modal == 1 || modal == 2} className='absolute top-0 left-[42%]' width={300} footer={false} closable={false}>
//                   {modal == 1 &&
//                   <div>
//                       <h6 className='text-[12px] font-[700]'>Delete Managed Office History Data</h6>
//                       <h6 className='text-[10px] bg-slate-100 p-[4px] leading-[14px]'>Are you sure want to delete the selected managed office history data once deleted will not be retrieved</h6>
                      
//                       <div className='flex mt-2 justify-end border-t pt-2'>
//                       <ButtonOutlinedAutoWidth  btnName="Cancel" onClick={()=>setmodal('')} />  
//                       <h6 className='w-[10px]'></h6>
//                       <ButtonFilledAutoWidth  btnName="Save" onClick={()=>deletehistoryfunc()} />  
//                       </div>    
//                   </div>}
      
//                   {modal == 2 &&
//                   <div>
//                       <h6 className='text-[12px] font-[700]'>Update Managed Office History Data</h6>
//                       <h6 className='text-[10px] bg-slate-100 p-[4px] leading-[14px]'>Use the below form to update the remarks for the managed office history data</h6>
                      
      
//                       <TextAreaInput1  error={selectedhistoryDataErr?.remarks} value={selectedhistoryData?.remarks} handlechange={(e)=>{setselectedhistoryData({...selectedhistoryData,remarks:e.target.value});setselectedhistoryDataErr({remarks:''})}} />
      
      
      
      
//                       <div className='flex mt-2 justify-end border-t pt-2'>
//                       <ButtonOutlinedAutoWidth  btnName="Cancel" onClick={()=>setmodal('')} />  
//                       <h6 className='w-[10px]'></h6>
//                       <ButtonFilledAutoWidth  btnName="Save" onClick={()=>update_office_space_history_func()} />  
//                       </div>    
//                   </div>}
//               </Modal>
//   <div className='min-w-[180px] w-[180px] max-w-[180px]'>
//     <IlsMenu /> 
//     </div>
//       {/* Main Content */}
//       <div className="flex-1 p-6 relative">
//         {/* Floating Edit Button */} 
//           {(roles?.includes('admin') || roles?.includes('db_head')) &&
//                         <div onClick={()=>{getilslandhistoryfun();setopenModal(1)}} className='flex items-center justify-center bg-slate-700 rounded pr-3 pl-2 cursor-pointer z-100 absolute right-20 p-1 border border-slate-700 text-white'>
//                             <CgPlayTrackPrevR className='mr-2 text-[10px]' />
//                             <h6 className='text-[11px]'>History</h6>
//                         </div>}
//        <div onClick={()=>{console.log("daaaata",state);navigate('/ils/land_data/edit',{state:state})}} className='flex items-center justify-center bg-slate-100 rounded pr-3 pl-2 cursor-pointer z-100 absolute right-2 top-2 p-1 border border-slate-400 '>
//               <AiOutlineEdit className='mr-2 text-[10px]' />
//               <h6 className='text-[11px]'>Edit</h6>
//           </div>
//         {/* Back Button */}
//         <div className="mb-3">
//             <GoBack />
//         </div>

//         {/* Main Card */}
//         <div className="card ml-4">
//           <div className="flex flex-col md:flex-row justify-between mb-6  pb-4">
//   <div className="flex items-start w-full md:w-auto">
//    <div  className='w-[100%] h-[150px] bg-slate-100 object-contain'>
//         {data?.main_image !== '' && <img alt="main_image" src={`${process.env.REACT_APP_AWS_IMAGE_URL}${data?.main_image}`} className='w-[100%] h-[150px] bg-slate-100 object-contain' />}
//         </div>  
//   <div>
//     <h2 className="text-2xl font-bold text-blue-500 mb-1">LOGOS - INDIQUBE</h2>
//     <p className="text-sm text-gray-500 whitespace-nowrap overflow-hidden text-ellipsis">
//   Zone: <span className="italic text-green-500">{data?.zone}</span>
// </p>

// <p className="text-sm text-gray-500 mt-1 whitespace-nowrap overflow-hidden text-ellipsis">
//   Area: <span className="italic text-green-500">{data?.location}</span>
// </p>

// <p className="text-sm text-gray-500 mt-1 whitespace-nowrap overflow-hidden text-ellipsis">
//   Landmark: <span className="italic text-green-500">{data?.landmark}</span>
// </p>

//   </div>
// </div>

//           </div>

//           {/* Property Info Grid */}
//           <div className="grid  grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">


//           <Section
//               title="More Information"
//               details={[
//                 { label: 'Land Area', value: `${data?.land_area}` },
//                 { label: 'Location', value: `${data?.location}` },
//                 { label: 'Land Status', value: `${data?.landstatus}` },
//                 { label: 'Frontage', value: `${data?.frontage}` },
//                 { label: 'Access Road Width', value:`${data?.access_road_width}` },
//                 { label: 'Landmark', value: `${data?.landmark}` },
//                 { label: 'Surroundings', value: `${data?.surroundings}` },
//                 { label: 'Conversion Type', value: `${data?.conversion_type}` },
//                 // { label: 'Coordinate', value: `${data?.coordinate}` },
//                 { label: 'Zone', value: data?.zone },
//               ]}
//             />

//             {/* <Section
//               title="Property Overview"
//               details={[
//                 { label: 'Type Of Transaction', value: `${data?.type_of_transaction}` },
//                 { label: 'Built To Suit Rent Price', value: `Rs. ${data?.built_to_suit_rent_price}` },
//                 { label: 'Sale price', value: `Rs. ${data?.sale_price}` },
//                 { label: 'Rent Price', value: `Rs. ${data?.rent_price}` },
//                 { label: 'JV/JD Ratio', value: `Rs. ${data?.jvjd_ratio}` },
//               ]}
//             /> */}

// <Section
//   title="Property Overview"
//   details={[
//     { label: 'Type Of Transaction', value: data?.type_of_transaction || '-' },
//     {
//       label: 'Built To Suit Rent Price',
//       value: data?.built_to_suit_rent_price ? `Rs. ${data.built_to_suit_rent_price}` : '-',
//     },
//     {
//       label: 'Sale price',
//       value: data?.sale_price ? `Rs. ${data.sale_price}` : '-',
//     },
//     {
//       label: 'Rent Price',
//       value: data?.rent_price ? `Rs. ${data.rent_price}` : '-',
//     },
//     {
//       label: 'JV/JD Ratio',
//       value: data?.jvjd_ratio ? `Rs. ${data.jvjd_ratio}` : '-',
//     },
//   ]}
// />


//             <Section
//               title="Contact Information"
//               details={[
//                 { label: 'Primary Contact', value: data?.primary_contact_name },
//                 { label: 'Primary Phone', value: data?.primary_contact_mobile },
//                 { label: 'Secondary Contact', value: data?.secondary_contact_name },
//                 { label: 'Secondary Phone', value: data?.secondary_contact_mobile },
//                 { label: 'POC Name', value: data?.point_of_contact_name },
//                 { label: 'POC Mobile', value: data?.point_of_contact_mobile },
//               ]}
//             />

//             <Section
//               title="Creator Information"
//               details={[
//                 { label: 'Ownership Details', value: data?.ownership_details },
//                 { label: 'Created At', value: new Date(data?.createdAt).toLocaleDateString() },
//               ]}
//             />

//             <div className="md:col-span-2 lg:col-span-1">
//             <h3 className="text-base font-bold text-gray-800 mb-2 border-b pb-1">Location Details</h3>
//               <div className="space-y-0.5 divide-y divide-gray-100">
// <Detail
//   label="Coordinate"
//   value={
//     data?.coordinate ? (
//       data.coordinate.startsWith('http') ? (

//         <a
//           href={data.coordinate}
//           target="_blank"
//           rel="noreferrer"
//           className="text-blue-500 hover:underline"
//         >
//           {data.coordinate}
//         </a>
//       ) : (
//         // Plain coordinate converted to Google Maps search link
//         <a
//           href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
//             data.coordinate
//           )}`}
//           target="_blank"
//           rel="noreferrer"
//           className="text-blue-500 hover:underline"
//           title="Open in Google Maps"
//         >
//           {data.coordinate}
//         </a>
//       )
//     ) : (
//       '-'
//     )
//   }
// />

// {data?.coordinate && !data.coordinate.includes('°') && (
//     <div className="pt-3">
//       <iframe
//         className="rounded-md"
//         src={`https://www.google.com/maps?q=${encodeURIComponent(
//           data.coordinate
//         )}&output=embed`}
//         width="100%"
//         height="200"
//         style={{ border: 0 }}
//         loading="lazy"
//         allowFullScreen
//         referrerPolicy="no-referrer-when-downgrade"
//         title="Map Preview"
//       />
//     </div>
//   )}
//               </div>

//             </div>
//           </div>
//         </div>
//       </div> 
//     </div>
//   )
// }





// const Section = ({ title, details }) => (
//   <div className="mb-4">
//     <h3 className="text-sm font-bold text-gray-800 mb-1 border-b pb-0.5">{title}</h3>
//     <div className="divide-y divide-gray-200">
//       {details.map((item, index) => (
//         <div
//           key={index}
//           className="grid grid-cols-2 items-center text-xs"
//         >
//           <div className="bg-gray-300 text-gray-900 px-2 py-1 font-medium border-b border-gray-200">
//             {item.label}
//           </div>
//           <div className="bg-white text-gray-600 px-2 py-1 border-b border-gray-200 text-right">
//             {item.value || '-'}
//           </div>
//         </div>
//       ))}
//     </div>
//   </div>
// );

// const Detail = ({ label, value }) => (
//   <div className="grid grid-cols-2 items-center text-xs">
//     <div className="bg-gray-200 text-gray-800 px-2 py-1 font-medium border-b border-gray-200">
//       {label}
//     </div>
//     <div className="bg-white text-gray-600 px-2 py-1 border-b border-gray-200 text-right">
//       {value}
//     </div>
//   </div>
// );

// export default IlsLandDataDetail







///====================>>>    Its working
// import React, { useEffect, useState } from 'react';
// import IlsMenu from './IlsMenu'
// import { useLocation, useNavigate } from 'react-router-dom'
// // import { DeleteOfficeSpaceHistoryService, GetOfficeSpaceDetailService, GetOfficeSpaceHistoryService, UpdateOfficeSpaceHistoryService } from '../../../services/database/mainoptions/OfficeSpaceServices'
// import { DeleteOfficeSpaceHistoryService, GetOfficeSpaceDetailService, GetOfficeSpaceHistoryService, UpdateOfficeSpaceHistoryService } from '../../services/database/mainoptions/OfficeSpaceServices';
// import { DeleteILSLandDataService,GetILSLandDetailService, GetILSLandDataService ,GetIlsLandHistoryService, DeleteIlsLandHistoryService,UpdateIlsLandHistoryService} from '../../services/IlsLandDataServices'
// import toast from 'react-hot-toast'
// import GoBack from '../../components/back/GoBack'
// import { GrLocationPin } from "react-icons/gr";
// import { CgPlayTrackPrevR } from "react-icons/cg";
// import { AiOutlineClose, AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai'
// import { Modal,Drawer } from 'antd'
// import { useSelector } from 'react-redux'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
// import { TextAreaInput1 } from '../../components/input'
// import {FiChevronRight,FiChevronLeft} from 'react-icons/fi';
// import { IconButton, } from '@mui/material'


// function IlsLandDataDetail() {
//   const roles = useSelector(state=>state.Auth.roles)
//   const [openModal,setopenModal] = useState(null)  
//   const {state} = useLocation() 
//     const [data,setdata] = useState({})
//     const [page,setpage] = useState(1)
//     const [modal,setmodal] = useState(null)
//     const [historyData,sethistoryData] = useState({datas:[],pagination:{total:0,totalPages:0,limit:25}})
//     const [selectedhistoryData,setselectedhistoryData] = useState({})
//     const [selectedhistoryDataErr,setselectedhistoryDataErr] = useState({})
//     const [selectedImage,setselectedImage] = useState("")

//   // const [floorSelected,setfloorSelected] = useState(null)

//   useEffect(()=>{
//     getilslandhistoryfun()
//   },[page])

//   const navigate = useNavigate()

//   useEffect(()=>{
//     getdetail()
//   },[state])

  
//   async function getdetail() {
//     const response = await GetILSLandDetailService(state)
//     if(response?.status == 200){
//         setselectedImage(response?.data?.datas[0]?.main_image)
//         setdata(response?.data?.datas[0])
//     }else{
//         navigate(-1)
//         toast.error("Data Not Found")
//     }
//   }

 

//   function openFile(v){
//     let url = `${v}`
//     window.open(url,'_blank')
//    }




//    async function getilslandhistoryfun(){
//     const response = await GetIlsLandHistoryService(page,state)
//     sethistoryData(response?.data?.data)
//    }

//    async function deletehistoryfunc() {
//      if(!selectedhistoryData?._id){
//         toast.error("Office Space History Data Not Selected ")
//      }else{
//         const response = await DeleteIlsLandHistoryService(selectedhistoryData?._id)
//         if(response?.status == 200){
//             toast.success("Office Space History Data Deleted")
//             setmodal('')
//             getilslandhistoryfun()
//             setpage(1)
//           }
//      }
//    }
       
//    async function update_office_space_history_func() {
//     if(!selectedhistoryData?.remarks){
//        setselectedhistoryDataErr({...selectedhistoryDataErr,remarks:"This Field is required*"})
//     }else{
//       let sendData = {...selectedhistoryData}
//       delete sendData.ils_land_data
//       delete sendData.updated_by

//       const response = await UpdateIlsLandHistoryService(sendData?._id,sendData)
//       if(response?.status == 200){
//         toast.success("Office Space History Data Updated")
//         setmodal('')
//         getilslandhistoryfun()
//         setpage(1)
//       }
//     }
//    }

// return (
// <div className="flex min-h-screen bg-gray-100">
//       {/* Sidebar */}
//       {/* <div className="w-[180px] bg-white shadow-md min-h-screen">
//         <IlsMenu />
//       </div> */}
//   <div className='min-w-[180px] w-[180px] max-w-[180px]'>
//     <IlsMenu /> 
//     </div>
//       {/* Main Content */}
//       <div className="flex-1 p-6 relative">
//         {/* Floating Edit Button */}
//        <div onClick={()=>{console.log("daaaata",state);navigate('/ils/land_data/edit',{state:state})}} className='flex items-center justify-center bg-slate-100 rounded pr-3 pl-2 cursor-pointer z-100 absolute right-2 top-2 p-1 border border-slate-400 '>
//               <AiOutlineEdit className='mr-2 text-[10px]' />
//               <h6 className='text-[11px]'>Edit</h6>
//           </div>
//         {/* Back Button */}
//         <div className="mb-3">
//             <GoBack />
//         </div>

//         {/* Main Card */}
//         <div className="card ml-4">
//           <div className="flex flex-col md:flex-row justify-between mb-6  pb-4">
//   <div className="flex items-start w-full md:w-auto">
//    <div  className='w-[100%] h-[150px] bg-slate-100 object-contain'>
//         {data?.main_image !== '' && <img alt="main_image" src={`${process.env.REACT_APP_AWS_IMAGE_URL}${data?.main_image}`} className='w-[100%] h-[150px] bg-slate-100 object-contain' />}
//         </div>  
//   <div>
//     <h2 className="text-2xl font-bold text-blue-500 mb-1">LOGOS - INDIQUBE</h2>
//     <p className="text-sm text-gray-500 whitespace-nowrap overflow-hidden text-ellipsis">
//   Zone: <span className="italic text-green-500">{data?.zone}</span>
// </p>

// <p className="text-sm text-gray-500 mt-1 whitespace-nowrap overflow-hidden text-ellipsis">
//   Area: <span className="italic text-green-500">{data?.location}</span>
// </p>

// <p className="text-sm text-gray-500 mt-1 whitespace-nowrap overflow-hidden text-ellipsis">
//   Landmark: <span className="italic text-green-500">{data?.landmark}</span>
// </p>

//   </div>
// </div>

//           </div>

//           {/* Property Info Grid */}
//           <div className="grid  grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">


//           <Section
//               title="More Information"
//               details={[
//                 { label: 'Land Area', value: `${data?.land_area}` },
//                 { label: 'Location', value: `${data?.location}` },
//                 { label: 'Land Status', value: `${data?.landstatus}` },
//                 { label: 'Frontage', value: `${data?.frontage}` },
//                 { label: 'Access Road Width', value:`${data?.access_road_width}` },
//                 { label: 'Landmark', value: `${data?.landmark}` },
//                 { label: 'Surroundings', value: `${data?.surroundings}` },
//                 { label: 'Conversion Type', value: `${data?.conversion_type}` },
//                 // { label: 'Coordinate', value: `${data?.coordinate}` },
//                 { label: 'Zone', value: data?.zone },
//               ]}
//             />

//             {/* <Section
//               title="Property Overview"
//               details={[
//                 { label: 'Type Of Transaction', value: `${data?.type_of_transaction}` },
//                 { label: 'Built To Suit Rent Price', value: `Rs. ${data?.built_to_suit_rent_price}` },
//                 { label: 'Sale price', value: `Rs. ${data?.sale_price}` },
//                 { label: 'Rent Price', value: `Rs. ${data?.rent_price}` },
//                 { label: 'JV/JD Ratio', value: `Rs. ${data?.jvjd_ratio}` },
//               ]}
//             /> */}

// <Section
//   title="Property Overview"
//   details={[
//     { label: 'Type Of Transaction', value: data?.type_of_transaction || '-' },
//     {
//       label: 'Built To Suit Rent Price',
//       value: data?.built_to_suit_rent_price ? `Rs. ${data.built_to_suit_rent_price}` : '-',
//     },
//     {
//       label: 'Sale price',
//       value: data?.sale_price ? `Rs. ${data.sale_price}` : '-',
//     },
//     {
//       label: 'Rent Price',
//       value: data?.rent_price ? `Rs. ${data.rent_price}` : '-',
//     },
//     {
//       label: 'JV/JD Ratio',
//       value: data?.jvjd_ratio ? `Rs. ${data.jvjd_ratio}` : '-',
//     },
//   ]}
// />


//             <Section
//               title="Contact Information"
//               details={[
//                 { label: 'Primary Contact', value: data?.primary_contact_name },
//                 { label: 'Primary Phone', value: data?.primary_contact_mobile },
//                 { label: 'Secondary Contact', value: data?.secondary_contact_name },
//                 { label: 'Secondary Phone', value: data?.secondary_contact_mobile },
//                 { label: 'POC Name', value: data?.point_of_contact_name },
//                 { label: 'POC Mobile', value: data?.point_of_contact_mobile },
//               ]}
//             />

//             <Section
//               title="Creator Information"
//               details={[
//                 { label: 'Ownership Details', value: data?.ownership_details },
//                 { label: 'Created At', value: new Date(data?.createdAt).toLocaleDateString() },
//               ]}
//             />

//             <div className="md:col-span-2 lg:col-span-1">
//             <h3 className="text-base font-bold text-gray-800 mb-2 border-b pb-1">Location Details</h3>
//               <div className="space-y-0.5 divide-y divide-gray-100">
// <Detail
//   label="Coordinate"
//   value={
//     data?.coordinate ? (
//       data.coordinate.startsWith('http') ? (

//         <a
//           href={data.coordinate}
//           target="_blank"
//           rel="noreferrer"
//           className="text-blue-500 hover:underline"
//         >
//           {data.coordinate}
//         </a>
//       ) : (
//         // Plain coordinate converted to Google Maps search link
//         <a
//           href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
//             data.coordinate
//           )}`}
//           target="_blank"
//           rel="noreferrer"
//           className="text-blue-500 hover:underline"
//           title="Open in Google Maps"
//         >
//           {data.coordinate}
//         </a>
//       )
//     ) : (
//       '-'
//     )
//   }
// />

// {data?.coordinate && !data.coordinate.includes('°') && (
//     <div className="pt-3">
//       <iframe
//         className="rounded-md"
//         src={`https://www.google.com/maps?q=${encodeURIComponent(
//           data.coordinate
//         )}&output=embed`}
//         width="100%"
//         height="200"
//         style={{ border: 0 }}
//         loading="lazy"
//         allowFullScreen
//         referrerPolicy="no-referrer-when-downgrade"
//         title="Map Preview"
//       />
//     </div>
//   )}
//               </div>

//             </div>
//           </div>
//         </div>
//       </div> 
//     </div>
//   )
// }





// const Section = ({ title, details }) => (
//   <div className="mb-4">
//     <h3 className="text-sm font-bold text-gray-800 mb-1 border-b pb-0.5">{title}</h3>
//     <div className="divide-y divide-gray-200">
//       {details.map((item, index) => (
//         <div
//           key={index}
//           className="grid grid-cols-2 items-center text-xs"
//         >
//           <div className="bg-gray-300 text-gray-900 px-2 py-1 font-medium border-b border-gray-200">
//             {item.label}
//           </div>
//           <div className="bg-white text-gray-600 px-2 py-1 border-b border-gray-200 text-right">
//             {item.value || '-'}
//           </div>
//         </div>
//       ))}
//     </div>
//   </div>
// );

// const Detail = ({ label, value }) => (
//   <div className="grid grid-cols-2 items-center text-xs">
//     <div className="bg-gray-200 text-gray-800 px-2 py-1 font-medium border-b border-gray-200">
//       {label}
//     </div>
//     <div className="bg-white text-gray-600 px-2 py-1 border-b border-gray-200 text-right">
//       {value}
//     </div>
//   </div>
// );

// export default IlsLandDataDetail








///=============================+>>>>>> History 2

// import React, { useEffect, useState } from 'react';
// import IlsMenu from './IlsMenu'
// import { useLocation, useNavigate } from 'react-router-dom'
// // import { DeleteOfficeSpaceHistoryService, GetOfficeSpaceDetailService, GetOfficeSpaceHistoryService, UpdateOfficeSpaceHistoryService } from '../../../services/database/mainoptions/OfficeSpaceServices'
// import { DeleteOfficeSpaceHistoryService, GetOfficeSpaceDetailService, GetOfficeSpaceHistoryService, UpdateOfficeSpaceHistoryService } from '../../services/database/mainoptions/OfficeSpaceServices';
// import { DeleteILSLandDataService,GetILSLandDetailService, GetILSLandDataService ,GetIlsLandHistoryService} from '../../services/IlsLandDataServices'
// import toast from 'react-hot-toast'
// import GoBack from '../../components/back/GoBack'
// import { GrLocationPin } from "react-icons/gr";
// import { CgPlayTrackPrevR } from "react-icons/cg";
// import { AiOutlineClose, AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai'
// import { Modal,Drawer } from 'antd'
// import { useSelector } from 'react-redux'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
// import { TextAreaInput1 } from '../../components/input'
// import {FiChevronRight,FiChevronLeft} from 'react-icons/fi';
// import { IconButton, } from '@mui/material'


// function IlsLandDataDetail() {
//   const roles = useSelector(state=>state.Auth.roles)
//   const [openModal,setopenModal] = useState(null)  
//   const {state} = useLocation() 
//     const [data,setdata] = useState({})
//     const [page,setpage] = useState(1)
//     const [modal,setmodal] = useState(null)
//     const [historyData,sethistoryData] = useState({datas:[],pagination:{total:0,totalPages:0,limit:25}})
//     const [selectedhistoryData,setselectedhistoryData] = useState({})
//     const [selectedhistoryDataErr,setselectedhistoryDataErr] = useState({})
//     const [selectedImage,setselectedImage] = useState("")

//   // const [floorSelected,setfloorSelected] = useState(null)

//   useEffect(()=>{
//     getilslandhistoryfun()
//   },[page])

//   const navigate = useNavigate()

//   useEffect(()=>{
//     getdetail()
//   },[state])

  
//   async function getdetail() {
//     const response = await GetILSLandDetailService(state)
//     if(response?.status == 200){
//         setselectedImage(response?.data?.datas[0]?.main_image)
//         setdata(response?.data?.datas[0])
//     }else{
//         navigate(-1)
//         toast.error("Data Not Found")
//     }
//   }

 

//   function openFile(v){
//     let url = `${v}`
//     window.open(url,'_blank')
//    }




//    async function getilslandhistoryfun(){
//     const response = await GetIlsLandHistoryService(page,state)
//     sethistoryData(response?.data?.data)
//    }

//   //  async function deletehistoryfunc() {
//   //    if(!selectedhistoryData?._id){
//   //       toast.error("Office Space History Data Not Selected ")
//   //    }else{
//   //       const response = await DeleteOfficeSpaceHistoryService(selectedhistoryData?._id)
//   //       if(response?.status == 200){
//   //           toast.success("Office Space History Data Deleted")
//   //           setmodal('')
//   //           getofficespacehistoryfun()
//   //           setpage(1)
//   //         }
//   //    }
//   //  }
       
//   //  async function update_office_space_history_func() {
//   //   if(!selectedhistoryData?.remarks){
//   //      setselectedhistoryDataErr({...selectedhistoryDataErr,remarks:"This Field is required*"})
//   //   }else{
//   //     let sendData = {...selectedhistoryData}
//   //     delete sendData.managed_office
//   //     delete sendData.updated_by

//   //     const response = await UpdateOfficeSpaceHistoryService(sendData?._id,sendData)
//   //     if(response?.status == 200){
//   //       toast.success("Office Space History Data Updated")
//   //       setmodal('')
//   //       getofficespacehistoryfun()
//   //       setpage(1)
//   //     }
//   //   }
//   //  }






//   /// old 33
// //   const {state} = useLocation()
// //   const navigate = useNavigate()
// //   const [data,setdata] = useState({})
// //   const [selectedImage,setselectedImage] = useState("")
  
// // console.log("%%%", state)

// //    useEffect(()=>{
// //       getdetail()
// //     },[state])
// //   async function getdetail() {
// //     const response = await GetILSLandDetailService(state)
// //     console.log("&&&&&",response)
// //     if(response?.status == 200){
// //         setselectedImage(response?.data?.datas[0]?.main_image)
// //         setdata(response?.data?.datas[0])
// //     }else{
// //         navigate(-1)
// //         toast.error("Data Not Found")
// //     }
// //   }

// //   console.log("state",state)



//   return (
// <div className="flex min-h-screen bg-gray-100">
//       {/* Sidebar */}
//       {/* <div className="w-[180px] bg-white shadow-md min-h-screen">
//         <IlsMenu />
//       </div> */}
//   <div className='min-w-[180px] w-[180px] max-w-[180px]'>
//     <IlsMenu /> 
//     </div>
//       {/* Main Content */}
//       <div className="flex-1 p-6 relative">
//         {/* Floating Edit Button */}
//        <div onClick={()=>{console.log("daaaata",state);navigate('/ils/land_data/edit',{state:state})}} className='flex items-center justify-center bg-slate-100 rounded pr-3 pl-2 cursor-pointer z-100 absolute right-2 top-2 p-1 border border-slate-400 '>
//               <AiOutlineEdit className='mr-2 text-[10px]' />
//               <h6 className='text-[11px]'>Edit</h6>
//           </div>
//         {/* Back Button */}
//         <div className="mb-3">
//             <GoBack />
//         </div>

//         {/* Main Card */}
//         <div className="card ml-4">
//           <div className="flex flex-col md:flex-row justify-between mb-6  pb-4">
//   <div className="flex items-start w-full md:w-auto">
//    <div  className='w-[100%] h-[150px] bg-slate-100 object-contain'>
//         {data?.main_image !== '' && <img alt="main_image" src={`${process.env.REACT_APP_AWS_IMAGE_URL}${data?.main_image}`} className='w-[100%] h-[150px] bg-slate-100 object-contain' />}
//         </div>  
//   <div>
//     <h2 className="text-2xl font-bold text-blue-500 mb-1">LOGOS - INDIQUBE</h2>
//     <p className="text-sm text-gray-500 whitespace-nowrap overflow-hidden text-ellipsis">
//   Zone: <span className="italic text-green-500">{data?.zone}</span>
// </p>

// <p className="text-sm text-gray-500 mt-1 whitespace-nowrap overflow-hidden text-ellipsis">
//   Area: <span className="italic text-green-500">{data?.location}</span>
// </p>

// <p className="text-sm text-gray-500 mt-1 whitespace-nowrap overflow-hidden text-ellipsis">
//   Landmark: <span className="italic text-green-500">{data?.landmark}</span>
// </p>

//   </div>
// </div>

//           </div>

//           {/* Property Info Grid */}
//           <div className="grid  grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">


//           <Section
//               title="More Information"
//               details={[
//                 { label: 'Land Area', value: `${data?.land_area}` },
//                 { label: 'Location', value: `${data?.location}` },
//                 { label: 'Land Status', value: `${data?.landstatus}` },
//                 { label: 'Frontage', value: `${data?.frontage}` },
//                 { label: 'Access Road Width', value:`${data?.access_road_width}` },
//                 { label: 'Landmark', value: `${data?.landmark}` },
//                 { label: 'Surroundings', value: `${data?.surroundings}` },
//                 { label: 'Conversion Type', value: `${data?.conversion_type}` },
//                 // { label: 'Coordinate', value: `${data?.coordinate}` },
//                 { label: 'Zone', value: data?.zone },
//               ]}
//             />

//             {/* <Section
//               title="Property Overview"
//               details={[
//                 { label: 'Type Of Transaction', value: `${data?.type_of_transaction}` },
//                 { label: 'Built To Suit Rent Price', value: `Rs. ${data?.built_to_suit_rent_price}` },
//                 { label: 'Sale price', value: `Rs. ${data?.sale_price}` },
//                 { label: 'Rent Price', value: `Rs. ${data?.rent_price}` },
//                 { label: 'JV/JD Ratio', value: `Rs. ${data?.jvjd_ratio}` },
//               ]}
//             /> */}

// <Section
//   title="Property Overview"
//   details={[
//     { label: 'Type Of Transaction', value: data?.type_of_transaction || '-' },
//     {
//       label: 'Built To Suit Rent Price',
//       value: data?.built_to_suit_rent_price ? `Rs. ${data.built_to_suit_rent_price}` : '-',
//     },
//     {
//       label: 'Sale price',
//       value: data?.sale_price ? `Rs. ${data.sale_price}` : '-',
//     },
//     {
//       label: 'Rent Price',
//       value: data?.rent_price ? `Rs. ${data.rent_price}` : '-',
//     },
//     {
//       label: 'JV/JD Ratio',
//       value: data?.jvjd_ratio ? `Rs. ${data.jvjd_ratio}` : '-',
//     },
//   ]}
// />


//             <Section
//               title="Contact Information"
//               details={[
//                 { label: 'Primary Contact', value: data?.primary_contact_name },
//                 { label: 'Primary Phone', value: data?.primary_contact_mobile },
//                 { label: 'Secondary Contact', value: data?.secondary_contact_name },
//                 { label: 'Secondary Phone', value: data?.secondary_contact_mobile },
//                 { label: 'POC Name', value: data?.point_of_contact_name },
//                 { label: 'POC Mobile', value: data?.point_of_contact_mobile },
//               ]}
//             />

//             <Section
//               title="Creator Information"
//               details={[
//                 { label: 'Ownership Details', value: data?.ownership_details },
//                 { label: 'Created At', value: new Date(data?.createdAt).toLocaleDateString() },
//               ]}
//             />

//             <div className="md:col-span-2 lg:col-span-1">
//             <h3 className="text-base font-bold text-gray-800 mb-2 border-b pb-1">Location Details</h3>
//               <div className="space-y-0.5 divide-y divide-gray-100">
// <Detail
//   label="Coordinate"
//   value={
//     data?.coordinate ? (
//       data.coordinate.startsWith('http') ? (

//         <a
//           href={data.coordinate}
//           target="_blank"
//           rel="noreferrer"
//           className="text-blue-500 hover:underline"
//         >
//           {data.coordinate}
//         </a>
//       ) : (
//         // Plain coordinate converted to Google Maps search link
//         <a
//           href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
//             data.coordinate
//           )}`}
//           target="_blank"
//           rel="noreferrer"
//           className="text-blue-500 hover:underline"
//           title="Open in Google Maps"
//         >
//           {data.coordinate}
//         </a>
//       )
//     ) : (
//       '-'
//     )
//   }
// />

// {data?.coordinate && !data.coordinate.includes('°') && (
//     <div className="pt-3">
//       <iframe
//         className="rounded-md"
//         src={`https://www.google.com/maps?q=${encodeURIComponent(
//           data.coordinate
//         )}&output=embed`}
//         width="100%"
//         height="200"
//         style={{ border: 0 }}
//         loading="lazy"
//         allowFullScreen
//         referrerPolicy="no-referrer-when-downgrade"
//         title="Map Preview"
//       />
//     </div>
//   )}
//               </div>

//             </div>
//           </div>
//         </div>
//       </div> 
//     </div>
//   )
// }





// const Section = ({ title, details }) => (
//   <div className="mb-4">
//     <h3 className="text-sm font-bold text-gray-800 mb-1 border-b pb-0.5">{title}</h3>
//     <div className="divide-y divide-gray-200">
//       {details.map((item, index) => (
//         <div
//           key={index}
//           className="grid grid-cols-2 items-center text-xs"
//         >
//           <div className="bg-gray-300 text-gray-900 px-2 py-1 font-medium border-b border-gray-200">
//             {item.label}
//           </div>
//           <div className="bg-white text-gray-600 px-2 py-1 border-b border-gray-200 text-right">
//             {item.value || '-'}
//           </div>
//         </div>
//       ))}
//     </div>
//   </div>
// );

// const Detail = ({ label, value }) => (
//   <div className="grid grid-cols-2 items-center text-xs">
//     <div className="bg-gray-200 text-gray-800 px-2 py-1 font-medium border-b border-gray-200">
//       {label}
//     </div>
//     <div className="bg-white text-gray-600 px-2 py-1 border-b border-gray-200 text-right">
//       {value}
//     </div>
//   </div>
// );

// export default IlsLandDataDetail












// =========>>>>> Below is working good without history



// import React, { useEffect, useState } from 'react';
// import IlsMenu from './IlsMenu'
// import { useLocation, useNavigate } from 'react-router-dom'
// // import { DeleteOfficeSpaceHistoryService, GetOfficeSpaceDetailService, GetOfficeSpaceHistoryService, UpdateOfficeSpaceHistoryService } from '../../../services/database/mainoptions/OfficeSpaceServices'
// import { DeleteOfficeSpaceHistoryService, GetOfficeSpaceDetailService, GetOfficeSpaceHistoryService, UpdateOfficeSpaceHistoryService } from '../../services/database/mainoptions/OfficeSpaceServices';
// import { DeleteILSLandDataService,GetILSLandDetailService, GetILSLandDataService } from '../../services/IlsLandDataServices'
// import toast from 'react-hot-toast'
// import GoBack from '../../components/back/GoBack'
// import { GrLocationPin } from "react-icons/gr";
// import { CgPlayTrackPrevR } from "react-icons/cg";
// import { AiOutlineClose, AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai'
// import { Modal,Drawer } from 'antd'
// import { useSelector } from 'react-redux'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
// import { TextAreaInput1 } from '../../components/input'
// import {FiChevronRight,FiChevronLeft} from 'react-icons/fi';
// import { IconButton, } from '@mui/material'


// function IlsLandDataDetail() {
//   const roles = useSelector(state=>state.Auth.roles)
//   const [openModal,setopenModal] = useState(null)  
//   const {state} = useLocation() 
//     const [data,setdata] = useState({})
//     const [page,setpage] = useState(1)
//     const [modal,setmodal] = useState(null)
//     const [historyData,sethistoryData] = useState({datas:[],pagination:{total:0,totalPages:0,limit:25}})
//     const [selectedhistoryData,setselectedhistoryData] = useState({})
//     const [selectedhistoryDataErr,setselectedhistoryDataErr] = useState({})
//     const [selectedImage,setselectedImage] = useState("")

//   // const [floorSelected,setfloorSelected] = useState(null)

//   // useEffect(()=>{
//   //     getofficespacehistoryfun()
//   // },[page])
//   const navigate = useNavigate()

//   useEffect(()=>{
//     getdetail()
//   },[state])

  
//   async function getdetail() {
//     const response = await GetILSLandDetailService(state)
//     if(response?.status == 200){
//         setselectedImage(response?.data?.datas[0]?.main_image)
//         setdata(response?.data?.datas[0])
//     }else{
//         navigate(-1)
//         toast.error("Data Not Found")
//     }
//   }

 

//   function openFile(v){
//     let url = `${v}`
//     window.open(url,'_blank')
//    }

//   //  async function getofficespacehistoryfun(){
//   //   const response = await GetOfficeSpaceHistoryService(page,state)
//   //   sethistoryData(response?.data?.data)
//   //  }

//   //  async function deletehistoryfunc() {
//   //    if(!selectedhistoryData?._id){
//   //       toast.error("Office Space History Data Not Selected ")
//   //    }else{
//   //       const response = await DeleteOfficeSpaceHistoryService(selectedhistoryData?._id)
//   //       if(response?.status == 200){
//   //           toast.success("Office Space History Data Deleted")
//   //           setmodal('')
//   //           getofficespacehistoryfun()
//   //           setpage(1)
//   //         }
//   //    }
//   //  }
       
//   //  async function update_office_space_history_func() {
//   //   if(!selectedhistoryData?.remarks){
//   //      setselectedhistoryDataErr({...selectedhistoryDataErr,remarks:"This Field is required*"})
//   //   }else{
//   //     let sendData = {...selectedhistoryData}
//   //     delete sendData.managed_office
//   //     delete sendData.updated_by

//   //     const response = await UpdateOfficeSpaceHistoryService(sendData?._id,sendData)
//   //     if(response?.status == 200){
//   //       toast.success("Office Space History Data Updated")
//   //       setmodal('')
//   //       getofficespacehistoryfun()
//   //       setpage(1)
//   //     }
//   //   }
//   //  }






//   /// old 33
// //   const {state} = useLocation()
// //   const navigate = useNavigate()
// //   const [data,setdata] = useState({})
// //   const [selectedImage,setselectedImage] = useState("")
  
// // console.log("%%%", state)

// //    useEffect(()=>{
// //       getdetail()
// //     },[state])
// //   async function getdetail() {
// //     const response = await GetILSLandDetailService(state)
// //     console.log("&&&&&",response)
// //     if(response?.status == 200){
// //         setselectedImage(response?.data?.datas[0]?.main_image)
// //         setdata(response?.data?.datas[0])
// //     }else{
// //         navigate(-1)
// //         toast.error("Data Not Found")
// //     }
// //   }

// //   console.log("state",state)



//   return (
// <div className="flex min-h-screen bg-gray-100">
//       {/* Sidebar */}
//       {/* <div className="w-[180px] bg-white shadow-md min-h-screen">
//         <IlsMenu />
//       </div> */}
//   <div className='min-w-[180px] w-[180px] max-w-[180px]'>
//     <IlsMenu /> 
//     </div>
//       {/* Main Content */}
//       <div className="flex-1 p-6 relative">
//         {/* Floating Edit Button */}
//        <div onClick={()=>{console.log("daaaata",state);navigate('/ils/land_data/edit',{state:state})}} className='flex items-center justify-center bg-slate-100 rounded pr-3 pl-2 cursor-pointer z-100 absolute right-2 top-2 p-1 border border-slate-400 '>
//               <AiOutlineEdit className='mr-2 text-[10px]' />
//               <h6 className='text-[11px]'>Edit</h6>
//           </div>
//         {/* Back Button */}
//         <div className="mb-3">
//             <GoBack />
//         </div>

//         {/* Main Card */}
//         <div className="card ml-4">
//           <div className="flex flex-col md:flex-row justify-between mb-6  pb-4">
//   <div className="flex items-start w-full md:w-auto">
//    <div  className='w-[100%] h-[150px] bg-slate-100 object-contain'>
//         {data?.main_image !== '' && <img alt="main_image" src={`${process.env.REACT_APP_AWS_IMAGE_URL}${data?.main_image}`} className='w-[100%] h-[150px] bg-slate-100 object-contain' />}
//         </div>  
//   <div>
//     <h2 className="text-2xl font-bold text-blue-500 mb-1">LOGOS - INDIQUBE</h2>
//     <p className="text-sm text-gray-500 whitespace-nowrap overflow-hidden text-ellipsis">
//   Zone: <span className="italic text-green-500">{data?.zone}</span>
// </p>

// <p className="text-sm text-gray-500 mt-1 whitespace-nowrap overflow-hidden text-ellipsis">
//   Area: <span className="italic text-green-500">{data?.location}</span>
// </p>

// <p className="text-sm text-gray-500 mt-1 whitespace-nowrap overflow-hidden text-ellipsis">
//   Landmark: <span className="italic text-green-500">{data?.landmark}</span>
// </p>

//   </div>
// </div>

//           </div>

//           {/* Property Info Grid */}
//           <div className="grid  grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">


//           <Section
//               title="More Information"
//               details={[
//                 { label: 'Land Area', value: `${data?.land_area}` },
//                 { label: 'Location', value: `${data?.location}` },
//                 { label: 'Land Status', value: `${data?.landstatus}` },
//                 { label: 'Frontage', value: `${data?.frontage}` },
//                 { label: 'Access Road Width', value:`${data?.access_road_width}` },
//                 { label: 'Landmark', value: `${data?.landmark}` },
//                 { label: 'Surroundings', value: `${data?.surroundings}` },
//                 { label: 'Conversion Type', value: `${data?.conversion_type}` },
//                 // { label: 'Coordinate', value: `${data?.coordinate}` },
//                 { label: 'Zone', value: data?.zone },
//               ]}
//             />

//             {/* <Section
//               title="Property Overview"
//               details={[
//                 { label: 'Type Of Transaction', value: `${data?.type_of_transaction}` },
//                 { label: 'Built To Suit Rent Price', value: `Rs. ${data?.built_to_suit_rent_price}` },
//                 { label: 'Sale price', value: `Rs. ${data?.sale_price}` },
//                 { label: 'Rent Price', value: `Rs. ${data?.rent_price}` },
//                 { label: 'JV/JD Ratio', value: `Rs. ${data?.jvjd_ratio}` },
//               ]}
//             /> */}

// <Section
//   title="Property Overview"
//   details={[
//     { label: 'Type Of Transaction', value: data?.type_of_transaction || '-' },
//     {
//       label: 'Built To Suit Rent Price',
//       value: data?.built_to_suit_rent_price ? `Rs. ${data.built_to_suit_rent_price}` : '-',
//     },
//     {
//       label: 'Sale price',
//       value: data?.sale_price ? `Rs. ${data.sale_price}` : '-',
//     },
//     {
//       label: 'Rent Price',
//       value: data?.rent_price ? `Rs. ${data.rent_price}` : '-',
//     },
//     {
//       label: 'JV/JD Ratio',
//       value: data?.jvjd_ratio ? `Rs. ${data.jvjd_ratio}` : '-',
//     },
//   ]}
// />


//             <Section
//               title="Contact Information"
//               details={[
//                 { label: 'Primary Contact', value: data?.primary_contact_name },
//                 { label: 'Primary Phone', value: data?.primary_contact_mobile },
//                 { label: 'Secondary Contact', value: data?.secondary_contact_name },
//                 { label: 'Secondary Phone', value: data?.secondary_contact_mobile },
//                 { label: 'POC Name', value: data?.point_of_contact_name },
//                 { label: 'POC Mobile', value: data?.point_of_contact_mobile },
//               ]}
//             />

//             <Section
//               title="Creator Information"
//               details={[
//                 { label: 'Ownership Details', value: data?.ownership_details },
//                 { label: 'Created At', value: new Date(data?.createdAt).toLocaleDateString() },
//               ]}
//             />

//             <div className="md:col-span-2 lg:col-span-1">
//             <h3 className="text-base font-bold text-gray-800 mb-2 border-b pb-1">Location Details</h3>
//               <div className="space-y-0.5 divide-y divide-gray-100">
// <Detail
//   label="Coordinate"
//   value={
//     data?.coordinate ? (
//       data.coordinate.startsWith('http') ? (

//         <a
//           href={data.coordinate}
//           target="_blank"
//           rel="noreferrer"
//           className="text-blue-500 hover:underline"
//         >
//           {data.coordinate}
//         </a>
//       ) : (
//         // Plain coordinate converted to Google Maps search link
//         <a
//           href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
//             data.coordinate
//           )}`}
//           target="_blank"
//           rel="noreferrer"
//           className="text-blue-500 hover:underline"
//           title="Open in Google Maps"
//         >
//           {data.coordinate}
//         </a>
//       )
//     ) : (
//       '-'
//     )
//   }
// />

// {data?.coordinate && !data.coordinate.includes('°') && (
//     <div className="pt-3">
//       <iframe
//         className="rounded-md"
//         src={`https://www.google.com/maps?q=${encodeURIComponent(
//           data.coordinate
//         )}&output=embed`}
//         width="100%"
//         height="200"
//         style={{ border: 0 }}
//         loading="lazy"
//         allowFullScreen
//         referrerPolicy="no-referrer-when-downgrade"
//         title="Map Preview"
//       />
//     </div>
//   )}
//               </div>

//             </div>
//           </div>
//         </div>
//       </div> 
//     </div>
//   )
// }





// const Section = ({ title, details }) => (
//   <div className="mb-4">
//     <h3 className="text-sm font-bold text-gray-800 mb-1 border-b pb-0.5">{title}</h3>
//     <div className="divide-y divide-gray-200">
//       {details.map((item, index) => (
//         <div
//           key={index}
//           className="grid grid-cols-2 items-center text-xs"
//         >
//           <div className="bg-gray-300 text-gray-900 px-2 py-1 font-medium border-b border-gray-200">
//             {item.label}
//           </div>
//           <div className="bg-white text-gray-600 px-2 py-1 border-b border-gray-200 text-right">
//             {item.value || '-'}
//           </div>
//         </div>
//       ))}
//     </div>
//   </div>
// );

// const Detail = ({ label, value }) => (
//   <div className="grid grid-cols-2 items-center text-xs">
//     <div className="bg-gray-200 text-gray-800 px-2 py-1 font-medium border-b border-gray-200">
//       {label}
//     </div>
//     <div className="bg-white text-gray-600 px-2 py-1 border-b border-gray-200 text-right">
//       {value}
//     </div>
//   </div>
// );

// export default IlsLandDataDetail