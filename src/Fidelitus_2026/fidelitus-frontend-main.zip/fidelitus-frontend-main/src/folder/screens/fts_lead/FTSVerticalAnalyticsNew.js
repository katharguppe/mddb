import React, { useState, useEffect } from 'react';
import FTSLeadMenu from './FTSLeadMenu';
import { GetVerticalDasboarddMontlyReviewReportService } from '../../services/ftsVerticalReportServices/FTSVerticalLeadReportServices';
import { GetDepartmentService } from '../../services/DepartmentServices';
import Priceconstants from '../../constants/imageConstants';
import { DatePicker } from 'antd';
import { BiFilterAlt } from 'react-icons/bi'
import { BsArrowRepeat } from 'react-icons/bs';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';


function FTSVerticalAnalytics() {

  const user = useSelector(state=>state.Auth)
  const [department, setdepartment] = useState([])

  const navigate = useNavigate()

  const [search, setsearch] = useState({ from_date: '', to_date: '', from_date1: '', to_date1: '', assigned_department: '', recieved_department: '' });

  const [mainData,setmainData] = useState({})

  const [page, setpage] = useState(1)

  const converted = [
    { label: 'Converted', value: 1 },
    { label: 'Rejected', value: 2 },
    { label: 'Pending', value: 3 },
    { label: 'Progress', value: 4 },
    { label: 'Lead Generated', value: 5 },
  ]

  useEffect(() => {
    getdepartment()
    getdata()
  }, [page])

  async function getdata() {
    const response = await GetVerticalDasboarddMontlyReviewReportService(search?.from_date1, search?.to_date1, user?.department_id[0]?.id)
    setmainData(response?.data?.data)
  }

  async function getdepartment() {
    const response = await GetDepartmentService()
    let d = response?.data?.datas
    let user_department = user?.department_id[0]?.department_name

    let arr = []
    
    
    let transaction = d?.find((f) => f?.department_name === "Transaction Team")
    let project = d?.find((f) => f?.department_name === "Project Team")
    let hr = d?.find((f) => f?.department_name === "HR Team")
    let fms = d?.find((f) => f?.department_name === "FMS Team")
    let fidelitus_gallery = d?.find((f) => f?.department_name === "Fidelitus Gallery")
    let shilpa_foundation = d?.find((f) => f?.department_name === "Shilpa Foundation")
    let corp_team = d?.find((f) => f?.department_name === "Corp Team")
    let fts_team = d?.find((f) => f?.department_name === "FTS Team")
    let backend_team = d?.find((f) => f?.department_name === "Backend Team")

    if (![null, undefined, '', 'null', 'undefined']?.includes(transaction) && transaction?.department_name !== user_department) {
      arr.push(transaction)
    }
    if (![null, undefined, '', 'null', 'undefined']?.includes(project) && project?.department_name !== user_department) {
      arr.push(project)
    }
    if (![null, undefined, '', 'null', 'undefined']?.includes(hr) && hr?.department_name !== user_department) {
      arr.push(hr)
    }
    if (![null, undefined, '', 'null', 'undefined']?.includes(fms) && fms?.department_name !== user_department) {
      arr.push(fms)
    }
    if (![null, undefined, '', 'null', 'undefined']?.includes(fidelitus_gallery) && fidelitus_gallery?.department_name !== user_department) {
      arr.push(fidelitus_gallery)
    }
    if (![null, undefined, '', 'null', 'undefined']?.includes(shilpa_foundation) && shilpa_foundation?.department_name !== user_department) {
      arr.push(shilpa_foundation)
    }

    if (![null, undefined, '', 'null', 'undefined']?.includes(corp_team) && corp_team?.department_name !== user_department) {
      arr.push(corp_team)
    }

    if (![null, undefined, '', 'null', 'undefined']?.includes(backend_team) && backend_team?.department_name !== user_department) {
      arr.push(backend_team)
    }

    if (![null, undefined, '', 'null', 'undefined']?.includes(fts_team) && fts_team?.department_name !== user_department) {
      arr.push(fts_team)
    }
    setdepartment(arr)
  }

  async function applyfilterfunction() {
    const response = await GetVerticalDasboarddMontlyReviewReportService(search?.from_date1, search?.to_date1, user?.department_id[0]?.id)
    setmainData(response?.data?.data)
  }

  async function resetfilterfunction() {
    setsearch({ from_date: '', to_date: '', from_date1: '', to_date1: '', assigned_department: '', recieved_department: '' })
    setpage(1)
    const response = await GetVerticalDasboarddMontlyReviewReportService('', '', user?.department_id[0]?.id)
    setmainData(response?.data?.data)

  }

  function getleadSharedCount(department){
    let findData =  mainData?.totalftsLeadShared?.find((f)=>f?._id?.department_name === department)
    if(findData !== undefined && findData !== null){
      return findData?.total
    }
    return 0
  }

  function getleadRecivedCount(department,stage){
    let findData =  mainData?.totalftsLeadReceieved?.find((f)=>f?._id?.department_name === department)
    
    console.log("department",department)
    console.log("findData",findData)
    
    if(findData !== undefined && findData !== null){
      if(stage == 'Converted'){
        return findData?.converted
      }
      if(stage == 'Rejected'){
        return findData?.rejected
      }
      if(stage == 'Pending'){
        return findData?.pending
      }
      if(stage == 'Progress'){
        return findData?.progress
      }
      if(stage == 'Recieved'){
        return findData?.total
      }
    }
    return 0
  }


  function openVerticalLead(v){
      navigate('/fts_leads/vertical_lead',{state:{...search,status:v}})
  }


  function openLeadShared(v){
    navigate('/fts_leads/shared_to_fts',{state:{...search,department:v.id,status:''}})
  }

  function openLeadRecieved(v,type){
    let findData = converted.find((f)=>f.label == type)
    navigate('/fts_leads/lead_received_from_fts',{state:{...search,department:v.id,status:findData?.value}})
  }


  return (
    <div className="flex bg-white">
      <div className="min-w-44">
        <FTSLeadMenu />
      </div>

      <div className="p-3 bg-white w-full h-full text-black">
        <div className="mb-3  border-b flex justify-between items-center p-2">
          <h2 className="text-sm font-extrabold text-gray-700">{user?.department_id[0]?.department_name} Analytics</h2>

          <div className='flex items-center'>
            <DatePicker size='small' style={{ fontSize: '11px' }} ampm={false} placeholder='From Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2' value={search?.from_date} onChange={(v, v1) => { console.log('v na', new Date(v).toLocaleDateString()); setsearch({ ...search, from_date: v, from_date1: v1 }) }} />
            <DatePicker size='small' style={{ fontSize: '11px' }} ampm={false} placeholder='To Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2' value={search?.to_date} onChange={(v, v1) => { console.log('v na', new Date(v).toLocaleDateString()); setsearch({ ...search, to_date: v, to_date1: v1 }) }} />

            <BiFilterAlt onClick={() => applyfilterfunction(1)} size={25} className='bg-slate-600 p-[5px] text-white cursor-pointer rounded ml-1' />
            <BsArrowRepeat onClick={() => resetfilterfunction(1)} size={25} className='bg-slate-200 p-[5px]  text-black cursor-pointer rounded ml-1' />
          </div>

        </div>

        <div className="overflow-x-auto">
          <div className="w-full border text-sm text-left">

            <div className="flex items-center text-slate-600 text-[11.5px] font-[700]">
              <h6 className="p-1 w-[15%] text-[11px] text-slate-600 bg-blue-50 uppercase">Vertical Info</h6>
              {department?.map((d) => (
                <h6
                  key={d?._id}
                  className="p-1 text-[10px] border-l text-slate-600 uppercase text-center"
                  style={{
                    minWidth: `${85 / department?.length}%`,
                    maxWidth: `${85 / department?.length}%`,
                  }}
                >
                  {d?.department_name}
                </h6>
                ))}
            </div>

            <div>

              <div className="border-t flex  items-center">
                <h6 className="p-1 text-[13px] text-gray-700 bg-blue-50 font-bold w-[15%]">Leads Shared</h6>
                {department?.map((d) => (
                  <h6
                     onClick={()=>openLeadShared(d)}
                    key={d?._id}
                    className="p-1 text-[12px] font-[800]  border-l cursor-pointer  text-center"
                    style={{
                      minWidth: `${85 / department?.length}%`,
                      maxWidth: `${85 / department?.length}%`,
                    }}
                  >
                    {getleadSharedCount(d?.department_name)}
                  </h6>
                ))}
              </div>

              <div className="border-t flex  items-center">
                <h6 className="p-1 text-[13px] text-gray-700 bg-blue-50 font-bold w-[15%]">Leads Recieved</h6>
                {department?.map((d) => (
                  <h6
                    key={d?._id}
                    onClick={()=>openLeadRecieved(d)}
                    className="p-1 text-[12px] cursor-pointer font-[800]  border-l  text-center"
                    style={{
                      minWidth: `${85 / department?.length}%`,
                      maxWidth: `${85 / department?.length}%`,
                    }}
                  >
                    {getleadRecivedCount(d?.department_name,'Recieved')}
                  </h6>
                ))}
              </div>

              <div className="border-t flex  items-center">
                <h6 className="p-1 text-[13px] text-gray-700 bg-blue-50 font-bold w-[15%]">Leads Pending</h6>
                {department?.map((d) => (
                  <h6
                    key={d?._id}
                    onClick={()=>openLeadRecieved(d,'Pending')}
                    className="p-1 text-[12px] cursor-pointer font-[800]  border-l  text-center"
                    style={{
                      minWidth: `${85 / department?.length}%`,
                      maxWidth: `${85 / department?.length}%`,
                    }}
                  >
                    {getleadRecivedCount(d?.department_name,'Pending')}
                  </h6>
                ))}
              </div>


              <div className="border-t flex  items-center">
                <h6 className="p-1 text-[13px] text-gray-700 bg-blue-50 font-bold w-[15%]">Leads Converted</h6>
                {department?.map((d) => (
                  <h6
                    key={d?._id}
                    onClick={()=>openLeadRecieved(d,'Converted')}
                    className="p-1 text-[12px] cursor-pointer font-[800]  border-l  text-center"
                    style={{
                      minWidth: `${85 / department?.length}%`,
                      maxWidth: `${85 / department?.length}%`,
                    }}
                  >
                    {getleadRecivedCount(d?.department_name,'Converted')}
                  </h6>
                ))}
              </div>

              <div className="border-t flex  items-center">
                <h6 className="p-1 text-[13px] text-gray-700 bg-blue-50 font-bold w-[15%]">Leads Rejected</h6>
                {department?.map((d) => (
                  <h6
                    key={d?._id}
                    onClick={()=>openLeadRecieved(d,'Rejected')}
                    className="p-1 text-[12px] cursor-pointer font-[800]  border-l  text-center"
                    style={{
                      minWidth: `${85 / department?.length}%`,
                      maxWidth: `${85 / department?.length}%`,
                    }}
                  >
                    {getleadRecivedCount(d?.department_name,'Rejected')}
                  </h6>
                ))}
              </div>



            </div>
          </div>
        </div>

     

        <div className="flex mt-4 justify-between items-start">
          <div className='w-[30%]'>

            <h6 className='font-[700] text-[13px] border-b pb-1 mb-1 text-gray-700'>Total Leads Generated</h6>
            <div className='flex border'>
              <div className='w-[50%]'>
                <h6 className="p-1 bg-blue-50 text-[13px] border-r text-slate-600 font-bold">Leads</h6>
                <h6 className="p-1 bg-blue-50 text-[13px] border-r border-t text-slate-600 font-bold">Progress</h6>
                <h6 className="p-1 bg-blue-50 text-[13px] border-r border-t text-slate-600 font-bold">Converted</h6>
                <h6 className="p-1 bg-blue-50 text-[13px] border-r border-t text-slate-600 font-bold">Rejected</h6>
                <h6 className="p-1 bg-blue-50 text-[13px] border-r border-t text-slate-600 font-bold">Hold</h6>
              </div>
              <div className='w-[50%] cursor-pointer' >
                <h6 onClick={()=>openVerticalLead('')} className="p-1 text-[13px] text-blue-600 font-bold">{(mainData?.totalftsvertical_data?.length > 0 ? mainData?.totalftsvertical_data[0]?.count : 0)}</h6>
                <h6 onClick={()=>openVerticalLead('Progress')} className="p-1 text-[13px] border-t font-bold">{(mainData?.totalftsvertical_data?.length > 0 ? mainData?.totalftsvertical_data[0]?.progress  : 0)}</h6>
                <h6 onClick={()=>openVerticalLead('Converted')} className="p-1 text-[13px] border-t font-bold">{(mainData?.totalftsvertical_data?.length > 0 ? mainData?.totalftsvertical_data[0]?.converted  : 0)}</h6>
                <h6 onClick={()=>openVerticalLead('Rejected')} className="p-1 text-[13px] border-t font-bold">{(mainData?.totalftsvertical_data?.length > 0 ? mainData?.totalftsvertical_data[0]?.rejected  : 0)}</h6>
                <h6 onClick={()=>openVerticalLead('Hold')} className="p-1 text-[13px] border-t font-bold">{(mainData?.totalftsvertical_data?.length > 0 ? mainData?.totalftsvertical_data[0]?.hold  : 0)}</h6>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

export default FTSVerticalAnalytics;

