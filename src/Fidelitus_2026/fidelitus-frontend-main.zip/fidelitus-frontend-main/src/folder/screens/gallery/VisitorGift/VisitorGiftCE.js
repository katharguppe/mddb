import React, { useEffect, useState } from 'react'
import GalleryAppBar from '../GalleryAppBar'
import GoBack from '../../../components/back/GoBack'
import { TextInput, TextAreaInput1 } from '../../../components/input'
import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../../components/button'
import Uploader from '../../../components/Uploader'
import { useLocation, useNavigate } from 'react-router-dom'
import { toast } from 'react-hot-toast'
import { DatePicker } from 'antd'
import dayjs from 'dayjs'

import {
  CreateGalleryVisitorGiftService,
  UpdateGalleryVisitorGiftService
} from '../../../services/Gallery/GalleryVisitorGiftServices'

function VisitorGiftCE() {

  const { pathname, state } = useLocation()
  const path = pathname.split('/').pop()
  const navigate = useNavigate()

  const [data, setdata] = useState({
    name: '',
    mobile: '',
    gift_status: 'Not Given',
    gift_name: '',
    gift_given_date: null,
    remarks: '',
    file: ''
  })

  /* ======================
     PREFILL EDIT DATA
  ====================== */
  useEffect(() => {
    if (path === 'edit' && state) {
      setdata({
        name: state?.name || '',
        mobile: state?.mobile || '',
        gift_status: state?.gift_status || 'Not Given',
        gift_name: state?.gift_name || '',
        gift_given_date: state?.gift_given_date
          ? dayjs(state.gift_given_date)
          : null,
        remarks: state?.remarks || '',
        file: state?.file || ''
      })
    }
  }, [])

  /* ======================
     SUBMIT HANDLER
  ====================== */
  async function submit() {
    if (!data.name) {
      toast.error("Name is required")
      return
    }
    if (!data.mobile) {
      toast.error("Mobile is required")
      return
    }
    if (data.mobile.length !== 10) {
      toast.error("Enter valid 10 digit mobile number")
      return
    }

    const fd = new FormData()
    fd.append('name', data.name)
    fd.append('mobile', data.mobile)
    fd.append('gift_status', data.gift_status)
    fd.append('gift_name', data.gift_name)
    fd.append('remarks', data.remarks)

    // Gift Given Date
    if (data.gift_status === 'Given' && data.gift_given_date) {
      fd.append(
        'gift_given_date',
        data.gift_given_date.format('YYYY-MM-DD')
      )
    } else {
      fd.append('gift_given_date', '')
    }

    // File
    if (data.file && data.file?.name) {
      fd.append('file', data.file)
    }

    if (path === 'create') {
      const res = await CreateGalleryVisitorGiftService(fd)
      if (res?.status === 201) {
        toast.success("Gift added successfully")
        navigate(-1)
      }
    }

    if (path === 'edit') {
      const res = await UpdateGalleryVisitorGiftService(state?._id, fd)
      if (res?.status === 200 || res?.status === 201) {
        toast.success("Gift updated successfully")
        navigate(-1)
      }
    }
  }

  return (
    <div className='h-screen max-h-screen overflow-hidden'>
      <div className='flex'>
        <GalleryAppBar />

        <div className='w-full p-5 overflow-y-scroll'>
          <GoBack />

          <h6 className='font-[700] mb-1'>Create / Edit Visitor Gift</h6>
          <h6 className='text-[11px] p-2 mb-3 bg-slate-100'>
            Use this form to add or update visitor gift details
          </h6>

          {/* UPLOADER */}
          <Uploader
            image={data.file}
            setimagefunc={(e) => setdata({ ...data, file: e })}
            removeimageuploadfunc={() => setdata({ ...data, file: '' })}
          />

          {/* NAME */}
          <TextInput
            label="Name"
            name="name"
            value={data.name}
            handlechange={(e) =>
              setdata({ ...data, name: e.target.value })
            }
          />

          {/* MOBILE */}
          <TextInput
            label="Mobile"
            name="mobile"
            type="number"
            value={data.mobile}
            handlechange={(e) =>
              setdata({ ...data, mobile: e.target.value })
            }
          />

          {/* GIFT STATUS */}
          <div className='mt-2'>
            <label className='text-[12px] font-[600]'>Gift Status</label>
            <select
              className='w-full p-1 mt-1 border'
              value={data.gift_status}
              onChange={(e) => {
                const value = e.target.value
                setdata({
                  ...data,
                  gift_status: value,
                  gift_given_date: value === 'Given' ? dayjs() : null
                })
              }}
            >
              <option value="Given">Given</option>
              <option value="Not Given">Not Given</option>
            </select>
          </div>

          {/* GIFT GIVEN DATE */}
          {data.gift_status === 'Given' && (
            <div className='mt-3'>
              <label className='text-[12px] font-[600]'>
                Gift Given Date
              </label>
              <DatePicker
                className='w-full mt-1'
                format="DD-MM-YYYY"
                value={data.gift_given_date}
                onChange={(date) =>
                  setdata({ ...data, gift_given_date: date })
                }
              />
            </div>
          )}

          {/* GIFT NAME */}
          <TextInput
            label="Gift Name"
            value={data.gift_name}
            handlechange={(e) =>
              setdata({ ...data, gift_name: e.target.value })
            }
          />

          {/* REMARKS */}
          <TextAreaInput1
            label="Remarks"
            value={data.remarks}
            handlechange={(e) =>
              setdata({ ...data, remarks: e.target.value })
            }
          />

          {/* ACTION BUTTONS */}
          <div className='flex gap-2 mt-4'>
            <ButtonOutlinedAutoWidth
              btnName="Back"
              onClick={() => navigate(-1)}
            />
            <ButtonFilledAutoWidth
              btnName="Save"
              onClick={submit}
            />
          </div>

        </div>
      </div>
    </div>
  )
}

export default VisitorGiftCE









//=========>> Old one



// import React, { useEffect, useState } from 'react'
// import GalleryAppBar from '../GalleryAppBar'
// import GoBack from '../../../components/back/GoBack'
// import { TextInput, TextAreaInput1 } from '../../../components/input'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../../components/button'
// import Uploader from '../../../components/Uploader'
// import { useLocation, useNavigate } from 'react-router-dom'
// import { toast } from 'react-hot-toast'
// import { DatePicker } from 'antd'
// import moment from 'moment'


// import {
//   CreateGalleryVisitorGiftService,
//   UpdateGalleryVisitorGiftService
// } from '../../../services/Gallery/GalleryVisitorGiftServices'

// function VisitorGiftCE() {

//   const { pathname, state } = useLocation()
//   const path = pathname.split('/').pop()
//   const navigate = useNavigate()

//   const [data, setdata] = useState({
//     name: '',
//     mobile: '',
//     gift_status: 'Not Given',
//     gift_name: '',
//     gift_given_date: null,
//     remarks: '',
//     file: ''
//   })

//   /* ======================
//      PREFILL EDIT DATA
//   ====================== */
//   useEffect(() => {
//     if (path === 'edit' && state) {
//       setdata({
//         name: state?.name || '',
//         mobile: state?.mobile || '',
//         gift_status: state?.gift_status || 'Not Given',
//         gift_name: state?.gift_name || '',
//         gift_given_date: state?.gift_given_date
//           ? moment(state.gift_given_date)
//           : null,
//         remarks: state?.remarks || '',
//         file: state?.file || ''
//       })
//     }
//   }, [])

//   /* ======================
//      SUBMIT HANDLER
//   ====================== */
//   async function submit() {
//     if (!data.name) {
//       toast.error("Name is required")
//       return
//     }
//     if (!data.mobile) {
//       toast.error("Mobile is required")
//       return
//     }
//     if (data.mobile.length !== 10) {
//       toast.error("Enter valid 10 digit mobile number")
//       return
//     }

//     const fd = new FormData()
//     fd.append('name', data.name)
//     fd.append('mobile', data.mobile)
//     fd.append('gift_status', data.gift_status)
//     fd.append('gift_name', data.gift_name)
//     fd.append('remarks', data.remarks)

//     // Gift Given Date
//     if (data.gift_status === 'Given' && data.gift_given_date) {
//       fd.append(
//         'gift_given_date',
//         data.gift_given_date.format('YYYY-MM-DD')
//       )
//     } else {
//       fd.append('gift_given_date', '')
//     }

//     // File
//     if (data.file && data.file?.name) {
//       fd.append('file', data.file)
//     }

//     if (path === 'create') {
//       const res = await CreateGalleryVisitorGiftService(fd)
//       if (res?.status === 201) {
//         toast.success("Gift added successfully")
//         navigate(-1)
//       }
//     }

//     if (path === 'edit') {
//       const res = await UpdateGalleryVisitorGiftService(state?._id, fd)
//       if (res?.status === 200 || res?.status === 201) {
//         toast.success("Gift updated successfully")
//         navigate(-1)
//       }
//     }
//   }

//   return (
//     <div className='h-screen max-h-screen overflow-hidden'>
//       <div className='flex'>
//         <GalleryAppBar />

//         <div className='w-full p-5 overflow-y-scroll'>
//           <GoBack />

//           <h6 className='font-[700] mb-1'>Create / Edit Visitor Gift</h6>
//           <h6 className='text-[11px] p-2 mb-3 bg-slate-100'>
//             Use this form to add or update visitor gift details
//           </h6>

//           {/* UPLOADER */}
//           <Uploader
//             image={data.file}
//             setimagefunc={(e) => setdata({ ...data, file: e })}
//             removeimageuploadfunc={() => setdata({ ...data, file: '' })}
//           />

//           {/* NAME */}
//           <TextInput
//             label="Name"
//             name="name"
//             value={data.name}
//             handlechange={(e) =>
//               setdata({ ...data, name: e.target.value })
//             }
//           />

//           {/* MOBILE */}
//           <TextInput
//             label="Mobile"
//             name="mobile"
//             type="number"
//             value={data.mobile}
//             handlechange={(e) =>
//               setdata({ ...data, mobile: e.target.value })
//             }
//           />

//           {/* GIFT STATUS */}
//           <div className='mt-2'>
//             <label className='text-[12px] font-[600]'>Gift Status</label>
//             <select
//               className='w-full p-1 mt-1 border'
//               value={data.gift_status}
//               onChange={(e) => {
//                 const value = e.target.value
//                 setdata({
//                   ...data,
//                   gift_status: value,
//                   gift_given_date: value === 'Given' ? moment() : null
//                 })
//               }}
//             >
//               <option value="Given">Given</option>
//               <option value="Not Given">Not Given</option>
//             </select>
//           </div>

//           {/* GIFT GIVEN DATE */}
//           {data.gift_status === 'Given' && (
//             <div className='mt-3'>
//               <label className='text-[12px] font-[600]'>
//                 Gift Given Date
//               </label>
//               <DatePicker
//                 className='w-full mt-1'
//                 format="DD-MM-YYYY"
//                 value={data.gift_given_date}
//                 onChange={(date) =>
//                   setdata({ ...data, gift_given_date: date })
//                 }
//               />
//             </div>
//           )}

//           {/* GIFT NAME */}
//           <TextInput
//             label="Gift Name"
//             value={data.gift_name}
//             handlechange={(e) =>
//               setdata({ ...data, gift_name: e.target.value })
//             }
//           />

//           {/* REMARKS */}
//           <TextAreaInput1
//             label="Remarks"
//             value={data.remarks}
//             handlechange={(e) =>
//               setdata({ ...data, remarks: e.target.value })
//             }
//           />

//           {/* ACTION BUTTONS */}
//           <div className='flex gap-2 mt-4'>
//             <ButtonOutlinedAutoWidth
//               btnName="Back"
//               onClick={() => navigate(-1)}
//             />
//             <ButtonFilledAutoWidth
//               btnName="Save"
//               onClick={submit}
//             />
//           </div>

//         </div>
//       </div>
//     </div>
//   )
// }

// export default VisitorGiftCE








//===========>> Old one

// import React, { useEffect, useState } from 'react'
// import GalleryAppBar from '../GalleryAppBar'
// import GoBack from '../../../components/back/GoBack'
// import { TextInput, TextAreaInput1 } from '../../../components/input'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../../components/button'
// import Uploader from '../../../components/Uploader'
// import { useLocation, useNavigate } from 'react-router-dom'
// import { toast } from 'react-hot-toast'

// import {
//   CreateGalleryVisitorGiftService,
//   UpdateGalleryVisitorGiftService
// } from '../../../services/Gallery/GalleryVisitorGiftServices'

// function VisitorGiftCE() {

//   const { pathname, state } = useLocation()
//   const path = pathname.split('/').pop()
//   const navigate = useNavigate()

//   const [data, setdata] = useState({
//     name: '',
//     mobile: '',
//     gift_status: 'Not Given',
//     gift_name: '',
//     remarks: '',
//     file: ''
//   })

//   useEffect(() => {
//     if (path === 'edit') {
//       setdata({ ...state })
//     }
//   }, [])

//   async function submit() {
//     if (!data.name || !data.mobile) {
//       toast.error("Name & Mobile required")
//       return
//     }

//     const fd = new FormData()
//     Object.keys(data).forEach(k => {
//       if (k === 'file' && data.file?.name) fd.append('file', data.file)
//       else fd.append(k, data[k])
//     })

//     if (path === 'create') {
//       const res = await CreateGalleryVisitorGiftService(fd)
//       if (res.status === 201) {
//         toast.success("Gift added")
//         navigate(-1)
//       }
//     } else {
//       const res = await UpdateGalleryVisitorGiftService(state._id, fd)
//       if (res.status === 200 || res.status === 201) {
//         toast.success("Gift updated")
//         navigate(-1)
//       }
//     }
//   }

//   return (
//     <div className='h-screen'>
//       <div className='flex'>
//         <GalleryAppBar />
//         <div className='w-full p-5'>
//           <GoBack />

//           <Uploader image={data.file} setimagefunc={e => setdata({ ...data, file: e })} />

//           <TextInput label="Name" name="name" value={data.name} handlechange={e => setdata({ ...data, name: e.target.value })} />
//           <TextInput label="Mobile" name="mobile" value={data.mobile} handlechange={e => setdata({ ...data, mobile: e.target.value })} />

//           <select
//             className='w-full p-1 my-2 border'
//             value={data.gift_status}
//             onChange={e => setdata({ ...data, gift_status: e.target.value })}
//           >
//             <option value="Given">Given</option>
//             <option value="Not Given">Not Given</option>
//           </select>

//           <TextInput label="Gift Name" value={data.gift_name} handlechange={e => setdata({ ...data, gift_name: e.target.value })} />
//           <TextAreaInput1 label="Remarks" value={data.remarks} handlechange={e => setdata({ ...data, remarks: e.target.value })} />

//           <div className='flex gap-2'>
//             <ButtonOutlinedAutoWidth btnName="Back" onClick={() => navigate(-1)} />
//             <ButtonFilledAutoWidth btnName="Save" onClick={submit} />
//           </div>
//         </div>
//       </div>
//     </div>
//   )
// }

// export default VisitorGiftCE
