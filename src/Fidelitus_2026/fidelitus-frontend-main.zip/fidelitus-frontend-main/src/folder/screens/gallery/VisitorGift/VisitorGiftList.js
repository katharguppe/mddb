import React, { useEffect, useState } from 'react'
import GalleryAppBar from '../GalleryAppBar'
import { ButtonOutlinedAutoWidth, ButtonFilledAutoWidth } from '../../../components/button'
import { useNavigate } from 'react-router-dom'
import { AiOutlineEdit, AiOutlineDelete, AiOutlineFileExcel } from 'react-icons/ai'
import { Modal } from 'antd'
import dayjs from 'dayjs'
import axios from 'axios'
import fileDownload from "js-file-download"
import { toast } from 'react-hot-toast'
import { IoClose } from 'react-icons/io5'

import { get } from '../../../helpers/apihelpers'
import {
  GetGalleryVisitorGiftListService,
  DeleteGalleryVisitorGiftService,
  DownloadGalleryVisitorGiftExcelService
} from '../../../services/Gallery/GalleryVisitorGiftServices'

function VisitorGiftList() {

  const [datas, setdatas] = useState({})
  const [page, setpage] = useState(1)
  const [modal, setmodal] = useState(false)
  const [selected, setselected] = useState({})
  const [search, setsearch] = useState({
    text: '',
    gift_status: '',
    activate: false
  })

  const navigate = useNavigate()

  /* ======================
     LOAD DATA
  ====================== */
  useEffect(() => {
    loadData(page)
  }, [page])

  async function loadData(page) {
    if (!search.activate) {
      const res = await GetGalleryVisitorGiftListService(page)
      setdatas(res?.data)
      return
    }

    let query = `api/gallery_visitor_gift/filter?page=${page}`

    if (search.text) query += `&search_text=${encodeURIComponent(search.text)}`
    if (search.gift_status) query += `&gift_status=${encodeURIComponent(search.gift_status)}`

    const res = await get(query)
    setdatas(res?.data)
  }

  /* ======================
     APPLY FILTER
  ====================== */
  async function applyFilter() {
    setsearch({ ...search, activate: true })
    setpage(1)

    let query = `api/gallery_visitor_gift/filter?page=1`

    if (search.text) query += `&search_text=${encodeURIComponent(search.text)}`
    if (search.gift_status) query += `&gift_status=${encodeURIComponent(search.gift_status)}`

    const res = await get(query)
    setdatas(res?.data)
  }

  /* ======================
     DELETE
  ====================== */
  async function deleteData() {
    const res = await DeleteGalleryVisitorGiftService(selected?._id)
    if (res?.status === 200) {
      toast.success("Deleted successfully")
      setmodal(false)
      loadData(page)
    }
  }

  /* ======================
     EXCEL DOWNLOAD
  ====================== */
  async function downloadExcel() {
    const res = await DownloadGalleryVisitorGiftExcelService()
    const path = res.data.path

    axios.get(`${process.env.REACT_APP_AWS_IMAGE_URL}${path}`, {
      responseType: 'blob'
    }).then(res => {
      fileDownload(res.data, 'visitor_gift_list.xlsx')
      toast.success("Excel downloaded")
    })
  }

  return (
    <div className="h-screen bg-slate-50">
      <div className="flex h-full">
        <GalleryAppBar />

        <div className="w-full p-5">

          {/* HEADER */}
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-[18px] font-[700] text-slate-800">
                Visitor Gift List
              </h2>
              <p className="text-[12px] text-slate-500">
                Total Records: {datas?.pagination?.total || 0}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <select
                className="border rounded-md text-[12px] px-2 py-1 bg-white"
                value={search.gift_status}
                onChange={e => setsearch({ ...search, gift_status: e.target.value })}
              >
                <option value="">All Status</option>
                <option value="Given">Given</option>
                <option value="Not Given">Not Given</option>
              </select>

              <input
                className="border rounded-md text-[12px] px-2 py-1"
                placeholder="Search name / mobile"
                value={search.text}
                onChange={e => setsearch({ ...search, text: e.target.value })}
              />

              <ButtonOutlinedAutoWidth btnName="Filter" onClick={applyFilter} />
              <ButtonOutlinedAutoWidth btnName="Add Gift" onClick={() => navigate('create')} />

              <AiOutlineFileExcel
                size={22}
                className="text-green-600 cursor-pointer hover:scale-110"
                onClick={downloadExcel}
              />
            </div>
          </div>

          {/* TABLE (SCROLLABLE BODY ONLY) */}
          <div className="bg-white border rounded-lg shadow">
            {/* TABLE HEADER */}
            <div className="grid grid-cols-12 bg-slate-100 text-[12px] font-[600] text-slate-600 px-3 py-2 sticky top-0 z-10">
              <div className="col-span-1">#</div>
              <div className="col-span-2">Gift</div>
              <div className="col-span-2">Name</div>
              <div className="col-span-2">Mobile</div>
              <div className="col-span-2">Status</div>
              <div className="col-span-2">Gift Date</div>
              <div className="col-span-1 text-center">Action</div>
            </div>

            {/* TABLE BODY */}
            <div className="max-h-[65vh] overflow-y-auto">
              {datas?.datas?.length === 0 && (
                <div className="py-16 text-center text-slate-500 text-[13px]">
                  No visitor gift records found
                </div>
              )}

              {datas?.datas?.map((d, i) => (
                <div
                  key={d._id}
                  className="grid grid-cols-12 px-3 py-2 text-[12.5px] border-t hover:bg-slate-50 items-center"
                >
                  <div className="col-span-1 font-[600]">{i + 1}</div>

                  <div className="col-span-2">
                    {d?.file ? (
                      <img
                        src={`${process.env.REACT_APP_BACKEND_IMAGE_URL}${d.file}`}
                        alt="Gift"
                        className="object-cover w-10 h-10 border rounded-md cursor-pointer hover:scale-105"
                        onClick={() =>
                          window.open(
                            `${process.env.REACT_APP_BACKEND_IMAGE_URL}${d.file}`,
                            '_blank'
                          )
                        }
                      />
                    ) : (
                      <div className="w-10 h-10 flex items-center justify-center bg-slate-200 rounded-md text-[11px] font-[700]">
                        NA
                      </div>
                    )}
                  </div>

                  <div className="col-span-2 truncate">{d.name}</div>
                  <div className="col-span-2">{d.mobile}</div>

                  <div className="col-span-2">
                    <span
                      className={`px-2 py-[2px] rounded-full text-[11px] font-[600]
                        ${d.gift_status === 'Given'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-orange-100 text-orange-700'}
                      `}
                    >
                      {d.gift_status}
                    </span>
                  </div>

                  <div className="col-span-2">
                    {d.gift_given_date
                      ? dayjs(d.gift_given_date).format('DD MMM YYYY')
                      : '-'}
                  </div>

                  <div className="flex justify-center col-span-1 gap-2">
                    <AiOutlineEdit
                      className="text-blue-600 cursor-pointer hover:scale-110"
                      onClick={() => navigate('edit', { state: d })}
                    />
                    <AiOutlineDelete
                      className="text-red-600 cursor-pointer hover:scale-110"
                      onClick={() => {
                        setselected(d)
                        setmodal(true)
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* DELETE MODAL */}
      <Modal open={modal} footer={false} closable={false} width={320}>
        <div className="relative">
          <IoClose
            className="absolute top-0 right-0 cursor-pointer"
            onClick={() => setmodal(false)}
          />
          <h6 className="mb-2 font-[700]">Delete Gift Record</h6>
          <p className="mb-4 text-[12px] text-slate-600">
            Are you sure you want to delete gift for <b>{selected?.name}</b>?
          </p>

          <div className="flex justify-end gap-2">
            <ButtonOutlinedAutoWidth btnName="Cancel" onClick={() => setmodal(false)} />
            <ButtonFilledAutoWidth btnName="Delete" onClick={deleteData} />
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default VisitorGiftList








//=========>> pagination implimenting 



// import React, { useEffect, useState } from 'react'
// import GalleryAppBar from '../GalleryAppBar'
// import { ButtonOutlinedAutoWidth, ButtonFilledAutoWidth } from '../../../components/button'
// import { useNavigate } from 'react-router-dom'
// import { AiOutlineEdit, AiOutlineDelete, AiOutlineFileExcel } from 'react-icons/ai'
// import { Modal } from 'antd'
// import dayjs from 'dayjs'
// import axios from 'axios'
// import fileDownload from "js-file-download"
// import { toast } from 'react-hot-toast'
// import { IoClose } from 'react-icons/io5'

// import { get } from '../../../helpers/apihelpers'
// import {
//   GetGalleryVisitorGiftListService,
//   DeleteGalleryVisitorGiftService,
//   DownloadGalleryVisitorGiftExcelService
// } from '../../../services/Gallery/GalleryVisitorGiftServices'

// function VisitorGiftList() {

//   const [datas, setdatas] = useState({})
//   const [page, setpage] = useState(1)
//   const [modal, setmodal] = useState(false)
//   const [selected, setselected] = useState({})
//   const [search, setsearch] = useState({
//     text: '',
//     gift_status: '',
//     activate: false
//   })

//   const navigate = useNavigate()

//   /* ======================
//      LOAD DATA
//   ====================== */
//   useEffect(() => {
//     loadData(page)
//   }, [page])

//   async function loadData(page) {
//     // Normal list (no filter)
//     if (!search.activate) {
//       const res = await GetGalleryVisitorGiftListService(page)
//       setdatas(res?.data)
//       return
//     }

//     // FILTERED LIST (MANUAL QUERY – NO DATE PARAMS)
//     let query = `api/gallery_visitor_gift/filter?page=${page}`

//     if (search.text) {
//       query += `&search_text=${encodeURIComponent(search.text)}`
//     }

//     if (search.gift_status) {
//       query += `&gift_status=${encodeURIComponent(search.gift_status)}`
//     }

//     const res = await get(query)
//     setdatas(res?.data)
//   }

//   /* ======================
//      APPLY FILTER
//   ====================== */
//   async function applyFilter() {
//     setsearch({ ...search, activate: true })
//     setpage(1)

//     let query = `api/gallery_visitor_gift/filter?page=1`

//     if (search.text) {
//       query += `&search_text=${encodeURIComponent(search.text)}`
//     }

//     if (search.gift_status) {
//       query += `&gift_status=${encodeURIComponent(search.gift_status)}`
//     }

//     const res = await get(query)
//     setdatas(res?.data)
//   }

//   /* ======================
//      DELETE
//   ====================== */
//   async function deleteData() {
//     const res = await DeleteGalleryVisitorGiftService(selected?._id)
//     if (res?.status === 200) {
//       toast.success("Deleted successfully")
//       setmodal(false)
//       loadData(page)
//     }
//   }

//   /* ======================
//      EXCEL DOWNLOAD
//   ====================== */
//   async function downloadExcel() {
//     const res = await DownloadGalleryVisitorGiftExcelService()
//     const path = res.data.path

//     axios.get(`${process.env.REACT_APP_AWS_IMAGE_URL}${path}`, {
//       responseType: 'blob'
//     }).then(res => {
//       fileDownload(res.data, 'visitor_gift_list.xlsx')
//       toast.success("Excel downloaded")
//     })
//   }

//   return (
//     <div className="h-screen overflow-hidden bg-slate-50">
//       <div className="flex">
//         <GalleryAppBar />

//         <div className="w-full p-5 overflow-y-auto">

//           {/* HEADER */}
//           <div className="flex items-center justify-between mb-4">
//             <div>
//               <h2 className="text-[18px] font-[700] text-slate-800">
//                 Visitor Gift List
//               </h2>
//               <p className="text-[12px] text-slate-500">
//                 Total Records: {datas?.pagination?.total || 0}
//               </p>
//             </div>

//             <div className="flex items-center gap-2">
//               <select
//                 className="border rounded-md text-[12px] px-2 py-1 bg-white"
//                 value={search.gift_status}
//                 onChange={e => setsearch({ ...search, gift_status: e.target.value })}
//               >
//                 <option value="">All Status</option>
//                 <option value="Given">Given</option>
//                 <option value="Not Given">Not Given</option>
//               </select>

//               <input
//                 className="border rounded-md text-[12px] px-2 py-1"
//                 placeholder="Search name / mobile"
//                 value={search.text}
//                 onChange={e => setsearch({ ...search, text: e.target.value })}
//               />

//               <ButtonOutlinedAutoWidth btnName="Filter" onClick={applyFilter} />
//               <ButtonOutlinedAutoWidth btnName="Add Gift" onClick={() => navigate('create')} />

//               <AiOutlineFileExcel
//                 size={22}
//                 className="text-green-600 transition cursor-pointer hover:scale-110"
//                 onClick={downloadExcel}
//               />
//             </div>
//           </div>

//           {/* TABLE */}
//           <div className="overflow-hidden bg-white border rounded-lg shadow">
//             <div className="grid grid-cols-12 bg-slate-100 text-[12px] font-[600] text-slate-600 px-3 py-2">
//               <div className="col-span-1">#</div>
//               <div className="col-span-2">Gift</div>
//               <div className="col-span-2">Name</div>
//               <div className="col-span-2">Mobile</div>
//               <div className="col-span-2">Status</div>
//               <div className="col-span-2">Gift Date</div>
//               <div className="col-span-1 text-center">Action</div>
//             </div>

//             {datas?.datas?.length === 0 && (
//               <div className="py-16 text-center text-slate-500 text-[13px]">
//                 No visitor gift records found
//               </div>
//             )}

//             {datas?.datas?.map((d, i) => (
//               <div
//                 key={d._id}
//                 className="grid grid-cols-12 px-3 py-2 text-[12.5px] border-t hover:bg-slate-50 transition items-center"
//               >
//                 <div className="col-span-1 font-[600]">{i + 1}</div>

//                 {/* GIFT IMAGE */}
//                 <div className="col-span-2">
//                   {d?.file ? (
//                     <img
//                       src={`${process.env.REACT_APP_BACKEND_IMAGE_URL}${d.file}`}
//                       alt="Gift"
//                       className="object-cover w-10 h-10 transition border rounded-md cursor-pointer hover:scale-105"
//                       onClick={() =>
//                         window.open(
//                           `${process.env.REACT_APP_BACKEND_IMAGE_URL}${d.file}`,
//                           '_blank'
//                         )
//                       }
//                     />
//                   ) : (
//                     <div className="w-10 h-10 flex items-center justify-center bg-slate-200 rounded-md text-[11px] font-[700] uppercase">
//                       {d?.gift_name?.slice(0, 2) || 'NA'}
//                     </div>
//                   )}
//                 </div>

//                 <div className="col-span-2 truncate">{d.name}</div>
//                 <div className="col-span-2">{d.mobile}</div>

//                 <div className="col-span-2">
//                   <span
//                     className={`px-2 py-[2px] rounded-full text-[11px] font-[600]
//                       ${d.gift_status === 'Given'
//                         ? 'bg-green-100 text-green-700'
//                         : 'bg-orange-100 text-orange-700'
//                       }`}
//                   >
//                     {d.gift_status}
//                   </span>
//                 </div>

//                 <div className="col-span-2">
//                   {d.gift_given_date
//                     ? dayjs(d.gift_given_date).format('DD MMM YYYY')
//                     : '-'}
//                 </div>

//                 <div className="flex justify-center col-span-1 gap-2">
//                   <AiOutlineEdit
//                     className="text-blue-600 cursor-pointer hover:scale-110"
//                     onClick={() => navigate('edit', { state: d })}
//                   />
//                   <AiOutlineDelete
//                     className="text-red-600 cursor-pointer hover:scale-110"
//                     onClick={() => {
//                       setselected(d)
//                       setmodal(true)
//                     }}
//                   />
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>

//       {/* DELETE MODAL */}
//       <Modal open={modal} footer={false} closable={false} width={320}>
//         <div className="relative">
//           <IoClose
//             className="absolute top-0 right-0 cursor-pointer"
//             onClick={() => setmodal(false)}
//           />
//           <h6 className="mb-2 font-[700]">Delete Gift Record</h6>
//           <p className="mb-4 text-[12px] text-slate-600">
//             Are you sure you want to delete gift for <b>{selected?.name}</b>?
//           </p>

//           <div className="flex justify-end gap-2">
//             <ButtonOutlinedAutoWidth btnName="Cancel" onClick={() => setmodal(false)} />
//             <ButtonFilledAutoWidth btnName="Delete" onClick={deleteData} />
//           </div>
//         </div>
//       </Modal>
//     </div>
//   )
// }

// export default VisitorGiftList








//===========+>> Old one  19th jan


// import React, { useEffect, useState } from 'react'
// import GalleryAppBar from '../GalleryAppBar'
// import { ButtonOutlinedAutoWidth, ButtonFilledAutoWidth } from '../../../components/button'
// import { useNavigate } from 'react-router-dom'
// import { AiOutlineEdit, AiOutlineDelete, AiOutlineFileExcel } from 'react-icons/ai'
// import { Modal } from 'antd'
// import dayjs from 'dayjs'
// import axios from 'axios'
// import fileDownload from "js-file-download"
// import { toast } from 'react-hot-toast'
// import { IoClose } from 'react-icons/io5'

// import {
//   GetGalleryVisitorGiftListService,
//   SearchGalleryVisitorGiftService,
//   DeleteGalleryVisitorGiftService,
//   DownloadGalleryVisitorGiftExcelService
// } from '../../../services/Gallery/GalleryVisitorGiftServices'

// function VisitorGiftList() {

//   const [datas, setdatas] = useState({})
//   const [page, setpage] = useState(1)
//   const [modal, setmodal] = useState(false)
//   const [selected, setselected] = useState({})
//   const [search, setsearch] = useState({
//     text: '',
//     gift_status: '',
//     activate: false
//   })

//   const navigate = useNavigate()

//   useEffect(() => {
//     loadData(page)
//   }, [page])

//   async function loadData(page) {
//     const res = search.activate
//       ? await SearchGalleryVisitorGiftService({
//           search_text: search.text,
//           gift_status: search.gift_status,
//           page
//         })
//       : await GetGalleryVisitorGiftListService(page)

//     setdatas(res?.data)
//   }

//   async function applyFilter() {
//     setsearch({ ...search, activate: true })
//     setpage(1)
//     loadData(1)
//   }

//   async function deleteData() {
//     const res = await DeleteGalleryVisitorGiftService(selected?._id)
//     if (res?.status === 200) {
//       toast.success("Deleted successfully")
//       setmodal(false)
//       loadData(page)
//     }
//   }

//   async function downloadExcel() {
//     const res = await DownloadGalleryVisitorGiftExcelService()
//     const path = res.data.path
//     axios.get(`${process.env.REACT_APP_AWS_IMAGE_URL}${path}`, {
//       responseType: 'blob'
//     }).then(res => {
//       fileDownload(res.data, 'visitor_gift_list.xlsx')
//       toast.success("Excel downloaded")
//     })
//   }

//   return (
//     <div className="h-screen overflow-hidden bg-slate-50">
//       <div className="flex">
//         <GalleryAppBar />

//         <div className="w-full p-5 overflow-y-auto">

//           {/* HEADER */}
//           <div className="flex items-center justify-between mb-4">
//             <div>
//               <h2 className="text-[18px] font-[700] text-slate-800">
//                 Visitor Gift List
//               </h2>
//               <p className="text-[12px] text-slate-500">
//                 Total Records: {datas?.pagination?.total || 0}
//               </p>
//             </div>

//             <div className="flex items-center gap-2">
//               <select
//                 className="border rounded-md text-[12px] px-2 py-1 bg-white"
//                 value={search.gift_status}
//                 onChange={e => setsearch({ ...search, gift_status: e.target.value })}
//               >
//                 <option value="">All Status</option>
//                 <option value="Given">Given</option>
//                 <option value="Not Given">Not Given</option>
//               </select>

//               <input
//                 className="border rounded-md text-[12px] px-2 py-1"
//                 placeholder="Search name / mobile"
//                 value={search.text}
//                 onChange={e => setsearch({ ...search, text: e.target.value })}
//               />

//               <ButtonOutlinedAutoWidth btnName="Filter" onClick={applyFilter} />
//               <ButtonOutlinedAutoWidth btnName="Add Gift" onClick={() => navigate('create')} />

//               <AiOutlineFileExcel
//                 size={22}
//                 className="text-green-600 transition cursor-pointer hover:scale-110"
//                 onClick={downloadExcel}
//               />
//             </div>
//           </div>

//           {/* TABLE */}
//           <div className="overflow-hidden bg-white border rounded-lg shadow">
//             <div className="grid grid-cols-12 bg-slate-100 text-[12px] font-[600] text-slate-600 px-3 py-2">
//               <div className="col-span-1">#</div>
//               <div className="col-span-2">Gift</div>
//               <div className="col-span-2">Name</div>
//               <div className="col-span-2">Mobile</div>
//               <div className="col-span-2">Status</div>
//               <div className="col-span-2">Gift Date</div>
//               <div className="col-span-1 text-center">Action</div>
//             </div>

//             {datas?.datas?.length === 0 && (
//               <div className="text-center py-16 text-slate-500 text-[13px]">
//                 No visitor gift records found
//               </div>
//             )}

//             {datas?.datas?.map((d, i) => (
//               <div
//                 key={d._id}
//                 className="grid grid-cols-12 px-3 py-2 text-[12.5px] border-t hover:bg-slate-50 transition items-center"
//               >
//                 <div className="col-span-1 font-[600]">{i + 1}</div>

//                 {/* GIFT IMAGE */}
//                 <div className="col-span-2">
//                   {d?.file ? (
//                     <img
//                       src={`${process.env.REACT_APP_BACKEND_IMAGE_URL}${d.file}`}
//                       alt="Gift"
//                       className="object-cover w-10 h-10 transition border rounded-md cursor-pointer hover:scale-105"
//                       onClick={() =>
//                         window.open(
//                           `${process.env.REACT_APP_BACKEND_IMAGE_URL}${d.file}`,
//                           '_blank'
//                         )
//                       }
//                     />
//                   ) : (
//                     <div className="w-10 h-10 flex items-center justify-center bg-slate-200 rounded-md text-[11px] font-[700] uppercase">
//                       {d?.gift_name?.slice(0, 2) || 'NA'}
//                     </div>
//                   )}
//                 </div>

//                 <div className="col-span-2 truncate">{d.name}</div>
//                 <div className="col-span-2">{d.mobile}</div>

//                 {/* STATUS */}
//                 <div className="col-span-2">
//                   <span
//                     className={`px-2 py-[2px] rounded-full text-[11px] font-[600]
//                       ${
//                         d.gift_status === 'Given'
//                           ? 'bg-green-100 text-green-700'
//                           : 'bg-orange-100 text-orange-700'
//                       }`}
//                   >
//                     {d.gift_status}
//                   </span>
//                 </div>

//                 <div className="col-span-2">
//                   {d.gift_given_date
//                     ? dayjs(d.gift_given_date).format('DD MMM YYYY')
//                     : '-'}
//                 </div>

//                 {/* ACTIONS */}
//                 <div className="flex justify-center col-span-1 gap-2">
//                   <AiOutlineEdit
//                     className="text-blue-600 cursor-pointer hover:scale-110"
//                     onClick={() => navigate('edit', { state: d })}
//                   />
//                   <AiOutlineDelete
//                     className="text-red-600 cursor-pointer hover:scale-110"
//                     onClick={() => {
//                       setselected(d)
//                       setmodal(true)
//                     }}
//                   />
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>

//       {/* DELETE MODAL */}
//       <Modal open={modal} footer={false} closable={false} width={320}>
//         <div className="relative">
//           <IoClose
//             className="absolute top-0 right-0 cursor-pointer"
//             onClick={() => setmodal(false)}
//           />
//           <h6 className="font-[700] mb-2">Delete Gift Record</h6>
//           <p className="text-[12px] text-slate-600 mb-4">
//             Are you sure you want to delete gift for <b>{selected?.name}</b>?
//           </p>

//           <div className="flex justify-end gap-2">
//             <ButtonOutlinedAutoWidth btnName="Cancel" onClick={() => setmodal(false)} />
//             <ButtonFilledAutoWidth btnName="Delete" onClick={deleteData} />
//           </div>
//         </div>
//       </Modal>
//     </div>
//   )
// }

// export default VisitorGiftList









//==========>>> Old 2


// import React, { useEffect, useState } from 'react'
// import GalleryAppBar from '../GalleryAppBar'
// import { ButtonOutlinedAutoWidth, ButtonFilledAutoWidth } from '../../../components/button'
// import { useNavigate } from 'react-router-dom'
// import { AiOutlineEdit, AiOutlineDelete, AiOutlineFileExcel } from 'react-icons/ai'
// import { Modal } from 'antd'
// import dayjs from 'dayjs'
// import axios from 'axios'
// import fileDownload from "js-file-download"
// import { toast } from 'react-hot-toast'
// import { IoClose } from 'react-icons/io5'

// import {
//   GetGalleryVisitorGiftListService,
//   SearchGalleryVisitorGiftService,
//   DeleteGalleryVisitorGiftService,
//   DownloadGalleryVisitorGiftExcelService
// } from '../../../services/Gallery/GalleryVisitorGiftServices'

// function VisitorGiftList() {

//   const [datas, setdatas] = useState({})
//   const [page, setpage] = useState(1)
//   const [modal, setmodal] = useState(false)
//   const [selected, setselected] = useState({})
//   const [search, setsearch] = useState({
//     text: '',
//     gift_status: '',
//     activate: false
//   })

//   const navigate = useNavigate()

//   useEffect(() => {
//     loadData(page)
//   }, [page])

//   async function loadData(page) {
//     const res = search.activate
//       ? await SearchGalleryVisitorGiftService({
//           search_text: search.text,
//           gift_status: search.gift_status,
//           page
//         })
//       : await GetGalleryVisitorGiftListService(page)

//     setdatas(res?.data)
//   }

//   async function applyFilter() {
//     setsearch({ ...search, activate: true })
//     setpage(1)
//     loadData(1)
//   }

//   async function deleteData() {
//     const res = await DeleteGalleryVisitorGiftService(selected?._id)
//     if (res?.status === 200) {
//       toast.success("Deleted successfully")
//       setmodal(false)
//       loadData(page)
//     }
//   }

//   async function downloadExcel() {
//     const res = await DownloadGalleryVisitorGiftExcelService()
//     const path = res.data.path
//     axios.get(`${process.env.REACT_APP_AWS_IMAGE_URL}${path}`, {
//       responseType: 'blob'
//     }).then(res => {
//       fileDownload(res.data, 'visitor_gift_list.xlsx')
//       toast.success("Excel downloaded")
//     })
//   }

//   return (
//     <div className="h-screen overflow-hidden bg-slate-50">
//       <div className="flex">
//         <GalleryAppBar />

//         <div className="w-full p-5 overflow-y-auto">

//           {/* HEADER */}
//           <div className="flex items-center justify-between mb-4">
//             <div>
//               <h2 className="text-[18px] font-[700] text-slate-800">
//                 Visitor Gift List
//               </h2>
//               <p className="text-[12px] text-slate-500">
//                 Total Records: {datas?.pagination?.total || 0}
//               </p>
//             </div>

//             <div className="flex items-center gap-2">
//               <select
//                 className="border rounded-md text-[12px] px-2 py-1 bg-white"
//                 value={search.gift_status}
//                 onChange={e => setsearch({ ...search, gift_status: e.target.value })}
//               >
//                 <option value="">All Status</option>
//                 <option value="Given">Given</option>
//                 <option value="Not Given">Not Given</option>
//               </select>

//               <input
//                 className="border rounded-md text-[12px] px-2 py-1"
//                 placeholder="Search name / mobile"
//                 value={search.text}
//                 onChange={e => setsearch({ ...search, text: e.target.value })}
//               />

//               <ButtonOutlinedAutoWidth btnName="Filter" onClick={applyFilter} />
//               <ButtonOutlinedAutoWidth btnName="Add Gift" onClick={() => navigate('create')} />

//               <AiOutlineFileExcel
//                 size={22}
//                 className="text-green-600 transition cursor-pointer hover:scale-110"
//                 onClick={downloadExcel}
//               />
//             </div>
//           </div>

//           {/* TABLE */}
//           <div className="overflow-hidden bg-white border rounded-lg shadow">
//             <div className="grid grid-cols-12 bg-slate-100 text-[12px] font-[600] text-slate-600 px-3 py-2">
//               <div className="col-span-1">#</div>
//               <div className="col-span-2">Name</div>
//               <div className="col-span-2">Mobile</div>
//               <div className="col-span-2">Status</div>
//               <div className="col-span-2">Gift</div>
//               <div className="col-span-2">Date</div>
//               <div className="col-span-1 text-center">Action</div>
//             </div>

//             {datas?.datas?.length === 0 && (
//               <div className="text-center py-16 text-slate-500 text-[13px]">
//                 No visitor gift records found
//               </div>
//             )}

//             {datas?.datas?.map((d, i) => (
//               <div
//                 key={d._id}
//                 className="grid grid-cols-12 px-3 py-2 text-[12.5px] border-t hover:bg-slate-50 transition"
//               >
//                 <div className="col-span-1 font-[600]">{i + 1}</div>
//                 <div className="col-span-2 truncate">{d.name}</div>
//                 <div className="col-span-2">{d.mobile}</div>

//                 {/* STATUS BADGE */}
//                 <div className="col-span-2">
//                   <span
//                     className={`px-2 py-[2px] rounded-full text-[11px] font-[600]
//                     ${
//                       d.gift_status === 'Given'
//                         ? 'bg-green-100 text-green-700'
//                         : 'bg-orange-100 text-orange-700'
//                     }`}
//                   >
//                     {d.gift_status}
//                   </span>
//                 </div>

//                 <div className="col-span-2 truncate">{d.gift_name || '-'}</div>

//                 <div className="col-span-2">
//                   {d.gift_given_date
//                     ? dayjs(d.gift_given_date).format('DD MMM YYYY')
//                     : '-'}
//                 </div>

//                 {/* ACTIONS */}
//                 <div className="flex justify-center col-span-1 gap-2">
//                   <AiOutlineEdit
//                     className="text-blue-600 cursor-pointer hover:scale-110"
//                     onClick={() => navigate('edit', { state: d })}
//                   />
//                   <AiOutlineDelete
//                     className="text-red-600 cursor-pointer hover:scale-110"
//                     onClick={() => {
//                       setselected(d)
//                       setmodal(true)
//                     }}
//                   />
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>

//       {/* DELETE MODAL */}
//       <Modal open={modal} footer={false} closable={false} width={320}>
//         <div className="relative">
//           <IoClose
//             className="absolute top-0 right-0 cursor-pointer"
//             onClick={() => setmodal(false)}
//           />
//           <h6 className="font-[700] mb-2">Delete Gift Record</h6>
//           <p className="text-[12px] text-slate-600 mb-4">
//             Are you sure you want to delete gift for <b>{selected?.name}</b>?
//           </p>

//           <div className="flex justify-end gap-2">
//             <ButtonOutlinedAutoWidth btnName="Cancel" onClick={() => setmodal(false)} />
//             <ButtonFilledAutoWidth btnName="Delete" onClick={deleteData} />
//           </div>
//         </div>
//       </Modal>
//     </div>
//   )
// }

// export default VisitorGiftList




//=======>>> old



// import React, { useEffect, useState } from 'react'
// import GalleryAppBar from '../GalleryAppBar'
// import { ButtonOutlinedAutoWidth, ButtonFilledAutoWidth } from '../../../components/button'
// import { useNavigate } from 'react-router-dom'
// import { AiOutlineEdit, AiOutlineDelete, AiOutlineFileExcel } from 'react-icons/ai'
// import { Tooltip, IconButton } from '@mui/material'
// import { DatePicker, Modal } from 'antd'
// import moment from 'moment'
// import axios from 'axios'
// import fileDownload from "js-file-download"
// import { toast } from 'react-hot-toast'
// import { IoClose } from 'react-icons/io5'

// import {
//   GetGalleryVisitorGiftListService,
//   SearchGalleryVisitorGiftService,
//   DeleteGalleryVisitorGiftService,
//   DownloadGalleryVisitorGiftExcelService
// } from '../../../services/Gallery/GalleryVisitorGiftServices'

// function VisitorGiftList() {

//   const [datas, setdatas] = useState({})
//   const [page, setpage] = useState(1)
//   const [modal, setmodal] = useState(false)
//   const [selected, setselected] = useState({})
//   const [search, setsearch] = useState({
//     text: '',
//     gift_status: '',
//     from_date: '',
//     to_date: '',
//     activate: false
//   })

//   const navigate = useNavigate()

//   useEffect(() => {
//     loadData(page)
//   }, [page])

//   async function loadData(page) {
//     if (!search.activate) {
//       const res = await GetGalleryVisitorGiftListService(page)
//       setdatas(res?.data)
//     } else {
//       applyFilter(page)
//     }
//   }

//   async function applyFilter(page = 1) {
//     setsearch({ ...search, activate: true })
//     const res = await SearchGalleryVisitorGiftService({
//       search_text: search.text,
//       gift_status: search.gift_status,
//       from_date: search.from_date,
//       to_date: search.to_date,
//       page
//     })
//     setdatas(res?.data)
//   }

//   async function deleteData() {
//     const res = await DeleteGalleryVisitorGiftService(selected?._id)
//     if (res?.status === 200) {
//       toast.success("Deleted successfully")
//       setmodal(false)
//       loadData(page)
//     }
//   }

//   async function downloadExcel() {
//     const res = await DownloadGalleryVisitorGiftExcelService()
//     const path = res.data.path
//     axios.get(`${process.env.REACT_APP_AWS_IMAGE_URL}${path}`, { responseType: 'blob' })
//       .then(res => {
//         fileDownload(res.data, 'visitor_gift_list.xlsx')
//         toast.success("Excel downloaded")
//       })
//   }

//   return (
//     <div className='h-screen overflow-hidden'>
//       <div className='flex'>
//         <GalleryAppBar />

//         <div className='w-full p-4'>
//           <div className='flex justify-between pb-2 border-b'>
//             <h6 className='font-bold'>Visitor Gift List ({datas?.pagination?.total})</h6>

//             <div className='flex items-center gap-2'>
//               <select
//                 className='border text-[12px] px-2 py-1'
//                 value={search.gift_status}
//                 onChange={e => setsearch({ ...search, gift_status: e.target.value })}
//               >
//                 <option value="">All</option>
//                 <option value="Given">Given</option>
//                 <option value="Not Given">Not Given</option>
//               </select>

//               <input
//                 className='border text-[12px] px-2 py-1'
//                 placeholder='Search'
//                 value={search.text}
//                 onChange={e => setsearch({ ...search, text: e.target.value })}
//               />

//               <ButtonOutlinedAutoWidth btnName="Filter" onClick={() => applyFilter(1)} />
//               <ButtonOutlinedAutoWidth btnName="Add Gift" onClick={() => navigate('create')} />
//               <AiOutlineFileExcel size={22} onClick={downloadExcel} />
//             </div>
//           </div>

//           {/* TABLE */}
//           {datas?.datas?.map((d, i) => (
//             <div key={d._id} className='flex border-b text-[12px] py-1'>
//               <div className='w-12'>{i + 1}</div>
//               <div className='w-32'>{d.name}</div>
//               <div className='w-32'>{d.mobile}</div>
//               <div className='w-32'>{d.gift_status}</div>
//               <div className='w-40'>{d.gift_name}</div>
//               <div className='w-32'>{moment(d.createdAt).format('ll')}</div>
//               <div className='flex w-20'>
//                 <AiOutlineEdit onClick={() => navigate('edit', { state: d })} />
//                 <AiOutlineDelete onClick={() => { setselected(d); setmodal(true) }} />
//               </div>
//             </div>
//           ))}

//         </div>
//       </div>

//       {/* DELETE MODAL */}
//       <Modal open={modal} footer={false} closable={false}>
//         <IoClose onClick={() => setmodal(false)} />
//         <h6>Delete this gift record?</h6>
//         <ButtonFilledAutoWidth btnName="Yes" onClick={deleteData} />
//       </Modal>
//     </div>
//   )
// }

// export default VisitorGiftList
