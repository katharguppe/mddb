import React, { useEffect, useState } from 'react'
import FinanceMenu from '../finance/FinanceMenu'
import { GetFinanceDashboardService } from '../../services/FinanceServices'
import {FcMoneyTransfer} from 'react-icons/fc';
import {RiBillLine} from 'react-icons/ri';
import ReactApexChart from 'react-apexcharts';
import QtreviewMenu from './QtreviewMenu';


function QtreviewDashboardMain() {

  const [data,setdata] = useState({})
  // const [series,setseries] = useState([])

  const chartOptions = {
    plotOptions: {
      color:['#000','#000'],
      size:'40%',
      radialBar: {
          inverseOrder: false,
          startAngle: 0,
          endAngle: 360,
          offsetX: 0,
          offsetY: 0,
          hollow: {
              margin: 5,
              size: '50%',
              color: '#f2f2f2',
              image: undefined,
              imageWidth: 150,
              imageHeight: 150,
              imageOffsetX: 0,
              imageOffsetY: 0,
              imageClipped: true,
              position: 'front',
             
          },
          track: {
              show: true,
              startAngle: undefined,
              endAngle: undefined,
              background: '#f2f2f2',
              strokeWidth: '50%',
              opacity: 1,
              margin: 5, 
              dropShadow: {
                  enabled: false,
                  top: 0,
                  left: 0,
                  opacity: 1
              }
          },
          dataLabels: {
              show: true,
              name: {
                  show: true,
                  fontSize: '12px',
                  fontFamily: undefined,
                  fontWeight: 400,
                  color: undefined,
                  color:'#000',
                },
                value: {
                  show: true,
                  fontSize: '14px',
                  fontFamily: undefined,
                  fontWeight: 900,
                  color: undefined,
                  offsetY: 1,
                  formatter: function (val) {
                    return val + '%'
                  }
                },
                
          },
          
      },
    },
    labels: ['Amount Collected'],
    fill:{
      colors: ['#008ef2'],
    }
  }

  const [chartOptions1,setchartOptions1] = useState({
  series:[],
  chart: {
    toolbar: {
      show: false
    }
  },
    plotOptions: {
      
      bar: {
        horizontal: false,
        columnWidth: '55%',
        endingShape: 'rounded',
        dataLabels: {
          position: 'top', // top, center, bottom
        },
        
      },
    },
    dataLabels: {
      enabled: false
    },
    grid:{
      show: true,
      borderColor: '#fafafa',
    },
  
    stroke: {
      width: 1,
      
      curve: 'smooth',
      colors: ['transparent']
    },
    xaxis: {
      categories: ['Invoice Pending', 'Invoice Revise', 'Invoice Raised', 'Approval Pending ', 'Payment Deleted'],
    },
    yaxis: {
      title: {
        text: 'Count'
      }
    },
    fill: {
      opacity: 1
    },
    tooltip: {
      y: {
        formatter: function (val) {
          console.log("val",val)
          return  val
        }
      }
    },
    fill:['#027cd1']
  })



  useEffect(()=>{
    getData()
  },[])

  async function getData(){
     const response = await GetFinanceDashboardService()
     let d = response?.data?.datas
     setdata(response?.data?.datas)
     let form = [
      {
        name:'count',
        data:[d?.invoice_pending,d?.invoice_revise,d?.invoice_raised,d?.payment_approval_pending,d?.payment_deleted]
      }]  
     setchartOptions1({...chartOptions1,series:[...form]})
  }

  let rupeeIndian = Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
  });



  return (
    <div>
      <div className='flex'>
        <QtreviewMenu />
        <div className='mx-4 mt-5'>
        <h6 className='text-[14px] font-[700] ml-2 pt-4'>Finance Statistics</h6>
       
    
        </div>
      </div>
    </div>
  )
}

export default QtreviewDashboardMain;