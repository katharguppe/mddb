import { Avatar } from '@mui/material'
import React from 'react'
import { ButtonOutlined } from '../../components/button'
import { useNavigate } from 'react-router-dom'


function MainprofileAppbar() {
  const navigate = useNavigate()

 


  return (
    <div className='mr-0 min-h-screen max-h-sceen border-r  w-44 px-2'>
       <div className='flex items-center'>
        <Avatar  sx={{ width: 50, height: 50 }} src='https://avatars.githubusercontent.com/u/89134199?s=96&v=4' className='border' />
        <div className='ml-2'>
            <h6 className={`font-[600] sm:text-[18px]  cursor-pointer hover:underline mb-0 pb-0 `}>Krishnapythonprogrammer</h6>
            <span className='text-[11px] text-[#646d76]'>Your personal account</span>
        </div>
       </div>
       <div className='mt-2 sm:mt-0'>
       <ButtonOutlined btnName="Go to your personal profile" onClick={()=>navigate(-1)} />
       </div>
    </div>
  )
}

export default MainprofileAppbar