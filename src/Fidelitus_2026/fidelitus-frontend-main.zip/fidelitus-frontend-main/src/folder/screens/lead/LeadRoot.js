import React from 'react'

function LeadRoot() {
  
    const routes = [
        {name:'My Contact',path:'/contact'},
        {name:'Options Shared',path:'/contact'},
        {name:'My Inspection',path:'/contact'},
        {name:'LOI / Agreement',path:'/contact'},
        {name:'Invoice Raised',path:'/contact'},
        {name:'Hold Contact',path:'/contact'},
    ]
  return (
    <div>
        <div className='w-40 border-r'>
             {routes?.map((r)=>(
                <h6>{r?.name}</h6>
             ))}
        </div>
    </div>
  )
}

export default LeadRoot