import React,{useState,useEffect} from 'react'
import ItMenu from '../ItMenu'
import { useLocation, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../../components/button';
import { Modal } from 'antd';
import { IconButton } from '@mui/material'
import moment from 'moment';
import { RiBillLine } from 'react-icons/ri';
import { AiOutlineEdit,AiOutlineDelete,AiOutlineFileExcel } from 'react-icons/ai';
import { Tooltip } from '@mui/material';
import {BsArrowRepeat} from 'react-icons/bs';
import {FiChevronRight,FiChevronLeft} from 'react-icons/fi';
import { HiOutlineDuplicate } from "react-icons/hi";
import Uploader from '../../../components/Uploader';
import ErrorComponent from '../../../components/errorDesign/ErrorComponent';
import { useSelector } from 'react-redux';
import { DeleteCompanyOptionService, GetCompanyOptionService, UploadCompanyOptionService } from '../../../services/ITServices/CompanyOption/CompanyOptionServices';


function CompanyInventoryOptionList() {


  const {pathname}  = useLocation()
  const path = pathname.split('/')[pathname.split('/').length - 1]
  const roles = useSelector(state=>state.Auth.roles)

  const [excel,setexcel] = useState({file:'',error:''})

  const [data,setdata] = useState([])
  const [selecteddata,setselecteddata] = useState({})
  const [loader, setloader] = useState(false);
  const [modal, setModal] = useState(false);
  const [modal1,setModal1] = useState(false)
  const [search,setsearch] = useState({text:'',stage:'',status:''})

  const [stages,setstages] = useState([])
  const [status,setstatus] = useState([])

  const [type,settype] = useState('')
  const [page,setpage] = useState(1)


  const navigate = useNavigate()
  

  useEffect(()=>{
   getdata()
  },[page])


    async function getdata(){
        setloader(true)
        const response = await GetCompanyOptionService(page,search?.text)
        setloader(false)
        setdata(response.data)
    }  

    async function deletedata(){
        const response = await DeleteCompanyOptionService(selecteddata._id)
        if(response.status === 200){
            setModal(false)
            toast.success("Deleted Successfully")
            getdata()
        }
    }

    async function resetfunc() {
      setpage(1)
      setsearch({text:'',stage:'',status:''})
      const response = await GetCompanyOptionService(1,'')
      setdata(response.data)
    }

    async function applyfilterfunction() {
      setpage(1)
      const response = await GetCompanyOptionService(1,search?.text,type,search?.stage?.value !== undefined ? search?.stage?.value : '',search?.status?.value !== undefined ? search?.status?.value : '')
      setdata(response.data)
    }

    async function  uploadExcel() {
      if(!excel?.file){
        setexcel({...excel,error:'This Field is required!'})
      }else{
        const response = await UploadCompanyOptionService({file:excel?.file})
        if(response?.status === 201){
          getdata(type,1)
          toast.success("Excel Uploaded Successfully")
          setexcel({file:'',error:''})
          setModal1(false)
        }else if(response?.status === 422){
          toast.error("Invalid Excel Format")
  
        }
      }
    }

  return (
    <div className='flex mx-0 box-border  max-h-screen overflow-y-scroll overflow-x-hidden'>
         <Modal open={modal1} width={350} closable={false} footer={false} className='absolute top-0 left-[40%]'>
          <div className='absolute right-6'>
           <a href="https://fcplfmsbucket.s3.ap-south-1.amazonaws.com/sample.xlsx" downlaod> <h6 className='text-[10px] cursor-pointer font-[700] flex underline items-center'><AiOutlineFileExcel className='mr-1' /> Download Sample</h6></a>
          </div>
          <h6 className="font-bold text-[13px]  mb-2 w-full">Upload Excel</h6>
          <Uploader image={excel?.file}  setimagefunc={(e)=>{setexcel({...excel,file:e,error:''})}}  removeimageuploadfunc = {()=>setexcel({...excel,file:'',error:''})} />

          <ErrorComponent error={excel?.error} />
          <div className='mt-2 flex items-center'>
            <ButtonOutlinedAutoWidth btnName="Close" onClick={()=>setModal1(false)}/>
            <div className='ml-2'>
            <ButtonFilledAutoWidth btnName="Save" onClick={()=>uploadExcel()} />
            </div>
          </div>
      </Modal>  
     
        <Modal
        keepMounted
        open={modal}
        onClose={()=>setModal(false)}
        width={300}
        footer={false}
        closable={false}
       
      >
        <div >
          <h6 className="font-bold text-[15px] text-center mb-2 w-full">Are you sure?</h6>
          <h6 className='bg-slate-100 text-center text-[12px] p-1.5 font-[400]'>After deleting you cannot retrieve it back before deleting check once whether you have used it in some data</h6>
          <div className='flex justify-end mt-3 '>
            {/* <div className='mr-1 w-full'> */}
            <ButtonOutlinedAutoWidth btnName={'Cancel'} onClick={()=>setModal(false)} />
            {/* </div> */}
            <div  className='ml-2'>
            <ButtonFilledAutoWidth btnName={'Confirm'} onClick={()=>deletedata()}  /> 
            </div>
          </div>
        </div>
        </Modal>
        

        <div>
            <ItMenu />
        </div>
        <div className='px-4 w-[100%]'>
        <div >
        <div className='pt-5'>
        <div className="flex justify-between align-center items-center border-b pb-2 ">
        <span className="font-black text-[14px]">Total Company Asset ({data?.pagination?.total})</span>


        <div className='flex items-center'>
              <div className='flex items-center text-[12px] mr-2'>
                       
                       
                       
                  
                      
                        {/* <AiOutlineFileExcel onClick={()=>setModal1(true)} size={24}  className='mr-1 bg-gray-200 p-1.5' /> */}

                        <h6 className='mr-2 font-[600]'>{page == 1 ? data?.datas?.length > 0 ? 1 : 0 : (page - 1) * data?.pagination?.limit } - {data?.pagination?.limit} of {data?.pagination?.total} </h6>
                        <IconButton onClick={resetfunc}><BsArrowRepeat size={16} /></IconButton>

                        <div>
                        <IconButton onClick={()=>{page > 1 ? setpage(page-1) : console.log('')}}><FiChevronLeft className={`${page === 1 ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>
                        <IconButton onClick={()=>{ page < data?.pagination?.totalPages  ? setpage(page+1) : console.log('')}}><FiChevronRight className={`${(data?.pagination?.totalPages === page || data?.datas?.length === 0)  ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>

                        </div>
                    </div>

          
         

                    <div className='mr-2 flex'>
                        

                    <input  id="search_text" placeholder='Search text' type='text' value={search.text} onChange={(e)=>setsearch({...search,text:e.target.value})} className='border py-[3px] focus:ring-0 focus:outline-0 text-[14px]  w-28 px-1 rounded-md border-slate-300' />
                     
                 

                   
                    </div>    

                  
                <ButtonOutlinedAutoWidth btnName="Add Filter" onClick={()=>applyfilterfunction(1)} /> 
               
                <div className='ml-2'>
                <ButtonFilledAutoWidth btnName="Add Data" onClick={()=>navigate('create')}/> 
                </div>
                    </div>

        
        </div>
        </div>
        
        
        {!loader &&
        <>
          {data?.datas?.length === 0 &&
          <div className='grid place-items-center mt-20  items-center justify-center'>
            <img src={'https://fidecrmfiles.s3.amazonaws.com/NoDataFound1.png'} className='w-40 h-40 object-contain' /> 
            <h6 className='font-bold text-[14px] -mt-10'>No data found</h6>
            <h6 className='font-[500] w-[70%] text-center text-slate-700 text-[12.5px] -mt-2'>Oops we couldn't find any data added based on your current page option please click on add the data button to see list here.</h6>
          </div>
          }
      

          {data?.datas?.length > 0 &&
          <div className='grid grid-cols-6 gap-1 mt-2'>
              {data?.datas?.map((d,i)=>(
              <div  key={d?.id}  className='border items-center relative justify-between px-2 py-1 border-b'>
                <div className='h-[100px] flex items-center justify-center bg-slate-100'>
                  {![null,undefined,'','null','undefined']?.includes(d?.image) && <img src={`${process.env.REACT_APP_AWS_IMAGE_URL}${d?.image}`} alt="No Img" className='h-[80px] bg-slate-100' />}
                  </div>
                  <h6 className='text-[13px] font-[500] '>{d.name}</h6>
                  <h6 className='text-[12px] font-[500] '>ASSET ID : <span className='font-[800]'>{d.asset_id}</span></h6>
                  <h6 className='text-[10px] font-[500] '>Type : <span className='font-[800]'>Company Asset</span></h6>
                  <h6 className='text-[10px] font-[500] bg-slate-100 mt-1 p-1'>Created At : <span className='text-[10px] font-[800]'>{moment(d.createdAt).format('LLL')}</span> </h6>
                  <div className='absolute right-0 p-1 bg-white top-0 flex'>
                  <Tooltip title="Detail" >
                  <span><RiBillLine size={12} className="cursor-pointer" onClick={()=>{navigate('detail',{state:d})}}/></span>
                  </Tooltip>
                  <Tooltip title="Duplicate" >
                  <span><HiOutlineDuplicate size={12} className="cursor-pointer ml-2" onClick={()=>{navigate('create',{state:d})}}/></span>
                  </Tooltip>
                  <Tooltip title="Edit" >
                  <span><AiOutlineEdit size={12} className="cursor-pointer ml-2" onClick={()=>{navigate('edit',{state:d})}}/></span>
                  </Tooltip>
                  {roles?.includes('admin') &&  
                  <Tooltip title="Delete">
                  <span><AiOutlineDelete size={12} className='ml-2 cursor-pointer'  onClick={()=>{setselecteddata(d);setModal(true)}}/></span>
                  </Tooltip>}
                  </div>
              </div>
              ))}
          </div>}
        </>}      

          </div>
        </div>
        
    </div>
  )
}

export default CompanyInventoryOptionList