import React,{useEffect, useState,useRef} from 'react'
import { toast } from 'react-hot-toast'
import { ButtonFilledAutoWidth } from '../../../components/button'
import { TextAreaInput1, TextInput } from '../../../components/input'
import { useNavigate, useLocation } from 'react-router-dom'
import GoBack from '../../../components/back/GoBack'
import ItMenu from '../ItMenu'
import { UploadInventoryOptionService } from '../../../services/ITServices/InventoryOption/InventoryOptionServices'
import Uploader from '../../../components/Uploader'
import  {toPng} from 'html-to-image';
import { CreateCompanyOptionService, UpdateCompanyOptionService } from '../../../services/ITServices/CompanyOption/CompanyOptionServices'
import { AiOutlineDownload } from 'react-icons/ai'
import image_logo from '../../../assets/images/fcpl_white_logo.png'
import {BiCheckbox,BiCheckboxSquare} from 'react-icons/bi'

function CompanyInventoryOptionCE() {

  const stickerRef = useRef();
  const stickerRef1 = useRef();

  const [typeSelected,settypeSelected] = useState('')
 
  const [data,setdata] = useState({device_id:'',asset_id:'',barcode:'',name:'',configuration:'',units:'',image:''});  
  const [error,seterror] = useState({device_id:'',asset_id:'',barcode:'',name:'',configuration:'',units:'',image:''});


  
  const {pathname}  = useLocation()
  const path1 = pathname.split('/')[pathname.split('/').length - 1]

  const {state} = useLocation();
  const navigate = useNavigate();


  useEffect(()=>{
    if(state?._id !== null && state?._id !== undefined && path1 !== 'create'){

      let passData = {
        ...state 
      }


      setdata({...data,...passData})
    }else{
      if(state?._id !== undefined){
        let passData = {
          ...state 
        }

        setdata({...data,...passData})
      }
    }
  },[state])

  function handlechange(e){
    setdata({...data,[e.target.name] : e.target.value})
    seterror({...error,[e.target.name]:''})
  }


  async function submitform(){
    if(!data.name){
        seterror({...error,name:'Name field is required *'})
    }else if(!data.device_id){
      seterror({...error,device_id:'Device ID field is required *'})
    }else{
      if(state?._id === undefined || state?._id === null || path1 === 'create'){
        let send_data = {...data}
        delete send_data._id

        const response = await CreateCompanyOptionService(send_data)
        if (response.status === 201) {
          resetform()
          toast.success(`Company Asset Created Successfully`)
        }   
        if(response.status === 422){
          seterror({...error,name:response?.data?.errors?.name})
        } 
      }else{
        let send_data = {...data}
        send_data["_id"] = state?._id

        const response = await UpdateCompanyOptionService(send_data,state?._id)
        if (response.status === 200) {
          resetform()
          navigate(-1)
          toast.success(`Company Asset Updated Successfully`)
        }   
        if(response.status === 422){
          seterror({...error,name:response?.data?.errors?.name})
        } 
      }
  }
  }

  function resetform(){
    setdata({device_id:'',asset_id:'',barcode:'',name:'',configuration:'',units:'',image:''})
    seterror({device_id:'',asset_id:'',barcode:'',name:'',configuration:'',units:'',image:''})
  }

  async function uploadfilefunc(v,name){
    const fd = new FormData()
    fd.append('file',v); 
    const response = await UploadInventoryOptionService(fd)
    if(response?.status === 200){
    setdata({...data,[name]:response?.data?.data})
    }
  }

 function downloadSticker(){
  
  if (typeSelected == 1 && stickerRef.current) {
    toPng(stickerRef.current)
        .then((dataUrl) => {
            const link = document.createElement('a');
            link.download = `sticker.png`;
            link.href = dataUrl;
            link.click();
        })
        .catch((err) => {
            console.error('Error generating sticker:', err);
        });
  }

  if (typeSelected == 2 && stickerRef1.current) {
    toPng(stickerRef1.current)
        .then((dataUrl) => {
            const link = document.createElement('a');
            link.download = `sticker.png`;
            link.href = dataUrl;
            link.click();
        })
        .catch((err) => {
            console.error('Error generating sticker:', err);
        });
  }

 }
  

  return (
    <div className='flex '>


    <div >
      <ItMenu />
    </div> 
   
    <div className=' px-4 pt-5' >


        <div className='sm:w-full lg:w-72'>
        <GoBack /> 

        <h6 className='font-[700]'>{(state?._id !== null && state?._id !== undefined && path1 !== 'create') ? 'Edit' : 'Add'} Company Asset</h6>
        <h6 className='text-[10px] bg-slate-100 p-2 font-[500] leading-snug' >Use the below form to create or edit the <b> Company Asset</b> for your comapny employees.</h6>
        </div>


        <div className='flex border-box min-w-[450px] max-w-[450px]'>
          <div className='w-[65%]  mr-5'>
          <TextInput 
              label={'Name'}  
              variant="standard"
              name="name"
              type="text"
              mandatory={true}
              error={error.name}
              value={data.name}
              handlechange={handlechange}
              placeholder="Enter your name"
              InputLabelProps={{
                  style: { color: '#fff', }, 
              }}/>


          <TextInput 
              label={'Device Id'}  
              variant="standard"
              name="device_id"
              type="text"
              error={error.device_id}
              value={data.device_id}
              mandatory={true}
              handlechange={handlechange}
              placeholder="Enter your name"
              InputLabelProps={{
                  style: { color: '#fff', }, 
              }}/>

          {(state?._id !== null && state?._id !== undefined && path1 !== 'create') &&
          <TextInput 
              label={'Asset Id (Unique)'}  
              variant="standard"
              name="asset_id"
              type="text"
              readOnly={true}
              error={error.asset_id}
              value={data.asset_id}
              mandatory={true}
              handlechange={handlechange}
              placeholder="Enter your name"
              InputLabelProps={{
                  style: { color: '#fff', }, 
              }}/>}

           <TextAreaInput1 
                label={'Configuration'}  
                variant="standard"
                name="configuration"
                type="text"
                mandatory={false}
                error={error.configuration}
                value={data.configuration}
                handlechange={handlechange}
                placeholder=""
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>

            <TextInput 
                label={'Units'}  
                variant="standard"
                name="units"
                type="text"
                mandatory={false}
                error={error.units}
                value={data.units}
                handlechange={handlechange}
                placeholder=""
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>    
          
          <h6 className='text-[11px] font-[600] mb-1 mt-2' >Image</h6>    
          <Uploader image={data?.image}  setimagefunc={(e)=>{uploadfilefunc(e,'image');seterror({...error,image:''})}}  removeimageuploadfunc = {()=>{setdata({...data,image:''});seterror({...error,image:''})}}/>    


          {(state?._id !== null && state?._id !== undefined && path1 !== 'create') &&
               <> 
                <div className='mt-2'>
                  <h6 className='text-[11px] font-[800]'>Select Type For Download</h6>
                  
                  <div className='flex mt-2 items-center'>
                    <div onClick={()=>settypeSelected(1)} className='flex items-center'>
                    {typeSelected != '1' ? <BiCheckbox />  : <BiCheckboxSquare /> }
                    <h6 className='text-[11px] font-[700] ml-1'>Large</h6>
                    </div>

                    <div onClick={()=>settypeSelected(2)} className='flex ml-2 items-center'> 
                    {typeSelected != '2' ? <BiCheckbox />  : <BiCheckboxSquare /> }
                    <h6 className='text-[11px] font-[700] ml-1'>Small</h6>
                    </div>
                  </div>

                </div>
               
                {state?._id !== undefined && typeSelected !== '' &&
                <div className='flex'>
                  {typeSelected == '1' &&
                  <div ref={stickerRef} className='bg-slate-700 p-2 border h-[80px] mt-2 w-[200px] rounded  overflow-hidden'>
                    <div className='flex items-center'>
                      <img alt="image" style={{width:'20px',height:'20px',resize:'contain'}} src={image_logo} />
                      <h6 className='text-[11px] text-center w-[100%] text-center font-[900] text-white'>Property of Fidelitus</h6>
                    </div>
                    <div className='bg-white p-1 mt-1'>
                      <h1 className='text-[13px] px-1 uppercase text-center font-[900]'>{data?.asset_id}</h1>
                    </div>
                  </div>}

                  {typeSelected == '2' &&
                  <div ref={stickerRef1} className='bg-slate-700 p-2 border h-[80px] mt-2 w-[100px] rounded  overflow-hidden'>
                    <div className='flex items-center justify-center'>
                      <img alt="image" style={{width:'20px',height:'20px',resize:'contain'}} src={image_logo} />
                    </div>
                    <div className='bg-white p-1 mt-1'>
                      <h1 className='text-[8px] break-all px-1 uppercase text-center font-[900]'>{data?.asset_id}</h1>
                    </div>
                  </div>}

                  <AiOutlineDownload onClick={downloadSticker} className='ml-2 mt-2 cursor-pointer' />
                </div>}
                </>}


          </div>  

        </div>

         
        <div className='mt-5'>
        <ButtonFilledAutoWidth btnName={(state?._id !== null && state?._id !== undefined && path1 !== 'create') ? "Update Company Asset" : "Add Company Asset"}  onClick={submitform} />  
        </div>

    </div>
    </div>
  )
}

export default CompanyInventoryOptionCE