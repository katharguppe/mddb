import React, { useState,useEffect } from 'react'
import {  ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button';
import moment from 'moment';
import { useLocation, useNavigate } from 'react-router-dom';
import {AiOutlineDelete, AiOutlineEdit} from 'react-icons/ai';  
import { MdOutlineAlarm } from "react-icons/md";
import {FiChevronRight,FiChevronLeft} from 'react-icons/fi';
import { IconButton, Tooltip } from '@material-ui/core';
import { DatePicker, Modal, Select } from 'antd';
import { useSelector } from 'react-redux';
import { RiFileExcel2Line } from "react-icons/ri";
import MDTaskMenu from './MDTaskMenu';
import { DeleteMDAssignTaskService, GetMDAssignTaskService } from '../../services/MdTaskServices';
import { GetDepartmentService } from '../../services/DepartmentServices';
import toast from 'react-hot-toast';


function MDTasklist() {

  const {pathname} = useLocation()
  const navigator = useNavigate()
  const [search,setsearch] = useState({text:'',from_date:'',to_date:'',from_date1:'',to_date1:'',activate:false,department:'',user:''})

  const roles = useSelector(state=>state.Auth.roles)

  const [step,setstep] = useState('Pending')
  
  const [page,setpage] = useState(1)

  const [data,setdata] = useState({})
  const [departments,setdepartments] = useState([])

  useEffect(()=>{
    getdata()
    getoptions()
  },[step,page])

  async function getoptions(){
      const response = await GetDepartmentService()
      let arr = []
  
      response?.data?.datas?.forEach((d)=>{
          arr.push({value:d?.id,label:d?.department_name})
      })
  
      setdepartments(arr)
    } 
  

  async function getdata() {
    const response = await GetMDAssignTaskService(page,search?.from_date1,search?.to_date1,search?.text,search?.department,search?.user,step)
    setdata(response?.data)
    console.log("response?.data",response?.data)
  }


  async function applyFilter() {
    setpage(1)
    const response = await GetMDAssignTaskService(1,search?.from_date1,search?.to_date1,search?.text,search?.department,search?.user,step)
    setdata(response?.data)
  }

  async function resetfilter() {
    setpage(1)
    setsearch({text:'',from_date:'',to_date:'',from_date1:'',to_date1:'',activate:false,department:'',user:''})
    const response = await GetMDAssignTaskService(1,'','','','','',step)
    setdata(response?.data)
  }

  async function gotocreate() {
    navigator('create')
  }


  function gotoedit(d){
    navigator('edit',{state:d})
  }

  async function deleteData(d) {
    const response = await DeleteMDAssignTaskService(d)
    if(response?.status == 200){
      toast.success("Deleted Successfully!")
    }
    getdata()

  }

  



  return (
    <div className='w-[98%] h-screen overflow-hidden'>
        <div className='flex'>
            <div className='min-w-44'>
            <MDTaskMenu />
            </div>
            <div className='w-[100%] pl-5 mt-4'>
            <div className='flex items-center -mt-1 border-b justify-between pb-1'>
                <h6 className='font-[800] text-[13px]'>Total Task ({data?.pagination?.total})</h6>

                <div className='flex items-center text-[12px]'>

                    <h6 className='mr-2 font-[600]'>{page == 1 ? data?.datas?.length > 0 ? 1 : 0 : (page - 1) * data?.pagination?.limit } - {data?.pagination?.limit} of {data?.pagination?.total}  </h6>

                    <div>
                    <IconButton onClick={()=>{page > 1 ? setpage(page-1) : console.log('')}}><FiChevronLeft className={`${page === 1 ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>
                    <IconButton onClick={()=>{ page < data?.pagination?.totalPages  ? setpage(page+1) : console.log('')}}><FiChevronRight className={`${(data?.pagination?.totalPages === page || data?.datas?.length === 0) ? 'opacity-50 ' : 'opacity-100'}`}  size={16} /></IconButton>

                    </div>

                    {(roles?.includes('md_admin') || roles?.includes('admin')) && <>
                    <DatePicker  size='small' style={{fontSize:'11px'}} ampm={false} placeholder='From Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2'  value={search?.from_date} onChange={(v,v1) => {console.log('v na',new Date(v).toLocaleDateString());setsearch({...search,from_date:v,from_date1:v1})}} /> 

                    <DatePicker size='small' style={{fontSize:'11px'}} ampm={false} placeholder='To Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2'  value={search?.to_date} onChange={(v,v1) => {console.log('v na',new Date(v).toLocaleDateString());setsearch({...search,to_date:v,to_date1:v1})}} /> 

                    
                    <div className='mr-2'>
                        

                    <input  id="search_text" placeholder='Search text' type='text' value={search.text} onChange={(e)=>setsearch({...search,text:e.target.value})} className='border py-[3px] focus:ring-0 focus:outline-0 text-[14px]  w-[100px] px-1 rounded-md border-slate-300' />
                

                    </div> 

                    <Select 
                        bordered={false}
                        value={search?.department !== '' ? search?.department : null}
                        options={departments}
                        onChange={(e)=>setsearch({...search,department:e})}
                        placeholder={'Department'}
                        className='border rounded-[6px] border-slate-300 h-[30px] mr-2 w-[100px]' 
                        
                        />   


                    <div className='mr-2'>
                    <ButtonOutlinedAutoWidth btnName="Apply Filter" onClick={()=>applyFilter()} /> 
                    </div>
                    <div className='mr-2'>
                    <ButtonOutlinedAutoWidth btnName="Reset Filter" onClick={()=>resetfilter()} /> 
                    </div>
                   
                    <ButtonFilledAutoWidth btnName="Add" onClick={()=>gotocreate()} />
                    </>}
                </div>
            </div>

          
            <div className='flex  items-center border-b'>
                <h6 onClick={()=>setstep('Pending')} className={`font-[600] ${step === 'Pending' && 'bg-slate-600 text-white'} text-center cursor-pointer py-1 w-[80px] text-[11px]`}>Pending</h6>
                <h6 onClick={()=>setstep('Progress')} className={`font-[600] ${step === 'Progress' && 'bg-slate-600 text-white'} text-center cursor-pointer py-1 w-[80px] text-[11px]`}>Progress</h6>
                <h6 onClick={()=>setstep('Completed')} className={`font-[600] ${step === 'Completed' && 'bg-slate-600 text-white'} text-center cursor-pointer py-1 w-[80px] text-[11px]`}>Completed</h6>
            </div>
            <div className='overflow-x-hidden h-[90vh] mb-[50px] overflow-y-scroll'>
            
            {data?.datas?.length === 0 &&
            <div className='grid place-items-center mt-20  items-center justify-center'>
                <img src={'https://fidecrmfiles.s3.amazonaws.com/NoDataFound1.png'} className='w-40 h-40 object-contain' /> 
                <h6 className='font-bold text-[14px] -mt-10'>No data found</h6>
                <h6 className='font-[500] w-[70%] text-center text-slate-700 text-[12.5px] -mt-2'>Oops we couldn't find any data based on your current stage please add the data to see list here.</h6>
            </div>}

            {data?.datas?.length > 0 &&
            <div className='border-t max-h-[84vh] overflow-y-scroll border-l border-r mt-2'>
            <div className='flex border-b sticky top-0 z-50 bg-white '>
                <h6 className='text-[12px] font-[700] min-w-[50px] max-w-[50px] p-1 border-r'>SL No</h6>
                <h6 className='text-[12px] font-[700] min-w-[10%] max-w-[10%] p-1 border-r'>Department</h6>
                <h6 className='text-[12px] font-[700] min-w-[20%] max-w-[20%] p-1 border-r'>Title / Description</h6>
                <h6 className='text-[12px] font-[700] min-w-[20%] max-w-[20%] p-1 border-r'>Remarks</h6>
                <h6 className='text-[12px] font-[700] min-w-[10%] max-w-[10%] p-1 border-r'>DeadLine</h6>
                <h6 className='text-[12px] font-[700] min-w-[15%] max-w-[15%] p-1 border-r'>Assigned To</h6>
                <h6 className='text-[12px] font-[700] min-w-[10%] max-w-[10%] p-1 border-r'>Created</h6>
                <h6 className='text-[12px] font-[700] p-1'>Action</h6>
            </div>  
             
             {data?.datas?.map((d,i)=>(
             <div className={`flex  border-b  cursor-pointer`}>
                <h6 className='text-[12px] min-w-[50px] max-w-[50px] p-1 border-r'>{(page > 1 ? i+1+ (25 * (page - 1)) : i+1 )}</h6>
                <h6 className='text-[12px] min-w-[10%] font-[700] max-w-[10%] p-1 border-r'>{d?.department?.department_name}</h6>
                <h6 className='text-[12px] min-w-[20%] max-w-[20%] p-1 border-r'><b> Title : {d?.title}</b> <br></br> Description : {d?.description}</h6>
                <h6 className='text-[12px] min-w-[20%] max-w-[20%] p-1 border-r'>{d?.remarks}</h6>
                <h6 className='text-[10px] min-w-[10%] max-w-[10%] p-1 border-r'>{(d?.dead_line !== '' && d?.dead_line !== null && d?.dead_line !== undefined) && moment(d?.dead_line)?.format('LL')}</h6>
                <h6 className='text-[12px] min-w-[15%] max-w-[15%] p-1 border-r'>{d?.assigned_to?.name}</h6>
                <h6 className='text-[11px] min-w-[10%] max-w-[10%] p-1 border-r'>{moment(d?.createdAt)?.format('LL')}</h6>
                <h6 className='flex text-[12px] p-1'>
                    <AiOutlineEdit onClick={()=>{gotoedit(d)}} className='mr-2' />
                    {(roles?.includes('md_admin') || roles?.includes('admin')) && 
                    <AiOutlineDelete onClick={()=>{deleteData(d?._id)}} className='mr-2' />}
                </h6>
            </div>   
            ))} 
            </div>}
            </div>
            </div>
        </div>
    </div>
  )
}

export default MDTasklist