import React,{useState,useEffect} from 'react'
import { TextAreaInput1, TextInput } from '../../components/input'
import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
import { toast } from 'react-hot-toast'
import GoBack from '../../components/back/GoBack'
import { useLocation, useNavigate } from 'react-router-dom'
import { GetDepartmentService, GetUsersByDepartment } from '../../services/DepartmentServices'
import { Select } from 'antd'
import { GetSearchService } from '../../services/AuthServices'
import {BiErrorCircle} from 'react-icons/bi'
import { useSelector } from 'react-redux'
import MDTaskMenu from './MDTaskMenu'
import { CreateMDAssignTaskService, UpdateMDAssignTaskService } from '../../services/MdTaskServices'
import ErrorComponent from '../../components/errorDesign/ErrorComponent'


function MDTaskCE() {

  const {state,pathname} = useLocation() 
  const navigator = useNavigate()
  

  const user_id = useSelector(state=>state.Auth.id)
  
  const path = pathname?.split('/')[pathname?.split('/')?.length - 1]



  const [singleData,setsingleData] = useState({department:'',assigned_to:'',status:'Pending',title:'',description:'',remarks:'',dead_line:''})
  const [error,seterror] = useState({department:'',assigned_to:'',status:'',title:'',description:'',remarks:'',dead_line:''})
  const [departmentArr,setdepartmentArr] = useState([])
  const [users,setusers] = useState([])

 
  const status = [{label:'Pending',value:'Pending'},{label:'Progress',value:'Progress'},{label:'Completed',value:'Completed'}]

  useEffect(()=>{
    if(state?._id !== undefined){
       let sendData = {
        ...state,
        assigned_to:{label:state?.assigned_to?.name,value:state?.assigned_to?._id},
        department:{label:state?.department?.department_name,value:state?.department?._id},
        created_by:state?.created_by?._id,
       }

       searchfunction(state?.department?._id)
       setsingleData(sendData)
    }


    getoptions()
  },[state])
  


 
  async function getoptions(){
    const response = await GetDepartmentService()
    let arr = []

    response?.data?.datas?.forEach((d)=>{
        arr.push({value:d?.id,label:d?.department_name})
    })

    setdepartmentArr(arr)
  } 

  async function searchfunction(v){
   
    const response = await GetUsersByDepartment(v,1)
    let arr = []
    response?.data?.datas?.forEach((d)=>{
    arr.push({value:d?._id,label:`${d?.name}`})
    })
    setusers(arr)
    
  }

  async function submitform(){
    if(!singleData.title){
      seterror({...error,title:'This Field is required*'})
    }else if(!singleData.description){
      seterror({...error,description:'This Field is required*'})
    }else if(!singleData.department){
      seterror({...error,department:'This Field is required*'})
    }else if(!singleData.assigned_to){
      seterror({...error,assigned_to:'This Field is required*'})
    }else if(!singleData.dead_line){
      seterror({...error,dead_line:'This Field is required*'})
    }else if(singleData.status == 'Completed' && singleData.remarks == ''){
      seterror({...error,remarks:'This Field is required*'})
    }else{
      let sendData = {...singleData}
      sendData['department'] = singleData?.department?.value
      sendData['assigned_to'] = singleData?.assigned_to?.value
      if(singleData?.status?.value !== undefined){
        sendData['status'] = singleData?.status?.value
      }

      if(state?._id !== undefined){
        const response = await UpdateMDAssignTaskService(sendData,state?._id)
        if(response?.status == 200){
          toast.success("MD Assign Task Updated Successfully!")
          resetform()
        }
      }else{
        const response = await CreateMDAssignTaskService(sendData)
        if(response?.status == 201){
          toast.success("MD Assign Task Created Successfully!")
          resetform()
        }
      }
    }
  }


  function resetform(){
        setsingleData({department:'',assigned_to:'',status:'Pending',title:'',description:'',remarks:'',dead_line:''})
        seterror({department:'',assigned_to:'',status:'',title:'',description:'',remarks:'',dead_line:''})
        if(path === 'edit'){
            navigator(-1)
        }
       
  }

  async function handleSelect(e,e1){
    if(e1 === 'department'){
        searchfunction(e)
        setsingleData({...singleData,department:departmentArr?.find((d)=>d.value === e)})
        seterror({...error,department:''})
    }
    if(e1 === 'assigned_to'){
        setsingleData({...singleData,assigned_to:users?.find((d)=>d.value === e)})
        seterror({...error,assigned_to:''})
    }
    if(e1 === 'status'){
        setsingleData({...singleData,status:status?.find((d)=>d.value === e)})
        seterror({...error,status:''}) 
    }
  }    

  function handlechange(e){
        setsingleData({...singleData,[e.target.name] : e.target.value})
        seterror({...error,[e.target.name] : ''})
  }


  return (
    <div className='flex min-h-screen max-h-screen h-screen '>

      {/* <Modal open={modal} width={280} footer={false} closable={false}>
      <h6 className='text-[14px] font-[700]'>Create Reminder for the task</h6>  
            <h6 className='bg-slate-100 text-[10px] font-[500] p-1'>Use the below form to create the reminder to trigger for you</h6> 
           
              <div className='flex justify-between'>
              <div className='w-[48%]'>
              <h6 className='text-[11px] font-[600] mb-1 mt-2' >Date</h6>   
              <div className='border border-slate-300 '>
              <input type='date' value={data?.date} onChange={(v) => {setdata({...data,date:v.target.value});seterror1({...error1,date:''})}}  placeholder='' bordered={false} className='text-[12px] px-1 py-1.5 focus:outline-none w-[100%]' /> 
             
              </div>
              {error1?.date !== '' &&
              <div className='flex items-center mt-1'>
                  <BiErrorCircle className='text-red-500' size={14} />
                  <span className='text-[10px] text-red-500 ml-1'>{error1?.date}</span>
              </div>}
              </div>

              <div className='w-[48%]'>
              <h6 className='text-[11px] font-[600] mb-1 mt-2' >Time</h6>   
              <div className='border border-slate-300 '>
              <input type='time' value={data?.time} onChange={(v) => {setdata({...data,time:v.target.value});seterror1({...error1,time:''})}}  placeholder='' bordered={false} className='text-[12px] px-1 py-1.5 focus:outline-none w-[100%]' /> 
              
              </div>
              {error1?.time !== '' &&
              <div className='flex items-center mt-1'>
                  <BiErrorCircle className='text-red-500' size={14} />
                  <span className='text-[10px] text-red-500 ml-1'>{error1?.time}</span>
              </div>}
            </div>
            </div>

            <TextInput1 
             mandatory={true}
             label={'Title'}  
             variant="standard"
             name="title"
             type="text"
             value={data?.title}
             error={error1?.title}
             handlechange={handlechange2}
             placeholder=""
             InputLabelProps={{
                 style: { color: '#fff', }, 
             }}
            />


            <TextAreaInput1 
                mandatory={true}
                label={'Description'}  
                variant="standard"
                name="description"
                type="text"
                value={data?.description}
                error={error1?.description}
                handlechange={handlechange2}
                placeholder=""
                InputLabelProps={{
                    style: { color: '#fff', }, 
                }}/>


<div className='flex mt-2 border-t pt-2 w-full items-end '>
                <div className='mr-2'>
                <ButtonOutlinedAutoWidth btnName="Cancel" onClick={()=>setmodal(false)} />
                </div>
                <ButtonFilledAutoWidth btnName="Save" onClick={()=>addreminder()} />
            </div>

      </Modal> */}
      <MDTaskMenu />
           
           <div className='flex min-w-[300px] max-w-[300px]'>
           <div className=' border-r pr-5 border-slate-200 pl-5 min-h-screen max-h-screen h-screen overflow-y-scroll overflow-x-hidden' >
            <GoBack />
            
            <div className='border-b pb-2'>
                <h6 className='text-[13px] mb-1 font-[800]'>Create/Edit the Assign Task By You</h6>
                <h6 className='text-[12px] bg-slate-200 p-2'>Use the Below form to add the task for the user to work on it.</h6>
                
            </div>

           
            <>
             <TextInput  readOnly={path === 'create' ? false : (path === 'edit' && singleData?.created_by === user_id) ? false : true} value={singleData?.title} mandatory={true} error={error?.title} handlechange={handlechange} name="title" label="Title" />
             <TextAreaInput1  readOnly={path === 'create' ? false : (path === 'edit' && singleData?.created_by === user_id) ? false : true} value={singleData?.description} mandatory={true} error={error?.description} handlechange={handlechange} name="description" label="Description" />

              <h6 className='text-[12px] font-semibold mb-1 mt-1'>Department </h6>
                <Select
                value={singleData.department} 
                error={error.department}
                bordered={false}
                disabled={path === 'create' ? false : (path === 'edit' && singleData?.created_by === user_id) ? false : true}
                placeholder="" 
                onChange={(e)=>handleSelect(e,'department')} 
                options={departmentArr} 
                className='w-full border border-l-4 border-l-slate-800  outline-0 focus:outline-0 focus:ring-0 focus:border-none  focus:border-transparent focus:ring-offset-0 focus:shadow-none'
                />


              {error?.department !== '' && error?.department !== undefined &&
                <div className='flex items-center mt-1'>
                <BiErrorCircle className='text-red-500' size={14} />
                <span className='text-[10px] text-red-500 ml-1'>{error?.department}</span>
                </div>}
                

<>
              <h6 className='text-[12px] font-semibold mb-1 mt-1'>Assigned To </h6>
              <div className='w-[100%] max-w-[275px]'>
              <Select
                // showSearch 
                // filterOption={false} 
                value={singleData.assigned_to} 
                error={error.assigned_to}
                bordered={false}
                closable={true}
                allowClear={true}
                width={270}
                disabled={path === 'create' ? false : (path === 'edit' && singleData?.created_by === user_id) ? false : true}
                placeholder="" 
                onChange={(e)=>handleSelect(e,'assigned_to')} 
                options={users}
                // onSearch={searchfunction}
                className='w-full border  border-l-4 border-l-slate-800 outline-0 focus:outline-0 focus:ring-0 focus:border-none  focus:border-transparent focus:ring-offset-0 focus:shadow-none'
                />

                {/* <ErrorComponent error={error.assigned_to} />  */}

                </div>

                {error?.assigned_to !== '' && error?.assigned_to !== undefined &&
                <div className='flex items-center mt-1'>
                <BiErrorCircle className='text-red-500' size={14} />
                <span className='text-[10px] text-red-500 ml-1'>{error?.assigned_to}</span>
                </div>}

            
              </>

          
              <h6 className='text-[11px] font-[600] mb-1 mt-[6px]'>Task Deadline </h6>
              <input readOnly={path === 'create' ? false : (path === 'edit' && singleData?.created_by === user_id) ? false : true} className='border border-l-4 border-l-slate-800 outline-none focus:none focus:ring-0 p-1.5 text-[11px] w-full  text-[11px] border-gray-300 ' type='Date' value={singleData?.dead_line?.slice(0,10)} onChange={(e)=>{setsingleData({...singleData,dead_line:e.target.value});seterror({...error,dead_line:''})}} />

              {error?.dead_line !== '' && error?.dead_line !== undefined &&
                <div className='flex items-center mt-1'>
                <BiErrorCircle className='text-red-500' size={14} />
                <span className='text-[10px] text-red-500 ml-1'>{error?.dead_line}</span>
                </div>}
             


             <TextAreaInput1 value={singleData?.remarks} mandatory={false} error={error?.remarks} handlechange={handlechange} name="remarks" label="Remarks" />

              {/* <div className='flex items-center mt-0 mr-2 -ml-1 mt-2'>
                <h6 onClick={()=>setmodal(!modal)} className="cursor-pointer text-[9.5px] bg-green-700  p-[4px] font-[700] rounded px-[10px] text-white  ml-1">Reminder</h6> 
              </div> */}

              {/* {console.log(" state?.status", state?.status)} */}

               {path != 'create' &&
               <>
               <h6 className='text-[12px] font-semibold mb-1 mt-1'>Status </h6>
                <Select
                value={singleData.status} 
                error={error.status}
                bordered={false}
                placeholder="" 
                disabled={(state?.status == 'Completed' ? singleData?.created_by == user_id ? false : true : false)}
                onChange={(e)=>handleSelect(e,'status')} 
                options={status} 
                className='w-full border border-l-4 border-l-slate-800  outline-0 focus:outline-0 focus:ring-0 focus:border-none  focus:border-transparent focus:ring-offset-0 focus:shadow-none'
                />
               </>}
             <>
             

            
             


            
           


             
              { (singleData?.created_by === user_id || state?.status !== 'Completed') &&

              <div className='flex mt-2 border-t pt-2 w-full items-end '>
                  <div className='mr-2'>
                  <ButtonOutlinedAutoWidth btnName="Cancel" onClick={()=>navigator(-1)} />
                  </div>
                  <ButtonFilledAutoWidth btnName="Save" onClick={submitform} />
              </div>}


           </>

            </>
           
           </div>
           </div>


    </div>
  )
}

export default MDTaskCE