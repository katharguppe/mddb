import React from 'react'
import AtsMenu from './AtsMenu'

function AtsRoot() {
  return (
    <div>
        <AtsMenu />
    </div>
  )
}

export default AtsRoot