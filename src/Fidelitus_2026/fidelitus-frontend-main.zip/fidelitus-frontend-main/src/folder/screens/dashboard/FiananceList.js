import React, { useEffect, useState } from 'react'
import { IoMdAdd } from 'react-icons/io'
import { AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai'
import moment from 'moment'
import { useLocation, useNavigate } from 'react-router-dom'
import { toast } from 'react-hot-toast'
import { Pagination } from '@mui/material'

import { DeleteFinanceDataService, GetFinanceDataService } from '../../services/AdminServicesfile/FinanceData'
import { GetDepartmentService } from '../../services/DepartmentServices'
import { Select } from 'antd'
import { GrPowerReset } from 'react-icons/gr'

import FinanceMenu from '../finance/FinanceMenu'
import SettingsMenu from '../staticscreens/SettingsMenu'
import QtreviewMenu from '../qtreview/QtreviewMenu'

function FiananceList() {
  const navigator = useNavigate()
  const { pathname } = useLocation()
  const path = pathname.split('/')[1]

  const [data, setData] = useState([])
  const [pagination, setPagination] = useState({})
  const [page, setPage] = useState(1)
  const [department, setDepartment] = useState('')
  const [departmentArr, setDepartmentArr] = useState([])

  useEffect(() => {
    getData()
    getDepartments()
  }, [])

  useEffect(() => {
    getData()
  }, [department, page])

  const getData = async () => {
    const response = await GetFinanceDataService(department, page)
    setData(response.data.data)
    setPagination(response.data.pagination)
  }

  const getDepartments = async () => {
    const response = await GetDepartmentService()
    const arr = response?.data?.datas?.map(d => ({ label: d.department_name, value: d.id }))
    setDepartmentArr(arr)
  }

  const deleteData = async (id) => {
    const response = await DeleteFinanceDataService(id)
    if (response.status === 200) {
      toast.success('Deleted Successfully')
      getData()
    }
  }

  const handlePagination = (e, pageNumber) => setPage(pageNumber)

  const rupee = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' })

  return (
    <div className="flex">
      {path === 'finance' && <FinanceMenu />}
      {path === 'settings' && <SettingsMenu />}
      {path === 'qtreview' && <QtreviewMenu />}

      <div className="mx-5 w-[85%]">
        {/* Header */}
        <div className="flex items-center justify-between pt-4 pb-1 border-b">
          <h6 className="text-[14px] font-[800]">Finance Data({pagination?.total})</h6>
          <div className="flex items-center">
            <div className="mr-2 border rounded-md border-slate-300">
              <Select
                value={department || null}
                style={{ width: 130 }}
                options={departmentArr}
                size="small"
                bordered={false}
                className="py-0.5"
                placeholder="Select Department"
                onChange={v => { setPage(1); setDepartment(v) }}
              />
            </div>
            <IoMdAdd
              className="bg-gray-100 p-1.5 z-50 cursor-pointer"
              size={30}
              onClick={() => navigator(`/${path}/finance_dashboard_data/create`)}
            />
            <GrPowerReset
              className="bg-gray-100 p-1.5 ml-2 z-50 cursor-pointer"
              size={30}
              onClick={() => setDepartment('')}
            />
          </div>
        </div>

        {/* No Data */}
        {data.length === 0 && (
          <div className="grid items-center justify-center mt-20 place-items-center">
            <img
              src="https://fidecrmfiles.s3.amazonaws.com/NoDataFound1.png"
              className="object-contain w-40 h-40"
            />
            <h6 className="font-bold text-[14px] -mt-10">No data found</h6>
            <h6 className="font-[500] text-slate-700 text-[12px] -mt-2">
              Try Any Filter Option to See the "Invoice Report" For the Vertical
            </h6>
          </div>
        )}

        {/* Data Table */}
        {data.length > 0 && (
          <div className="mt-4 overflow-x-auto border border-gray-200 rounded-lg">
            {/* Table Header */}
       {/* Table Header */}
       <div className="flex bg-slate-700 text-white text-[12px] font-semibold h-[40px] items-center">
  <h6 className="flex-1 p-2 text-center border-r">SL NO</h6>
  <h6 className="flex-1 p-2 border-r">Department</h6>
  <h6 className="flex-1 p-2 border-r">Date</h6>
  <h6 className="flex-1 p-2 border-r">Yearly Target</h6>
  <h6 className="flex-1 p-2 border-r">Half Yearly Target</h6>
  <h6 className="flex-1 p-2 border-r">Achieved Revenue</h6>
  <h6 className="flex-1 p-2 border-r">Expenses</h6>
  <h6 className="flex-1 p-2 border-r">Net Revenue</h6>
  <h6 className="flex-1 p-2 border-r">Shortfall</h6>
  <h6 className="flex-1 p-2 border-r">Action</h6>
</div>

            {/* Table Rows */}
            {data.map((d, i) => (
  <div
    key={d._id}
    className="flex text-[12px] font-medium odd:bg-white even:bg-gray-50 hover:bg-gray-100 transition"
  >
    <h6 className="flex-1 p-2 font-bold text-center border-r">
      {page === 1 ? i + 1 : (page - 1) * pagination.limit + (i + 1)}
    </h6>
    <h6 className="flex-1 p-2 font-semibold border-r">{d?.department?.department_name}</h6>
    <h6 className="flex-1 p-2 font-bold border-r">
      {moment(d.from).format('MMM')} - {moment(d.to).format('MMM')}
    </h6>
    <h6 className="flex-1 p-2 font-bold border-r">{d?.invoice_raised_no}</h6>
    <h6 className="flex-1 p-2 font-semibold border-r">{rupee.format(d?.invoice_amount)?.split('.')[0]}</h6>
    <h6 className="flex-1 p-2 font-semibold border-r">{rupee.format(d?.amount_collected)?.split('.')[0]}</h6>
    <h6 className="flex-1 p-2 font-semibold border-r">{d?.expenses !== undefined && rupee.format(d?.expenses)?.split('.')[0]}</h6>
    <h6 className="flex-1 p-2 font-semibold border-r">{rupee.format(d?.total_outstanding)?.split('.')[0]}</h6>
    <h6 className="flex-1 p-2 text-center border-r">
      <span className={`px-2 py-1 text-[12px] rounded ${d?.amount_collected - d?.expenses < 0 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
        {d?.amount_collected - d?.expenses < 0 ? 'Loss' : 'Profit'}
      </span>
    </h6>
    <h6 className="flex justify-center flex-1 gap-2 p-2">
      <AiOutlineEdit
        size={16}
        className="text-blue-600 cursor-pointer"
        onClick={() => navigator(`/${path}/finance_dashboard_data/edit`, { state: d })}
      />
      <AiOutlineDelete
        size={16}
        className="text-red-600 cursor-pointer"
        onClick={() => deleteData(d?._id)}
      />
    </h6>
  </div>
))}

            {/* Pagination */}
            {pagination?.total > pagination?.limit && (
              <div className="flex items-center justify-center mt-6">
                <Pagination
                  size="small"
                  page={page}
                  className="flex justify-center pb-10 my-5"
                  count={pagination?.totalPages}
                  onChange={handlePagination}
                />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

export default FiananceList












//================================================>>>>> Old one updating with table


// import React, { useEffect, useState } from 'react'
// import {IoMdAdd} from 'react-icons/io'
// import { DeleteFinanceDataService, GetFinanceDataService } from '../../services/AdminServicesfile/FinanceData'
// import moment from 'moment'
// import { useLocation, useNavigate } from 'react-router-dom'
// import {AiOutlineEdit,AiOutlineDelete} from 'react-icons/ai'
// import { toast } from 'react-hot-toast'
// import { GetDepartmentService } from '../../services/DepartmentServices'
// import {  Select } from 'antd'
// import {
//   Pagination,
// } from "@mui/material";
// import {GrPowerReset} from 'react-icons/gr';
// import SettingsMenu from '../staticscreens/SettingsMenu'
// import FinanceMenu from '../finance/FinanceMenu'
// import QtreviewMenu from '../qtreview/QtreviewMenu'

// function FiananceList() {

//   const  navigator = useNavigate()
//   const [data,setdata] = useState([])
//   const [pagination,setpagination] = useState({})
//   const [page,setpage] = useState(1)

//   const [department,setdepartment] = useState('')
//   const [departmentArr,setdepartmentArr] = useState('')

//   const {pathname} = useLocation()
 
//   const path = pathname.split('/')[1]



  
//   useEffect(()=>{
//     getData()
//     getDepartment()
//   },[])

//   useEffect(()=>{
//     getData()
//   },[department,page])

//   async function getData(){
//     const response = await GetFinanceDataService(department,page)
//     setdata(response.data.data)
//     setpagination(response.data.pagination)
//   }

  
//   let rupee = new Intl.NumberFormat('en-IN', {
//     style: 'currency',
//     currency: 'INR',
//   });

//   const getDepartment = async() =>{
//     const response = await GetDepartmentService()
//     let arr = []
//     response?.data?.datas?.forEach((d)=>{
//        arr.push({label:d?.department_name,value:d?.id})
//     })
//     setdepartmentArr(arr)
//   }


//   async function deleteData(id){
//     const response = await DeleteFinanceDataService(id)
//     if(response.status === 200){
//         getData()
//         toast.success('Deleted Successfully')
//     }
//   }

//   const handlePagination = (e, pageNumber) => {
//     setpage(pageNumber)
//   }

//   return (
//     <div className='flex'>
//       {path === 'finance' &&
//       <FinanceMenu />}
//       {path === 'settings' &&
//       <SettingsMenu /> }
//        {path === 'qtreview' &&
//       <QtreviewMenu /> }
//     <div className='mx-5 w-[85%]'>
//         <div className='flex items-center justify-between pt-4 pb-1 border-b'>
//         <h6 className='text-[14px] font-[800]'>Finance Data123 ({pagination?.total})</h6>
//         <div className='flex items-center'>
//             <div className='mr-2 border rounded-md border-slate-300'>
//             <Select 
//              value={department !== '' ? department : null} 
//              style={{ width: 130 }}
//              options={departmentArr} 
//              size='small' 
//              bordered={false} 
//              className='py-0.5' 
//              placeholder='Select Department' 
//              onChange={(v)=>{setpage(1);setdepartment(v)}} />
//             </div>
//             <IoMdAdd className='bg-gray-100 p-1.5 z-50' size={30} onClick={()=>navigator(`/${path}/finance_dashboard_data/create`)} />
//             <GrPowerReset className='bg-gray-100 p-1.5 ml-2 z-50' size={30} onClick={()=>setdepartment('')} />
//         </div>
//         </div>

//         {data.length === 0 &&
//         <div className='grid items-center justify-center mt-20 place-items-center'>
//           <img src={'https://fidecrmfiles.s3.amazonaws.com/NoDataFound1.png'} className='object-contain w-40 h-40' /> 
//           <h6 className='font-bold text-[14px] -mt-10'>No data found</h6>
//           <h6 className='font-[500] text-slate-700 text-[12.5px] -mt-2'>Try Any Filter Option to See the "Invoice Report" For the Vertical</h6>
//         </div>}
       
//         {data?.length > 0 &&
//         <div>
//             <div className='flex items-center mt-1 border-t border-b border-l border-r'>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[4.5%] max-w-[4.5%] w-[4.5%] border-r'>SL NO</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Department</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[15%] max-w-[15%]  w-[15%] border-r'>Date</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[4.5%] max-w-[4.5%]  w-[4.5%] border-r'>No</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[15%] max-w-[15%]  w-[15%] border-r'>Invoice Raised Amount</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[13%] max-w-[13%]  w-[13%] border-r'>Amount Collected</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[13%] max-w-[13%]  w-[13%] border-r'>Total Outstanding</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Expenses</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Profit / Loss</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Action</h6>
//             </div>
            
//             {data?.map((d,i)=>(
//             <div className='flex items-center border-b border-l border-r'>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[4.5%] font-[800] max-w-[4.5%] w-[4.5%] border-r'>{page === 1 ? i+1 : ((page-1) * pagination.limit) + (i+1)}</h6>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[10%] max-w-[10%] w-[10%] border-r'>{d?.department?.department_name}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[15%] max-w-[15%] w-[15%] border-r'>{moment(d?.from).format('DD-MM-YYYY')} -  {moment(d?.to).format('DD-MM-YYYY')}</h6>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[4.5%] max-w-[4.5%] w-[4.5%] border-r'>{d?.invoice_raised_no}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[15%] max-w-[15%] w-[15%] font-[600] border-r'>{rupee?.format(d?.invoice_amount)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[13%] max-w-[13%] w-[13%] font-[600] border-r'>{rupee?.format(d?.amount_collected)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[13%] max-w-[13%] w-[13%] font-[600] border-r'>{rupee?.format(d?.total_outstanding)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>{d?.expenses !== undefined && rupee?.format(d?.expenses)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'> <span className='bg-slate-100 p-1 text-[10px] text-slate-600 px-2'>{(d?.amount_collected - d?.expenses) < 0 ? 'Loss' : 'Profit'}</span> </h6>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[10%] max-w-[10%]  w-[10%]  flex'><AiOutlineEdit size={13} onClick={()=>navigator(`/${path}/finance_dashboard_data/edit`,{state:d})} /> <AiOutlineDelete onClick={()=>deleteData(d?._id)} className='ml-2' size={13} /></h6>

//             </div>
//             ))}

//     <div className="flex items-center justify-center mt-10 tex-center ">
//     {(pagination?.total > pagination?.limit &&
//         <Pagination size={'small'} page={page} className="flex justify-center pb-20 my-10" count={pagination?.totalPages} onChange={handlePagination} />
//     )}
//     </div>
//         </div>}
//     </div>
//     </div> 
//   )
// }

// export default FiananceList








//==================================>>>> Qt update



// import React, { useEffect, useState } from 'react'
// import {IoMdAdd} from 'react-icons/io'
// import { DeleteFinanceDataService, GetFinanceDataService } from '../../services/AdminServicesfile/FinanceData'
// import moment from 'moment'
// import { useLocation, useNavigate } from 'react-router-dom'
// import {AiOutlineEdit,AiOutlineDelete} from 'react-icons/ai'
// import { toast } from 'react-hot-toast'
// import { GetDepartmentService } from '../../services/DepartmentServices'
// import {  Select } from 'antd'
// import {
//   Pagination,
// } from "@mui/material";
// import {GrPowerReset} from 'react-icons/gr';
// import SettingsMenu from '../staticscreens/SettingsMenu'
// import FinanceMenu from '../finance/FinanceMenu'

// function FiananceList() {

//   const  navigator = useNavigate()
//   const [data,setdata] = useState([])
//   const [pagination,setpagination] = useState({})
//   const [page,setpage] = useState(1)

//   const [department,setdepartment] = useState('')
//   const [departmentArr,setdepartmentArr] = useState('')

//   const {pathname} = useLocation()
 
//   const path = pathname.split('/')[1]



  
//   useEffect(()=>{
//     getData()
//     getDepartment()
//   },[])

//   useEffect(()=>{
//     getData()
//   },[department,page])

//   async function getData(){
//     const response = await GetFinanceDataService(department,page)
//     setdata(response.data.data)
//     setpagination(response.data.pagination)
//   }

  
//   let rupee = new Intl.NumberFormat('en-IN', {
//     style: 'currency',
//     currency: 'INR',
//   });

//   const getDepartment = async() =>{
//     const response = await GetDepartmentService()
//     let arr = []
//     response?.data?.datas?.forEach((d)=>{
//        arr.push({label:d?.department_name,value:d?.id})
//     })
//     setdepartmentArr(arr)
//   }


//   async function deleteData(id){
//     const response = await DeleteFinanceDataService(id)
//     if(response.status === 200){
//         getData()
//         toast.success('Deleted Successfully')
//     }
//   }

//   const handlePagination = (e, pageNumber) => {
//     setpage(pageNumber)
//   }

//   return (
//     <div className='flex'>
//       {path === 'finance' &&
//       <FinanceMenu />}
//       {path === 'settings' &&
//       <SettingsMenu /> }
//     <div className='mx-5 w-[85%]'>
//         <div className='flex items-center justify-between pt-4 pb-1 border-b'>
//         <h6 className='text-[14px] font-[800]'>Finance Data123 ({pagination?.total})</h6>
//         <div className='flex items-center'>
//             <div className='mr-2 border rounded-md border-slate-300'>
//             <Select 
//              value={department !== '' ? department : null} 
//              style={{ width: 130 }}
//              options={departmentArr} 
//              size='small' 
//              bordered={false} 
//              className='py-0.5' 
//              placeholder='Select Department' 
//              onChange={(v)=>{setpage(1);setdepartment(v)}} />
//             </div>
//             <IoMdAdd className='bg-gray-100 p-1.5 z-50' size={30} onClick={()=>navigator(`/${path}/finance_dashboard_data/create`)} />
//             <GrPowerReset className='bg-gray-100 p-1.5 ml-2 z-50' size={30} onClick={()=>setdepartment('')} />
//         </div>
//         </div>

//         {data.length === 0 &&
//         <div className='grid items-center justify-center mt-20 place-items-center'>
//           <img src={'https://fidecrmfiles.s3.amazonaws.com/NoDataFound1.png'} className='object-contain w-40 h-40' /> 
//           <h6 className='font-bold text-[14px] -mt-10'>No data found</h6>
//           <h6 className='font-[500] text-slate-700 text-[12.5px] -mt-2'>Try Any Filter Option to See the "Invoice Report" For the Vertical</h6>
//         </div>}
       
//         {data?.length > 0 &&
//         <div>
//             <div className='flex items-center mt-1 border-t border-b border-l border-r'>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[4.5%] max-w-[4.5%] w-[4.5%] border-r'>SL NO</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Department</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[15%] max-w-[15%]  w-[15%] border-r'>Date</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[4.5%] max-w-[4.5%]  w-[4.5%] border-r'>No</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[15%] max-w-[15%]  w-[15%] border-r'>Invoice Raised Amount</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[13%] max-w-[13%]  w-[13%] border-r'>Amount Collected</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[13%] max-w-[13%]  w-[13%] border-r'>Total Outstanding</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Expenses</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Profit / Loss</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Action</h6>
//             </div>
            
//             {data?.map((d,i)=>(
//             <div className='flex items-center border-b border-l border-r'>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[4.5%] font-[800] max-w-[4.5%] w-[4.5%] border-r'>{page === 1 ? i+1 : ((page-1) * pagination.limit) + (i+1)}</h6>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[10%] max-w-[10%] w-[10%] border-r'>{d?.department?.department_name}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[15%] max-w-[15%] w-[15%] border-r'>{moment(d?.from).format('DD-MM-YYYY')} -  {moment(d?.to).format('DD-MM-YYYY')}</h6>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[4.5%] max-w-[4.5%] w-[4.5%] border-r'>{d?.invoice_raised_no}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[15%] max-w-[15%] w-[15%] font-[600] border-r'>{rupee?.format(d?.invoice_amount)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[13%] max-w-[13%] w-[13%] font-[600] border-r'>{rupee?.format(d?.amount_collected)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[13%] max-w-[13%] w-[13%] font-[600] border-r'>{rupee?.format(d?.total_outstanding)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>{d?.expenses !== undefined && rupee?.format(d?.expenses)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'> <span className='bg-slate-100 p-1 text-[10px] text-slate-600 px-2'>{(d?.amount_collected - d?.expenses) < 0 ? 'Loss' : 'Profit'}</span> </h6>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[10%] max-w-[10%]  w-[10%]  flex'><AiOutlineEdit size={13} onClick={()=>navigator(`/${path}/finance_dashboard_data/edit`,{state:d})} /> <AiOutlineDelete onClick={()=>deleteData(d?._id)} className='ml-2' size={13} /></h6>

//             </div>
//             ))}

//     <div className="flex items-center justify-center mt-10 tex-center ">
//     {(pagination?.total > pagination?.limit &&
//         <Pagination size={'small'} page={page} className="flex justify-center pb-20 my-10" count={pagination?.totalPages} onChange={handlePagination} />
//     )}
//     </div>
//         </div>}
//     </div>
//     </div> 
//   )
// }

// export default FiananceList






/// /////////>>>> Old data

// import React, { useEffect, useState } from 'react'
// import {IoMdAdd} from 'react-icons/io'
// import { DeleteFinanceDataService, GetFinanceDataService } from '../../services/AdminServicesfile/FinanceData'
// import moment from 'moment'
// import { useLocation, useNavigate } from 'react-router-dom'
// import {AiOutlineEdit,AiOutlineDelete} from 'react-icons/ai'
// import { toast } from 'react-hot-toast'
// import { GetDepartmentService } from '../../services/DepartmentServices'
// import {  Select } from 'antd'
// import {
//   Pagination,
// } from "@mui/material";
// import {GrPowerReset} from 'react-icons/gr';
// import SettingsMenu from '../staticscreens/SettingsMenu'
// import FinanceMenu from '../finance/FinanceMenu'

// function FiananceList() {

//   const  navigator = useNavigate()
//   const [data,setdata] = useState([])
//   const [pagination,setpagination] = useState({})
//   const [page,setpage] = useState(1)

//   const [department,setdepartment] = useState('')
//   const [departmentArr,setdepartmentArr] = useState('')

//   const {pathname} = useLocation()
 
//   const path = pathname.split('/')[1]



  
//   useEffect(()=>{
//     getData()
//     getDepartment()
//   },[])

//   useEffect(()=>{
//     getData()
//   },[department,page])

//   async function getData(){
//     const response = await GetFinanceDataService(department,page)
//     setdata(response.data.data)
//     setpagination(response.data.pagination)
//   }

  
//   let rupee = new Intl.NumberFormat('en-IN', {
//     style: 'currency',
//     currency: 'INR',
//   });

//   const getDepartment = async() =>{
//     const response = await GetDepartmentService()
//     let arr = []
//     response?.data?.datas?.forEach((d)=>{
//        arr.push({label:d?.department_name,value:d?.id})
//     })
//     setdepartmentArr(arr)
//   }


//   async function deleteData(id){
//     const response = await DeleteFinanceDataService(id)
//     if(response.status === 200){
//         getData()
//         toast.success('Deleted Successfully')
//     }
//   }

//   const handlePagination = (e, pageNumber) => {
//     setpage(pageNumber)
//   }

//   return (
//     <div className='flex'>
//       {path === 'finance' &&
//       <FinanceMenu />}
//       {path === 'settings' &&
//       <SettingsMenu /> }
//     <div className='mx-5 w-[85%]'>
//         <div className='flex items-center justify-between pt-4 pb-1 border-b'>
//         <h6 className='text-[14px] font-[800]'>Finance Data ({pagination?.total})</h6>
//         <div className='flex items-center'>
//             <div className='mr-2 border rounded-md border-slate-300'>
//             <Select 
//              value={department !== '' ? department : null} 
//              style={{ width: 130 }}
//              options={departmentArr} 
//              size='small' 
//              bordered={false} 
//              className='py-0.5' 
//              placeholder='Select Department' 
//              onChange={(v)=>{setpage(1);setdepartment(v)}} />
//             </div>
//             <IoMdAdd className='bg-gray-100 p-1.5 z-50' size={30} onClick={()=>navigator(`/${path}/finance_dashboard_data/create`)} />
//             <GrPowerReset className='bg-gray-100 p-1.5 ml-2 z-50' size={30} onClick={()=>setdepartment('')} />
//         </div>
//         </div>

//         {data.length === 0 &&
//         <div className='grid items-center justify-center mt-20 place-items-center'>
//           <img src={'https://fidecrmfiles.s3.amazonaws.com/NoDataFound1.png'} className='object-contain w-40 h-40' /> 
//           <h6 className='font-bold text-[14px] -mt-10'>No data found</h6>
//           <h6 className='font-[500] text-slate-700 text-[12.5px] -mt-2'>Try Any Filter Option to See the "Invoice Report" For the Vertical</h6>
//         </div>}
       
//         {data?.length > 0 &&
//         <div>
//             <div className='flex items-center mt-1 border-t border-b border-l border-r'>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[4.5%] max-w-[4.5%] w-[4.5%] border-r'>SL NO</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Department</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[15%] max-w-[15%]  w-[15%] border-r'>Date</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[4.5%] max-w-[4.5%]  w-[4.5%] border-r'>No</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[15%] max-w-[15%]  w-[15%] border-r'>Invoice Raised Amount</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[13%] max-w-[13%]  w-[13%] border-r'>Amount Collected</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[13%] max-w-[13%]  w-[13%] border-r'>Total Outstanding</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Expenses</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Profit / Loss</h6>
//                 <h6 className='text-[12px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>Action</h6>
//             </div>
            
//             {data?.map((d,i)=>(
//             <div className='flex items-center border-b border-l border-r'>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[4.5%] font-[800] max-w-[4.5%] w-[4.5%] border-r'>{page === 1 ? i+1 : ((page-1) * pagination.limit) + (i+1)}</h6>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[10%] max-w-[10%] w-[10%] border-r'>{d?.department?.department_name}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[15%] max-w-[15%] w-[15%] border-r'>{moment(d?.from).format('DD-MM-YYYY')} -  {moment(d?.to).format('DD-MM-YYYY')}</h6>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[4.5%] max-w-[4.5%] w-[4.5%] border-r'>{d?.invoice_raised_no}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[15%] max-w-[15%] w-[15%] font-[600] border-r'>{rupee?.format(d?.invoice_amount)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[13%] max-w-[13%] w-[13%] font-[600] border-r'>{rupee?.format(d?.amount_collected)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[500]  p-1 min-w-[13%] max-w-[13%] w-[13%] font-[600] border-r'>{rupee?.format(d?.total_outstanding)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'>{d?.expenses !== undefined && rupee?.format(d?.expenses)?.split('.')[0]}</h6>
//                 <h6 className='text-[11.5px] font-[700] p-1 min-w-[10%] max-w-[10%]  w-[10%] border-r'> <span className='bg-slate-100 p-1 text-[10px] text-slate-600 px-2'>{(d?.amount_collected - d?.expenses) < 0 ? 'Loss' : 'Profit'}</span> </h6>
//                 <h6 className='text-[11.5px] font-[500] p-1 min-w-[10%] max-w-[10%]  w-[10%]  flex'><AiOutlineEdit size={13} onClick={()=>navigator(`/${path}/finance_dashboard_data/edit`,{state:d})} /> <AiOutlineDelete onClick={()=>deleteData(d?._id)} className='ml-2' size={13} /></h6>

//             </div>
//             ))}

//     <div className="flex items-center justify-center mt-10 tex-center ">
//     {(pagination?.total > pagination?.limit &&
//         <Pagination size={'small'} page={page} className="flex justify-center pb-20 my-10" count={pagination?.totalPages} onChange={handlePagination} />
//     )}
//     </div>
//         </div>}
//     </div>
//     </div> 
//   )
// }

// export default FiananceList