import React,{useState,useEffect} from 'react'
import { GetDepartmentService } from '../../services/DepartmentServices'
import { GetFinanceDataService } from '../../services/AdminServicesfile/FinanceData'
import {
  Pagination,
} from "@mui/material";
import moment from 'moment';
import {GoGraph} from 'react-icons/go';
import Chart from "react-apexcharts";
import { Drawer } from 'antd';
import {IoMdClose} from 'react-icons/io';
import SettingsMenu from '../staticscreens/SettingsMenu';
import { useLocation } from 'react-router-dom';
import FinanceMenu from '../finance/FinanceMenu';
import QtreviewMenu from '../qtreview/QtreviewMenu';

function FinanceDashboard() {
  // const [graph_value,setgraph_value] = useState({options:'',series:[]})
  const [graph_value, setgraph_value] = useState({
    options: {
      chart: { type: "donut" },
      labels: [],
      legend: { fontWeight: "bold" },
      plotOptions: { pie: { size: "100%", distributed: true } },
    },
    series: [],
    shotfall: 0,
  });
  
  const [department,setdepartment] = useState([])
  const [selected_department,setselected_department] = useState({})
  const [data,setdata] = useState([])
  const [singleData,setsingleData] = useState({})
  const [pagination,setpagination] = useState([])
  const [page,setpage] = useState(1)

  const [selected_Data,setselected_Data] = useState('')

  const [graph,setgraph] = useState(false)
  

  const {pathname} = useLocation()
 
  const path = pathname.split('/')[1]

  useEffect(()=>{
    getDepartment()
  },[])

  const getDepartment = async() =>{
      const response = await GetDepartmentService()
      setdepartment(response.data.datas)
  }

  useEffect(()=>{
    if(selected_department.id !== null && selected_department.id !== undefined){
      getData()
    }
  },[page,selected_department])
  
  let rupee = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
  });

  async function getData(){
    const response = await GetFinanceDataService(selected_department?.id,page)
    if(page === 1){
      setsingleData(response.data.data[0])
    }
    setdata(response.data.data)
    setpagination(response.data.pagination)
  }


  // async function setgraph_valuefun(graph_data) {
  //   const invoiceAmount = Number(graph_data?.invoice_amount) || 0;
  //   const totalOutstanding = Number(graph_data?.total_outstanding) || 0;
  //   const profitLoss = invoiceAmount - totalOutstanding; // already number now
  
  //   // ✅ Ensure numeric addition
  //   const shotfall = Number(invoiceAmount) + Math.abs(Number(profitLoss));
  
  //   // Labels for chart
  //   let labels = [
  //     `Half Yearly Target ${rupee.format(invoiceAmount)}`,
  //     `Net Revenue ${rupee.format(totalOutstanding)}`,
  //     `Shortfall ${rupee.format(Math.abs(profitLoss))}`
  //   ];
  
  //   // Series as % of invoice amount
  //   let series = [
  //     100,
  //     (totalOutstanding / invoiceAmount) * 100,
  //     (Math.abs(profitLoss) / invoiceAmount) * 100
  //   ];
  
  //   setgraph_value({
  //     ...graph_value,
  //     series,
  //     shotfall, // always integer/number
  //     options: {
  //       chart: { type: 'donut' },
  //       legend: { fontWeight: 'bold' },
  //       plotOptions: { pie: { size: '100%', distributed: true } },
  //       labels
  //     }
  //   });
  // }

  async function setgraph_valuefun(graph_data) {
    const invoiceAmount = Number(graph_data?.invoice_amount) || 0; // Half Yearly Target
    const totalOutstanding = Number(graph_data?.total_outstanding) || 0;
    const amountCollected = Number(graph_data?.amount_collected) || 0;
    const profitLoss = invoiceAmount-amountCollected;
  
   const nextQaurter = invoiceAmount/2;
 

    // ✅ Ensure numeric addition
    const shotfall =  profitLoss;
   // (d?.amount_collected || 0)  - (d?.invoice_amount || 0);
    // Labels for chart
    let labels = [
      `Half Yearly Target ${rupee.format(invoiceAmount)}`,
      `Net Revenue ${rupee.format(totalOutstanding)}`,
      `Shortfall ${rupee.format(Math.abs(profitLoss))}`
    ];
  
    // Series as % of invoice amount
    let series = [
      100,
      (totalOutstanding / invoiceAmount) * 100,
      (Math.abs(profitLoss) / invoiceAmount) * 100
    ];
  
    setgraph_value({
      ...graph_value,
      series,
      shotfall, // next quarter target
      nextQaurter,
      halfYearTarget: invoiceAmount, // ✅ keep Half Yearly target separately
      options: {
        chart: { type: "donut" },
        legend: { fontWeight: "bold" },
        plotOptions: { pie: { size: "100%", distributed: true } },
        labels
      }
    });
  }
  
  
  const handlePagination = (e, pageNumber) => {
    setpage(pageNumber)
  }
  

  const categories = [];
  const splitSeries = {
    name: "Values",
    data: []
  };
  const colorsArray = []; // for unique colors
  
  data.forEach((d) => {
    // Yearly Target
    categories.push(`Yearly Target`);
    splitSeries.data.push(d?.invoice_raised_no || 0);
    colorsArray.push("#2563eb"); // blue
  
    // Quarterly Target
    categories.push(`Half Yearly Target`);
    splitSeries.data.push(d?.invoice_amount || 0);
    colorsArray.push("#16a34a"); // green
  
    // Actual Revenue
    categories.push(`Achieved Revenue`);
    splitSeries.data.push(d?.amount_collected || 0);
    colorsArray.push("#f59e0b"); // red
  
    // Expenses
    categories.push(`Expenses`);
    splitSeries.data.push(d?.expenses || 0);
    colorsArray.push("#dc2626"); // orange
  
    // Net Profit
    categories.push(`Net Revenue`);
    splitSeries.data.push(d?.total_outstanding || 0);
    colorsArray.push("#7c3aed"); // purple
  });
  
  

  const formatNumber = (val) => {
    return new Intl.NumberFormat("en-IN").format(val); // adds commas
  };
  
  
  return (
    <div className=''>
       <div className='flex'>
       {path === 'finance' &&
      <FinanceMenu />}
      {path === 'settings' &&
      <SettingsMenu /> }
            {path === 'qtreview' &&
      <QtreviewMenu /> }

      <Drawer closable={false} maskStyle={{background:'black',opacity:'0.7'}} width={'50%'} placement="right" onClose={()=>setgraph(false)} open={graph}>
        <div className='relative'>
          <IoMdClose className='absolute right-0' onClick={()=>setgraph(false)} />
         <h6 className='text-[14px] font-[700]'>Graphical Representation</h6>
         <h6 className='leading-tight bg-gray-100 p-2 text-[13px] my-2'>See the graphical representation of revenue or loss for the period of invocie from (<span className='text-[10px] font-[900]'>{moment(selected_Data?.from).format('LL')} - {moment(selected_Data?.to).format('LL')}</span>)</h6>
         
         <div className='w-4/5'>
         <Chart
              options={graph_value?.options}
              type="donut"
              height="290"
              series={graph_value?.series}
              width={'500'}
            />
        </div>
        </div>
      </Drawer>
      
       <div className='w-[85%] px-4 mt-5'>
        <h6 className='border-b pb-2 text-[13.5px] font-[800]'>Quarterly review--updating</h6>
{/* Toggle Buttons */}
{/* Toggle Buttons */}
<div className="flex flex-wrap justify-center gap-2 mt-4">
  {department
    ?.filter(
      (d) =>
        ![
          "MD Personal",
          "Software Team",
          "FTS Team",
          "Finance Team",
        ].includes(d?.department_name)
    )
    .map((d) => (
      <button
        key={d?.id}
        onClick={async () => {
          setpage(1);
          setselected_department(d);

          // Fetch data for this department
          const response = await GetFinanceDataService(d?.id, 1);
          setdata(response.data.data);
          setpagination(response.data.pagination);

          // Automatically call the graph function for the first item
          if (response.data.data?.length > 0) {
            const firstItem = response.data.data[0];
            setselected_Data(firstItem);
            setgraph_valuefun(firstItem);
          }
        }}
        className={`
          px-4 py-2 rounded-full text-sm font-semibold transition
          duration-300 ease-in-out
          border border-gray-300
          ${
            selected_department?.id === d?.id
              ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
              : "bg-white text-gray-700 hover:bg-blue-50 hover:text-blue-700"
          }
        `}
      >
        {d?.department_name === "Digital Media" ? "FMS TurnOver" : d?.department_name}
      </button>
    ))}
</div>



       {data.length === 0 &&
        <div className='grid items-center justify-center mt-20 place-items-center'>
          <img src={'https://fidecrmfiles.s3.amazonaws.com/NoDataFound1.png'} className='object-contain w-40 h-40' /> 
          <h6 className='font-bold text-[14px] -mt-10'>No data found</h6>
          <h6 className='font-[500] text-slate-700 text-[12.5px] -mt-2'>Try Any Filter Option to See the "Invoice Report" For the Vertical</h6>
        </div>}

        {data.length > 0 &&
          <>    
<div className="mt-10 overflow-hidden border border-gray-200 rounded-lg shadow-md">
  {/* Top Bar */}
  <h6 className="text-[14px] font-[700] px-3 py-3 bg-gray-100 border-b">
    Data Found ({pagination?.total})
  </h6>

  {/* Header Row */}
<div className="flex bg-slate-700 text-white text-[13px] font-semibold h-[50px] items-center">
  <h6 className="p-3 w-[6%] text-[10px] text-center border-r">SL NO</h6>
  {/* <h6 className="p-3 w-[18%] border-r">Date</h6> */}
  <h6 className="p-3 w-[14%] border-r">Yearly Target</h6>
  <h6 className="p-3 w-[14%] border-r">Half Yearly Target</h6> {/* ✅ changed */}
  {/* <h6 className="p-3 w-[14%] border-r">Achieved Revenue</h6>  */}
  <h6 className="p-3 w-[14%] border-r">
    {selected_department?.department_name === "Shilpa Foundation"
      ? "Fund Received"
      : "Achieved Revenue"}
  </h6>
  <h6 className="p-3 w-[14%] border-r">Expenses</h6>
  <h6 className="p-3 w-[14%] border-r">Net Revenue</h6> {/* ✅ kept same */}
  <h6 className="p-3 w-[12%] border-r text-center">Shortfall</h6>
  <h6 className="p-3 w-[6%] text-center">Action</h6>
</div>

  {/* Data Rows */}
  {data?.map((d, i) => (
    <div
      key={d?._id}
      className="flex text-[15px] font-medium odd:bg-white even:bg-gray-50 hover:bg-gray-100 transition"
    >
      {/* SL NO */}
      <h6 className="p-3 w-[6%] text-center font-bold border-r">
        {page === 1 ? i + 1 : (page - 1) * pagination.limit + (i + 1)}
      </h6>

      {/* Date (Bold) */}
      {/* <h6 className="p-3 w-[18%] text-[12px] border-r font-bold">
  {moment(d?.from).format("MMM")} - {moment(d?.to).format("MMM")}
</h6> */}

      {/* Yearly Target (Bold + ₹ symbol) */}
      <h6 className="p-3 w-[14%] border-r font-bold">
        {rupee?.format(d?.invoice_raised_no)?.split(".")[0]}
      </h6>

      {/* Quarterly Target */}
      <h6 className="p-3 w-[14%] border-r font-semibold">
        {rupee?.format(d?.invoice_amount)?.split(".")[0]}
      </h6>

      {/* Actual Revenue */}
      <h6 className="p-3 w-[14%] border-r font-semibold">
        {rupee?.format(d?.amount_collected)?.split(".")[0]}
      </h6>

      {/* Expenses */}
      <h6 className="p-3 w-[14%] border-r font-semibold">
        {d?.expenses !== undefined && rupee?.format(d?.expenses)?.split(".")[0]}
      </h6>

      {/* Net Profit */}
      <h6 className="p-3 w-[14%] border-r font-semibold">
        {rupee?.format(d?.total_outstanding)?.split(".")[0]}
      </h6>

{/* Profit / Loss */}
<h6 className="p-3 w-[12%] border-r text-center">
  {(() => {
    const difference = (d?.amount_collected || 0)  - (d?.invoice_amount || 0);
    const formattedDiff = formatNumber(Math.abs(difference)); // add commas
    if (difference >= 0) {
      return (
        <span className="px-2 py-1 text-[13px] font-bold  text-green-600 rounded">
         {formattedDiff} <span className="px-2 py-1 text-green-600 bg-green-100 ">Profit</span> 
        </span>
      );
    } else {
      return (
        <span className="px-2  py-1 text-[13px] font-bold  text-red-600 rounded">
        {formattedDiff}  <span className="px-2 py-1 text-red-600 bg-red-100 ">Loss</span> 
        </span>
      );
    }
  })()}
</h6>

      {/* Action */}
      <h6
        className="p-3 w-[6%] text-center cursor-pointer"
        onClick={() => {
          setselected_Data(d);
          setgraph_valuefun(d);
          setgraph(true);
        }}
      >
        <GoGraph size={20} className="mx-auto text-slate-600 hover:text-slate-900" />
      </h6>
    </div>
  ))}
</div>
       </>
        }    
{/* Chart Section - Show only if data exists */}
{data.length > 0 && (
  <div className="p-5 mt-10 bg-white border border-gray-200 rounded-lg shadow-md">
    <h6 className="text-[16px] font-[700] mb-4">Visual Representation</h6>

    {/* ✅ Bar Chart with fixed 300px height */}
    <div className="w-full h-[300px]">
      <Chart
        type="bar"
        height="100%"
        width="100%"
        series={[splitSeries]}
        options={{
          chart: { type: "bar", toolbar: { show: true } },
          plotOptions: {
            bar: {
              horizontal: false,
              columnWidth: "35%",
              borderRadius: 4,
              distributed: true,
            },
          },
          colors: colorsArray,
          dataLabels: {
            enabled: true,
            style: {
              fontSize: "12px",
              fontWeight: "600",
              colors: ["#fff"],
            },
            formatter: function (val) {
              return formatNumber(val);
            },
            offsetY: -6,
          },
          xaxis: {
            categories: categories,
            labels: { style: { fontSize: "13px", fontWeight: 600 } },
          },
          yaxis: {
            labels: { formatter: (val) => `₹${formatNumber(val)}` },
          },
          legend: { show: false },
        }}
      />
    </div>
  </div>
)}

<div className="flex justify-center mt-10">
  <div className="w-full h-[450px] bg-white border border-gray-200 rounded-lg shadow-md p-4">
    {/* <h6 className="text-[16px] font-[700] mb-4 text-center">Distribution View</h6> */}
    <div className="relative">
      <h6 className="text-[14px] font-[700]">Graphical Representation</h6>
      <h6 className="leading-tight bg-gray-100 p-2 text-[13px] my-2">
      Visual comparison of revenue achieved vs. target and the next target to achieve
        {/* (<span className="text-[10px] font-[900]">
          {moment(selected_Data?.from).format("LL")} - {moment(selected_Data?.to).format("LL")}
        </span>) */}
      </h6>

      {/* ✅ Flex container for chart + shortfall */}
      <div className="flex items-center">
        {/* Chart */}
        <div className="w-3/5">
          <Chart
            options={graph_value?.options}
            type="donut"
            height="290"
            series={graph_value?.series}
            width={"500"}
          />
        </div>

        {/* Shortfall display */}
        {graph_value?.shotfall !== undefined && (
  <div className="w-2/6 text-left">
    {/* Half Yearly Target + Shortfall row */}
    <div className="mb-3">
  {/* Labels */}
  <div className="flex items-center text-[12px] gap-x-[10px] text-black ">
  <span>Quarter Target</span>
  <span className="mx-[15px] font-bold ">+</span> {/* 10px left + 10px right = 20px gap */}
  <span>Shortfall</span>
</div>

  {/* Values */}
  <div className="flex items-center text-[14px] gap-x-[17px] font-bold text-black">
  <span>₹{formatNumber(graph_value?.nextQaurter || 0)}</span>
  <span className="mx-[10px] font-bold"></span> {/* 20px gap around + */}
  <span>₹{formatNumber(graph_value?.shotfall || 0)}</span>
</div>
</div>
{/* Next Quarter Target */}
    <h6 className="text-[25px] font-[700] text-blue-600">
      Next Quarter Target is: {" "}
      <span className="text-[29px] font-[800] text-red-600">
        ₹{formatNumber(graph_value?.nextQaurter + (graph_value?.shotfall || 0))}
      </span>
    </h6>
  </div>
)}

      </div>
    </div>
  </div>
</div>
        </div>    
        </div>       
    </div>
  )
}

export default FinanceDashboard








//===================>>>> Shilpa foundestion table edit




// import React,{useState,useEffect} from 'react'
// import { GetDepartmentService } from '../../services/DepartmentServices'
// import { GetFinanceDataService } from '../../services/AdminServicesfile/FinanceData'
// import {
//   Pagination,
// } from "@mui/material";
// import moment from 'moment';
// import {GoGraph} from 'react-icons/go';
// import Chart from "react-apexcharts";
// import { Drawer } from 'antd';
// import {IoMdClose} from 'react-icons/io';
// import SettingsMenu from '../staticscreens/SettingsMenu';
// import { useLocation } from 'react-router-dom';
// import FinanceMenu from '../finance/FinanceMenu';
// import QtreviewMenu from '../qtreview/QtreviewMenu';

// function FinanceDashboard() {
//   // const [graph_value,setgraph_value] = useState({options:'',series:[]})
//   const [graph_value, setgraph_value] = useState({
//     options: {
//       chart: { type: "donut" },
//       labels: [],
//       legend: { fontWeight: "bold" },
//       plotOptions: { pie: { size: "100%", distributed: true } },
//     },
//     series: [],
//     shotfall: 0,
//   });
  
//   const [department,setdepartment] = useState([])
//   const [selected_department,setselected_department] = useState({})
//   const [data,setdata] = useState([])
//   const [singleData,setsingleData] = useState({})
//   const [pagination,setpagination] = useState([])
//   const [page,setpage] = useState(1)

//   const [selected_Data,setselected_Data] = useState('')

//   const [graph,setgraph] = useState(false)
  

//   const {pathname} = useLocation()
 
//   const path = pathname.split('/')[1]

//   useEffect(()=>{
//     getDepartment()
//   },[])

//   const getDepartment = async() =>{
//       const response = await GetDepartmentService()
//       setdepartment(response.data.datas)
//   }

//   useEffect(()=>{
//     if(selected_department.id !== null && selected_department.id !== undefined){
//       getData()
//     }
//   },[page,selected_department])
  
//   let rupee = new Intl.NumberFormat('en-IN', {
//     style: 'currency',
//     currency: 'INR',
//   });

//   async function getData(){
//     const response = await GetFinanceDataService(selected_department?.id,page)
//     if(page === 1){
//       setsingleData(response.data.data[0])
//     }
//     setdata(response.data.data)
//     setpagination(response.data.pagination)
//   }


//   // async function setgraph_valuefun(graph_data) {
//   //   const invoiceAmount = Number(graph_data?.invoice_amount) || 0;
//   //   const totalOutstanding = Number(graph_data?.total_outstanding) || 0;
//   //   const profitLoss = invoiceAmount - totalOutstanding; // already number now
  
//   //   // ✅ Ensure numeric addition
//   //   const shotfall = Number(invoiceAmount) + Math.abs(Number(profitLoss));
  
//   //   // Labels for chart
//   //   let labels = [
//   //     `Half Yearly Target ${rupee.format(invoiceAmount)}`,
//   //     `Net Revenue ${rupee.format(totalOutstanding)}`,
//   //     `Shortfall ${rupee.format(Math.abs(profitLoss))}`
//   //   ];
  
//   //   // Series as % of invoice amount
//   //   let series = [
//   //     100,
//   //     (totalOutstanding / invoiceAmount) * 100,
//   //     (Math.abs(profitLoss) / invoiceAmount) * 100
//   //   ];
  
//   //   setgraph_value({
//   //     ...graph_value,
//   //     series,
//   //     shotfall, // always integer/number
//   //     options: {
//   //       chart: { type: 'donut' },
//   //       legend: { fontWeight: 'bold' },
//   //       plotOptions: { pie: { size: '100%', distributed: true } },
//   //       labels
//   //     }
//   //   });
//   // }

//   async function setgraph_valuefun(graph_data) {
//     const invoiceAmount = Number(graph_data?.invoice_amount) || 0; // Half Yearly Target
//     const totalOutstanding = Number(graph_data?.total_outstanding) || 0;
//     const amountCollected = Number(graph_data?.amount_collected) || 0;
//     const profitLoss = invoiceAmount-amountCollected;
  
//    const nextQaurter = invoiceAmount/2;
 

//     // ✅ Ensure numeric addition
//     const shotfall =  profitLoss;
//    // (d?.amount_collected || 0)  - (d?.invoice_amount || 0);
//     // Labels for chart
//     let labels = [
//       `Half Yearly Target ${rupee.format(invoiceAmount)}`,
//       `Net Revenue ${rupee.format(totalOutstanding)}`,
//       `Shortfall ${rupee.format(Math.abs(profitLoss))}`
//     ];
  
//     // Series as % of invoice amount
//     let series = [
//       100,
//       (totalOutstanding / invoiceAmount) * 100,
//       (Math.abs(profitLoss) / invoiceAmount) * 100
//     ];
  
//     setgraph_value({
//       ...graph_value,
//       series,
//       shotfall, // next quarter target
//       nextQaurter,
//       halfYearTarget: invoiceAmount, // ✅ keep Half Yearly target separately
//       options: {
//         chart: { type: "donut" },
//         legend: { fontWeight: "bold" },
//         plotOptions: { pie: { size: "100%", distributed: true } },
//         labels
//       }
//     });
//   }
  
  
//   const handlePagination = (e, pageNumber) => {
//     setpage(pageNumber)
//   }
  

//   const categories = [];
//   const splitSeries = {
//     name: "Values",
//     data: []
//   };
//   const colorsArray = []; // for unique colors
  
//   data.forEach((d) => {
//     // Yearly Target
//     categories.push(`Yearly Target`);
//     splitSeries.data.push(d?.invoice_raised_no || 0);
//     colorsArray.push("#2563eb"); // blue
  
//     // Quarterly Target
//     categories.push(`Half Yearly Target`);
//     splitSeries.data.push(d?.invoice_amount || 0);
//     colorsArray.push("#16a34a"); // green
  
//     // Actual Revenue
//     categories.push(`Achieved Revenue`);
//     splitSeries.data.push(d?.amount_collected || 0);
//     colorsArray.push("#f59e0b"); // red
  
//     // Expenses
//     categories.push(`Expenses`);
//     splitSeries.data.push(d?.expenses || 0);
//     colorsArray.push("#dc2626"); // orange
  
//     // Net Profit
//     categories.push(`Net Revenue`);
//     splitSeries.data.push(d?.total_outstanding || 0);
//     colorsArray.push("#7c3aed"); // purple
//   });
  
  

//   const formatNumber = (val) => {
//     return new Intl.NumberFormat("en-IN").format(val); // adds commas
//   };
  
  
//   return (
//     <div className=''>
//        <div className='flex'>
//        {path === 'finance' &&
//       <FinanceMenu />}
//       {path === 'settings' &&
//       <SettingsMenu /> }
//             {path === 'qtreview' &&
//       <QtreviewMenu /> }

//       <Drawer closable={false} maskStyle={{background:'black',opacity:'0.7'}} width={'50%'} placement="right" onClose={()=>setgraph(false)} open={graph}>
//         <div className='relative'>
//           <IoMdClose className='absolute right-0' onClick={()=>setgraph(false)} />
//          <h6 className='text-[14px] font-[700]'>Graphical Representation</h6>
//          <h6 className='leading-tight bg-gray-100 p-2 text-[13px] my-2'>See the graphical representation of revenue or loss for the period of invocie from (<span className='text-[10px] font-[900]'>{moment(selected_Data?.from).format('LL')} - {moment(selected_Data?.to).format('LL')}</span>)</h6>
         
//          <div className='w-4/5'>
//          <Chart
//               options={graph_value?.options}
//               type="donut"
//               height="290"
//               series={graph_value?.series}
//               width={'500'}
//             />
//         </div>
//         </div>
//       </Drawer>
      
//        <div className='w-[85%] px-4 mt-5'>
//         <h6 className='border-b pb-2 text-[13.5px] font-[800]'>Quarterly review</h6>
// {/* Toggle Buttons */}
// {/* Toggle Buttons */}
// <div className="flex flex-wrap justify-center gap-2 mt-4">
//   {department
//     ?.filter(
//       (d) =>
//         ![
//           "MD Personal",
//           "Software Team",
//           "FTS Team",
//           "Finance Team",
//         ].includes(d?.department_name)
//     )
//     .map((d) => (
//       <button
//         key={d?.id}
//         onClick={async () => {
//           setpage(1);
//           setselected_department(d);

//           // Fetch data for this department
//           const response = await GetFinanceDataService(d?.id, 1);
//           setdata(response.data.data);
//           setpagination(response.data.pagination);

//           // Automatically call the graph function for the first item
//           if (response.data.data?.length > 0) {
//             const firstItem = response.data.data[0];
//             setselected_Data(firstItem);
//             setgraph_valuefun(firstItem);
//           }
//         }}
//         className={`
//           px-4 py-2 rounded-full text-sm font-semibold transition
//           duration-300 ease-in-out
//           border border-gray-300
//           ${
//             selected_department?.id === d?.id
//               ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
//               : "bg-white text-gray-700 hover:bg-blue-50 hover:text-blue-700"
//           }
//         `}
//       >
//         {d?.department_name === "Digital Media" ? "FMS TurnOver" : d?.department_name}
//       </button>
//     ))}
// </div>



//        {data.length === 0 &&
//         <div className='grid items-center justify-center mt-20 place-items-center'>
//           <img src={'https://fidecrmfiles.s3.amazonaws.com/NoDataFound1.png'} className='object-contain w-40 h-40' /> 
//           <h6 className='font-bold text-[14px] -mt-10'>No data found</h6>
//           <h6 className='font-[500] text-slate-700 text-[12.5px] -mt-2'>Try Any Filter Option to See the "Invoice Report" For the Vertical</h6>
//         </div>}

//         {data.length > 0 &&
//           <>    
// <div className="mt-10 overflow-hidden border border-gray-200 rounded-lg shadow-md">
//   {/* Top Bar */}
//   <h6 className="text-[14px] font-[700] px-3 py-3 bg-gray-100 border-b">
//     Data Found ({pagination?.total})
//   </h6>

//   {/* Header Row */}
// <div className="flex bg-slate-700 text-white text-[13px] font-semibold h-[50px] items-center">
//   <h6 className="p-3 w-[6%] text-[10px] text-center border-r">SL NO</h6>
//   {/* <h6 className="p-3 w-[18%] border-r">Date</h6> */}
//   <h6 className="p-3 w-[14%] border-r">Yearly Target</h6>
//   <h6 className="p-3 w-[14%] border-r">Half Yearly Target</h6> {/* ✅ changed */}
//   <h6 className="p-3 w-[14%] border-r">Achieved Revenue</h6> 
//   <h6 className="p-3 w-[14%] border-r">Expenses</h6>
//   <h6 className="p-3 w-[14%] border-r">Net Revenue</h6> {/* ✅ kept same */}
//   <h6 className="p-3 w-[12%] border-r text-center">Shortfall</h6>
//   <h6 className="p-3 w-[6%] text-center">Action</h6>
// </div>

//   {/* Data Rows */}
//   {data?.map((d, i) => (
//     <div
//       key={d?._id}
//       className="flex text-[15px] font-medium odd:bg-white even:bg-gray-50 hover:bg-gray-100 transition"
//     >
//       {/* SL NO */}
//       <h6 className="p-3 w-[6%] text-center font-bold border-r">
//         {page === 1 ? i + 1 : (page - 1) * pagination.limit + (i + 1)}
//       </h6>

//       {/* Date (Bold) */}
//       {/* <h6 className="p-3 w-[18%] text-[12px] border-r font-bold">
//   {moment(d?.from).format("MMM")} - {moment(d?.to).format("MMM")}
// </h6> */}

//       {/* Yearly Target (Bold + ₹ symbol) */}
//       <h6 className="p-3 w-[14%] border-r font-bold">
//         {rupee?.format(d?.invoice_raised_no)?.split(".")[0]}
//       </h6>

//       {/* Quarterly Target */}
//       <h6 className="p-3 w-[14%] border-r font-semibold">
//         {rupee?.format(d?.invoice_amount)?.split(".")[0]}
//       </h6>

//       {/* Actual Revenue */}
//       <h6 className="p-3 w-[14%] border-r font-semibold">
//         {rupee?.format(d?.amount_collected)?.split(".")[0]}
//       </h6>

//       {/* Expenses */}
//       <h6 className="p-3 w-[14%] border-r font-semibold">
//         {d?.expenses !== undefined && rupee?.format(d?.expenses)?.split(".")[0]}
//       </h6>

//       {/* Net Profit */}
//       <h6 className="p-3 w-[14%] border-r font-semibold">
//         {rupee?.format(d?.total_outstanding)?.split(".")[0]}
//       </h6>

// {/* Profit / Loss */}
// <h6 className="p-3 w-[12%] border-r text-center">
//   {(() => {
//     const difference = (d?.amount_collected || 0)  - (d?.invoice_amount || 0);
//     const formattedDiff = formatNumber(Math.abs(difference)); // add commas
//     if (difference >= 0) {
//       return (
//         <span className="px-2 py-1 text-[13px] font-bold  text-green-600 rounded">
//          {formattedDiff} <span className="px-2 py-1 text-green-600 bg-green-100 ">Profit</span> 
//         </span>
//       );
//     } else {
//       return (
//         <span className="px-2  py-1 text-[13px] font-bold  text-red-600 rounded">
//         {formattedDiff}  <span className="px-2 py-1 text-red-600 bg-red-100 ">Loss</span> 
//         </span>
//       );
//     }
//   })()}
// </h6>

//       {/* Action */}
//       <h6
//         className="p-3 w-[6%] text-center cursor-pointer"
//         onClick={() => {
//           setselected_Data(d);
//           setgraph_valuefun(d);
//           setgraph(true);
//         }}
//       >
//         <GoGraph size={20} className="mx-auto text-slate-600 hover:text-slate-900" />
//       </h6>
//     </div>
//   ))}
// </div>
//        </>
//         }    
// {/* Chart Section - Show only if data exists */}
// {data.length > 0 && (
//   <div className="p-5 mt-10 bg-white border border-gray-200 rounded-lg shadow-md">
//     <h6 className="text-[16px] font-[700] mb-4">Visual Representation</h6>

//     {/* ✅ Bar Chart with fixed 300px height */}
//     <div className="w-full h-[300px]">
//       <Chart
//         type="bar"
//         height="100%"
//         width="100%"
//         series={[splitSeries]}
//         options={{
//           chart: { type: "bar", toolbar: { show: true } },
//           plotOptions: {
//             bar: {
//               horizontal: false,
//               columnWidth: "35%",
//               borderRadius: 4,
//               distributed: true,
//             },
//           },
//           colors: colorsArray,
//           dataLabels: {
//             enabled: true,
//             style: {
//               fontSize: "12px",
//               fontWeight: "600",
//               colors: ["#fff"],
//             },
//             formatter: function (val) {
//               return formatNumber(val);
//             },
//             offsetY: -6,
//           },
//           xaxis: {
//             categories: categories,
//             labels: { style: { fontSize: "13px", fontWeight: 600 } },
//           },
//           yaxis: {
//             labels: { formatter: (val) => `₹${formatNumber(val)}` },
//           },
//           legend: { show: false },
//         }}
//       />
//     </div>
//   </div>
// )}

// <div className="flex justify-center mt-10">
//   <div className="w-full h-[450px] bg-white border border-gray-200 rounded-lg shadow-md p-4">
//     {/* <h6 className="text-[16px] font-[700] mb-4 text-center">Distribution View</h6> */}
//     <div className="relative">
//       <h6 className="text-[14px] font-[700]">Graphical Representation</h6>
//       <h6 className="leading-tight bg-gray-100 p-2 text-[13px] my-2">
//       Visual comparison of revenue achieved vs. target and the next target to achieve
//         {/* (<span className="text-[10px] font-[900]">
//           {moment(selected_Data?.from).format("LL")} - {moment(selected_Data?.to).format("LL")}
//         </span>) */}
//       </h6>

//       {/* ✅ Flex container for chart + shortfall */}
//       <div className="flex items-center">
//         {/* Chart */}
//         <div className="w-3/5">
//           <Chart
//             options={graph_value?.options}
//             type="donut"
//             height="290"
//             series={graph_value?.series}
//             width={"500"}
//           />
//         </div>

//         {/* Shortfall display */}
//         {graph_value?.shotfall !== undefined && (
//   <div className="w-2/6 text-left">
//     {/* Half Yearly Target + Shortfall row */}
//     <div className="mb-3">
//   {/* Labels */}
//   <div className="flex items-center text-[12px] gap-x-[10px] text-black ">
//   <span>Quarter Target</span>
//   <span className="mx-[15px] font-bold ">+</span> {/* 10px left + 10px right = 20px gap */}
//   <span>Shortfall</span>
// </div>

//   {/* Values */}
//   <div className="flex items-center text-[14px] gap-x-[17px] font-bold text-black">
//   <span>₹{formatNumber(graph_value?.nextQaurter || 0)}</span>
//   <span className="mx-[10px] font-bold"></span> {/* 20px gap around + */}
//   <span>₹{formatNumber(graph_value?.shotfall || 0)}</span>
// </div>
// </div>
// {/* Next Quarter Target */}
//     <h6 className="text-[25px] font-[700] text-blue-600">
//       Next Quarter Target is: {" "}
//       <span className="text-[29px] font-[800] text-red-600">
//         ₹{formatNumber(graph_value?.nextQaurter + (graph_value?.shotfall || 0))}
//       </span>
//     </h6>
//   </div>
// )}

//       </div>
//     </div>
//   </div>
// </div>
//         </div>    
//         </div>       
//     </div>
//   )
// }

// export default FinanceDashboard








//===================>>>> Old one 



// import React,{useState,useEffect} from 'react'
// import { GetDepartmentService } from '../../services/DepartmentServices'
// import { GetFinanceDataService } from '../../services/AdminServicesfile/FinanceData'
// import {
//   Pagination,
// } from "@mui/material";
// import moment from 'moment';
// import {GoGraph} from 'react-icons/go';
// import Chart from "react-apexcharts";
// import { Drawer } from 'antd';
// import {IoMdClose} from 'react-icons/io';
// import SettingsMenu from '../staticscreens/SettingsMenu';
// import { useLocation } from 'react-router-dom';
// import FinanceMenu from '../finance/FinanceMenu';
// import QtreviewMenu from '../qtreview/QtreviewMenu';

// function FinanceDashboard() {
//   // const [graph_value,setgraph_value] = useState({options:'',series:[]})
//   const [graph_value, setgraph_value] = useState({
//     options: {
//       chart: { type: "donut" },
//       labels: [],
//       legend: { fontWeight: "bold" },
//       plotOptions: { pie: { size: "100%", distributed: true } },
//     },
//     series: [],
//     shotfall: 0,
//   });
  
//   const [department,setdepartment] = useState([])
//   const [selected_department,setselected_department] = useState({})
//   const [data,setdata] = useState([])
//   const [singleData,setsingleData] = useState({})
//   const [pagination,setpagination] = useState([])
//   const [page,setpage] = useState(1)

//   const [selected_Data,setselected_Data] = useState('')

//   const [graph,setgraph] = useState(false)
  

//   const {pathname} = useLocation()
 
//   const path = pathname.split('/')[1]

//   useEffect(()=>{
//     getDepartment()
//   },[])

//   const getDepartment = async() =>{
//       const response = await GetDepartmentService()
//       setdepartment(response.data.datas)
//   }

//   useEffect(()=>{
//     if(selected_department.id !== null && selected_department.id !== undefined){
//       getData()
//     }
//   },[page,selected_department])
  
//   let rupee = new Intl.NumberFormat('en-IN', {
//     style: 'currency',
//     currency: 'INR',
//   });

//   async function getData(){
//     const response = await GetFinanceDataService(selected_department?.id,page)
//     if(page === 1){
//       setsingleData(response.data.data[0])
//     }
//     setdata(response.data.data)
//     setpagination(response.data.pagination)
//   }


//   // async function setgraph_valuefun(graph_data) {
//   //   const invoiceAmount = Number(graph_data?.invoice_amount) || 0;
//   //   const totalOutstanding = Number(graph_data?.total_outstanding) || 0;
//   //   const profitLoss = invoiceAmount - totalOutstanding; // already number now
  
//   //   // ✅ Ensure numeric addition
//   //   const shotfall = Number(invoiceAmount) + Math.abs(Number(profitLoss));
  
//   //   // Labels for chart
//   //   let labels = [
//   //     `Half Yearly Target ${rupee.format(invoiceAmount)}`,
//   //     `Net Revenue ${rupee.format(totalOutstanding)}`,
//   //     `Shortfall ${rupee.format(Math.abs(profitLoss))}`
//   //   ];
  
//   //   // Series as % of invoice amount
//   //   let series = [
//   //     100,
//   //     (totalOutstanding / invoiceAmount) * 100,
//   //     (Math.abs(profitLoss) / invoiceAmount) * 100
//   //   ];
  
//   //   setgraph_value({
//   //     ...graph_value,
//   //     series,
//   //     shotfall, // always integer/number
//   //     options: {
//   //       chart: { type: 'donut' },
//   //       legend: { fontWeight: 'bold' },
//   //       plotOptions: { pie: { size: '100%', distributed: true } },
//   //       labels
//   //     }
//   //   });
//   // }

//   async function setgraph_valuefun(graph_data) {
//     const invoiceAmount = Number(graph_data?.invoice_amount) || 0; // Half Yearly Target
//     const totalOutstanding = Number(graph_data?.total_outstanding) || 0;
//     const amountCollected = Number(graph_data?.amount_collected) || 0;
//     const profitLoss = invoiceAmount-amountCollected;
  
//    const nextQaurter = invoiceAmount/2;
 

//     // ✅ Ensure numeric addition
//     const shotfall =  profitLoss;
//    // (d?.amount_collected || 0)  - (d?.invoice_amount || 0);
//     // Labels for chart
//     let labels = [
//       `Half Yearly Target ${rupee.format(invoiceAmount)}`,
//       `Net Revenue ${rupee.format(totalOutstanding)}`,
//       `Shortfall ${rupee.format(Math.abs(profitLoss))}`
//     ];
  
//     // Series as % of invoice amount
//     let series = [
//       100,
//       (totalOutstanding / invoiceAmount) * 100,
//       (Math.abs(profitLoss) / invoiceAmount) * 100
//     ];
  
//     setgraph_value({
//       ...graph_value,
//       series,
//       shotfall, // next quarter target
//       nextQaurter,
//       halfYearTarget: invoiceAmount, // ✅ keep Half Yearly target separately
//       options: {
//         chart: { type: "donut" },
//         legend: { fontWeight: "bold" },
//         plotOptions: { pie: { size: "100%", distributed: true } },
//         labels
//       }
//     });
//   }
  
  
//   const handlePagination = (e, pageNumber) => {
//     setpage(pageNumber)
//   }
  

//   const categories = [];
//   const splitSeries = {
//     name: "Values",
//     data: []
//   };
//   const colorsArray = []; // for unique colors
  
//   data.forEach((d) => {
//     // Yearly Target
//     categories.push(`Yearly Target`);
//     splitSeries.data.push(d?.invoice_raised_no || 0);
//     colorsArray.push("#2563eb"); // blue
  
//     // Quarterly Target
//     categories.push(`Half Yearly Target`);
//     splitSeries.data.push(d?.invoice_amount || 0);
//     colorsArray.push("#16a34a"); // green
  
//     // Actual Revenue
//     categories.push(`Achieved Revenue`);
//     splitSeries.data.push(d?.amount_collected || 0);
//     colorsArray.push("#f59e0b"); // red
  
//     // Expenses
//     categories.push(`Expenses`);
//     splitSeries.data.push(d?.expenses || 0);
//     colorsArray.push("#dc2626"); // orange
  
//     // Net Profit
//     categories.push(`Net Revenue`);
//     splitSeries.data.push(d?.total_outstanding || 0);
//     colorsArray.push("#7c3aed"); // purple
//   });
  
  

//   const formatNumber = (val) => {
//     return new Intl.NumberFormat("en-IN").format(val); // adds commas
//   };
  
  
//   return (
//     <div className=''>
//        <div className='flex'>
//        {path === 'finance' &&
//       <FinanceMenu />}
//       {path === 'settings' &&
//       <SettingsMenu /> }
//             {path === 'qtreview' &&
//       <QtreviewMenu /> }

//       <Drawer closable={false} maskStyle={{background:'black',opacity:'0.7'}} width={'50%'} placement="right" onClose={()=>setgraph(false)} open={graph}>
//         <div className='relative'>
//           <IoMdClose className='absolute right-0' onClick={()=>setgraph(false)} />
//          <h6 className='text-[14px] font-[700]'>Graphical Representation</h6>
//          <h6 className='leading-tight bg-gray-100 p-2 text-[13px] my-2'>See the graphical representation of revenue or loss for the period of invocie from (<span className='text-[10px] font-[900]'>{moment(selected_Data?.from).format('LL')} - {moment(selected_Data?.to).format('LL')}</span>)</h6>
         
//          <div className='w-4/5'>
//          <Chart
//               options={graph_value?.options}
//               type="donut"
//               height="290"
//               series={graph_value?.series}
//               width={'500'}
//             />
//         </div>
//         </div>
//       </Drawer>
      
//        <div className='w-[85%] px-4 mt-5'>
//         <h6 className='border-b pb-2 text-[13.5px] font-[800]'>Quarterly review</h6>
// {/* Toggle Buttons */}
// {/* Toggle Buttons */}
// <div className="flex flex-wrap justify-center gap-2 mt-4">
//   {department
//     ?.filter(
//       (d) =>
//         ![
//           "MD Personal",
//           "Software Team",
//           "FTS Team",
//           "Finance Team",
//         ].includes(d?.department_name)
//     )
//     .map((d) => (
//       <button
//         key={d?.id}
//         onClick={async () => {
//           setpage(1);
//           setselected_department(d);

//           // Fetch data for this department
//           const response = await GetFinanceDataService(d?.id, 1);
//           setdata(response.data.data);
//           setpagination(response.data.pagination);

//           // Automatically call the graph function for the first item
//           if (response.data.data?.length > 0) {
//             const firstItem = response.data.data[0];
//             setselected_Data(firstItem);
//             setgraph_valuefun(firstItem);
//           }
//         }}
//         className={`
//           px-4 py-2 rounded-full text-sm font-semibold transition
//           duration-300 ease-in-out
//           border border-gray-300
//           ${
//             selected_department?.id === d?.id
//               ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
//               : "bg-white text-gray-700 hover:bg-blue-50 hover:text-blue-700"
//           }
//         `}
//       >
//         {d?.department_name === "Digital Media" ? "FMS TurnOver" : d?.department_name}
//       </button>
//     ))}
// </div>



//        {data.length === 0 &&
//         <div className='grid items-center justify-center mt-20 place-items-center'>
//           <img src={'https://fidecrmfiles.s3.amazonaws.com/NoDataFound1.png'} className='object-contain w-40 h-40' /> 
//           <h6 className='font-bold text-[14px] -mt-10'>No data found</h6>
//           <h6 className='font-[500] text-slate-700 text-[12.5px] -mt-2'>Try Any Filter Option to See the "Invoice Report" For the Vertical</h6>
//         </div>}

//         {data.length > 0 &&
//           <>    
// <div className="mt-10 overflow-hidden border border-gray-200 rounded-lg shadow-md">
//   {/* Top Bar */}
//   <h6 className="text-[14px] font-[700] px-3 py-3 bg-gray-100 border-b">
//     Data Found ({pagination?.total})
//   </h6>

//   {/* Header Row */}
// <div className="flex bg-slate-700 text-white text-[13px] font-semibold h-[50px] items-center">
//   <h6 className="p-3 w-[6%] text-[10px] text-center border-r">SL NO</h6>
//   {/* <h6 className="p-3 w-[18%] border-r">Date</h6> */}
//   <h6 className="p-3 w-[14%] border-r">Yearly Target</h6>
//   <h6 className="p-3 w-[14%] border-r">Half Yearly Target</h6> {/* ✅ changed */}
//   <h6 className="p-3 w-[14%] border-r">Achieved Revenue</h6> {/* ✅ changed */}
//   <h6 className="p-3 w-[14%] border-r">Expenses</h6>
//   <h6 className="p-3 w-[14%] border-r">Net Revenue</h6> {/* ✅ kept same */}
//   <h6 className="p-3 w-[12%] border-r text-center">Shortfall</h6>
//   <h6 className="p-3 w-[6%] text-center">Action</h6>
// </div>

//   {/* Data Rows */}
//   {data?.map((d, i) => (
//     <div
//       key={d?._id}
//       className="flex text-[15px] font-medium odd:bg-white even:bg-gray-50 hover:bg-gray-100 transition"
//     >
//       {/* SL NO */}
//       <h6 className="p-3 w-[6%] text-center font-bold border-r">
//         {page === 1 ? i + 1 : (page - 1) * pagination.limit + (i + 1)}
//       </h6>

//       {/* Date (Bold) */}
//       {/* <h6 className="p-3 w-[18%] text-[12px] border-r font-bold">
//   {moment(d?.from).format("MMM")} - {moment(d?.to).format("MMM")}
// </h6> */}

//       {/* Yearly Target (Bold + ₹ symbol) */}
//       <h6 className="p-3 w-[14%] border-r font-bold">
//         {rupee?.format(d?.invoice_raised_no)?.split(".")[0]}
//       </h6>

//       {/* Quarterly Target */}
//       <h6 className="p-3 w-[14%] border-r font-semibold">
//         {rupee?.format(d?.invoice_amount)?.split(".")[0]}
//       </h6>

//       {/* Actual Revenue */}
//       <h6 className="p-3 w-[14%] border-r font-semibold">
//         {rupee?.format(d?.amount_collected)?.split(".")[0]}
//       </h6>

//       {/* Expenses */}
//       <h6 className="p-3 w-[14%] border-r font-semibold">
//         {d?.expenses !== undefined && rupee?.format(d?.expenses)?.split(".")[0]}
//       </h6>

//       {/* Net Profit */}
//       <h6 className="p-3 w-[14%] border-r font-semibold">
//         {rupee?.format(d?.total_outstanding)?.split(".")[0]}
//       </h6>

// {/* Profit / Loss */}
// <h6 className="p-3 w-[12%] border-r text-center">
//   {(() => {
//     const difference = (d?.amount_collected || 0)  - (d?.invoice_amount || 0);
//     const formattedDiff = formatNumber(Math.abs(difference)); // add commas
//     if (difference >= 0) {
//       return (
//         <span className="px-2 py-1 text-[13px] font-bold  text-green-600 rounded">
//          {formattedDiff} <span className="px-2 py-1 text-green-600 bg-green-100 ">Profit</span> 
//         </span>
//       );
//     } else {
//       return (
//         <span className="px-2  py-1 text-[13px] font-bold  text-red-600 rounded">
//         {formattedDiff}  <span className="px-2 py-1 text-red-600 bg-red-100 ">Loss</span> 
//         </span>
//       );
//     }
//   })()}
// </h6>

//       {/* Action */}
//       <h6
//         className="p-3 w-[6%] text-center cursor-pointer"
//         onClick={() => {
//           setselected_Data(d);
//           setgraph_valuefun(d);
//           setgraph(true);
//         }}
//       >
//         <GoGraph size={20} className="mx-auto text-slate-600 hover:text-slate-900" />
//       </h6>
//     </div>
//   ))}
// </div>
//        </>
//         }    
// {/* Chart Section - Show only if data exists */}
// {data.length > 0 && (
//   <div className="p-5 mt-10 bg-white border border-gray-200 rounded-lg shadow-md">
//     <h6 className="text-[16px] font-[700] mb-4">Visual Representation</h6>

//     {/* ✅ Bar Chart with fixed 300px height */}
//     <div className="w-full h-[300px]">
//       <Chart
//         type="bar"
//         height="100%"
//         width="100%"
//         series={[splitSeries]}
//         options={{
//           chart: { type: "bar", toolbar: { show: true } },
//           plotOptions: {
//             bar: {
//               horizontal: false,
//               columnWidth: "35%",
//               borderRadius: 4,
//               distributed: true,
//             },
//           },
//           colors: colorsArray,
//           dataLabels: {
//             enabled: true,
//             style: {
//               fontSize: "12px",
//               fontWeight: "600",
//               colors: ["#fff"],
//             },
//             formatter: function (val) {
//               return formatNumber(val);
//             },
//             offsetY: -6,
//           },
//           xaxis: {
//             categories: categories,
//             labels: { style: { fontSize: "13px", fontWeight: 600 } },
//           },
//           yaxis: {
//             labels: { formatter: (val) => `₹${formatNumber(val)}` },
//           },
//           legend: { show: false },
//         }}
//       />
//     </div>
//   </div>
// )}

// <div className="flex justify-center mt-10">
//   <div className="w-full h-[450px] bg-white border border-gray-200 rounded-lg shadow-md p-4">
//     {/* <h6 className="text-[16px] font-[700] mb-4 text-center">Distribution View</h6> */}
//     <div className="relative">
//       <h6 className="text-[14px] font-[700]">Graphical Representation</h6>
//       <h6 className="leading-tight bg-gray-100 p-2 text-[13px] my-2">
//       Visual comparison of revenue achieved vs. target and the next target to achieve
//         {/* (<span className="text-[10px] font-[900]">
//           {moment(selected_Data?.from).format("LL")} - {moment(selected_Data?.to).format("LL")}
//         </span>) */}
//       </h6>

//       {/* ✅ Flex container for chart + shortfall */}
//       <div className="flex items-center">
//         {/* Chart */}
//         <div className="w-3/5">
//           <Chart
//             options={graph_value?.options}
//             type="donut"
//             height="290"
//             series={graph_value?.series}
//             width={"500"}
//           />
//         </div>

//         {/* Shortfall display */}
//         {graph_value?.shotfall !== undefined && (
//   <div className="w-2/6 text-left">
//     {/* Half Yearly Target + Shortfall row */}
//     <div className="mb-3">
//   {/* Labels */}
//   <div className="flex items-center text-[12px] gap-x-[10px] text-black ">
//   <span>Quarter Target</span>
//   <span className="mx-[15px] font-bold ">+</span> {/* 10px left + 10px right = 20px gap */}
//   <span>Shortfall</span>
// </div>

//   {/* Values */}
//   <div className="flex items-center text-[14px] gap-x-[17px] font-bold text-black">
//   <span>₹{formatNumber(graph_value?.nextQaurter || 0)}</span>
//   <span className="mx-[10px] font-bold"></span> {/* 20px gap around + */}
//   <span>₹{formatNumber(graph_value?.shotfall || 0)}</span>
// </div>
// </div>
// {/* Next Quarter Target */}
//     <h6 className="text-[25px] font-[700] text-blue-600">
//       Next Quarter Target is: {" "}
//       <span className="text-[29px] font-[800] text-red-600">
//         ₹{formatNumber(graph_value?.nextQaurter + (graph_value?.shotfall || 0))}
//       </span>
//     </h6>
//   </div>
// )}

//       </div>
//     </div>
//   </div>
// </div>
//         </div>    
//         </div>       
//     </div>
//   )
// }

// export default FinanceDashboard