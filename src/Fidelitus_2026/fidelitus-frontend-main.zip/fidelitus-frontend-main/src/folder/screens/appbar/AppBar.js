import { Avatar } from 'antd';
import React, { useState } from 'react';
import { appbarlogo } from '../../constants/imageConstants';
import {RiNotification3Line,RiArrowDownSFill} from 'react-icons/ri';
import {BiPlus} from 'react-icons/bi';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import {HiOutlineMenuAlt3} from 'react-icons/hi';
import Tooltip from '@mui/material/Tooltip';
import { Divider } from '@mui/material';
import { useSelector,useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { LogOutAction } from '../../redux/actions/authAction';
import { Progress } from "@material-tailwind/react";

function AppBar() {

  const [anchorEl, setAnchorEl] = useState(null);
  const [anchorEl1, setAnchorEl1] = useState(null);
  const dispatch =  useDispatch()
  const open = Boolean(anchorEl);
  const open1 = Boolean(anchorEl1);
  const navigate = useNavigate()

  const auth = useSelector(state=>state.Auth)
  // console.log("auth screen",auth)


  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClick1 = (event) => {
    setAnchorEl1(event.currentTarget);
  };

  const handleClose = () => {
    navigate('/profile')
    setAnchorEl(null);
    open1 = false
  };

  const handleClose1 = () => {
    setAnchorEl1(null);
  };


  const menu = [
    {name:'Home',path:'/dashboard'},
    {name:'Leads',path:'/leads'},
    // {name:'Tasks',path:''},
    // {name:'Reminder',path:''},
    // {name:'Explore',path:''},
  ]  

  function logoutfunc(){
    dispatch(LogOutAction())
    navigate("/");
  }
  


  return (
    <>
    <div className=' bg-[#24292f] p-2 sm:px-8  flex items-center justify-between '>

        <div className='flex items-center py-2 sm:py-0'>

        <HiOutlineMenuAlt3 className='text-white block sm:hidden' size={22} />   
        <Avatar src={appbarlogo} size="medium" className="cursor-pointer hidden md:block" sx={{width:28,height:28}} variant="square" />
        <div className='hidden sm:flex flex ml-5 '>
            {menu?.map((m)=>(
                <h6 onClick={()=>navigate(m?.path)} className='font-[450] cursor-pointer text-[13.5px] mx-2 text-white'>{m?.name}</h6>
            ))}
        </div>
        </div>  


        <Avatar src={appbarlogo} size="medium" className="cursor-pointer block ml-14 md:hidden" sx={{width:28,height:28}} variant="square" />


        <div className='flex  items-center text-white'>
            <Tooltip componentsProps={{
                tooltip: {
                sx: {
                    bgcolor: '#1f2328',
                    '& .MuiTooltip-arrow': {
                    color: '#1f2328',
                    },
                },
                },
          }} title="Notifications"><span><RiNotification3Line className='mr-3 cursor-pointer hover:text-[#929498]' data-te-toggle="tooltip" title="Notifications" /></span></Tooltip>
           
            <div className='mr-3 flex items-center  cursor-pointer hover:text-[#929498]'>
                <BiPlus 
                    id="basic-button"
                    aria-controls={open ? 'basic-menu' : undefined}
                    aria-haspopup="true"
                    aria-expanded={open ? 'true' : undefined}
                    onClick={handleClick}        
                />
                <RiArrowDownSFill
                    id="basic-button"
                    aria-controls={open ? 'basic-menu' : undefined}
                    aria-haspopup="true"
                    aria-expanded={open ? 'true' : undefined}
                    onClick={handleClick}         
                />
                <Menu
                    id="basic-menu"
                    anchorEl={anchorEl}
                    open={open}
                    onClose={handleClose}
                    MenuListProps={{
                    'aria-labelledby': 'basic-button',
                    }}
                    PaperProps={{
                        elevation: 0,
                        sx: {
                          overflow: 'visible',
                          filter: 'drop-shadow(0.2px 0px 0.1px #d0d7de)',
                          mt: 1.5,
                          ml:1,
                          borderRadius:1.5,
                          border:'1.2px solid #d0d7de',
                          '& .MuiAvatar-root': {
                            width: 32,
                            height: 22,
                            ml: -2.5,
                            mr: -11,
                          },
                          '&:before': {
                            content: '""',
                            display: 'block',
                            position: 'absolute',
                            top: 0,
                            right: 11,
                            width: 8,
                            height: 8,
                            bgcolor: 'background.paper',
                            transform: 'translateY(-50%) rotate(45deg)',
                            zIndex: 0,
                          },
                        },
                    }}
                    transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                    anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
                >
                <MenuItem onClick={handleClose} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}},{color:'#1f2329',fontSize:'13.5px',padding:'0px 16px'}]}  dense={true}>New Task</MenuItem>
                <MenuItem onClick={handleClose} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}},{color:'#1f2329',fontSize:'13.5px',padding:'0px 16px'}]}  dense={true}>New Notes</MenuItem>
                <MenuItem onClick={handleClose} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}},{color:'#1f2329',fontSize:'13.5px',padding:'0px 16px'}]}  dense={true}>New Leads</MenuItem>
                </Menu>
            </div>
            

            <span className='flex items-center cursor-pointer hover:text-[#929498]'>
                <Avatar 
                    src={'https://avatars.githubusercontent.com/u/89134199?s=96&v=4'} 
                    size="small" 
                    sx={{ width: 12, height: 12 }} 
                    className="cursor-pointer" 
                    id="basic-button"
                    aria-controls={open1 ? 'basic-menu1' : undefined}
                    aria-haspopup="true"
                    aria-expanded={open1 ? 'true' : undefined}
                    onClick={handleClick1}       
                 />
                <RiArrowDownSFill 
                    id="basic-button"
                    aria-controls={open1 ? 'basic-menu1' : undefined}
                    aria-haspopup="true"
                    aria-expanded={open1 ? 'true' : undefined}
                    onClick={handleClick1}       
                 />

                <Menu
                    id="basic-menu1"
                    anchorEl={anchorEl1}
                    open={open1}
                    onClose={handleClose1}
                    MenuListProps={{
                    'aria-labelledby': 'basic-button',
                    }}
                    PaperProps={{
                        elevation: 0,
                        sx: {
                          overflow: 'visible',
                          filter: 'drop-shadow(0.2px 0px 0.1px #d0d7de)',
                          mt: 1.5,
                          ml:1,
                          borderRadius:1.5,
                          border:'1.2px solid #d0d7de',
                          '& .MuiAvatar-root': {
                            width: 32,
                            height: 22,
                            ml: -2.5,
                            mr: -11,
                          },
                          '&:before': {
                            content: '""',
                            display: 'block',
                            position: 'absolute',
                            top: 0,
                            right: 11,
                            width: 8,
                            height: 8,
                            bgcolor: 'background.paper',
                            transform: 'translateY(-50%) rotate(45deg)',
                            zIndex: 0,
                          },
                        },
                    }} 
                    transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                    anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
                >
                <div className='px-4 my-2 mb-3'>
                  <h6 className='text-[13px] mb-1'>Signed in as</h6>
                  <h6 className='text-[14px] mb-1 font-[600] truncate'>{auth?.name}</h6>
                </div>    
                <Divider></Divider>
                <MenuItem onClick={handleClose} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}},{color:'#1f2329',fontSize:'13.5px',padding:'0px 16px'}]} dense={true}>Your Profile</MenuItem>
                <MenuItem onClick={handleClose} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}},{color:'#1f2329',fontSize:'13.5px',padding:'0px 16px'}]} dense={true}>Your Tasks</MenuItem>
                <MenuItem onClick={handleClose} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}},{color:'#1f2329',fontSize:'13.5px',padding:'0px 16px'}]} dense={true}>Your Reminder</MenuItem>
                <MenuItem onClick={handleClose} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}},{color:'#1f2329',fontSize:'13.5px',padding:'0px 16px'}]} dense={true}>Your Organization</MenuItem>

                <Divider></Divider>
                <MenuItem onClick={handleClose} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}},{color:'#1f2329',fontSize:'13.5px',padding:'0px 16px'}]} dense={true}>Upgrade</MenuItem>
                <MenuItem onClick={handleClose} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}},{color:'#1f2329',fontSize:'13.5px',padding:'0px 16px'}]} dense={true}>Feature preview</MenuItem>
                <MenuItem onClick={handleClose} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}},{color:'#1f2329',fontSize:'13.5px',padding:'0px 16px'}]} dense={true}>Help</MenuItem>
                <MenuItem onClick={handleClose} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}},{color:'#1f2329',fontSize:'13.5px',padding:'0px 16px'}]} dense={true}>Settings</MenuItem>

                <Divider></Divider>
                <MenuItem onClick={logoutfunc} sx={[{'&:hover': {backgroundColor: '#0a69da',color:'#fff'}},{'&:selected':{backgroundColor:'#fff'}}]} dense={true}>Sign out</MenuItem>
                
                </Menu>

            </span>
        </div>

    </div>

    <Progress value={50} color="blue" />

    </>
  )
}

export default AppBar