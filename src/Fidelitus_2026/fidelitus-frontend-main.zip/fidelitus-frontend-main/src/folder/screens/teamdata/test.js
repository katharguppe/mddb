// if(paginationData?.pagination !== undefined){
//             if(paginationData?.pagination?.activate === true && paginationData?.pagination?.type === 'TeamLeads'){
//               if(user?.roles?.includes('hod')){
//                 setsearch({text:paginationData?.pagination?.search_text,from_date:paginationData?.pagination?.from_date,to_date:paginationData?.pagination?.to_date,activate:paginationData?.pagination?.activate})
//                 setselected_user(paginationData?.pagination?.employee_id === "" ? null : {label:paginationData?.pagination?.employee_id?.label,value:paginationData?.pagination?.employee_id?.value})
//                 setselected_department(paginationData?.pagination?.department_id?.value === undefined ? null : {label:paginationData?.pagination?.department_id?.label,value:paginationData?.pagination?.department_id?.value})
//                 setpage(1)

//               }else if(user?.roles?.includes('manager') && paginationData?.pagination?.employee_id === null && paginationData?.pagination?.employee_id === ''){
//                 setsearch({text:paginationData?.pagination?.search_text,from_date:paginationData?.pagination?.from_date,to_date:paginationData?.pagination?.to_date,activate:paginationData?.pagination?.activate})
//                 setselected_user(null)
//                 setselected_department(paginationData?.pagination?.department_id?.value === undefined ? null : {label:paginationData?.pagination?.department_id?.label,value:paginationData?.pagination?.department_id?.value})
//                 setpage(1)
//               }else{
//                 setsearch({text:paginationData?.pagination?.search_text,from_date:paginationData?.pagination?.from_date,to_date:paginationData?.pagination?.to_date,activate:paginationData?.pagination?.activate})
//                 setselected_user(paginationData?.pagination?.employee_id === "" ? null : {label:paginationData?.pagination?.employee_id?.label,value:paginationData?.pagination?.employee_id?.value})
//                 setselected_department(paginationData?.pagination?.department_id?.value === undefined ? null : {label:paginationData?.pagination?.department_id?.label,value:paginationData?.pagination?.department_id?.value})
//                 setpage(1)
//               }
//               if(user.roles.includes('manager') || user.roles.includes('reporting_manager')){ 
//                 getleads(1)
//               }else{
//                   getleads1(1)
//               }
//             }else{
//                 if(user.roles.includes('manager') || user.roles.includes('reporting_manager')){ 
//                   applyfilterfunction(1)
//                 }else{
//                   applyfilterfunction(1)
//                 }
//             }
//           }else{