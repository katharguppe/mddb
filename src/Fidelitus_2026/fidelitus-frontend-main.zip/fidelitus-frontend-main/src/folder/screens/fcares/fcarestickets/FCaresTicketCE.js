import React,{useState,useEffect} from 'react'
import Grid from '@mui/material/Grid';
import { TextAreaInput1, TextInput } from '../../../components/input';
import { ButtonFilled, ButtonOutlined } from '../../../components/button';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import {Select } from 'antd';
import GoBack from '../../../components/back/GoBack';
// import DailyTaskCE from './dailyTask/DailyTaskCE';
import FcaresMenu from '../FcaresMenu';
import { BiCheckbox,BiCheckboxSquare } from "react-icons/bi";
import { CreateFcaresTicketService, GetFcaresTicketByIdService, UpdateFcaresTicketService } from '../../../services/Fcares/FCaresTicketService';
import { Tooltip } from '@mui/material'
import { IoClose } from 'react-icons/io5'
import { GetFcaresPropertyService, UploadDocsFcaresPropertyService } from '../../../services/Fcares/FCaresPropertyServices';

function FCaresTicketCE() {



  const [data,setdata] = useState({
    property:'',
    ticket_created_by:'',
    status:'',
    remarks:'',
    attachment:'',
    summary:'',
    attachment1:'',
  })

  

  
 
  const [loader, setloader] = useState(false);

  const status = [{label:'Pending',value:'Pending'},{label:'Discussion',value:'Discussion'},{label:'In Progress',value:'In Progress'},{label:'Resolved',value:'Resolved'}]
  const [property,setproperty] = useState([])

  const [error,seterror] = useState({
    property:'',
    ticket_created_by:'',
    status:'',
    remarks:'',
    attachment:'',
    summary:'',
    attachment1:'',
  })

  const navigate = useNavigate()
  const location = useLocation()




  async function uploadfilefunc(v,name){

    const fd = new FormData()
    fd.append('file',v); 
    const response = await UploadDocsFcaresPropertyService(fd)
    if(response?.status === 200){
    setdata({...data,[name]:response?.data?.data})
    }
  }

  useEffect(()=>{
      getData()
  },[])

  async function getData(){
    const response = await GetFcaresPropertyService('','','','1',1)
    let arr = []
    // console.log("response?.data?.datas",response?.data?.data)
    response?.data?.data?.datas?.forEach((d)=>{
      // console.log("D Here",d)
      let obj = { 
        label:d?.building_name,
        value:d?._id,
        client:d?.client?._id !== undefined ? {label:d?.client?.name,value:d?.client?._id} : '',
        tenant:d?.tenant?._id !== undefined ? {label:d?.tenant?.name,value:d?.tenant?._id} : '' 
      }
      arr?.push(obj)
    })
    setproperty(arr)
  }
   

  
  useEffect(()=>{
    if(location?.pathname?.split('/')[location?.pathname?.split('/').length -1] === 'edit'){
      geteditdata()
    }
  },[location?.pathname])

  async function geteditdata(){
    const response =  await GetFcaresTicketByIdService(location?.state);
    let d = response?.data?.data

    let sendData = {
      ticket_created_by:d?.ticket_created_by,
      status:d?.status,
      remarks:d?.remarks,
      attachment:d?.attachment,
      summary:d?.summary,
      attachment1:d?.attachment1,
      _id:d?._id
    }
    let obj = {
      label:d?.property?.building_name,
      value:d?.property?._id
    }

    obj['client'] = d?.client?._id !== undefined ? {label:d?.client?.name,value:d?.client?._id} : ''
    obj['tenant'] = d?.tenant?._id !== undefined ? {label:d?.tenant?.name,value:d?.tenant?._id} : ''
    sendData['property'] = obj

    console.log("obj",obj)
   
    setdata(sendData)
  }

  // console.log("data?.operators",data?.operators)
  function handlechange(e){
    setdata({...data,[e.target.name] : e.target.value})
    seterror({...error,[e.target.name] : ''})
  }


  async function submitform(){
   
        const sendData = {...data}
        if(data?.property?.client?.value !== undefined){
          sendData['client'] = data?.property?.client?.value       
        } 
        if(data?.property?.tenant?.value !== undefined){
          sendData['tenant'] = data?.property?.tenant?.value       
        }    
        sendData['property'] = data?.property?.value




        if(location?.pathname?.split('/')[location?.pathname?.split('/').length - 1] === 'edit'){
        

          setloader(true)
          const response = await UpdateFcaresTicketService(sendData?._id,sendData)
          if(response.status === 200){
            setloader(false)
            // console.log("Anna data?.stage?.label",data?.stage?.label,"stage?.selected_stage?.label",stage?.selected_stage?.label)
            setloader(false)
            toast.success('Ticket Updated Successfully')
            resetform()
            navigate(-1)
          }
        }else{  
          setloader(true)
          const response = await CreateFcaresTicketService(sendData)
          if(response.status === 201){
              setloader(false)
              toast.success('Ticket Created Successfully')
              resetform()
          }
        }
  }

  function resetform(){
     setdata({
        property:'',
        ticket_created_by:'',
        status:'',
        remarks:'',
        attachment:'',
        summary:'',
        attachment1:'',
      })
      seterror({
        property:'',
        ticket_created_by:'',
        status:'',
        remarks:'',
        attachment:'',
        summary:'',
        attachment1:'',
      })
  }


  async function setpropertyfunc(v){
     let propertyFind = property?.find((f)=>f?.value === v)
     if(propertyFind !== null){
       setdata({...data,property:propertyFind})
     }
  }

  // console.log("data.kp",data?.property)
  // console.log("property",property)
  return (
    <div className='h-screen max-h-screen box-border overflow-hidden'>
    <div className='block sm:flex'>
        <FcaresMenu />
    <div className='pr-5 ml-5 min-h-screen max-h-screen h-screen overflow-y-scroll' >
    

  

    <div className='w-64 '>
      <GoBack />
     <div className='border-b  pb-2'>
      <h6 className='font-[800] mb-1'>{location?.pathname?.split('/')[location?.pathname?.split('/').length -1] === 'edit' ? 'Edit' : 'Create'} Ticket </h6> 
      <h6 className='text-[11px] leading-tight font-[500] p-2 bg-slate-100 '>Use the below form to create or edit the ticket for the property fcares .</h6> 
     </div> 
      <Grid container spacing={2}  >
        <Grid item xs={12}  md={12} >

        <h6 className='text-[12px] font-semibold mb-1 mt-1'>Property*</h6>
        <Select 
        value={data?.property}
        bordered={false}
        onChange={(e)=>{setpropertyfunc(e)}} 
        options={property}
        className='border-l-4 border-l-slate-600 w-full border  outline-0 focus:outline-0 focus:ring-0 focus:border-none focus:border-red-900 focus:border-transparent focus:ring-offset-0 focus:shadow-none'
        />

        <h6 className='text-[12px] font-semibold mb-1 mt-2'>Ticket Raised By*</h6>

       <div className='flex items-center'>
        <div className='flex cusror-pointer mr-2' onClick={()=>setdata({...data,ticket_created_by:'Client'})}>
            {data?.ticket_created_by !== 'Client' ? <BiCheckbox className='text-slate-300' /> : <BiCheckboxSquare className='text-slate-600' />}
            <h6 className='text-[10px] ml-[3px] font-[700]'>Client</h6>
        </div>

        <div className='flex cusror-pointer' onClick={()=>setdata({...data,ticket_created_by:'Tenant'})}>
            {data?.ticket_created_by !== 'Tenant' ? <BiCheckbox className='text-slate-300' /> : <BiCheckboxSquare className='text-slate-600' />}
            <h6 className='text-[10px] ml-[3px] font-[700]'>Teant</h6>
        </div>
        </div>
       


        <h6 className='text-[12px] font-semibold mb-1 mt-1'>Status*</h6>

        <Select 
        value={data.status}
        bordered={false}
        onChange={(e)=>{setdata({...data,status:e})}} 
        options={status}
        className='border-l-4 border-l-slate-600 w-full border  outline-0 focus:outline-0 focus:ring-0 focus:border-none focus:border-red-900 focus:border-transparent focus:ring-offset-0 focus:shadow-none'
        />


      <h6 className='text-[11px] font-[600] mb-1 mt-2' >Query Attachment</h6>
        {(data.attachment === '' || data.attachment == null) ?
            <form onClick={()=>document.querySelector(`.input-field6`).click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border border-slate-300 `}>
                <input type='file' onChange={({target:{files}})=>{
                  files[0] && uploadfilefunc(files[0],'attachment')
                }} accept="*" className='input-field6' hidden />
            </form> 
          :
              <div className='p-2 border border-slate-300 relative flex flex-col  cursor-pointer'>
                  <Tooltip title='Delete'><IoClose className='absolute top-3 right-2' onClick={()=>setdata({...data,attachment:''})}/></Tooltip>
                  <h6 className='text-[12px] truncate w-48 ml-0'>{data?.attachment}</h6>
              </div>
          }

          <TextAreaInput1 
              mandatory={true}
              label={'Remarks'}  
              variant="standard"
              name="remarks"
              type="text"
              value={data.remarks}
              error={error.remarks}
              handlechange={handlechange}
              placeholder=""
              InputLabelProps={{
                  style: { color: '#fff', }, 
              }}/>


<h6 className='text-[11px] font-[600] mb-1' >Resolve Attachment</h6>
        {(data.attachment1 === '' || data.attachment1 == null) ?
            <form onClick={()=>document.querySelector(`.input-field6`).click()} className={`p-4 flex flex-col items-center justify-center cursor-pointer border border-slate-300 `}>
                <input type='file' onChange={({target:{files}})=>{
                  files[0] && uploadfilefunc(files[0],'attachment1')
                }} accept="*" className='input-field6' hidden />
            </form> 
          :
              <div className='p-2 border border-slate-300 relative flex flex-col  cursor-pointer'>
                  <Tooltip title='Delete'><IoClose className='absolute top-3 right-2' onClick={()=>setdata({...data,attachment1:''})}/></Tooltip>
                  <h6 className='text-[12px] truncate w-48 ml-0'>{data?.attachment1}</h6>
              </div>
          }

               <TextAreaInput1 
            label={'Resolution Remark'}  
            variant="standard"
            name="summary"
            type="text"
            value={data.summary}
            error={error.summary}
            handlechange={handlechange}
            placeholder=""
            InputLabelProps={{
                style: { color: '#fff', }, 
            }}/>
           



       
            
        </Grid>
       
      </Grid>

   
   <div >
    <div className='flex items-center mt-5 mb-10  border-t pt-5'>
        <div className='mr-2'>
        <ButtonOutlined btnName={'Back'} onClick={()=>navigate(-1)} />
        </div>
        <div>
        {loader ?   
        <ButtonFilled btnName={loader ? 'Loading' : 'Save'} /> :
        <ButtonFilled btnName={loader ? 'Loading' : 'Save'} onClick={()=>submitform(null)} /> }
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
   
  )
}

export default FCaresTicketCE