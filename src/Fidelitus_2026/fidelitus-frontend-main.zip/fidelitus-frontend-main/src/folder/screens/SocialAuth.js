import React, { useState, useEffect } from "react";
import { auth } from "../../firebase"; // Import auth from firebase.js
import { getAuth,GoogleAuthProvider, signInWithPopup, signInWithRedirect, OAuthProvider,getRedirectResult } from "firebase/auth";

const SocialAuth = () => {
  const [idToken, setIdToken] = useState("");

  // Function to sign in with Google
  const handleGoogleSignIn = async () => {
    const provider = new GoogleAuthProvider();
    
    try {
      const result = await signInWithPopup(auth, provider);
      console.log("result",result)
      const token = await result.user.getIdToken(true); // Get Firebase ID Token
      setIdToken(token);
      console.log("Firebase ID Token:", token);
     

    } catch (error) {
      console.error("Error during sign-in:", error);
    }
  };


  const HandleAppleLogin = async () => {
    const auth = getAuth();
    const provider = new OAuthProvider("apple.com");

    try {
      const result = await signInWithPopup(auth, provider);
      console.log("Apple Login Success:", result);
      const token = await result.user.getIdToken();
      console.log("Firebase ID Token:", token);
    } catch (error) {
      console.error("Apple Login Error:", error.code, error.message);
    }
  };

  return (
    <div>
      <h2>Firebase Auth in React</h2>
      <button onClick={handleGoogleSignIn}>Sign in with Google</button>
      <br></br>
      <button onClick={HandleAppleLogin}>Sign in with Apple</button>
      {idToken && <p>ID Token: {idToken.substring(0, 30)}...</p>}
    </div>
  );
};

export default SocialAuth;