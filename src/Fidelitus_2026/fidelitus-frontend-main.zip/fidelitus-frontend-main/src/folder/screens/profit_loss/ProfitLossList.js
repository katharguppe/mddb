import React, { useEffect, useState } from 'react'
import ProfitLossMenu from './ProfiltLossMenu'
import { useLocation, useNavigate } from 'react-router-dom'
import { IconButton, Tooltip } from '@mui/material'
import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
import { DatePicker, Modal } from 'antd'
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi'
import moment from 'moment'
import { AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai'
import toast from 'react-hot-toast'
import { DeleteVerticalProfitLossService, GetVerticalProfitLossService } from '../../services/VerticalProfitLoss'
import { useSelector } from 'react-redux'
import Priceconstants from '../../constants/imageConstants'

function ProfitLossList() {

  const path = useLocation()
  const path1 = path?.pathname?.split('/')[2]
  const navigate = useNavigate()
  const user = useSelector(state => state.Auth)

  const [modal,setmodal] = useState(false)
  const [selected_data,setselected_data] = useState({})
  const [data,setdata] = useState({})
  const [page,setpage] = useState(1)

  const limit = 10

  const [search,setsearch] = useState({
    from_date:'',
    to_date:'',
    from_date1:'',
    to_date1:''
  })

  // ===============================
  // FETCH DATA
  // ===============================
  useEffect(()=>{
    fetchData(page)
  },[page])

  async function fetchData(currentPage){
    const response = await GetVerticalProfitLossService({
      from_date1: search?.from_date1 || '',
      to_date1: search?.to_date1 || '',
      page: currentPage,
      limit: limit
    })
    setdata(response?.data || {})
  }

  function applyFilter(){
    setpage(1)
    fetchData(1)
  }

  function resetfunc(){
    setsearch({
      from_date:'',
      to_date:'',
      from_date1:'',
      to_date1:''
    })
    setpage(1)
    fetchData(1)
  }

  async function gotoedit(e){
    navigate('edit',{state:e})
  }

  async function deleteDatafunc(){
    const response = await DeleteVerticalProfitLossService(selected_data?._id)
    if(response?.status === 200){
      toast.success("Deleted Successfully")
      fetchData(page)
    }
    setmodal(false)
    setselected_data({})
  }

  // ===============================
  // PAGINATION CALCULATION
  // ===============================
  const totalRecords = data?.pagination?.total || 0
  const totalPages = Math.ceil(totalRecords / limit)

  const startIndex = totalRecords === 0 ? 0 : (page - 1) * limit + 1
  const endIndex = Math.min(page * limit, totalRecords)

  return (
    <div className='flex h-screen overflow-hidden'>
      <ProfitLossMenu />

      <Modal open={modal} width={320} closable={false} footer={false}>
        <div>
          <h6 className='text-[15px] font-[700]'>Delete Data</h6>
          <h6 className='text-[11px] p-2'>Before deleting confirm.</h6>
          <div className='flex pt-2 border-t'>
            <ButtonOutlinedAutoWidth btnName="Cancel" onClick={()=>setmodal(false)} />
            <div className='w-[10px]'/>
            <ButtonFilledAutoWidth btnName="Sure" onClick={deleteDatafunc} />
          </div>
        </div>
      </Modal>

      {/* ================= MAIN CONTENT ================= */}
      <div className='w-[88%] px-4 mt-2 flex flex-col'>

        {/* ================= HEADER ================= */}
        <div className='flex items-center justify-between flex-shrink-0 pb-2 border-b'>

          <h6 className='font-[700] text-[14px]'>
            Total {path1} ({totalRecords})
          </h6>

          <div className='flex items-center gap-3'>

            <span className='text-[12px] font-[600]'>
              {totalRecords > 0 ? `${startIndex} - ${endIndex}` : 0} of {totalRecords}
            </span>

            <IconButton
              disabled={page === 1}
              onClick={()=>setpage(prev=>prev-1)}
            >
              <FiChevronLeft size={18}/>
            </IconButton>

            <span className='text-[12px] font-semibold'>
              Page {page} / {totalPages || 1}
            </span>

            <IconButton
              disabled={page >= totalPages}
              onClick={()=>setpage(prev=>prev+1)}
            >
              <FiChevronRight size={18}/>
            </IconButton>

            <DatePicker
              size='small'
              placeholder='From Date'
              value={search?.from_date}
              onChange={(v,v1)=>setsearch({...search,from_date:v,from_date1:v1})}
            />

            <DatePicker
              size='small'
              placeholder='To Date'
              value={search?.to_date}
              onChange={(v,v1)=>setsearch({...search,to_date:v,to_date1:v1})}
            />

            <ButtonOutlinedAutoWidth btnName="Add Filter" onClick={applyFilter} />
            <ButtonOutlinedAutoWidth btnName="Reset" onClick={resetfunc} />
            <ButtonFilledAutoWidth btnName="Add Data" onClick={()=>navigate('create')} />

          </div>
        </div>

        {/* ================= SCROLLABLE CARD AREA ================= */}
        <div className='flex-1 pr-2 mt-3 overflow-y-auto'>

        <div className='grid grid-cols-5 gap-1 mt-2'>
  {data?.datas
    ?.filter(d =>
      user?.roles?.includes('admin') ||
      user?.roles?.includes('finance_head') ||
      user?.department_id?.[0]?.department_name === 'Corp Team' ||
      user?.department_id?.[0]?.department_name === d?.department?.department_name
    )
    ?.map((d) => {
      const canEditDelete =
        user?.roles?.includes('admin') ||
        user?.roles?.includes('finance_head') ||
        user?.department_id?.[0]?.department_name === 'Corp Team' ||
        user?.department_id?.[0]?.department_name === d?.department?.department_name;

      return (
        <div
          key={d?._id}
          className='border px-1.5 py-1 mt-1 relative mx-1 cursor-pointer'
        >
          <div className='p-2 bg-sky-100'>
            {canEditDelete && (
              <>
                <Tooltip title="Delete">
                  <span
                    className='absolute top-0 right-0 p-1 bg-white'
                    onClick={() => { setselected_data(d); setmodal(true) }}
                  >
                    <AiOutlineDelete
                      size={20}
                      className='absolute top-0 p-1 bg-white right-6'
                    />
                  </span>
                </Tooltip>

                <Tooltip title="Edit">
                  <span
                    className='absolute top-0 right-0 p-1 bg-white'
                    onClick={() => { gotoedit(d) }}
                  >
                    <AiOutlineEdit
                      size={20}
                      className='absolute top-0 p-1 bg-white right-1'
                    />
                  </span>
                </Tooltip>
              </>
            )}

            <h6 className='text-[11px]'>
              Profit/Loss Data for month :
              <span className='font-[600] text-[11px] line-clamp-2'>
                <span className='font-[400]'>CreatedAt :-</span>
                {moment(d?.createdAt)?.format('ll')}
              </span>
            </h6>
          </div>

          {(d?.department !== '' && d?.department !== null && d?.department !== undefined) && (
            <h6 className='text-[11px] flex pt-1'>
              Department :
              <span className='pl-1 font-[600] text-[11px] line-clamp-2'>
                {d?.department?.department_name}
              </span>
            </h6>
          )}
{d?.department?.department_name === "Digital Media" ? (
  // Show only the breakdown rows
  <div className='mt-2 border'>
 

  {d?.expenses_bifurcation?.length > 0 && (
    <div className='flex text-[11px] border-b items-center'>
      <h6 className='w-[50%] p-1 border-r'>Total Data Updated</h6>
      <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
    </div>
  )}

  {d?.new_events?.length > 0 && (
    <div className='flex text-[11px] border-b items-center'>
      <h6 className='w-[50%] p-1 border-r'>New Events</h6>
      <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
    </div>
  )}
</div>
) : (
  <div className='mt-2 border'>
  <div className='flex text-[11px] items-center border-b'>
    <h6 className='w-[50%] p-1 border-r'>Opening Balance</h6>
    <h6 className='font-[800] p-1'>{Priceconstants(d?.turn_over ?? 0)}</h6>
  </div>
  <div className='flex text-[11px] items-center border-b'>
    <h6 className='w-[50%] p-1 border-r'>Income received</h6>
    <h6 className='font-[800] p-1'>{Priceconstants(d?.revenue ?? 0)}</h6>
  </div>
  <div className='flex text-[11px] items-center border-b'>
    <h6 className='w-[50%] p-1 border-r'>Expense</h6>
    <h6 className='font-[800] p-1'>{Priceconstants(d?.expense ?? 0)}</h6>
  </div>
  <div className='flex text-[11px] items-center border-b'>
  <h6 className='w-[50%] p-1 border-r'>Advance</h6>
  <h6 className='font-[800] p-1'>
    {Priceconstants(
      d?.loan_details?.reduce(
        (sum, loan) => sum + Number(loan?.loan_amount || 0),
        0
      )
    )}
  </h6>
</div>
  <div className='flex text-[11px] items-center border-b'>
    <h6 className='w-[50%] p-1 border-r'>Vendor Expense</h6>
    <h6 className='font-[800] p-1'>{Priceconstants(d?.vendor_expenses ?? 0)}</h6>
  </div>
  <div className='flex text-[11px] border-b items-center'>
    <h6 className='w-[50%] p-1 border-r'>Closing Balance</h6>
    <h6 className='font-[800] p-1'>{Priceconstants(d?.outstanding ?? 0)}</h6>
  </div>

  {d?.new_leads?.length > 0 && (
    <div className='flex text-[11px] border-b items-center'>
      <h6 className='w-[50%] p-1 border-r'>New Leads</h6>
      <h6 className='font-[800] p-1'>{d?.new_leads?.length}</h6>
    </div>
  )}

  {d?.expenses_bifurcation?.length > 0 && (
    <div className='flex text-[11px] border-b items-center'>
      <h6 className='w-[50%] p-1 border-r'>Expenses Bifurcation</h6>
      <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
    </div>
  )}

  {d?.new_events?.length > 0 && (
    <div className='flex text-[11px] border-b items-center'>
      <h6 className='w-[50%] p-1 border-r'>New Events</h6>
      <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
    </div>
  )}
</div>
)}


          <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
            Created By :
            <span className='pl-1 font-[600] text-[11px] -ml-1 line-clamp-2'>
              {d?.created_by?.name}
            </span>
          </h6>
          <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
            Created At : {moment(d?.createdAt).format('LLL')}
          </h6>
        </div>
      );
    })}
</div>
        </div>

      </div>
    </div>
  )
}

export default ProfitLossList








//=============>> Old alla are fixed xcept scrolling


// import React, { useEffect, useState } from 'react'
// import ProfitLossMenu from './ProfiltLossMenu'
// import { useLocation, useNavigate } from 'react-router-dom'
// import { IconButton, Tooltip } from '@mui/material'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
// import { DatePicker, Modal } from 'antd'
// import { FiChevronLeft, FiChevronRight } from 'react-icons/fi'
// import moment from 'moment'
// import { AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai'
// import toast from 'react-hot-toast'
// import { DeleteVerticalProfitLossService, GetVerticalProfitLossService } from '../../services/VerticalProfitLoss'
// import { useSelector } from 'react-redux'
// import Priceconstants from '../../constants/imageConstants'

// function ProfitLossList() {

//   const path = useLocation()
//   const path1 = path?.pathname?.split('/')[2]
//   const navigate = useNavigate()
//   const user = useSelector(state => state.Auth)

//   const [modal,setmodal] = useState(false)
//   const [selected_data,setselected_data] = useState({})
//   const [data,setdata] = useState({})
//   const [page,setpage] = useState(1)

//   const limit = 10

//   const [search,setsearch] = useState({
//     from_date:'',
//     to_date:'',
//     from_date1:'',
//     to_date1:''
//   })

//   // ===============================
//   // FETCH DATA
//   // ===============================
//   useEffect(()=>{
//     fetchData(page)
//   },[page])

//   async function fetchData(currentPage){
//     const response = await GetVerticalProfitLossService({
//       from_date1: search?.from_date1 || '',
//       to_date1: search?.to_date1 || '',
//       page: currentPage,
//       limit: limit
//     })

//     setdata(response?.data || {})
//   }

//   // ===============================
//   // FILTER
//   // ===============================
//   function applyFilter(){
//     setpage(1)
//     fetchData(1)
//   }

//   function resetfunc(){
//     setsearch({
//       from_date:'',
//       to_date:'',
//       from_date1:'',
//       to_date1:''
//     })
//     setpage(1)
//     fetchData(1)
//   }


//   async function gotoedit(e){
//     navigate('edit',{state:e})
//   }

//   // ===============================
//   // DELETE
//   // ===============================
//   async function deleteDatafunc(){
//     const response = await DeleteVerticalProfitLossService(selected_data?._id)
//     if(response?.status === 200){
//       toast.success("Deleted Successfully")
//       fetchData(page)
//     }
//     setmodal(false)
//     setselected_data({})
//   }

//   // ===============================
//   // PAGINATION FIX (IMPORTANT)
//   // ===============================
//   const totalRecords = data?.pagination?.total || 0
//   const totalPages = Math.ceil(totalRecords / limit)

//   const startIndex = totalRecords === 0 ? 0 : (page - 1) * limit + 1
//   const endIndex = Math.min(page * limit, totalRecords)

//   return (
//     <div className='flex max-h-screen min-h-screen overflow-hidden'>
//       <ProfitLossMenu />

//       {/* ================= DELETE MODAL ================= */}
//       <Modal open={modal} width={320} closable={false} footer={false}>
//         <div>
//           <h6 className='text-[15px] font-[700]'>Delete Data</h6>
//           <h6 className='text-[11px] p-2'>Before deleting confirm.</h6>
//           <div className='flex pt-2 border-t'>
//             <ButtonOutlinedAutoWidth btnName="Cancel" onClick={()=>setmodal(false)} />
//             <div className='w-[10px]'/>
//             <ButtonFilledAutoWidth btnName="Sure" onClick={deleteDatafunc} />
//           </div>
//         </div>
//       </Modal>

//       <div className='w-[88%] px-4 mt-2'>

//         {/* ================= HEADER + PAGINATION ================= */}
//         <div className='flex items-center justify-between pb-2 border-b'>

//           <h6 className='font-[700] text-[14px]'>
//             Total {path1} ({totalRecords})
//           </h6>

//           <div className='flex items-center gap-3'>

//             <span className='text-[12px] font-[600]'>
//               {totalRecords > 0 ? `${startIndex} - ${endIndex}` : 0} of {totalRecords}
//             </span>

//             <IconButton
//               disabled={page === 1}
//               onClick={()=>setpage(prev=>prev-1)}
//             >
//               <FiChevronLeft size={18}/>
//             </IconButton>

//             <span className='text-[12px] font-semibold'>
//               Page {page} / {totalPages || 1}
//             </span>

//             <IconButton
//               disabled={page >= totalPages}
//               onClick={()=>setpage(prev=>prev+1)}
//             >
//               <FiChevronRight size={18}/>
//             </IconButton>

//             <DatePicker
//               size='small'
//               placeholder='From Date'
//               value={search?.from_date}
//               onChange={(v,v1)=>setsearch({...search,from_date:v,from_date1:v1})}
//             />

//             <DatePicker
//               size='small'
//               placeholder='To Date'
//               value={search?.to_date}
//               onChange={(v,v1)=>setsearch({...search,to_date:v,to_date1:v1})}
//             />

//             <ButtonOutlinedAutoWidth
//               btnName="Add Filter"
//               onClick={applyFilter}
//             />

//             <ButtonOutlinedAutoWidth
//               btnName="Reset"
//               onClick={resetfunc}
//             />

//             <ButtonFilledAutoWidth
//               btnName="Add Data"
//               onClick={()=>navigate('create')}
//             />

//           </div>
//         </div>

//         {/* ================= CARDS ================= */}
//         <div className='grid grid-cols-5 gap-1 mt-2'>
//   {data?.datas
//     ?.filter(d =>
//       user?.roles?.includes('admin') ||
//       user?.roles?.includes('finance_head') ||
//       user?.department_id?.[0]?.department_name === 'Corp Team' ||
//       user?.department_id?.[0]?.department_name === d?.department?.department_name
//     )
//     ?.map((d) => {
//       const canEditDelete =
//         user?.roles?.includes('admin') ||
//         user?.roles?.includes('finance_head') ||
//         user?.department_id?.[0]?.department_name === 'Corp Team' ||
//         user?.department_id?.[0]?.department_name === d?.department?.department_name;

//       return (
//         <div
//           key={d?._id}
//           className='border px-1.5 py-1 mt-1 relative mx-1 cursor-pointer'
//         >
//           <div className='p-2 bg-sky-100'>
//             {canEditDelete && (
//               <>
//                 <Tooltip title="Delete">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { setselected_data(d); setmodal(true) }}
//                   >
//                     <AiOutlineDelete
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-6'
//                     />
//                   </span>
//                 </Tooltip>

//                 <Tooltip title="Edit">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { gotoedit(d) }}
//                   >
//                     <AiOutlineEdit
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-1'
//                     />
//                   </span>
//                 </Tooltip>
//               </>
//             )}

//             <h6 className='text-[11px]'>
//               Profit/Loss Data for month :
//               <span className='font-[600] text-[11px] line-clamp-2'>
//                 <span className='font-[400]'>CreatedAt :-</span>
//                 {moment(d?.createdAt)?.format('ll')}
//               </span>
//             </h6>
//           </div>

//           {(d?.department !== '' && d?.department !== null && d?.department !== undefined) && (
//             <h6 className='text-[11px] flex pt-1'>
//               Department :
//               <span className='pl-1 font-[600] text-[11px] line-clamp-2'>
//                 {d?.department?.department_name}
//               </span>
//             </h6>
//           )}
// {d?.department?.department_name === "Digital Media" ? (
//   // Show only the breakdown rows
//   <div className='mt-2 border'>
 

//   {d?.expenses_bifurcation?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>Total Data Updated</h6>
//       <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//     </div>
//   )}

//   {d?.new_events?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//       <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//     </div>
//   )}
// </div>
// ) : (
//   <div className='mt-2 border'>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Opening Balance</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.turn_over ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Income received</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.revenue ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Expense</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.expense ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//   <h6 className='w-[50%] p-1 border-r'>Advance</h6>
//   <h6 className='font-[800] p-1'>
//     {Priceconstants(
//       d?.loan_details?.reduce(
//         (sum, loan) => sum + Number(loan?.loan_amount || 0),
//         0
//       )
//     )}
//   </h6>
// </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Vendor Expense</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.vendor_expenses ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] border-b items-center'>
//     <h6 className='w-[50%] p-1 border-r'>Closing Balance</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.outstanding ?? 0)}</h6>
//   </div>

//   {d?.new_leads?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Leads</h6>
//       <h6 className='font-[800] p-1'>{d?.new_leads?.length}</h6>
//     </div>
//   )}

//   {d?.expenses_bifurcation?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>Expenses Bifurcation</h6>
//       <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//     </div>
//   )}

//   {d?.new_events?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//       <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//     </div>
//   )}
// </div>
// )}


//           <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
//             Created By :
//             <span className='pl-1 font-[600] text-[11px] -ml-1 line-clamp-2'>
//               {d?.created_by?.name}
//             </span>
//           </h6>
//           <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
//             Created At : {moment(d?.createdAt).format('LLL')}
//           </h6>
//         </div>
//       );
//     })}
// </div>
//         </div> 

//       </div>
//   )
// }

// export default ProfitLossList









//==============>>> Pagination fixed below only UI need to update




// import React, { useEffect, useState } from 'react'
// import ProfitLossMenu from './ProfiltLossMenu'
// import { useLocation, useNavigate } from 'react-router-dom'
// import { IconButton, Tooltip } from '@mui/material'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
// import { DatePicker, Modal } from 'antd'
// import { FiChevronLeft, FiChevronRight } from 'react-icons/fi'
// import moment from 'moment'
// import { AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai'
// import toast from 'react-hot-toast'
// import { DeleteVerticalProfitLossService, GetVerticalProfitLossService } from '../../services/VerticalProfitLoss'
// import { useSelector } from 'react-redux'
// import Priceconstants from '../../constants/imageConstants'

// function ProfitLossList() {

//   const path = useLocation()
//   const path1 = path?.pathname?.split('/')[2]
//   const navigate = useNavigate()
//   const user = useSelector(state => state.Auth)

//   const [modal,setmodal] = useState(false)
//   const [selected_data,setselected_data] = useState({})
//   const [data,setdata] = useState({})
//   const [page,setpage] = useState(1)

//   const limit = 10

//   const [search,setsearch] = useState({
//     from_date:'',
//     to_date:'',
//     from_date1:'',
//     to_date1:''
//   })

//   // ===============================
//   // FETCH DATA
//   // ===============================
//   useEffect(()=>{
//     fetchData(page)
//   },[page])

//   async function fetchData(currentPage){
//     const response = await GetVerticalProfitLossService({
//       from_date1: search?.from_date1 || '',
//       to_date1: search?.to_date1 || '',
//       page: currentPage,
//       limit: limit
//     })

//     setdata(response?.data || {})
//   }

//   // ===============================
//   // FILTER
//   // ===============================
//   function applyFilter(){
//     setpage(1)
//     fetchData(1)
//   }

//   function resetfunc(){
//     setsearch({
//       from_date:'',
//       to_date:'',
//       from_date1:'',
//       to_date1:''
//     })
//     setpage(1)
//     fetchData(1)
//   }

//   // ===============================
//   // DELETE
//   // ===============================
//   async function deleteDatafunc(){
//     const response = await DeleteVerticalProfitLossService(selected_data?._id)
//     if(response?.status === 200){
//       toast.success("Deleted Successfully")
//       fetchData(page)
//     }
//     setmodal(false)
//     setselected_data({})
//   }

//   // ===============================
//   // PAGINATION FIX (IMPORTANT)
//   // ===============================
//   const totalRecords = data?.pagination?.total || 0
//   const totalPages = Math.ceil(totalRecords / limit)

//   const startIndex = totalRecords === 0 ? 0 : (page - 1) * limit + 1
//   const endIndex = Math.min(page * limit, totalRecords)

//   return (
//     <div className='flex max-h-screen min-h-screen overflow-hidden'>
//       <ProfitLossMenu />

//       {/* ================= DELETE MODAL ================= */}
//       <Modal open={modal} width={320} closable={false} footer={false}>
//         <div>
//           <h6 className='text-[15px] font-[700]'>Delete Data</h6>
//           <h6 className='text-[11px] p-2'>Before deleting confirm.</h6>
//           <div className='flex pt-2 border-t'>
//             <ButtonOutlinedAutoWidth btnName="Cancel" onClick={()=>setmodal(false)} />
//             <div className='w-[10px]'/>
//             <ButtonFilledAutoWidth btnName="Sure" onClick={deleteDatafunc} />
//           </div>
//         </div>
//       </Modal>

//       <div className='w-[88%] px-4 mt-2'>

//         {/* ================= HEADER + PAGINATION ================= */}
//         <div className='flex items-center justify-between pb-2 border-b'>

//           <h6 className='font-[700] text-[14px]'>
//             Total {path1} ({totalRecords})
//           </h6>

//           <div className='flex items-center gap-3'>

//             <span className='text-[12px] font-[600]'>
//               {totalRecords > 0 ? `${startIndex} - ${endIndex}` : 0} of {totalRecords}
//             </span>

//             <IconButton
//               disabled={page === 1}
//               onClick={()=>setpage(prev=>prev-1)}
//             >
//               <FiChevronLeft size={18}/>
//             </IconButton>

//             <span className='text-[12px] font-semibold'>
//               Page {page} / {totalPages || 1}
//             </span>

//             <IconButton
//               disabled={page >= totalPages}
//               onClick={()=>setpage(prev=>prev+1)}
//             >
//               <FiChevronRight size={18}/>
//             </IconButton>

//             <DatePicker
//               size='small'
//               placeholder='From Date'
//               value={search?.from_date}
//               onChange={(v,v1)=>setsearch({...search,from_date:v,from_date1:v1})}
//             />

//             <DatePicker
//               size='small'
//               placeholder='To Date'
//               value={search?.to_date}
//               onChange={(v,v1)=>setsearch({...search,to_date:v,to_date1:v1})}
//             />

//             <ButtonOutlinedAutoWidth
//               btnName="Add Filter"
//               onClick={applyFilter}
//             />

//             <ButtonOutlinedAutoWidth
//               btnName="Reset"
//               onClick={resetfunc}
//             />

//             <ButtonFilledAutoWidth
//               btnName="Add Data"
//               onClick={()=>navigate('create')}
//             />

//           </div>
//         </div>

//         {/* ================= CARDS ================= */}
//         <div className='grid grid-cols-5 gap-1 mt-2'>

//           {data?.datas?.filter(d =>
//             user?.roles?.includes('admin') ||
//             user?.roles?.includes('finance_head') ||
//             user?.department_id?.[0]?.department_name === 'Corp Team' ||
//             user?.department_id?.[0]?.department_name === d?.department?.department_name
//           ).map(d=>{

//             const canEditDelete =
//               user?.roles?.includes('admin') ||
//               user?.roles?.includes('finance_head') ||
//               user?.department_id?.[0]?.department_name === 'Corp Team' ||
//               user?.department_id?.[0]?.department_name === d?.department?.department_name;

//             return (
//               <div key={d?._id} className='border px-1.5 py-1 mt-1 relative mx-1 cursor-pointer'>

//                 <div className='p-2 bg-sky-100'>
//                   {canEditDelete && (
//                     <>
//                       <Tooltip title="Delete">
//                         <span onClick={()=>{setselected_data(d);setmodal(true)}}>
//                           <AiOutlineDelete size={18} className='absolute right-6 top-1'/>
//                         </span>
//                       </Tooltip>
//                       <Tooltip title="Edit">
//                         <span onClick={()=>navigate('edit',{state:d})}>
//                           <AiOutlineEdit size={18} className='absolute right-1 top-1'/>
//                         </span>
//                       </Tooltip>
//                     </>
//                   )}

//                   <h6 className='text-[11px]'>
//                     CreatedAt : {moment(d?.createdAt)?.format('ll')}
//                   </h6>
//                 </div>

//                 <div className='mt-2 border'>
//                   <div className='flex text-[11px] border-b'>
//                     <h6 className='w-[50%] p-1 border-r'>Opening Balance</h6>
//                     <h6 className='p-1 font-[700]'>{Priceconstants(d?.turn_over ?? 0)}</h6>
//                   </div>
//                   <div className='flex text-[11px] border-b'>
//                     <h6 className='w-[50%] p-1 border-r'>Income received</h6>
//                     <h6 className='p-1 font-[700]'>{Priceconstants(d?.revenue ?? 0)}</h6>
//                   </div>
//                   <div className='flex text-[11px] border-b'>
//                     <h6 className='w-[50%] p-1 border-r'>Expense</h6>
//                     <h6 className='p-1 font-[700]'>{Priceconstants(d?.expense ?? 0)}</h6>
//                   </div>
//                   <div className='flex text-[11px]'>
//                     <h6 className='w-[50%] p-1 border-r'>Closing Balance</h6>
//                     <h6 className='p-1 font-[700]'>{Priceconstants(d?.outstanding ?? 0)}</h6>
//                   </div>
//                 </div>

//               </div>
//             )
//           })}

//         </div>

//       </div>
//     </div>
//   )
// }

// export default ProfitLossList






//===========>>> Old one  without pagination

// import React, { useEffect, useState } from 'react'
// import ProfitLossMenu from './ProfiltLossMenu'
// import { useLocation, useNavigate } from 'react-router-dom'
// import { IconButton, Tooltip } from '@mui/material'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
// import { DatePicker, Modal } from 'antd'
// import { BsArrowRepeat } from 'react-icons/bs'
// import { FiChevronLeft,FiChevronRight } from 'react-icons/fi'
// import moment from 'moment'
// import { AiOutlineEdit,AiOutlineDelete } from 'react-icons/ai'
// import toast from 'react-hot-toast'
// import { DeleteVerticalProfitLossService, GetVerticalProfitLossService } from '../../services/VerticalProfitLoss'
// import { useSelector } from 'react-redux'
// import Priceconstants from '../../constants/imageConstants'

// function ProfitLossList() {

//     const path = useLocation()
//     const path1 = path?.pathname?.split('/')[2]
//     const navigate = useNavigate()

//     // const user = useSelector(state=>state.Auth.user)
//     const user = useSelector(state=>state.Auth)
  
//     const [modal,setmodal] = useState(false)
//     const [selected_data,setselected_data] = useState({})
//     const [data,setdata] = useState({})
//     const [page,setpage] = useState(1)
//     const [search,setsearch] = useState({text:'',from_date:'',to_date:'',from_date1:'',to_date1:'',activate:false})
   


     
//   //   useEffect(()=>{
//   //     if(search?.activate){
//   //        applyfilterfunction(page)
//   //     } else {
//   //        getdata(page)
//   //     }
//   // },[page, path1, search?.activate])

//   useEffect(()=>{
//     fetchData(page)
//   },[])
   
//   function resetfunc(){
//     setsearch({
//         text:'',
//         from_date:'',
//         to_date:'',
//         from_date1:'',
//         to_date1:'',
//         activate:false
//     })
//     setpage(1)
// }
  
//       // async function applyfilterfunction(v = ''){
//       //   setsearch({...search,activate:true})
//       //   const response = await GetVerticalProfitLossService({from_date1:search?.from_date1,to_date1:search?.to_date1,page:v !==  '' ? v :page})
//       //   setdata(response?.data)
//       // }

//       async function applyfilterfunction(v = 1){
//         const response = await GetVerticalProfitLossService({
//             from_date1: search?.from_date1,
//             to_date1: search?.to_date1,
//             page: v
//         })
//         setdata(response?.data)
//     }

//       async function getdata(page){
//         const response = await GetVerticalProfitLossService({from_date1:search?.from_date1,to_date1:search?.to_date1,page})
//         setdata(response?.data)
//       }

//       async function gotoedit(e){
//         navigate('edit',{state:e})
//       }

//       async function deleteDatafunc(){
//         const response = await DeleteVerticalProfitLossService(selected_data?._id)
//         if(response?.status === 200){
//           toast.success("Deleted Successfully")
//           setmodal(false)
//           getdata(page)
//           setselected_data({})
//         }else{
//             toast.success("Error : Deleted Successfully")
//             setmodal(false)
//             getdata(page)
//             setselected_data({})
//         }

//       }

//       console.log("data?.datas",data?.datas?.length)
//       console.log("roles",user?.roles)  // incluse admin 
//      console.log("USer_Department_Name",user?.department_id[0]?.department_name)
//      console.log("USer_Department_Name",user?.department_id[0]?.department_name)

//      console.log("##################",data?.datas)


//      async function fetchData(currentPage){
//       const response = await GetVerticalProfitLossService({
//           from_date1: search?.activate ? search?.from_date1 : '',
//           to_date1: search?.activate ? search?.to_date1 : '',
//           page: currentPage
//       })
    
//       setdata(response?.data)
//     }
//   return (
//     <div className='flex max-h-screen min-h-screen overflow-hidden'>
//         <ProfitLossMenu /> 
//        < Modal open={modal} width={320} closable={false} footer={false}>
//           <div> 

//             <h6 className='text-[15px] font-[700]'>Delete Data</h6>
//             <h6 className='text-[11px] leading-tight p-2' >Before Deleting the data be sure that it is required or not for further purpose.</h6>
             
//              <div className='flex items-center pt-2 border-t'>
//                 <ButtonOutlinedAutoWidth btnName="Cancel" onClick={()=>setmodal(false)} />
//                 <h6 className='w-[10px]'></h6>
//                 <ButtonFilledAutoWidth btnName="Sure" onClick={deleteDatafunc} />
//              </div>
//           </div>
//        </Modal>
//         <div className='w-[88%] px-4 mt-2'>
//             <div className='flex items-center justify-between pb-2 border-b'>
//                 <h6 className='font-[700] text-[14px] '>Total<span className='capitalize'>{path1}</span> ({data?.pagination?.total})</h6>
//                 <div className='flex items-center'>
//                 <div className='flex items-center text-[12px] mr-2'>

//                     <h6 className='mr-2 font-[600]'>{page == 1 ? data?.datas?.length > 0 ? 1 : 0 : (page - 1) * data?.pagination?.limit } - {data?.pagination?.limit} of {data?.pagination?.total} </h6>
//                     <IconButton onClick={resetfunc}><BsArrowRepeat size={16} /></IconButton>

//                     <div>
//   <IconButton 
//     disabled={page === 1}
//     onClick={()=>{
//       const newPage = page - 1
//       setpage(newPage)
//       fetchData(newPage)
//     }}
//   >
//     <FiChevronLeft size={16} />
//   </IconButton>

//   <IconButton 
//     disabled={page >= (data?.pagination?.totalPages || 1)}
//     onClick={()=>{
//       const newPage = page + 1
//       setpage(newPage)
//       fetchData(newPage)
//     }}
//   >
//     <FiChevronRight size={16} />
//   </IconButton>
// </div>
//                 </div>


//                 <DatePicker size='small' style={{fontSize:'11px'}} ampm={false} placeholder='From Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2'  value={search?.from_date} onChange={(v,v1) => {setsearch({...search,from_date:v,from_date1:v1})}} /> 

//                 <DatePicker size='small' style={{fontSize:'11px'}} ampm={false} placeholder='To Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2'  value={search?.to_date} onChange={(v,v1) => {setsearch({...search,to_date:v,to_date1:v1})}} /> 
//                 <ButtonOutlinedAutoWidth 
//   btnName="Add Filter" 
//   onClick={()=>{
//     setsearch(prev=>({...prev, activate:true}))
//     setpage(1)
//     fetchData(1)
//   }} 
// />
          
//             <div className='ml-2'>
//             <ButtonFilledAutoWidth btnName="Add Data" onClick={()=>navigate('create')}/> 
//             </div>
//                 </div>
//             </div>
             
//             <div className='max-h-[90vh] overflow-y-scroll'>
//                 <div className='grid grid-cols-5 gap-1 mt-2'>
//   {data?.datas
//     ?.filter(d =>
//       user?.roles?.includes('admin') ||
//       user?.roles?.includes('finance_head') ||
//       user?.department_id?.[0]?.department_name === 'Corp Team' ||
//       user?.department_id?.[0]?.department_name === d?.department?.department_name
//     )
//     ?.map((d) => {
//       const canEditDelete =
//         user?.roles?.includes('admin') ||
//         user?.roles?.includes('finance_head') ||
//         user?.department_id?.[0]?.department_name === 'Corp Team' ||
//         user?.department_id?.[0]?.department_name === d?.department?.department_name;

//       return (
//         <div
//           key={d?._id}
//           className='border px-1.5 py-1 mt-1 relative mx-1 cursor-pointer'
//         >
//           <div className='p-2 bg-sky-100'>
//             {canEditDelete && (
//               <>
//                 <Tooltip title="Delete">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { setselected_data(d); setmodal(true) }}
//                   >
//                     <AiOutlineDelete
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-6'
//                     />
//                   </span>
//                 </Tooltip>

//                 <Tooltip title="Edit">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { gotoedit(d) }}
//                   >
//                     <AiOutlineEdit
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-1'
//                     />
//                   </span>
//                 </Tooltip>
//               </>
//             )}

//             <h6 className='text-[11px]'>
//               Profit/Loss Data for month :
//               <span className='font-[600] text-[11px] line-clamp-2'>
//                 <span className='font-[400]'>CreatedAt :-</span>
//                 {moment(d?.createdAt)?.format('ll')}
//               </span>
//             </h6>
//           </div>

//           {(d?.department !== '' && d?.department !== null && d?.department !== undefined) && (
//             <h6 className='text-[11px] flex pt-1'>
//               Department :
//               <span className='pl-1 font-[600] text-[11px] line-clamp-2'>
//                 {d?.department?.department_name}
//               </span>
//             </h6>
//           )}
// {d?.department?.department_name === "Digital Media" ? (
//   // Show only the breakdown rows
//   <div className='mt-2 border'>
 

//   {d?.expenses_bifurcation?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>Total Data Updated</h6>
//       <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//     </div>
//   )}

//   {d?.new_events?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//       <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//     </div>
//   )}
// </div>
// ) : (
//   <div className='mt-2 border'>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Opening Balance</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.turn_over ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Income received</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.revenue ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Expense</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.expense ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//   <h6 className='w-[50%] p-1 border-r'>Advance</h6>
//   <h6 className='font-[800] p-1'>
//     {Priceconstants(
//       d?.loan_details?.reduce(
//         (sum, loan) => sum + Number(loan?.loan_amount || 0),
//         0
//       )
//     )}
//   </h6>
// </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Vendor Expense</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.vendor_expenses ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] border-b items-center'>
//     <h6 className='w-[50%] p-1 border-r'>Closing Balance</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.outstanding ?? 0)}</h6>
//   </div>

//   {d?.new_leads?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Leads</h6>
//       <h6 className='font-[800] p-1'>{d?.new_leads?.length}</h6>
//     </div>
//   )}

//   {d?.expenses_bifurcation?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>Expenses Bifurcation</h6>
//       <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//     </div>
//   )}

//   {d?.new_events?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//       <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//     </div>
//   )}
// </div>
// )}


//           <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
//             Created By :
//             <span className='pl-1 font-[600] text-[11px] -ml-1 line-clamp-2'>
//               {d?.created_by?.name}
//             </span>
//           </h6>
//           <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
//             Created At : {moment(d?.createdAt).format('LLL')}
//           </h6>
//         </div>
//       );
//     })}
// </div>
//         </div> 
//         </div>

//     </div>
//   )
// }

// export default ProfitLossList













//=========>> Working on pagination 2026 feb 20


// import React, { useEffect, useState } from 'react'
// import ProfitLossMenu from './ProfiltLossMenu'
// import { useLocation, useNavigate } from 'react-router-dom'
// import { IconButton, Tooltip } from '@mui/material'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
// import { DatePicker, Modal } from 'antd'
// import { BsArrowRepeat } from 'react-icons/bs'
// import { FiChevronLeft,FiChevronRight } from 'react-icons/fi'
// import moment from 'moment'
// import { AiOutlineEdit,AiOutlineDelete } from 'react-icons/ai'
// import toast from 'react-hot-toast'
// import { DeleteVerticalProfitLossService, GetVerticalProfitLossService } from '../../services/VerticalProfitLoss'
// import { useSelector } from 'react-redux'
// import Priceconstants from '../../constants/imageConstants'

// function ProfitLossList() {

//     const path = useLocation()
//     const path1 = path?.pathname?.split('/')[2]
//     const navigate = useNavigate()

//     // const user = useSelector(state=>state.Auth.user)
//     const user = useSelector(state=>state.Auth)
  
//     const [modal,setmodal] = useState(false)
//     const [selected_data,setselected_data] = useState({})
//     const [data,setdata] = useState({})
//     const [page,setpage] = useState(1)
//     const [search,setsearch] = useState({text:'',from_date:'',to_date:'',from_date1:'',to_date1:'',activate:false})
   


     
//     useEffect(()=>{
//         if(search?.activate){
//            applyfilterfunction(page)
//         }else{
//            getdata(page)
//         }
//     },[page,path1])
   
//     async function resetfunc(){
//         setsearch({text:'',from_date:'',to_date:'',from_date1:'',to_date1:'',activate:false})
//         const response = await GetVerticalProfitLossService({from_date1:'',to_date1:'',page:1})
//         setdata(response?.data)
//       }
  
//       async function applyfilterfunction(v = ''){
//         setsearch({...search,activate:true})
//         const response = await GetVerticalProfitLossService({from_date1:search?.from_date1,to_date1:search?.to_date1,page:v !==  '' ? v :page})
//         setdata(response?.data)
//       }

//       async function getdata(page){
//         const response = await GetVerticalProfitLossService({from_date1:search?.from_date1,to_date1:search?.to_date1,page})
//         setdata(response?.data)
//       }

//       async function gotoedit(e){
//         navigate('edit',{state:e})
//       }

//       async function deleteDatafunc(){
//         const response = await DeleteVerticalProfitLossService(selected_data?._id)
//         if(response?.status === 200){
//           toast.success("Deleted Successfully")
//           setmodal(false)
//           getdata(page)
//           setselected_data({})
//         }else{
//             toast.success("Error : Deleted Successfully")
//             setmodal(false)
//             getdata(page)
//             setselected_data({})
//         }

//       }

//       console.log("data?.datas",data?.datas?.length)
//       console.log("roles",user?.roles)  // incluse admin 
//      console.log("USer_Department_Name",user?.department_id[0]?.department_name)
//      console.log("USer_Department_Name",user?.department_id[0]?.department_name)

//      console.log("##################",data?.datas)

//   return (
//     <div className='flex max-h-screen min-h-screen overflow-hidden'>
//         <ProfitLossMenu /> 
//        < Modal open={modal} width={320} closable={false} footer={false}>
//           <div> 

//             <h6 className='text-[15px] font-[700]'>Delete Data</h6>
//             <h6 className='text-[11px] leading-tight p-2' >Before Deleting the data be sure that it is required or not for further purpose.</h6>
             
//              <div className='flex items-center pt-2 border-t'>
//                 <ButtonOutlinedAutoWidth btnName="Cancel" onClick={()=>setmodal(false)} />
//                 <h6 className='w-[10px]'></h6>
//                 <ButtonFilledAutoWidth btnName="Sure" onClick={deleteDatafunc} />
//              </div>
//           </div>
//        </Modal>
//         <div className='w-[88%] px-4 mt-2'>
//             <div className='flex items-center justify-between pb-2 border-b'>
//                 <h6 className='font-[700] text-[14px] '>Total<span className='capitalize'>{path1}</span> ({data?.pagination?.total})</h6>
//                 <div className='flex items-center'>
//                 <div className='flex items-center text-[12px] mr-2'>

//                     <h6 className='mr-2 font-[600]'>{page == 1 ? data?.datas?.length > 0 ? 1 : 0 : (page - 1) * data?.pagination?.limit } - {data?.pagination?.limit} of {data?.pagination?.total} </h6>
//                     <IconButton onClick={resetfunc}><BsArrowRepeat size={16} /></IconButton>

//                     <div>
//                     <IconButton onClick={()=>{page > 1 ? setpage(page-1) : console.log('')}}><FiChevronLeft className={`${page === 1 ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>
//                     <IconButton onClick={()=>{ page < data?.pagination?.totalPages  ? setpage(page+1) : console.log('')}}><FiChevronRight className={`${(data?.pagination?.totalPages === page || data?.datas?.length === 0)  ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>

//                     </div>
//                 </div>


//                 <DatePicker size='small' style={{fontSize:'11px'}} ampm={false} placeholder='From Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2'  value={search?.from_date} onChange={(v,v1) => {setsearch({...search,from_date:v,from_date1:v1})}} /> 

//                 <DatePicker size='small' style={{fontSize:'11px'}} ampm={false} placeholder='To Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2'  value={search?.to_date} onChange={(v,v1) => {setsearch({...search,to_date:v,to_date1:v1})}} /> 

//             <ButtonOutlinedAutoWidth btnName="Add Filter" onClick={()=>applyfilterfunction(1)} /> 
          
//             <div className='ml-2'>
//             <ButtonFilledAutoWidth btnName="Add Data" onClick={()=>navigate('create')}/> 
//             </div>
//                 </div>
//             </div>
             
//             <div className='max-h-[90vh] overflow-y-scroll'>
//                 <div className='grid grid-cols-5 gap-1 mt-2'>
//   {data?.datas
//     ?.filter(d =>
//       user?.roles?.includes('admin') ||
//       user?.roles?.includes('finance_head') ||
//       user?.department_id?.[0]?.department_name === 'Corp Team' ||
//       user?.department_id?.[0]?.department_name === d?.department?.department_name
//     )
//     ?.map((d) => {
//       const canEditDelete =
//         user?.roles?.includes('admin') ||
//         user?.roles?.includes('finance_head') ||
//         user?.department_id?.[0]?.department_name === 'Corp Team' ||
//         user?.department_id?.[0]?.department_name === d?.department?.department_name;

//       return (
//         <div
//           key={d?._id}
//           className='border px-1.5 py-1 mt-1 relative mx-1 cursor-pointer'
//         >
//           <div className='p-2 bg-sky-100'>
//             {canEditDelete && (
//               <>
//                 <Tooltip title="Delete">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { setselected_data(d); setmodal(true) }}
//                   >
//                     <AiOutlineDelete
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-6'
//                     />
//                   </span>
//                 </Tooltip>

//                 <Tooltip title="Edit">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { gotoedit(d) }}
//                   >
//                     <AiOutlineEdit
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-1'
//                     />
//                   </span>
//                 </Tooltip>
//               </>
//             )}

//             <h6 className='text-[11px]'>
//               Profit/Loss Data for month :
//               <span className='font-[600] text-[11px] line-clamp-2'>
//                 <span className='font-[400]'>CreatedAt :-</span>
//                 {moment(d?.createdAt)?.format('ll')}
//               </span>
//             </h6>
//           </div>

//           {(d?.department !== '' && d?.department !== null && d?.department !== undefined) && (
//             <h6 className='text-[11px] flex pt-1'>
//               Department :
//               <span className='pl-1 font-[600] text-[11px] line-clamp-2'>
//                 {d?.department?.department_name}
//               </span>
//             </h6>
//           )}

//           {/* <div className='mt-2 border'>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Opening Balance</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.turn_over ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Income received</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.revenue ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Expense</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.expense ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Vendor Expense</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.vendor_expenses ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] border-b items-center'>
//               <h6 className='w-[50%] p-1 border-r'>Closing Balance</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.outstanding ?? 0)}</h6>
//             </div>

//             {d?.new_leads?.length > 0 && (
//               <div className='flex text-[11px] border-b items-center'>
//                 <h6 className='w-[50%] p-1 border-r'>New Leads</h6>
//                 <h6 className='font-[800] p-1'>{d?.new_leads?.length}</h6>
//               </div>
//             )}

//             {d?.expenses_bifurcation?.length > 0 && (
//               <div className='flex text-[11px] border-b items-center'>
//                 <h6 className='w-[50%] p-1 border-r'>Expenses Bifurcation</h6>
//                 <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//               </div>
//             )}

//             {d?.new_events?.length > 0 && (
//               <div className='flex text-[11px] border-b items-center'>
//                 <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//                 <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//               </div>
//             )}
//           </div> */}

// {d?.department?.department_name === "Digital Media" ? (
//   // Show only the breakdown rows
//   <div className='mt-2 border'>
 

//   {d?.expenses_bifurcation?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>Total Data Updated</h6>
//       <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//     </div>
//   )}

//   {d?.new_events?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//       <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//     </div>
//   )}
// </div>
// ) : (
//   <div className='mt-2 border'>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Opening Balance</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.turn_over ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Income received</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.revenue ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Expense</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.expense ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//   <h6 className='w-[50%] p-1 border-r'>Advance</h6>
//   <h6 className='font-[800] p-1'>
//     {Priceconstants(
//       d?.loan_details?.reduce(
//         (sum, loan) => sum + Number(loan?.loan_amount || 0),
//         0
//       )
//     )}
//   </h6>
// </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Vendor Expense</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.vendor_expenses ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] border-b items-center'>
//     <h6 className='w-[50%] p-1 border-r'>Closing Balance</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.outstanding ?? 0)}</h6>
//   </div>

//   {d?.new_leads?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Leads</h6>
//       <h6 className='font-[800] p-1'>{d?.new_leads?.length}</h6>
//     </div>
//   )}

//   {d?.expenses_bifurcation?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>Expenses Bifurcation</h6>
//       <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//     </div>
//   )}

//   {d?.new_events?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//       <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//     </div>
//   )}
// </div>
// )}


//           <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
//             Created By :
//             <span className='pl-1 font-[600] text-[11px] -ml-1 line-clamp-2'>
//               {d?.created_by?.name}
//             </span>
//           </h6>
//           <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
//             Created At : {moment(d?.createdAt).format('LLL')}
//           </h6>
//         </div>
//       );
//     })}
// </div>
//         </div> 
//         </div>

//     </div>
//   )
// }

// export default ProfitLossList













///==========>> Old is working feb 2026 using 


// import React, { useEffect, useState } from 'react'
// import ProfitLossMenu from './ProfiltLossMenu'
// import { useLocation, useNavigate } from 'react-router-dom'
// import { IconButton, Tooltip } from '@mui/material'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
// import { DatePicker, Modal } from 'antd'
// import { BsArrowRepeat } from 'react-icons/bs'
// import { FiChevronLeft,FiChevronRight } from 'react-icons/fi'
// import moment from 'moment'
// import { AiOutlineEdit,AiOutlineDelete } from 'react-icons/ai'
// import toast from 'react-hot-toast'
// import { DeleteVerticalProfitLossService, GetVerticalProfitLossService } from '../../services/VerticalProfitLoss'
// import { useSelector } from 'react-redux'
// import Priceconstants from '../../constants/imageConstants'

// function ProfitLossList() {

//     const path = useLocation()
//     const path1 = path?.pathname?.split('/')[2]
//     const navigate = useNavigate()

//     // const user = useSelector(state=>state.Auth.user)
//     const user = useSelector(state=>state.Auth)
  
//     const [modal,setmodal] = useState(false)
//     const [selected_data,setselected_data] = useState({})
//     const [data,setdata] = useState({})
//     const [page,setpage] = useState(1)
//     const [search,setsearch] = useState({text:'',from_date:'',to_date:'',from_date1:'',to_date1:'',activate:false})
   


     
//     useEffect(()=>{
//         if(search?.activate){
//            applyfilterfunction(page)
//         }else{
//            getdata(page)
//         }
//     },[page,path1])
   
//     async function resetfunc(){
//         setsearch({text:'',from_date:'',to_date:'',from_date1:'',to_date1:'',activate:false})
//         const response = await GetVerticalProfitLossService({from_date1:'',to_date1:'',page:1})
//         setdata(response?.data)
//       }
  
//       async function applyfilterfunction(v = ''){
//         setsearch({...search,activate:true})
//         const response = await GetVerticalProfitLossService({from_date1:search?.from_date1,to_date1:search?.to_date1,page:v !==  '' ? v :page})
//         setdata(response?.data)
//       }

//       async function getdata(page){
//         const response = await GetVerticalProfitLossService({from_date1:search?.from_date1,to_date1:search?.to_date1,page})
//         setdata(response?.data)
//       }

//       async function gotoedit(e){
//         navigate('edit',{state:e})
//       }

//       async function deleteDatafunc(){
//         const response = await DeleteVerticalProfitLossService(selected_data?._id)
//         if(response?.status === 200){
//           toast.success("Deleted Successfully")
//           setmodal(false)
//           getdata(page)
//           setselected_data({})
//         }else{
//             toast.success("Error : Deleted Successfully")
//             setmodal(false)
//             getdata(page)
//             setselected_data({})
//         }

//       }

//       console.log("data?.datas",data?.datas?.length)
//       console.log("roles",user?.roles)  // incluse admin 
//      console.log("USer_Department_Name",user?.department_id[0]?.department_name)
//      console.log("USer_Department_Name",user?.department_id[0]?.department_name)

//      console.log("##################",data?.datas)

//   return (
//     <div className='flex max-h-screen min-h-screen overflow-hidden'>
//         <ProfitLossMenu /> 
//        < Modal open={modal} width={320} closable={false} footer={false}>
//           <div> 

//             <h6 className='text-[15px] font-[700]'>Delete Data</h6>
//             <h6 className='text-[11px] leading-tight p-2' >Before Deleting the data be sure that it is required or not for further purpose.</h6>
             
//              <div className='flex items-center pt-2 border-t'>
//                 <ButtonOutlinedAutoWidth btnName="Cancel" onClick={()=>setmodal(false)} />
//                 <h6 className='w-[10px]'></h6>
//                 <ButtonFilledAutoWidth btnName="Sure" onClick={deleteDatafunc} />
//              </div>
//           </div>
//        </Modal>
//         <div className='w-[88%] px-4 mt-2'>
//             <div className='flex items-center justify-between pb-2 border-b'>
//                 <h6 className='font-[700] text-[14px] '>Total<span className='capitalize'>{path1}</span> ({data?.pagination?.total})</h6>
//                 <div className='flex items-center'>
//                 <div className='flex items-center text-[12px] mr-2'>

//                     <h6 className='mr-2 font-[600]'>{page == 1 ? data?.datas?.length > 0 ? 1 : 0 : (page - 1) * data?.pagination?.limit } - {data?.pagination?.limit} of {data?.pagination?.total} </h6>
//                     <IconButton onClick={resetfunc}><BsArrowRepeat size={16} /></IconButton>

//                     <div>
//                     <IconButton onClick={()=>{page > 1 ? setpage(page-1) : console.log('')}}><FiChevronLeft className={`${page === 1 ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>
//                     <IconButton onClick={()=>{ page < data?.pagination?.totalPages  ? setpage(page+1) : console.log('')}}><FiChevronRight className={`${(data?.pagination?.totalPages === page || data?.datas?.length === 0)  ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>

//                     </div>
//                 </div>


//                 <DatePicker size='small' style={{fontSize:'11px'}} ampm={false} placeholder='From Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2'  value={search?.from_date} onChange={(v,v1) => {setsearch({...search,from_date:v,from_date1:v1})}} /> 

//                 <DatePicker size='small' style={{fontSize:'11px'}} ampm={false} placeholder='To Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2'  value={search?.to_date} onChange={(v,v1) => {setsearch({...search,to_date:v,to_date1:v1})}} /> 

//             <ButtonOutlinedAutoWidth btnName="Add Filter" onClick={()=>applyfilterfunction(1)} /> 
          
//             <div className='ml-2'>
//             <ButtonFilledAutoWidth btnName="Add Data" onClick={()=>navigate('create')}/> 
//             </div>
//                 </div>
//             </div>
             
//             <div className='max-h-[90vh] overflow-y-scroll'>
//                 <div className='grid grid-cols-5 gap-1 mt-2'>
//   {data?.datas
//     ?.filter(d =>
//       user?.roles?.includes('admin') ||
//       user?.roles?.includes('finance_head') ||
//       user?.department_id?.[0]?.department_name === 'Corp Team' ||
//       user?.department_id?.[0]?.department_name === d?.department?.department_name
//     )
//     ?.map((d) => {
//       const canEditDelete =
//         user?.roles?.includes('admin') ||
//         user?.roles?.includes('finance_head') ||
//         user?.department_id?.[0]?.department_name === 'Corp Team' ||
//         user?.department_id?.[0]?.department_name === d?.department?.department_name;

//       return (
//         <div
//           key={d?._id}
//           className='border px-1.5 py-1 mt-1 relative mx-1 cursor-pointer'
//         >
//           <div className='p-2 bg-sky-100'>
//             {canEditDelete && (
//               <>
//                 <Tooltip title="Delete">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { setselected_data(d); setmodal(true) }}
//                   >
//                     <AiOutlineDelete
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-6'
//                     />
//                   </span>
//                 </Tooltip>

//                 <Tooltip title="Edit">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { gotoedit(d) }}
//                   >
//                     <AiOutlineEdit
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-1'
//                     />
//                   </span>
//                 </Tooltip>
//               </>
//             )}

//             <h6 className='text-[11px]'>
//               Profit/Loss Data for month :
//               <span className='font-[600] text-[11px] line-clamp-2'>
//                 <span className='font-[400]'>CreatedAt :-</span>
//                 {moment(d?.createdAt)?.format('ll')}
//               </span>
//             </h6>
//           </div>

//           {(d?.department !== '' && d?.department !== null && d?.department !== undefined) && (
//             <h6 className='text-[11px] flex pt-1'>
//               Department :
//               <span className='pl-1 font-[600] text-[11px] line-clamp-2'>
//                 {d?.department?.department_name}
//               </span>
//             </h6>
//           )}

//           {/* <div className='mt-2 border'>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Opening Balance</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.turn_over ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Income received</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.revenue ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Expense</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.expense ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Vendor Expense</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.vendor_expenses ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] border-b items-center'>
//               <h6 className='w-[50%] p-1 border-r'>Closing Balance</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.outstanding ?? 0)}</h6>
//             </div>

//             {d?.new_leads?.length > 0 && (
//               <div className='flex text-[11px] border-b items-center'>
//                 <h6 className='w-[50%] p-1 border-r'>New Leads</h6>
//                 <h6 className='font-[800] p-1'>{d?.new_leads?.length}</h6>
//               </div>
//             )}

//             {d?.expenses_bifurcation?.length > 0 && (
//               <div className='flex text-[11px] border-b items-center'>
//                 <h6 className='w-[50%] p-1 border-r'>Expenses Bifurcation</h6>
//                 <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//               </div>
//             )}

//             {d?.new_events?.length > 0 && (
//               <div className='flex text-[11px] border-b items-center'>
//                 <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//                 <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//               </div>
//             )}
//           </div> */}

// {d?.department?.department_name === "Digital Media" ? (
//   // Show only the breakdown rows
//   <div className='mt-2 border'>
 

//   {d?.expenses_bifurcation?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>Total Data Updated</h6>
//       <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//     </div>
//   )}

//   {d?.new_events?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//       <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//     </div>
//   )}
// </div>
// ) : (
//   <div className='mt-2 border'>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Opening Balance</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.turn_over ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Income received</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.revenue ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Expense</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.expense ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] items-center border-b'>
//     <h6 className='w-[50%] p-1 border-r'>Vendor Expense</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.vendor_expenses ?? 0)}</h6>
//   </div>
//   <div className='flex text-[11px] border-b items-center'>
//     <h6 className='w-[50%] p-1 border-r'>Closing Balance</h6>
//     <h6 className='font-[800] p-1'>{Priceconstants(d?.outstanding ?? 0)}</h6>
//   </div>

//   {d?.new_leads?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Leads</h6>
//       <h6 className='font-[800] p-1'>{d?.new_leads?.length}</h6>
//     </div>
//   )}

//   {d?.expenses_bifurcation?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>Expenses Bifurcation</h6>
//       <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//     </div>
//   )}

//   {d?.new_events?.length > 0 && (
//     <div className='flex text-[11px] border-b items-center'>
//       <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//       <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//     </div>
//   )}
// </div>
// )}


//           <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
//             Created By :
//             <span className='pl-1 font-[600] text-[11px] -ml-1 line-clamp-2'>
//               {d?.created_by?.name}
//             </span>
//           </h6>
//           <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
//             Created At : {moment(d?.createdAt).format('LLL')}
//           </h6>
//         </div>
//       );
//     })}
// </div>
//         </div> 
//         </div>

//     </div>
//   )
// }

// export default ProfitLossList


//============>>> =====================================================>>>        Old not using 

// import React, { useEffect, useState, useMemo } from 'react'
// import ProfitLossMenu from './ProfiltLossMenu'
// import { useLocation, useNavigate } from 'react-router-dom'
// import { IconButton, Tooltip } from '@mui/material'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
// import { DatePicker, Modal } from 'antd'
// import { BsArrowRepeat } from 'react-icons/bs'
// import { FiChevronLeft, FiChevronRight } from 'react-icons/fi'
// import moment from 'moment'
// import { AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai'
// import toast from 'react-hot-toast'
// import {
//   DeleteVerticalProfitLossService,
//   GetVerticalProfitLossService
// } from '../../services/VerticalProfitLoss'
// import { useSelector } from 'react-redux'
// import Priceconstants from '../../constants/imageConstants'

// function ProfitLossList() {
//   const path = useLocation()
//   const path1 = path?.pathname?.split('/')[2]
//   const navigate = useNavigate()

//   const user = useSelector(state => state.Auth)

//   const [modal, setModal] = useState(false)
//   const [selectedData, setSelectedData] = useState({})
//   const [data, setData] = useState({})
//   const [page, setPage] = useState(1)
//   const [search, setSearch] = useState({
//     text: '',
//     from_date: '',
//     to_date: '',
//     from_date1: '',
//     to_date1: '',
//     activate: false
//   })

//   /* ===================== ROLE RULE (ADMIN == FINANCE_HEAD) ===================== */
//   const isAdminOrFinanceHead = useMemo(() => {
//     return (
//       user?.roles?.includes('admin') ||
//       user?.roles?.includes('finance_head')
//     )
//   }, [user])

//   /* ===================== SINGLE DATA SOURCE ===================== */
//   const visibleData = useMemo(() => {
//     if (!Array.isArray(data?.datas)) return []

//     // ADMIN & FINANCE_HEAD SEE EVERYTHING
//     if (isAdminOrFinanceHead) return data.datas

//     // Others see only their department
//     return data.datas.filter(
//       d =>
//         user?.department_id?.[0]?.department_name ===
//         d?.department?.department_name
//     )
//   }, [data, isAdminOrFinanceHead, user])

//   /* ===================== FETCH ===================== */
//   useEffect(() => {
//     if (search.activate) {
//       applyFilter(page)
//     } else {
//       getData(page)
//     }
//   }, [page, path1])

//   async function resetFunc() {
//     setSearch({
//       text: '',
//       from_date: '',
//       to_date: '',
//       from_date1: '',
//       to_date1: '',
//       activate: false
//     })
//     const res = await GetVerticalProfitLossService({ page: 1 })
//     setData(res?.data)
//   }

//   async function applyFilter(p = page) {
//     setSearch(prev => ({ ...prev, activate: true }))
//     const res = await GetVerticalProfitLossService({
//       from_date1: search.from_date1,
//       to_date1: search.to_date1,
//       page: p
//     })
//     setData(res?.data)
//   }

//   async function getData(p) {
//     const res = await GetVerticalProfitLossService({
//       from_date1: search.from_date1,
//       to_date1: search.to_date1,
//       page: p
//     })
//     setData(res?.data)
//   }

//   async function deleteDataFunc() {
//     const res = await DeleteVerticalProfitLossService(selectedData?._id)
//     if (res?.status === 200) {
//       toast.success('Deleted Successfully')
//     } else {
//       toast.error('Delete failed')
//     }
//     setModal(false)
//     setSelectedData({})
//     getData(page)
//   }

//   function gotoEdit(d) {
//     navigate('edit', { state: d })
//   }

//   return (
//     <div className="flex max-h-screen min-h-screen overflow-hidden">
//       <ProfitLossMenu />

//       {/* DELETE MODAL */}
//       <Modal open={modal} width={320} closable={false} footer={false}>
//         <h6 className="text-[15px] font-[700]">Delete Data</h6>
//         <p className="text-[11px] p-2">
//           Are you sure you want to delete this data?
//         </p>
//         <div className="flex pt-2 border-t">
//           <ButtonOutlinedAutoWidth btnName="Cancel" onClick={() => setModal(false)} />
//           <div className="w-2" />
//           <ButtonFilledAutoWidth btnName="Sure" onClick={deleteDataFunc} />
//         </div>
//       </Modal>

//       <div className="w-[88%] px-4 mt-2">
//         {/* HEADER */}
//         <div className="flex items-center justify-between pb-2 border-b">
//           <h6 className="font-[700] text-[14px]">
//             Total <span className="capitalize">{path1}</span> (
//             {data?.pagination?.total || 0})
//           </h6>

//           <div className="flex items-center">
//             <IconButton onClick={resetFunc}>
//               <BsArrowRepeat size={16} />
//             </IconButton>

//             <DatePicker
//               size="small"
//               placeholder="From Date"
//               className="mr-2 w-28"
//               value={search.from_date}
//               onChange={(v, v1) =>
//                 setSearch({ ...search, from_date: v, from_date1: v1 })
//               }
//             />

//             <DatePicker
//               size="small"
//               placeholder="To Date"
//               className="mr-2 w-28"
//               value={search.to_date}
//               onChange={(v, v1) =>
//                 setSearch({ ...search, to_date: v, to_date1: v1 })
//               }
//             />

//             <ButtonOutlinedAutoWidth btnName="Add Filter" onClick={() => applyFilter(1)} />

//             {isAdminOrFinanceHead && (
//               <div className="ml-2">
//                 <ButtonFilledAutoWidth
//                   btnName="Add Data"
//                   onClick={() => navigate('create')}
//                 />
//               </div>
//             )}
//           </div>
//         </div>

//         {/* GRID */}
//         <div className="max-h-[90vh] overflow-y-scroll">
//           <div className="grid grid-cols-5 gap-2 mt-2">
//             {visibleData.map(d => (
//               <div key={d?._id} className="relative p-2 border">
//                 {isAdminOrFinanceHead && (
//                   <>
//                     <Tooltip title="Delete">
//                       <AiOutlineDelete
//                         className="absolute cursor-pointer top-2 right-8"
//                         onClick={() => {
//                           setSelectedData(d)
//                           setModal(true)
//                         }}
//                       />
//                     </Tooltip>
//                     <Tooltip title="Edit">
//                       <AiOutlineEdit
//                         className="absolute cursor-pointer top-2 right-2"
//                         onClick={() => gotoEdit(d)}
//                       />
//                     </Tooltip>
//                   </>
//                 )}

//                 <h6 className="text-[11px]">
//                   Created At: {moment(d?.createdAt).format('LL')}
//                 </h6>

//                 <h6 className="text-[11px]">
//                   Department: <b>{d?.department?.department_name}</b>
//                 </h6>

//                 <div className="mt-2 border">
//                   <div className="flex text-[11px] border-b">
//                     <span className="w-1/2 p-1">Opening Balance</span>
//                     <span className="p-1 font-bold">
//                       {Priceconstants(d?.turn_over ?? 0)}
//                     </span>
//                   </div>
//                   <div className="flex text-[11px] border-b">
//                     <span className="w-1/2 p-1">Income</span>
//                     <span className="p-1 font-bold">
//                       {Priceconstants(d?.revenue ?? 0)}
//                     </span>
//                   </div>
//                   <div className="flex text-[11px]">
//                     <span className="w-1/2 p-1">Closing Balance</span>
//                     <span className="p-1 font-bold">
//                       {Priceconstants(d?.outstanding ?? 0)}
//                     </span>
//                   </div>
//                 </div>

//                 <p className="text-[10px] mt-1">
//                   Created By: <b>{d?.created_by?.name}</b>
//                 </p>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>
//     </div>
//   )
// }

// export default ProfitLossList





//=================================================================================>>>>>>>   Old without digital media Update

// import React, { useEffect, useState } from 'react'
// import ProfitLossMenu from './ProfiltLossMenu'
// import { useLocation, useNavigate } from 'react-router-dom'
// import { IconButton, Tooltip } from '@mui/material'
// import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
// import { DatePicker, Modal } from 'antd'
// import { BsArrowRepeat } from 'react-icons/bs'
// import { FiChevronLeft,FiChevronRight } from 'react-icons/fi'
// import moment from 'moment'
// import { AiOutlineEdit,AiOutlineDelete } from 'react-icons/ai'
// import toast from 'react-hot-toast'
// import { DeleteVerticalProfitLossService, GetVerticalProfitLossService } from '../../services/VerticalProfitLoss'
// import { useSelector } from 'react-redux'
// import Priceconstants from '../../constants/imageConstants'

// function ProfitLossList() {

//     const path = useLocation()
//     const path1 = path?.pathname?.split('/')[2]
//     const navigate = useNavigate()

//     // const user = useSelector(state=>state.Auth.user)
//     const user = useSelector(state=>state.Auth)
  
//     const [modal,setmodal] = useState(false)
//     const [selected_data,setselected_data] = useState({})
//     const [data,setdata] = useState({})
//     const [page,setpage] = useState(1)
//     const [search,setsearch] = useState({text:'',from_date:'',to_date:'',from_date1:'',to_date1:'',activate:false})
   


     
//     useEffect(()=>{
//         if(search?.activate){
//            applyfilterfunction(page)
//         }else{
//            getdata(page)
//         }
//     },[page,path1])
   
//     async function resetfunc(){
//         setsearch({text:'',from_date:'',to_date:'',from_date1:'',to_date1:'',activate:false})
//         const response = await GetVerticalProfitLossService({from_date1:'',to_date1:'',page:1})
//         setdata(response?.data)
//       }
  
//       async function applyfilterfunction(v = ''){
//         setsearch({...search,activate:true})
//         const response = await GetVerticalProfitLossService({from_date1:search?.from_date1,to_date1:search?.to_date1,page:v !==  '' ? v :page})
//         setdata(response?.data)
//       }

//       async function getdata(page){
//         const response = await GetVerticalProfitLossService({from_date1:search?.from_date1,to_date1:search?.to_date1,page})
//         setdata(response?.data)
//       }

//       async function gotoedit(e){
//         navigate('edit',{state:e})
//       }

//       async function deleteDatafunc(){
//         const response = await DeleteVerticalProfitLossService(selected_data?._id)
//         if(response?.status === 200){
//           toast.success("Deleted Successfully")
//           setmodal(false)
//           getdata(page)
//           setselected_data({})
//         }else{
//             toast.success("Error : Deleted Successfully")
//             setmodal(false)
//             getdata(page)
//             setselected_data({})
//         }

//       }

//       console.log("data?.datas",data?.datas?.length)
//       console.log("roles",user?.roles)  // incluse admin 
//      console.log("USer_Department_Name",user?.department_id[0]?.department_name)
//      console.log("USer_Department_Name",user?.department_id[0]?.department_name)

//   return (
//     <div className='flex max-h-screen min-h-screen overflow-hidden'>
//         <ProfitLossMenu /> 
//        < Modal open={modal} width={320} closable={false} footer={false}>
//           <div> 

//             <h6 className='text-[15px] font-[700]'>Delete Data</h6>
//             <h6 className='text-[11px] leading-tight p-2' >Before Deleting the data be sure that it is required or not for further purpose.</h6>
             
//              <div className='flex items-center pt-2 border-t'>
//                 <ButtonOutlinedAutoWidth btnName="Cancel" onClick={()=>setmodal(false)} />
//                 <h6 className='w-[10px]'></h6>
//                 <ButtonFilledAutoWidth btnName="Sure" onClick={deleteDatafunc} />
//              </div>
//           </div>
//        </Modal>
//         <div className='w-[88%] px-4 mt-2'>
//             <div className='flex items-center justify-between pb-2 border-b'>
//                 <h6 className='font-[700] text-[14px] '>Total123456<span className='capitalize'>{path1}</span> ({data?.pagination?.total})</h6>
//                 <div className='flex items-center'>
//                 <div className='flex items-center text-[12px] mr-2'>

//                     <h6 className='mr-2 font-[600]'>{page == 1 ? data?.datas?.length > 0 ? 1 : 0 : (page - 1) * data?.pagination?.limit } - {data?.pagination?.limit} of {data?.pagination?.total} </h6>
//                     <IconButton onClick={resetfunc}><BsArrowRepeat size={16} /></IconButton>

//                     <div>
//                     <IconButton onClick={()=>{page > 1 ? setpage(page-1) : console.log('')}}><FiChevronLeft className={`${page === 1 ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>
//                     <IconButton onClick={()=>{ page < data?.pagination?.totalPages  ? setpage(page+1) : console.log('')}}><FiChevronRight className={`${(data?.pagination?.totalPages === page || data?.datas?.length === 0)  ? 'opacity-50' : 'opacity-100'}`}  size={16} /></IconButton>

//                     </div>
//                 </div>


//                 <DatePicker size='small' style={{fontSize:'11px'}} ampm={false} placeholder='From Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2'  value={search?.from_date} onChange={(v,v1) => {setsearch({...search,from_date:v,from_date1:v1})}} /> 

//                 <DatePicker size='small' style={{fontSize:'11px'}} ampm={false} placeholder='To Date' className='text-[11px] py-[2.6px]  w-28 border-slate-300 mr-2'  value={search?.to_date} onChange={(v,v1) => {setsearch({...search,to_date:v,to_date1:v1})}} /> 

//             <ButtonOutlinedAutoWidth btnName="Add Filter" onClick={()=>applyfilterfunction(1)} /> 
          
//             <div className='ml-2'>
//             <ButtonFilledAutoWidth btnName="Add Data" onClick={()=>navigate('create')}/> 
//             </div>
//                 </div>
//             </div>
             
//             <div className='max-h-[90vh] overflow-y-scroll'>
//             {/* <div className='grid grid-cols-5 gap-1 mt-2'>
//             {data?.datas
//     ?.filter(d =>
//       user?.roles?.includes('admin') ||
//       user?.roles?.includes('finance_head') ||
//       user?.department_id?.[0]?.department_name === d?.department?.department_name
//     )
//       ?.map((d) => (
//         <div
//           key={d?._id}
//           className='border px-1.5 py-1 mt-1 relative mx-1 cursor-pointer'
//         >
//           <div className='p-2 bg-sky-100'>
//             {(user?.department_id?.[0]?.department_name === d?.department?.department_name ||
//               user?.roles?.includes('admin')) && (
//               <>
//                 <Tooltip title="Delete">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { setselected_data(d); setmodal(true) }}
//                   >
//                     <AiOutlineDelete
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-6'
//                     />
//                   </span>
//                 </Tooltip>

//                 <Tooltip title="Edit">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { gotoedit(d) }}
//                   >
//                     <AiOutlineEdit
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-1'
//                     />
//                   </span>
//                 </Tooltip>
//               </>
//             )}

//             <h6 className='text-[11px]'>
//               Profit/Loss Data for month :
//               <span className='font-[600] text-[11px] line-clamp-2'>
//                 <span className='font-[400]'>CreatedAt :-</span>
//                 {moment(d?.createdAt)?.format('ll')}
//               </span>
//             </h6>
//           </div>

//                                 {(d?.department !== '' && d?.department !== null && d?.department !== undefined)  &&
//                                 <h6 className='text-[11px] flex pt-1' >Department : <span className='pl-1 font-[600] text-[11px] line-clamp-2'>{d?.department?.department_name}</span> </h6>}

//                                 <div className='mt-2 border'> 
//                                 <div className='flex text-[11px] items-center border-b'> 
//                                         <h6 className='w-[50%] p-1 border-r'>Opening Balance</h6>
//                                         <h6 className='font-[800] p-1'>{Priceconstants(d?.turn_over === null ? 0 : d?.turn_over)}</h6>
//                                     </div> 
//                                     <div className='flex text-[11px] items-center border-b'> 
//                                         <h6 className='w-[50%] p-1 border-r'>Income received</h6>
//                                         <h6 className='font-[800] p-1'>{Priceconstants(d?.revenue === null ? 0 : d?.revenue)}</h6>
//                                     </div> 
                                  
//                                     <div className='flex text-[11px] items-center border-b'> 
//                                         <h6 className='w-[50%] p-1 border-r'>Expense</h6>
//                                         <h6 className='font-[800] p-1'>{Priceconstants(d?.expense === null ? 0 : d?.expense)}</h6>
//                                     </div> 
//                                     <div className='flex text-[11px] border-b items-center'> 
//                                         <h6 className='w-[50%] p-1 border-r'>Closing Balance</h6>
//                                         <h6 className='font-[800] p-1'>{Priceconstants(d?.outstanding === null ? 0 : d?.outstanding)}</h6>
//                                     </div> 

//                                     {d?.new_leads?.length > 0 &&
//                                     <div className='flex text-[11px] border-b items-center'> 
//                                         <h6 className='w-[50%] p-1 border-r'>New Leads</h6>
//                                         <h6 className='font-[800] p-1'>{d?.new_leads?.length}</h6>
//                                     </div>}

//                                     {d?.expenses_bifurcation?.length > 0 &&
//                                     <div className='flex text-[11px] border-b items-center'> 
//                                         <h6 className='w-[50%] p-1 border-r'>Expenses Bifurcation</h6>
//                                         <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//                                     </div>}

//                                     {d?.new_events?.length > 0 &&
//                                     <div className='flex text-[11px] border-b items-center'> 
//                                         <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//                                         <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//                                     </div>}
//                                 </div>  
                                

//                                 <h6 className='text-[10px] ml-1 font-[400] mt-0.5' >Created By : <span className='pl-1 font-[600] text-[11px] -ml-1 line-clamp-2'>{d?.created_by?.name}</span></h6>
//                                 <h6 className='text-[10px] ml-1 font-[400] mt-0.5' >Created At : {moment(d?.createdAt).format('LLL')}</h6>

//                     </div>  
//                 ))} 

//                 </div> */}
//                 <div className='grid grid-cols-5 gap-1 mt-2'>
//   {data?.datas
//     ?.filter(d =>
//       user?.roles?.includes('admin') ||
//       user?.roles?.includes('finance_head') ||
//       user?.department_id?.[0]?.department_name === 'Corp Team' ||
//       user?.department_id?.[0]?.department_name === d?.department?.department_name
//     )
//     ?.map((d) => {
//       const canEditDelete =
//         user?.roles?.includes('admin') ||
//         user?.roles?.includes('finance_head') ||
//         user?.department_id?.[0]?.department_name === 'Corp Team' ||
//         user?.department_id?.[0]?.department_name === d?.department?.department_name;

//       return (
//         <div
//           key={d?._id}
//           className='border px-1.5 py-1 mt-1 relative mx-1 cursor-pointer'
//         >
//           <div className='p-2 bg-sky-100'>
//             {canEditDelete && (
//               <>
//                 <Tooltip title="Delete">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { setselected_data(d); setmodal(true) }}
//                   >
//                     <AiOutlineDelete
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-6'
//                     />
//                   </span>
//                 </Tooltip>

//                 <Tooltip title="Edit">
//                   <span
//                     className='absolute top-0 right-0 p-1 bg-white'
//                     onClick={() => { gotoedit(d) }}
//                   >
//                     <AiOutlineEdit
//                       size={20}
//                       className='absolute top-0 p-1 bg-white right-1'
//                     />
//                   </span>
//                 </Tooltip>
//               </>
//             )}

//             <h6 className='text-[11px]'>
//               Profit/Loss Data for month :
//               <span className='font-[600] text-[11px] line-clamp-2'>
//                 <span className='font-[400]'>CreatedAt :-</span>
//                 {moment(d?.createdAt)?.format('ll')}
//               </span>
//             </h6>
//           </div>

//           {(d?.department !== '' && d?.department !== null && d?.department !== undefined) && (
//             <h6 className='text-[11px] flex pt-1'>
//               Department :
//               <span className='pl-1 font-[600] text-[11px] line-clamp-2'>
//                 {d?.department?.department_name}
//               </span>
//             </h6>
//           )}

//           <div className='mt-2 border'>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Opening Balance</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.turn_over ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Income received</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.revenue ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Expense</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.expense ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] items-center border-b'>
//               <h6 className='w-[50%] p-1 border-r'>Vendor Expense</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.vendor_expenses ?? 0)}</h6>
//             </div>
//             <div className='flex text-[11px] border-b items-center'>
//               <h6 className='w-[50%] p-1 border-r'>Closing Balance</h6>
//               <h6 className='font-[800] p-1'>{Priceconstants(d?.outstanding ?? 0)}</h6>
//             </div>

//             {d?.new_leads?.length > 0 && (
//               <div className='flex text-[11px] border-b items-center'>
//                 <h6 className='w-[50%] p-1 border-r'>New Leads</h6>
//                 <h6 className='font-[800] p-1'>{d?.new_leads?.length}</h6>
//               </div>
//             )}

//             {d?.expenses_bifurcation?.length > 0 && (
//               <div className='flex text-[11px] border-b items-center'>
//                 <h6 className='w-[50%] p-1 border-r'>Expenses Bifurcation</h6>
//                 <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
//               </div>
//             )}

//             {d?.new_events?.length > 0 && (
//               <div className='flex text-[11px] border-b items-center'>
//                 <h6 className='w-[50%] p-1 border-r'>New Events</h6>
//                 <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
//               </div>
//             )}
//           </div>

//           <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
//             Created By :
//             <span className='pl-1 font-[600] text-[11px] -ml-1 line-clamp-2'>
//               {d?.created_by?.name}
//             </span>
//           </h6>
//           <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
//             Created At : {moment(d?.createdAt).format('LLL')}
//           </h6>
//         </div>
//       );
//     })}
// </div>

//             </div> 
//         </div>

//     </div>
//   )
// }

// export default ProfitLossList