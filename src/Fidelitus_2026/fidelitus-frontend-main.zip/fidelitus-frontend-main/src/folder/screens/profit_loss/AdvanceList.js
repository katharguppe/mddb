import React, { useEffect, useState } from 'react'
import ProfitLossMenu from './ProfiltLossMenu'
import { useLocation, useNavigate } from 'react-router-dom'
import { IconButton, Tooltip } from '@mui/material'
import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
import { DatePicker, Modal } from 'antd'
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi'
import moment from 'moment'
import { AiOutlineEdit, AiOutlineDelete } from 'react-icons/ai'
import toast from 'react-hot-toast'
import { DeleteVerticalProfitLossService, GetVerticalProfitLossService } from '../../services/VerticalProfitLoss'
import { useSelector } from 'react-redux'
import Priceconstants from '../../constants/imageConstants'

function ProfitLossList() {

  const path = useLocation()
  const path1 = path?.pathname?.split('/')[2]
  const navigate = useNavigate()
  const user = useSelector(state => state.Auth)

  const [modal,setmodal] = useState(false)
  const [selected_data,setselected_data] = useState({})
  const [data,setdata] = useState({})
  const [page,setpage] = useState(1)

  const limit = 10

  const [search,setsearch] = useState({
    from_date:'',
    to_date:'',
    from_date1:'',
    to_date1:''
  })

  // ===============================
  // FETCH DATA
  // ===============================
  useEffect(()=>{
    fetchData(page)
  },[page])

  async function fetchData(currentPage){
    const response = await GetVerticalProfitLossService({
      from_date1: search?.from_date1 || '',
      to_date1: search?.to_date1 || '',
      page: currentPage,
      limit: limit
    })
    setdata(response?.data || {})
  }

  function applyFilter(){
    setpage(1)
    fetchData(1)
  }

  function resetfunc(){
    setsearch({
      from_date:'',
      to_date:'',
      from_date1:'',
      to_date1:''
    })
    setpage(1)
    fetchData(1)
  }

  async function gotoedit(e){
    navigate('edit',{state:e})
  }

  async function deleteDatafunc(){
    const response = await DeleteVerticalProfitLossService(selected_data?._id)
    if(response?.status === 200){
      toast.success("Deleted Successfully")
      fetchData(page)
    }
    setmodal(false)
    setselected_data({})
  }

  // ===============================
  // PAGINATION CALCULATION
  // ===============================
  const totalRecords = data?.pagination?.total || 0
  const totalPages = Math.ceil(totalRecords / limit)

  const startIndex = totalRecords === 0 ? 0 : (page - 1) * limit + 1
  const endIndex = Math.min(page * limit, totalRecords)

  return (
    <div className='flex h-screen overflow-hidden'>
      <ProfitLossMenu />

      <Modal open={modal} width={320} closable={false} footer={false}>
        <div>
          <h6 className='text-[15px] font-[700]'>Delete Data</h6>
          <h6 className='text-[11px] p-2'>Before deleting confirm.</h6>
          <div className='flex pt-2 border-t'>
            <ButtonOutlinedAutoWidth btnName="Cancel" onClick={()=>setmodal(false)} />
            <div className='w-[10px]'/>
            <ButtonFilledAutoWidth btnName="Sure" onClick={deleteDatafunc} />
          </div>
        </div>
      </Modal>

      {/* ================= MAIN CONTENT ================= */}
      <div className='w-[88%] px-4 mt-2 flex flex-col'>

        {/* ================= HEADER ================= */}
        <div className='flex items-center justify-between flex-shrink-0 pb-2 border-b'>

          <h6 className='font-[700] text-[14px]'>
            Total {path1} ({totalRecords})
          </h6>

          <div className='flex items-center gap-3'>

            <span className='text-[12px] font-[600]'>
              {totalRecords > 0 ? `${startIndex} - ${endIndex}` : 0} of {totalRecords}
            </span>

            <IconButton
              disabled={page === 1}
              onClick={()=>setpage(prev=>prev-1)}
            >
              <FiChevronLeft size={18}/>
            </IconButton>

            <span className='text-[12px] font-semibold'>
              Page {page} / {totalPages || 1}
            </span>

            <IconButton
              disabled={page >= totalPages}
              onClick={()=>setpage(prev=>prev+1)}
            >
              <FiChevronRight size={18}/>
            </IconButton>

            <DatePicker
              size='small'
              placeholder='From Date'
              value={search?.from_date}
              onChange={(v,v1)=>setsearch({...search,from_date:v,from_date1:v1})}
            />

            <DatePicker
              size='small'
              placeholder='To Date'
              value={search?.to_date}
              onChange={(v,v1)=>setsearch({...search,to_date:v,to_date1:v1})}
            />

            <ButtonOutlinedAutoWidth btnName="Add Filter" onClick={applyFilter} />
            <ButtonOutlinedAutoWidth btnName="Reset" onClick={resetfunc} />
            <ButtonFilledAutoWidth btnName="Add Data" onClick={()=>navigate('create')} />

          </div>
        </div>

        {/* ================= SCROLLABLE CARD AREA ================= */}
        <div className='flex-1 pr-2 mt-3 overflow-y-auto'>

        <div className='grid grid-cols-5 gap-1 mt-2'>
  {data?.datas
    ?.filter(d =>
      user?.roles?.includes('admin') ||
      user?.roles?.includes('finance_head') ||
      user?.department_id?.[0]?.department_name === 'Corp Team' ||
      user?.department_id?.[0]?.department_name === d?.department?.department_name
    )
    ?.map((d) => {
      const canEditDelete =
        user?.roles?.includes('admin') ||
        user?.roles?.includes('finance_head') ||
        user?.department_id?.[0]?.department_name === 'Corp Team' ||
        user?.department_id?.[0]?.department_name === d?.department?.department_name;

      return (
        <div
          key={d?._id}
          className='border px-1.5 py-1 mt-1 relative mx-1 cursor-pointer'
        >
          <div className='p-2 bg-sky-100'>
            {canEditDelete && (
              <>
                <Tooltip title="Delete">
                  <span
                    className='absolute top-0 right-0 p-1 bg-white'
                    onClick={() => { setselected_data(d); setmodal(true) }}
                  >
                    <AiOutlineDelete
                      size={20}
                      className='absolute top-0 p-1 bg-white right-6'
                    />
                  </span>
                </Tooltip>

                <Tooltip title="Edit">
                  <span
                    className='absolute top-0 right-0 p-1 bg-white'
                    onClick={() => { gotoedit(d) }}
                  >
                    <AiOutlineEdit
                      size={20}
                      className='absolute top-0 p-1 bg-white right-1'
                    />
                  </span>
                </Tooltip>
              </>
            )}

            <h6 className='text-[11px]'>
              Profit/Loss Data for month :
              <span className='font-[600] text-[11px] line-clamp-2'>
                <span className='font-[400]'>CreatedAt :-</span>
                {moment(d?.createdAt)?.format('ll')}
              </span>
            </h6>
          </div>

          {(d?.department !== '' && d?.department !== null && d?.department !== undefined) && (
            <h6 className='text-[11px] flex pt-1'>
              Department :
              <span className='pl-1 font-[600] text-[11px] line-clamp-2'>
                {d?.department?.department_name}
              </span>
            </h6>
          )}
{d?.department?.department_name === "Digital Media" ? (
  // Show only the breakdown rows
  <div className='mt-2 border'>
 

  {d?.expenses_bifurcation?.length > 0 && (
    <div className='flex text-[11px] border-b items-center'>
      <h6 className='w-[50%] p-1 border-r'>Total Data Updated</h6>
      <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
    </div>
  )}

  {d?.new_events?.length > 0 && (
    <div className='flex text-[11px] border-b items-center'>
      <h6 className='w-[50%] p-1 border-r'>New Events</h6>
      <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
    </div>
  )}
</div>
) : (
  <div className='mt-2 border'>
  <div className='flex text-[11px] items-center border-b'>
    <h6 className='w-[50%] p-1 border-r'>Opening Balance</h6>
    <h6 className='font-[800] p-1'>{Priceconstants(d?.turn_over ?? 0)}</h6>
  </div>
  <div className='flex text-[11px] items-center border-b'>
    <h6 className='w-[50%] p-1 border-r'>Income received</h6>
    <h6 className='font-[800] p-1'>{Priceconstants(d?.revenue ?? 0)}</h6>
  </div>
  <div className='flex text-[11px] items-center border-b'>
    <h6 className='w-[50%] p-1 border-r'>Expense</h6>
    <h6 className='font-[800] p-1'>{Priceconstants(d?.expense ?? 0)}</h6>
  </div>
  <div className='flex text-[11px] items-center border-b'>
  <h6 className='w-[50%] p-1 border-r'>Advance</h6>
  <h6 className='font-[800] p-1'>
    {Priceconstants(
      d?.loan_details?.reduce(
        (sum, loan) => sum + Number(loan?.loan_amount || 0),
        0
      )
    )}
  </h6>
</div>
  <div className='flex text-[11px] items-center border-b'>
    <h6 className='w-[50%] p-1 border-r'>Vendor Expense</h6>
    <h6 className='font-[800] p-1'>{Priceconstants(d?.vendor_expenses ?? 0)}</h6>
  </div>
  <div className='flex text-[11px] border-b items-center'>
    <h6 className='w-[50%] p-1 border-r'>Closing Balance</h6>
    <h6 className='font-[800] p-1'>{Priceconstants(d?.outstanding ?? 0)}</h6>
  </div>

  {d?.new_leads?.length > 0 && (
    <div className='flex text-[11px] border-b items-center'>
      <h6 className='w-[50%] p-1 border-r'>New Leads</h6>
      <h6 className='font-[800] p-1'>{d?.new_leads?.length}</h6>
    </div>
  )}

  {d?.expenses_bifurcation?.length > 0 && (
    <div className='flex text-[11px] border-b items-center'>
      <h6 className='w-[50%] p-1 border-r'>Expenses Bifurcation</h6>
      <h6 className='font-[800] p-1'>{d?.expenses_bifurcation?.length}</h6>
    </div>
  )}

  {d?.new_events?.length > 0 && (
    <div className='flex text-[11px] border-b items-center'>
      <h6 className='w-[50%] p-1 border-r'>New Events</h6>
      <h6 className='font-[800] p-1'>{d?.new_events?.length}</h6>
    </div>
  )}
</div>
)}


          <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
            Created By :
            <span className='pl-1 font-[600] text-[11px] -ml-1 line-clamp-2'>
              {d?.created_by?.name}
            </span>
          </h6>
          <h6 className='text-[10px] ml-1 font-[400] mt-0.5'>
            Created At : {moment(d?.createdAt).format('LLL')}
          </h6>
        </div>
      );
    })}
</div>
        </div>

      </div>
    </div>
  )
}

export default ProfitLossList

