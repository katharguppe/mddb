import React, { useEffect, useState } from 'react'
import { ButtonFilledAutoWidth, ButtonOutlinedAutoWidth } from '../../components/button'
import GoBack from '../../components/back/GoBack'
import { TextAreaInput1, TextInput } from '../../components/input'
import { useLocation, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import ProfitLossMenu from './ProfiltLossMenu'
import { CreateVerticalProfitLossService, UpdateVerticalProfitLossService } from '../../services/VerticalProfitLoss'
import { useSelector } from 'react-redux'
import { AiOutlineDelete, AiOutlineEdit, AiOutlinePlus } from "react-icons/ai";
import { Modal, Select } from 'antd'
import { GetDepartmentService } from '../../services/DepartmentServices'
import Priceconstants from '../../constants/imageConstants'
import moment from 'moment'

function AdvanceCreate() {

  const user = useSelector(state => state.Auth)
  const roles = useSelector(state => state.Auth.roles)

  const navigate = useNavigate()
  const { pathname, state } = useLocation()
  let path = pathname?.split("/").pop()

  // ================= BASIC INFO =================

  const [data, setdata] = useState({
    department: '',
    createdAt: ''
  })

  const [error, seterror] = useState({
    department: '',
    createdAt: ''
  })

  const [departmentArr, setdepartmentArr] = useState([])

  // ================= LOAN STATES =================

  const [loan_list, setloan_list] = useState([])
  const [loanModal, setloanModal] = useState(false)
  const [deleteModal, setdeleteModal] = useState(false)
  const [deletedIndex, setdeletedIndex] = useState(null)

  const [loanInfo, setloanInfo] = useState({
    name: '',
    loan_received_date: '',
    loan_amount: '',
    interest_rate: '',
    interest_amount: '',
    repayment_with_interest: '',
    repayment_without_interest: '',
    outstanding_amount: '',
    remarks: ''
  })

  const [loanInfoerr, setloanInfoerr] = useState({})

  // ================= LOAD EDIT DATA =================

  useEffect(() => {

    if (path === 'edit' && state) {

      setdata({
        department: {
          label: state?.department?.department_name,
          value: state?.department?._id
        },
        createdAt: state?.createdAt?.slice(0, 10)
      })

      setloan_list(
        state?.loan_details?.map(l => ({
          ...l,
          loan_amount: Number(l.loan_amount || 0),
          interest_rate: Number(l.interest_rate || 0),
          interest_amount: Number(l.interest_amount || 0),
          repayment_with_interest: Number(l.repayment_with_interest || 0),
          repayment_without_interest: Number(l.repayment_without_interest || 0),
          outstanding_amount: Number(l.outstanding_amount || 0)
        })) || []
      )
    }

    getDepartment()

  }, [])

  async function getDepartment() {
    const response = await GetDepartmentService()
    const arr = response?.data?.datas?.map(d => ({
      label: d?.department_name,
      value: d?.id
    }))
    setdepartmentArr(arr || [])
  }

  // ================= HANDLE LOAN CHANGE =================

  function handleLoanChange(e) {
    const { name, value } = e.target
    setloanInfo(prev => ({ ...prev, [name]: value }))
    setloanInfoerr(prev => ({ ...prev, [name]: '' }))
  }

  // ================= SAVE LOAN =================

  function saveLoan() {

    if (!loanInfo.name)
      return setloanInfoerr({ name: "Required" })

    if (!loanInfo.loan_received_date)
      return setloanInfoerr({ loan_received_date: "Required" })

    if (!loanInfo.loan_amount)
      return setloanInfoerr({ loan_amount: "Required" })

    const payload = {
      ...loanInfo,
      loan_amount: Number(loanInfo.loan_amount),
      interest_rate: Number(loanInfo.interest_rate || 0),
      interest_amount: Number(loanInfo.interest_amount || 0),
      repayment_with_interest: Number(loanInfo.repayment_with_interest || 0),
      repayment_without_interest: Number(loanInfo.repayment_without_interest || 0),
      outstanding_amount: Number(loanInfo.outstanding_amount || 0)
    }

    if (loanInfo.index === undefined) {
      setloan_list(prev => [...prev, payload])
    } else {
      const updated = [...loan_list]
      updated[loanInfo.index] = payload
      setloan_list(updated)
    }

    resetLoanModal()
  }

  function resetLoanModal() {
    setloanModal(false)
    setloanInfo({
      name: '',
      loan_received_date: '',
      loan_amount: '',
      interest_rate: '',
      interest_amount: '',
      repayment_with_interest: '',
      repayment_without_interest: '',
      outstanding_amount: '',
      remarks: ''
    })
  }

  // ================= DELETE =================

  function confirmDelete() {
    const updated = [...loan_list]
    updated.splice(deletedIndex, 1)
    setloan_list(updated)
    setdeleteModal(false)
  }

  // ================= FINAL SUBMIT =================

  async function submitData() {

    let valid = true
    let newError = { department: '', createdAt: '' }
  
    if (!data.department) {
      newError.department = "Department is required"
      valid = false
    }
  
    if (!data.createdAt) {
      newError.createdAt = "Created Date is required"
      valid = false
    }
  
    seterror(newError)
  
    if (!valid) return
  
    const payload = {
      department: data.department.value,
      createdAt: data.createdAt,
      loan_details: loan_list
    }
  
    if (path === 'create') {
      const response = await CreateVerticalProfitLossService(payload)
      if (response?.status === 201) {
        toast.success("Saved Successfully")
        navigate(-1)
      }
    } else {
      const response = await UpdateVerticalProfitLossService(payload, state?._id)
      if (response?.status === 200) {
        toast.success("Updated Successfully")
        navigate(-1)
      }
    }
  }

  // ================= UI =================

  return (
    <div className='flex'>
      <ProfitLossMenu />

      <div className='ml-5 w-[85%]'>

        <GoBack />

        <h6 className='text-[13px] font-[800] mb-4'>
          Add / Edit Loan Details
        </h6>

        {/* ================= LOAN TABLE ================= */}
{/* ================= BASIC INFO ================= */}

<div className='flex gap-5 mb-5'>

  {/* Department */}
  <div className='w-[250px]'>
    <h6 className='text-[11px] font-[600] mb-1'>
      Department <span className='text-red-500'>*</span>
    </h6>

    <Select
      options={departmentArr}
      value={data.department || null}
      onChange={(val) => {
        setdata({
          ...data,
          department: departmentArr.find(d => d.value === val)
        })
        seterror(prev => ({ ...prev, department: '' }))
      }}
      size='small'
      className='w-full'
      status={error.department ? "error" : ""}
    />

    {error.department &&
      <p className='text-red-500 text-[10px] mt-1'>
        {error.department}
      </p>
    }
  </div>

  {/* Created Date */}
  <div className='w-[200px]'>
    <h6 className='text-[11px] font-[600] mb-1'>
      Created Date <span className='text-red-500'>*</span>
    </h6>

    <input
      type='date'
      value={data.createdAt}
      onChange={(e) => {
        setdata({ ...data, createdAt: e.target.value })
        seterror(prev => ({ ...prev, createdAt: '' }))
      }}
      className={`border px-2 py-1 w-full text-[12px] 
        ${error.createdAt ? 'border-red-500' : 'border-slate-300'}`}
    />

    {error.createdAt &&
      <p className='text-red-500 text-[10px] mt-1'>
        {error.createdAt}
      </p>
    }
  </div>

</div>
        <div className='p-3 border'>

          <div className='flex items-center justify-between'>
            <h6 className='font-[700] text-[12px]'>Loan Info</h6>
            <AiOutlinePlus
              onClick={() => setloanModal(true)}
              className='cursor-pointer bg-slate-300 p-[3px]'
            />
          </div>

          <div className='mt-2 border'>

            <div className='flex bg-slate-100 text-[10px] font-[700]'>
              <div className='w-[18%] border-r p-1'>Name</div>
              <div className='w-[12%] border-r p-1'>Date</div>
              <div className='w-[12%] border-r p-1'>Loan Amt</div>
              <div className='w-[10%] border-r p-1'>Interest %</div>
              <div className='w-[12%] border-r p-1'>Interest Amt</div>
              <div className='w-[14%] border-r p-1'>Total Payable</div>
              <div className='w-[12%] border-r p-1'>Outstanding</div>
              <div className='w-[10%] p-1'>Action</div>
            </div>

            {loan_list.map((l, i) => (
              <div key={i} className='flex border-t text-[10px]'>

                <div className='w-[18%] border-r p-1'>{l.name}</div>
                <div className='w-[12%] border-r p-1'>
                  {moment(l.loan_received_date).format("DD/MM/YYYY")}
                </div>
                <div className='w-[12%] border-r p-1'>
                  {Priceconstants(l.loan_amount)}
                </div>
                <div className='w-[10%] border-r p-1'>{l.interest_rate}%</div>
                <div className='w-[12%] border-r p-1'>
                  {Priceconstants(l.interest_amount)}
                </div>
                <div className='w-[14%] border-r p-1'>
                  {Priceconstants(l.repayment_with_interest)}
                </div>
                <div className='w-[12%] border-r p-1 text-red-600 font-[700]'>
                  {Priceconstants(l.outstanding_amount)}
                </div>
                <div className='w-[10%] p-1 flex gap-2'>
                  <AiOutlineEdit
                    size={12}
                    onClick={() => {
                      setloanInfo({ ...l, index: i })
                      setloanModal(true)
                    }}
                  />
                  <AiOutlineDelete
                    size={12}
                    onClick={() => {
                      setdeletedIndex(i)
                      setdeleteModal(true)
                    }}
                  />
                </div>

              </div>
            ))}

          </div>
        </div>

        <div className='flex justify-end mt-5'>
          <ButtonFilledAutoWidth btnName="Save" onClick={submitData} />
        </div>

      </div>

      {/* ================= LOAN MODAL ================= */}

      <Modal open={loanModal} footer={false} closable={false} width={400}>
        <h6 className='text-[14px] font-[700] mb-3'>Loan Info</h6>

        <TextInput mandatory label="Name" name="name" value={loanInfo.name} error={loanInfoerr.name} handlechange={handleLoanChange} />
        <TextInput mandatory label="Loan Date" type="date" name="loan_received_date" value={loanInfo.loan_received_date} error={loanInfoerr.loan_received_date} handlechange={handleLoanChange} />
        <TextInput mandatory label="Loan Amount" type="number" name="loan_amount" value={loanInfo.loan_amount} error={loanInfoerr.loan_amount} handlechange={handleLoanChange} />
        <TextInput label="Interest Rate (%)" type="number" name="interest_rate" value={loanInfo.interest_rate} handlechange={handleLoanChange} />
        <TextInput label="Interest Amount" type="number" name="interest_amount" value={loanInfo.interest_amount} handlechange={handleLoanChange} />
        <TextInput label="Repayment With Interest" type="number" name="repayment_with_interest" value={loanInfo.repayment_with_interest} handlechange={handleLoanChange} />
        <TextInput label="Outstanding" type="number" name="outstanding_amount" value={loanInfo.outstanding_amount} handlechange={handleLoanChange} />
        <TextAreaInput1 label="Remarks" name="remarks" value={loanInfo.remarks} handlechange={handleLoanChange} />

        <div className='flex justify-end gap-2 mt-3'>
          <ButtonOutlinedAutoWidth btnName="Cancel" onClick={resetLoanModal} />
          <ButtonFilledAutoWidth btnName="Save" onClick={saveLoan} />
        </div>
      </Modal>

      {/* ================= DELETE MODAL ================= */}

      <Modal open={deleteModal} footer={false} closable={false} width={300}>
        <h6 className='text-[13px] font-[700] mb-3'>Confirm Delete?</h6>
        <div className='flex justify-end gap-2'>
          <ButtonOutlinedAutoWidth btnName="Cancel" onClick={() => setdeleteModal(false)} />
          <ButtonFilledAutoWidth btnName="Delete" onClick={confirmDelete} />
        </div>
      </Modal>

    </div>
  )
}

export default AdvanceCreate

