import { get, post, put, deleteRequest } from "../helpers/apihelpers";

/**
 * ==========================================
 *  BD Target Services (Matches Backend Exactly)
 * ==========================================
 */

/** 
 * Save/Create monthly target for logged-in user
 * POST /api/bd-targets
 */
export const saveBdTarget = (data) => {
  return post("/api/bd-targets", data);
};

/**
 * Get logged-in user's own monthly target(s)
 * GET /api/bd-targets
 */
export const getMyBdTarget = () => {
  return get("/api/bd-targets");
};

/**
 * Get a single target using its target ID
 * GET /api/bd-targets/:id
 */
export const getBdTargetById = (targetId) => {
  return get(`/api/bd-targets/${targetId}`);
};

/**
 * Update an existing target by target ID
 * PUT /api/bd-targets/:id
 */
export const updateBdTarget = (targetId, data) => {
  return put(`/api/bd-targets/${targetId}`, data);
};

/**
 * Delete a specific BD target (Admin/HOD or User's own)
 * DELETE /api/bd-targets/:id
 */
export const deleteBdTarget = (targetId) => {
  return deleteRequest(`/api/bd-targets/${targetId}`);
};

/**
 * Get all BD targets (Admin/Controller only)
 * GET /api/bd-targets/all
 */
export const getAllBdTargets = () => {
  return get("/api/bd-targets/all");
};



// export const getAllBdTargets = () => get("/api/bd-targets/all");







////=====>>>Old

// import { deleteRequest, get, post, postfd, publicPost, put } from "../helpers/apihelpers";

// // Create or update target
// export const saveBdTarget = (data) => {
//   return post("/api/bd-targets", data);
// };

// // Get logged-in user's target
// export const getMyBdTarget = () => {
//   return get("/api/bd-targets");
// };

// // Admin/HOD – get all BD targets
// export const getAllBdTargets = () => {
//   return get("/api/bd-targets/all");
// };

