import { get } from "../helpers/apihelpers";

export const GetAdminDashboardService=async()=>{
    try {
        const result = await get(`api/admin_dashboard/analytics`);
        return result;
    } catch (err) {
        return err.response;
    }
}
