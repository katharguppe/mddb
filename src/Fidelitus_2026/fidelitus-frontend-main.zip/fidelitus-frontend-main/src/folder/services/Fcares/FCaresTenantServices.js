import { deleteRequest, get, post, postfd, put } from "../../helpers/apihelpers";

export const CreateFcaresTenantService=async(data)=>{
    try {
        const result = await post(`api/fcares/tenant`, data);
        return result;
    } catch (err) {
        return err.response;
    }
}

export const UpdateFcaresTenantService=async(id,data)=>{
    try {
        const result = await put(`api/fcares/tenant/${id}`, data);
        return result;
    } catch (err) {
        return err.response;
    }
}

export const DeleteFcaresTenantService=async(id,data)=>{
    try {
        const result = await deleteRequest(`api/fcares/tenant/${id}`, data);
        return result;
    } catch (err) {
        return err.response;
    }
}

export const GetFcaresTenantService=async(from_date,to_Date,page)=>{
    try {
        const result = await get(`api/fcares/tenant?page=${page}&from_date=${from_date}&to_date=${to_Date}`);
        return result;
    } catch (err) {
        return err.response;
    }
}