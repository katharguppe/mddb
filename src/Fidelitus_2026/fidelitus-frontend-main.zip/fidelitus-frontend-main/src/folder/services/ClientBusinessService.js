import { get, post, put, deleteRequest } from "../helpers/apihelpers";

/* ===============================
   CREATE CLIENT
================================ */
export const createClientBusiness = (data) => {
  return post("/api/client-business/create", data);
};

/* ===============================
   GET MY CLIENTS (NORMAL USER)
================================ */
export const getMyClientBusiness = () => {
  return get("/api/client-business/my");
};

/* ===============================
   GET SINGLE CLIENT
================================ */
export const getClientBusinessById = (id) => {
  return get(`/api/client-business/get/${id}`);
};

/* ===============================
   UPDATE CLIENT
================================ */
export const updateClientBusiness = (id, data) => {
  return put(`/api/client-business/update/${id}`, data);
};

/* ===============================
   DELETE CLIENT
================================ */
export const deleteClientBusiness = (id) => {
  return deleteRequest(`/api/client-business/delete/${id}`);
};

/* ===============================
   FILTER (MD / ADMIN / HOD)
================================ */
export const filterClientBusiness = (params = {}) => {
  const query = new URLSearchParams(params).toString();
  return get(`/api/client-business/filter?${query}`);
};
